% education/init.pl — UnifyWeaver environment for education notebooks
%
% Thin shim that routes to the correct initializer depending on
% whether we're running in swipl-wasm (VFS) or native SWI-Prolog.
%
% Notebooks consult this via ['../init'].
%
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)

:- dynamic user:file_search_path/2.
:- dynamic user:unifyweaver_root/1.

education_init :-
    (   current_prolog_flag(arch, Arch),
        sub_atom(Arch, _, _, _, wasm)
    ->  % WASM: prelude.pl has hardcoded VFS paths
        (   current_predicate(uw_prelude:uw_version/1)
        ->  true                          % already loaded
        ;   consult('/user/prelude.pl')
        ),
        % Set working directory so relative paths in notebooks resolve correctly
        % (e.g., '../output/parent.sh' → '/user/education/output/parent.sh')
        working_directory(_, '/user/education/notebooks')
    ;   % Native: delegate to the main project init.pl (one level up)
        prolog_load_context(directory, Here),
        atom_concat(Here, '/../init', MainInit),
        consult(MainInit)
    ).

:- initialization(education_init, now).
