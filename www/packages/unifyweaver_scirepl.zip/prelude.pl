%% prelude.pl — UnifyWeaver environment for SciREPL (swipl-wasm)
%%
%% This file initializes the UnifyWeaver module system inside the
%% browser-based SWI-Prolog WASM kernel. It sets up file_search_path/2
%% entries so that use_module(unifyweaver(...)) calls resolve correctly
%% against the virtual filesystem.
%%
%% Auto-loaded by SciREPL when a UnifyWeaver package is imported.

:- module(uw_prelude, [
    uw_version/1,
    uw_root/1,
    show/1,
    show_all/1
]).

:- dynamic user:file_search_path/2.
:- dynamic user:unifyweaver_root/1.

%% uw_version(-Version)
%  Current UnifyWeaver version string.
uw_version('0.5.0-wasm').

%% uw_root(-Root)
%  The VFS root where UnifyWeaver files are mounted.
uw_root('/user').

%% Initialize search paths for the VFS layout.
%%
%% VFS structure (set up by PackageLoader):
%%   /user/src/unifyweaver/core/...
%%   /user/src/unifyweaver/targets/...
%%   /user/src/unifyweaver/bindings/...
%%   /user/examples/...
%%   /user/education/...
%%   /user/init.pl
%%   /user/prelude.pl

:- (   user:file_search_path(unifyweaver, _)
   ->  true
   ;   assertz(user:file_search_path(unifyweaver, '/user/src/unifyweaver'))
   ).

:- (   user:file_search_path(uw_core, _)
   ->  true
   ;   assertz(user:file_search_path(uw_core, '/user/src/unifyweaver/core'))
   ).

:- (   user:file_search_path(uw_targets, _)
   ->  true
   ;   assertz(user:file_search_path(uw_targets, '/user/src/unifyweaver/targets'))
   ).

:- (   user:file_search_path(uw_bindings, _)
   ->  true
   ;   assertz(user:file_search_path(uw_bindings, '/user/src/unifyweaver/bindings'))
   ).

:- (   user:file_search_path(uw_sources, _)
   ->  true
   ;   assertz(user:file_search_path(uw_sources, '/user/src/unifyweaver/sources'))
   ).

:- (   user:file_search_path(uw_glue, _)
   ->  true
   ;   assertz(user:file_search_path(uw_glue, '/user/src/unifyweaver/glue'))
   ).

:- (   user:file_search_path(uw_examples, _)
   ->  true
   ;   assertz(user:file_search_path(uw_examples, '/user/examples'))
   ).

:- (   user:file_search_path(uw_education, _)
   ->  true
   ;   assertz(user:file_search_path(uw_education, '/user/education'))
   ).

%% show(+Term)
%  Pretty-print a term to stdout.
show(X) :- print(X), nl.

%% show_all(+List)
%  Pretty-print each element of a list.
show_all([]).
show_all([H|T]) :- show(H), show_all(T).

%% between/3 polyfill (if not already available)
:- if(\+ current_predicate(between/3)).
between(Low, High, Low) :- Low =< High.
between(Low, High, X) :- Low < High, Low1 is Low + 1, between(Low1, High, X).
:- endif.
