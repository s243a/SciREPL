:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2026 John William Creighton (@s243a)
%
% wam_clojure_target.pl - WAM-to-Clojure hybrid target
%
% First implementation slice:
%   - emits a Clojure project scaffold for WAM-backed predicates
%   - uses one shared instruction table for cross-predicate calls
%   - pre-resolves label-based control-flow instructions at load time
%
% This is intentionally narrower than the mature Haskell/Rust targets.
% The goal of this slice is to establish the project/runtime/codegen
% shape so later work can focus on runtime parity and kernel lowering.

:- module(wam_clojure_target, [
    compile_wam_predicate_to_clojure/4,  % +Pred/Arity, +WamCode, +Options, -ClojureCode
    write_wam_clojure_project/3,         % +Predicates, +Options, +ProjectDir
    write_wam_clojurescript_files/3,     % +Predicates, +Options, +OutDir (runtime.cljs + core.cljs)
    clojure_foreign_predicate/3,         % +Pred, +Arity, +Options
    prepare_wam_clojure_lmdb_runtime_support/2, % +ProjectDir, +Options
    clojure_lmdb_reader_open_expr/3,     % +PathLiteral, +Options, -Expr
    clojure_lmdb_cache_log_snippet/3     % +Context, +Options, -Snippet
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module(library(filesex), [make_directory_path/1, directory_file_path/3]).
% library(process) is absent in swipl-wasm; only the LMDB runtime path uses it.
% Load best-effort so this module still loads in the browser (Scittle/SciREPL);
% process_create/3 throws existence_error at call time there, which is fine since
% the browser transpile path never invokes it.
:- catch(use_module(library(process), [process_create/3, process_wait/2]), _, true).
:- use_module('../core/template_system', [render_template/3]).
:- use_module('../targets/wam_target', [compile_predicate_to_wam/3]).
:- use_module('../targets/wam_clojure_lowered_emitter', [
    wam_clojure_lowerable/3,
    lower_predicate_to_clojure/4,
    clojure_lowered_func_name/2
]).
:- use_module('../targets/clojurescript_target', [clojurescript_interop_rewrite/2]).

%% read_whole_file(+Path, -String)
%  Read a file into a string using only core builtins (open/read_string) — avoids
%  library(readutil), which is absent in swipl-wasm.
read_whole_file(Path, String) :-
    setup_call_cleanup(open(Path, read, S),
                       read_string(S, _, String),
                       close(S)).

%% write_wam_clojurescript_files(+Predicates, +Options, +OutDir)
%  Transpile predicates to ClojureScript that runs under Scittle/SCI (browser) or
%  nbb. Generates the JVM WAM-Clojure project, then rewrites the JVM host interop
%  (Integer/parseInt, Math/rint, (long ...), catch Exception, ...) into JS interop
%  via the ClojureScript target's rewriter, writing OutDir/runtime.cljs and
%  OutDir/core.cljs. The runtime's format/Character/Pattern usage is already
%  portable in the template. core's CLI -main (edn-based) is dropped — the browser
%  drives predicates directly via invoke-predicate. The two namespaces cross-
%  require (SCI resolves a require of a namespace defined by a prior eval).
write_wam_clojurescript_files(Predicates, Options, OutDir) :-
    option(namespace(BaseNamespace), Options, 'generated.wam'),
    make_directory_path(OutDir),
    directory_file_path(OutDir, '.wamclj_tmp', TmpDir),
    write_wam_clojure_project(Predicates, Options, TmpDir),
    atomic_list_concat(NsParts, '.', BaseNamespace),
    atomic_list_concat(NsParts, '/', NsPath),
    format(atom(RuntimeClj), "~w/src/~w/runtime.clj", [TmpDir, NsPath]),
    format(atom(CoreClj),    "~w/src/~w/core.clj",    [TmpDir, NsPath]),
    % runtime.cljs
    read_whole_file(RuntimeClj, RuntimeSrc),
    clojurescript_interop_rewrite(RuntimeSrc, RuntimeCljs),
    format(atom(RuntimeOut), "~w/runtime.cljs", [OutDir]),
    write_text_file(RuntimeOut, RuntimeCljs),
    % core.cljs (drop CLI -main + its edn require — JVM/CLI only)
    read_whole_file(CoreClj, CoreSrc0),
    wamcljs_strip_main(CoreSrc0, CoreSrc1),
    wamcljs_replace(CoreSrc1, "[clojure.edn :as edn]", "", CoreSrc2),
    clojurescript_interop_rewrite(CoreSrc2, CoreCljs),
    format(atom(CoreOut), "~w/core.cljs", [OutDir]),
    write_text_file(CoreOut, CoreCljs).

wamcljs_strip_main(In, Out) :-
    ( sub_string(In, B, _, _, "(defn -main")
    ->  sub_string(In, 0, B, _, Out)
    ;   Out = In ).

wamcljs_replace(In, From, To, Out) :-
    ( sub_string(In, _, _, _, From)
    ->  atomic_list_concat(Parts, From, In),
        atomic_list_concat(Parts, To, Out)
    ;   Out = In ).

write_text_file(Path, Text) :-
    setup_call_cleanup(open(Path, write, S), write(S, Text), close(S)).

%% write_wam_clojure_project(+Predicates, +Options, +ProjectDir)
%  Generate a minimal hybrid/WAM Clojure project with:
%  - deps.edn
%  - runtime namespace containing instruction resolution helpers
%  - core namespace containing shared code/labels and predicate wrappers
write_wam_clojure_project(Predicates, Options, ProjectDir) :-
    clojure_wam_compile_options(Options, CompileOptions),
    option(namespace(BaseNamespace), Options, 'generated.wam'),
    option(module_name(ModuleName), Options, 'wam-clojure-generated'),
    atom_concat(BaseNamespace, '.runtime', RuntimeNamespace),
    atom_concat(BaseNamespace, '.core', CoreNamespace),
    get_time(TimeStamp),
    format_time(string(Date), "%Y-%m-%d %H:%M:%S", TimeStamp),
    make_directory_path(ProjectDir),
    write_deps_edn(ModuleName, CoreNamespace, ProjectDir),
    write_project_clj(ModuleName, CoreNamespace, ProjectDir),
    write_runtime_namespace(RuntimeNamespace, Date, ProjectDir),
    maybe_prepare_wam_clojure_lmdb_runtime_support(ProjectDir, Options),
    compile_predicates_for_project(Predicates, CompileOptions, CoreNamespace, RuntimeNamespace, CoreCode),
    write_namespace_file(ProjectDir, CoreNamespace, CoreCode),
    format(user_error, '[WAM-Clojure] Generated project at: ~w~n', [ProjectDir]).

clojure_wam_compile_options(Options, Options) :-
    option(inline_bagof_setof(_), Options),
    !.
clojure_wam_compile_options(Options, [inline_bagof_setof(true)|Options]).

write_deps_edn(ModuleName, CoreNamespace, ProjectDir) :-
    read_template_file('templates/targets/clojure_wam/deps.edn.mustache', Template),
    render_template(Template,
                    [module_name=ModuleName, core_namespace=CoreNamespace],
                    Content),
    directory_file_path(ProjectDir, 'deps.edn', DepsPath),
    write_file(DepsPath, Content).

write_project_clj(ModuleName, CoreNamespace, ProjectDir) :-
    read_template_file('templates/targets/clojure_wam/project.clj.mustache', Template),
    render_template(Template,
                    [module_name=ModuleName, core_namespace=CoreNamespace],
                    Content),
    directory_file_path(ProjectDir, 'project.clj', ProjectPath),
    write_file(ProjectPath, Content).

write_runtime_namespace(RuntimeNamespace, Date, ProjectDir) :-
    read_template_file('templates/targets/clojure_wam/runtime.clj.mustache', Template),
    render_template(Template,
                    [runtime_namespace=RuntimeNamespace, date=Date],
                    RuntimeCode),
    write_namespace_file(ProjectDir, RuntimeNamespace, RuntimeCode).

compile_predicates_for_project([], _, CoreNamespace, RuntimeNamespace, Code) :-
    format(atom(Code),
';; Generated by UnifyWeaver Clojure WAM Target
;; Namespace: ~w

(ns ~w
  (:require [clojure.edn :as edn]
            [~w :as runtime]))

(def compile-time-atom-seeds [])
(def compile-time-functor-seeds [])
(def atom-intern-context
  (runtime/build-intern-context compile-time-atom-seeds compile-time-functor-seeds))
(def atom-intern-table (:atom-intern atom-intern-context))
(def atom-deintern-table (:atom-deintern atom-intern-context))
(def functor-arity-table (:functor-arity atom-intern-context))

(def shared-wam-code-raw [])
(def shared-wam-labels {})
(def shared-wam-code
  (runtime/resolve-instructions shared-wam-code-raw shared-wam-labels atom-intern-context))
(def foreign-handlers {})

(def predicate-dispatch {})

(defn invoke-predicate [_pred-key _args]
  false)

(defn invoke-batch [cases]
  (mapv (fn [case]
          (invoke-predicate (:pred case) (:args case)))
        cases))

(defn -main [& _args]
  (if (= "--batch" (first _args))
    (doseq [result (invoke-batch (edn/read-string (slurp *in*)))]
      (println result))
    (println false)))
', [CoreNamespace, CoreNamespace, RuntimeNamespace]).
compile_predicates_for_project(Predicates, Options, CoreNamespace, RuntimeNamespace, Code) :-
    collect_wam_entries(Predicates, Options, 0,
                        PredicateBodies, RawEntries, LabelEntries, DispatchEntries,
                        AtomSeedEntries0, FunctorSeedEntries0),
    sort(AtomSeedEntries0, AtomSeedEntries),
    sort(FunctorSeedEntries0, FunctorSeedEntries),
    emit_clojure_string_vector(AtomSeedEntries, AtomSeedsCode),
    emit_clojure_string_vector(FunctorSeedEntries, FunctorSeedsCode),
    clojure_foreign_handlers_code(Options, ForeignHandlersCode),
    atomic_list_concat(RawEntries, '\n  ', RawBody0),
    atomic_list_concat(LabelEntries, '\n  ', LabelBody0),
    atomic_list_concat(PredicateBodies, '\n\n', WrapperCode),
    atomic_list_concat(DispatchEntries, '\n  ', DispatchBody0),
    (RawBody0 == "" -> RawBody = "" ; format(atom(RawBody), '  ~w', [RawBody0])),
    (LabelBody0 == "" -> LabelBody = "" ; format(atom(LabelBody), '  ~w', [LabelBody0])),
    (DispatchBody0 == "" -> DispatchBody = "" ; format(atom(DispatchBody), '  ~w', [DispatchBody0])),
    format(atom(Code),
';; Generated by UnifyWeaver Clojure WAM Target
;; Namespace: ~w

(ns ~w
  (:require [clojure.edn :as edn]
            [~w :as runtime]))

(def compile-time-atom-seeds ~w)
(def compile-time-functor-seeds ~w)
(def atom-intern-context
  (runtime/build-intern-context compile-time-atom-seeds compile-time-functor-seeds))
(def atom-intern-table (:atom-intern atom-intern-context))
(def atom-deintern-table (:atom-deintern atom-intern-context))
(def functor-arity-table (:functor-arity atom-intern-context))

(def shared-wam-code-raw [
~w
])

(def shared-wam-labels {
~w
})

(def shared-wam-code
  (runtime/resolve-instructions shared-wam-code-raw shared-wam-labels atom-intern-context))

(def foreign-handlers {
~w
})

~w

(def predicate-dispatch {
~w
})

(defn invoke-predicate [pred-key args]
  (if-let [f (get predicate-dispatch pred-key)]
    (boolean (apply f args))
    false))

(defn invoke-batch [cases]
  (mapv (fn [case]
          (invoke-predicate (:pred case) (:args case)))
        cases))

(defn -main [& args]
  (if (= "--batch" (first args))
    (doseq [result (invoke-batch (edn/read-string (slurp *in*)))]
      (println result))
    (let [[pred-key & pred-args] args]
      (println (invoke-predicate pred-key (mapv edn/read-string pred-args))))))

', [CoreNamespace, CoreNamespace, RuntimeNamespace,
    AtomSeedsCode, FunctorSeedsCode,
    RawBody, LabelBody, ForeignHandlersCode, WrapperCode, DispatchBody]).

collect_wam_entries([], _, _, [], [], [], [], [], []).
collect_wam_entries([PredIndicator|Rest], Options, PC,
                    [PredicateCode|RestWrappers], AllInstrs, AllLabels, [DispatchEntry|RestDispatch],
                    AllAtomSeeds, AllFunctorSeeds) :-
    predicate_indicator_parts(PredIndicator, _Module, Pred, Arity),
    format(atom(PredKey), '~w/~w', [Pred, Arity]),
    (   clojure_foreign_predicate(Pred, Arity, Options)
    ->  clojure_foreign_stub_data(Pred, Arity, PC, GoLiterals, LabelPairs, NextPC),
        compile_wam_predicate_to_clojure_shared(Pred/Arity, PC, PredicateCode),
        predicate_clojure_name(Pred, DispatchName),
        LocalAtomSeeds = [PredKey],
        LocalFunctorSeeds = []
    ;   wam_target:compile_predicate_to_wam(PredIndicator, Options, WamCode),
        wam_code_to_clojure_intern_seeds(WamCode, CodeAtomSeeds, CodeFunctorSeeds),
        (   wam_clojure_lowerable(Pred/Arity, WamCode, _Reason)
        ->  lower_predicate_to_clojure(Pred/Arity, WamCode, Options, LoweredCode),
            compile_wam_predicate_to_clojure_lowered(Pred/Arity, PC, WrapperCode),
            atomics_to_string([LoweredCode, "\n", WrapperCode], PredicateCode0),
            atom_string(PredicateCode, PredicateCode0),
            wam_code_to_clojure_data(WamCode, PC, GoLiterals, LabelPairs, NextPC),
            predicate_clojure_name(Pred, DispatchName)
        ;   wam_code_to_clojure_data(WamCode, PC, GoLiterals, LabelPairs, NextPC),
            compile_wam_predicate_to_clojure_shared(Pred/Arity, PC, PredicateCode),
            predicate_clojure_name(Pred, DispatchName)
        ),
        LocalAtomSeeds = [PredKey|CodeAtomSeeds],
        LocalFunctorSeeds = CodeFunctorSeeds
    ),
    maplist([Lit, Entry]>>format(atom(Entry), '~w', [Lit]), GoLiterals, InstrEntries),
    maplist([Label-Idx, Entry]>>format(atom(Entry), '~w ~w', [Label, Idx]), LabelPairs, LabelRows),
    format(atom(DispatchEntry), '"~w/~w" ~w', [Pred, Arity, DispatchName]),
    collect_wam_entries(Rest, Options, NextPC,
                        RestWrappers, RestInstrs, RestLabels, RestDispatch,
                        RestAtomSeeds, RestFunctorSeeds),
    append(InstrEntries, RestInstrs, AllInstrs),
    append(LabelRows, RestLabels, AllLabels),
    append(LocalAtomSeeds, RestAtomSeeds, AllAtomSeeds),
    append(LocalFunctorSeeds, RestFunctorSeeds, AllFunctorSeeds).

%% clojure_foreign_predicate(+Pred, +Arity, +Options) is semidet.
%  True when a predicate should be represented by a Clojure WAM
%  call-foreign stub instead of compiling its normal WAM body.
%
%  This first Clojure pass intentionally supports explicit controls only:
%  - foreign_predicates([p/n, ...]) opts predicates into foreign stubs.
%  - foreign_lowering(false) disables foreign stubs.
%  - no_kernels(true) disables foreign stubs for benchmark parity.
clojure_foreign_predicate(Pred, Arity, Options) :-
    \+ option(no_kernels(true), Options),
    \+ option(foreign_lowering(false), Options),
    clojure_foreign_relation_selected(Pred/Arity, Options).

clojure_foreign_relation_selected(Pred/Arity, Options) :-
    option(foreign_predicates(ForeignPreds), Options, []),
    member(Pred/Arity, ForeignPreds).
clojure_foreign_relation_selected(Pred/Arity, Options) :-
    option(clojure_lmdb_foreign_relations(Relations), Options, []),
    member(Pred/Arity-_, Relations).

clojure_foreign_stub_data(Pred, Arity, PC, Literals, LabelPairs, NextPC) :-
    format(atom(PredKey), '~w/~w', [Pred, Arity]),
    clj_string_literal(PredKey, PredKeyLit),
    clj_string_literal(Pred, PredLit),
    format(atom(CallLit), '{:op :call-foreign :pred ~w :arity ~w}', [PredLit, Arity]),
    Literals = [CallLit, '{:op :proceed}'],
    LabelPairs = [PredKeyLit-PC],
    NextPC is PC + 2.

clojure_foreign_handlers_code(Options, Code) :-
    option(clojure_foreign_handlers(ExplicitHandlers), Options, []),
    clojure_lmdb_foreign_handlers(Options, LmdbHandlers),
    append(LmdbHandlers, ExplicitHandlers, Handlers),
    maplist(clojure_foreign_handler_entry, Handlers, Entries),
    atomic_list_concat(Entries, '\n  ', Body),
    (Body == "" -> Code = "" ; format(atom(Code), '  ~w', [Body])).

clojure_lmdb_foreign_handlers(Options, Handlers) :-
    option(clojure_lmdb_foreign_relations(Relations), Options, []),
    maplist(clojure_lmdb_foreign_handler(Options), Relations, Handlers).

clojure_lmdb_foreign_handler(Options, Pred/Arity-ArtifactPath, handler(Pred/Arity, HandlerCode)) :-
    clojure_lmdb_foreign_handler_code(Pred/Arity, ArtifactPath, Options, HandlerCode).

clojure_lmdb_foreign_handler_code(category_parent/2, ArtifactPath, Options, HandlerCode) :-
    clojure_lmdb_path_literal(ArtifactPath, PathLiteral),
    clojure_lmdb_reader_open_expr(PathLiteral, Options, ReaderOpenExpr),
    clojure_lmdb_cache_log_snippet('category_parent/2', Options, LogSnippet),
    format(string(HandlerCode),
           "(let [reader-delay (delay ~w)] (fn [args] (let [child (nth args 0) parent (nth args 1) rows (.lookupArg1 ^generated.lmdb.LmdbArtifactReader @reader-delay child) result (boolean (some (fn [^generated.lmdb.LmdbRow row] (= parent (.value row))) rows))] (do ~w result))))",
           [ReaderOpenExpr, LogSnippet]).
clojure_lmdb_foreign_handler_code(category_ancestor/4, ArtifactPath, Options, HandlerCode) :-
    clojure_lmdb_path_literal(ArtifactPath, PathLiteral),
    clojure_lmdb_reader_open_expr(PathLiteral, Options, ReaderOpenExpr),
    clojure_lmdb_cache_log_snippet('category_ancestor/4', Options, LogSnippet),
    resolve_clojure_lmdb_ancestor_max_depth(Options, MaxDepth),
    format(string(HandlerCode),
           "(let [reader-delay (delay ~w) max-depth ~w term-list-values (fn term-list-values [term] (if (and (map? term) (= \"[|]/2\" (:functor term))) (cons (first (:args term)) (term-list-values (second (:args term)))) [])) parent-values (fn [category] (mapv (fn [^generated.lmdb.LmdbRow row] (.value row)) (.lookupArg1 ^generated.lmdb.LmdbArtifactReader @reader-delay category))) ancestor-hops (fn ancestor-hops [category target visited] (let [parents (parent-values category)] (vec (concat (for [parent parents :when (and (not (contains? visited parent)) (or (map? target) (= parent target)))] [parent 1]) (when (< (count visited) max-depth) (apply concat (for [mid parents :when (not (contains? visited mid)) [ancestor hops] (ancestor-hops mid target (conj visited mid))] [[ancestor (inc hops)]])))))))] (fn [args] (let [category (nth args 0) target (nth args 1) visited (set (term-list-values (nth args 3))) solutions (for [[ancestor hops] (ancestor-hops category target visited)] {:bindings {2 ancestor 3 hops}})] (do ~w {:solutions (vec solutions)}))))",
           [ReaderOpenExpr, MaxDepth, LogSnippet]).
clojure_lmdb_foreign_handler_code(Pred/Arity, _ArtifactPath, _Options, _HandlerCode) :-
    throw(error(unsupported_clojure_lmdb_foreign_relation(Pred/Arity), _)).

%% resolve_clojure_lmdb_ancestor_max_depth(+Options, -MaxDepth) is det.
%
%  Same instrumentation-bug class as the Haskell `resolve_max_depth/2`
%  (PR #1721) — without this resolver the LMDB ancestor handler used
%  a hardcoded 10 as fallback, silently overriding any user-asserted
%  `user:max_depth/1`. Priority:
%    1. Options list: clojure_lmdb_ancestor_max_depth(N)
%    2. user:max_depth/1 fact (asserted by the workload)
%    3. Default: 10 (matches the prior hardcoded value)
resolve_clojure_lmdb_ancestor_max_depth(Options, MaxDepth) :-
    (   option(clojure_lmdb_ancestor_max_depth(M), Options),
        integer(M), M >= 1
    ->  MaxDepth = M
    ;   current_predicate(user:max_depth/1),
        user:max_depth(M),
        integer(M), M >= 1
    ->  MaxDepth = M
    ;   MaxDepth = 10
    ).

clojure_foreign_handler_entry(handler(Pred/Arity, HandlerCode), Entry) :- !,
    clojure_foreign_handler_entry(Pred/Arity-HandlerCode, Entry).
clojure_foreign_handler_entry(Pred/Arity-HandlerCode, Entry) :-
    format(atom(PredKey), '~w/~w', [Pred, Arity]),
    clj_string_literal(PredKey, PredKeyLit),
    clojure_handler_code_text(HandlerCode, HandlerText),
    format(atom(Entry), '~w ~s', [PredKeyLit, HandlerText]).

maybe_prepare_wam_clojure_lmdb_runtime_support(ProjectDir, Options) :-
    clojure_lmdb_runtime_needed(Options),
    !,
    prepare_wam_clojure_lmdb_runtime_support(ProjectDir, Options).
maybe_prepare_wam_clojure_lmdb_runtime_support(_, _).

clojure_lmdb_runtime_needed(Options) :-
    option(clojure_lmdb_runtime_support(true), Options),
    !.
clojure_lmdb_runtime_needed(Options) :-
    option(clojure_lmdb_foreign_relations(Relations), Options, []),
    Relations \= [].

prepare_wam_clojure_lmdb_runtime_support(ProjectDir, _Options) :-
    absolute_file_name(ProjectDir, AbsoluteProjectDir),
    directory_file_path(AbsoluteProjectDir, 'classes', ClassesDir),
    directory_file_path(AbsoluteProjectDir, 'lib', LibDir),
    make_directory_path(ClassesDir),
    make_directory_path(LibDir),
    clojure_lmdb_helper_java_sources(JavaSources),
    atomic_list_concat(JavaSources, ' ', SourceArgs),
    format(atom(JavacCmd),
           'javac -d "~w" ~w',
           [ClassesDir, SourceArgs]),
    run_shell_command_or_throw(AbsoluteProjectDir, JavacCmd, javac_lmdb_helper_failed),
    format(atom(JarCmd),
           'jar --create --file "~w/lmdb-artifact-reader.jar" -C "~w" generated/lmdb',
           [LibDir, ClassesDir]),
    run_shell_command_or_throw(AbsoluteProjectDir, JarCmd, jar_lmdb_helper_failed),
    repo_relative_path('examples/scala_lmdb_jni_probe/native/lmdb_artifact_jni.c', NativeSource),
    format(atom(GccCmd),
           'JAVAC_REAL=$(readlink -f "$(command -v javac)") && JAVA_HOME_DIR=$(CDPATH= cd -- "$(dirname "$JAVAC_REAL")/.." && pwd) && cat "~w" | gcc -x c -shared -fPIC -include stddef.h -I"$JAVA_HOME_DIR/include" -I"$JAVA_HOME_DIR/include/linux" -I/data/data/com.termux/files/usr/include -L/data/data/com.termux/files/usr/lib -o "~w/liblmdb_artifact_jni.so" - -llmdb',
           [NativeSource, LibDir]),
    run_shell_command_or_throw(AbsoluteProjectDir, GccCmd, gcc_lmdb_helper_failed).

clojure_lmdb_reader_open_expr(PathLiteral, Options, Expr) :-
    option(clojure_lmdb_cache_policy(CachePolicy), Options, none),
    clojure_lmdb_reader_open_expr_for_policy(PathLiteral, CachePolicy, Expr).

clojure_lmdb_cache_log_snippet(_Context, Options, "nil") :-
    \+ option(clojure_lmdb_cache_debug(true), Options),
    !.
clojure_lmdb_cache_log_snippet(Context, _Options, Snippet) :-
    format(string(Snippet),
           "(binding [*out* *err*] (println (str \"lmdb_cache_stats ~w \" (pr-str (.cacheStats ^generated.lmdb.LmdbArtifactReader @reader-delay)))))",
           [Context]).

clojure_lmdb_reader_open_expr_for_policy(PathLiteral, memoize, Expr) :-
    format(string(Expr),
           "(generated.lmdb.LmdbArtifactReader/openMemoized (java.nio.file.Paths/get ~w (make-array String 0)))",
           [PathLiteral]).
clojure_lmdb_reader_open_expr_for_policy(PathLiteral, shared, Expr) :-
    format(string(Expr),
           "(generated.lmdb.LmdbArtifactReader/openSharedCached (java.nio.file.Paths/get ~w (make-array String 0)))",
           [PathLiteral]).
clojure_lmdb_reader_open_expr_for_policy(PathLiteral, two_level, Expr) :-
    format(string(Expr),
           "(generated.lmdb.LmdbArtifactReader/openTwoLevel (java.nio.file.Paths/get ~w (make-array String 0)))",
           [PathLiteral]).
clojure_lmdb_reader_open_expr_for_policy(PathLiteral, none, Expr) :-
    format(string(Expr),
           "(generated.lmdb.LmdbArtifactReader/open (java.nio.file.Paths/get ~w (make-array String 0)))",
           [PathLiteral]).

clojure_lmdb_path_literal(ArtifactPath, PathLiteral) :-
    string(ArtifactPath),
    !,
    clj_string_literal(ArtifactPath, PathLiteral).
clojure_lmdb_path_literal(ArtifactPath, PathLiteral) :-
    atom(ArtifactPath),
    !,
    clj_string_literal(ArtifactPath, PathLiteral).
clojure_lmdb_path_literal(path_literal(PathLiteral), PathLiteral).

clojure_handler_code_text(HandlerCode, HandlerCode) :-
    string(HandlerCode), !.
clojure_handler_code_text(HandlerCode, HandlerText) :-
    atom(HandlerCode),
    atom_string(HandlerCode, HandlerText).

compile_wam_predicate_to_clojure(PredIndicator, WamCode, _Options, ClojureCode) :-
    predicate_indicator_parts(PredIndicator, _Module, Pred, Arity),
    wam_code_to_clojure_data(WamCode, 0, RawEntries, LabelPairs, _),
    wam_code_to_clojure_intern_seeds(WamCode, AtomSeedEntries0, FunctorSeedEntries0),
    format(atom(PredKey), '~w/~w', [Pred, Arity]),
    sort([PredKey|AtomSeedEntries0], AtomSeedEntries),
    sort(FunctorSeedEntries0, FunctorSeedEntries),
    emit_clojure_string_vector(AtomSeedEntries, AtomSeedsCode),
    emit_clojure_string_vector(FunctorSeedEntries, FunctorSeedsCode),
    atomic_list_concat(RawEntries, '\n  ', RawBody0),
    atomic_list_concat(LabelPairs, '\n  ', LabelBody0),
    (RawBody0 == "" -> RawBody = "" ; format(atom(RawBody), '  ~w', [RawBody0])),
    (LabelBody0 == "" -> LabelBody = "" ; format(atom(LabelBody), '  ~w', [LabelBody0])),
    compile_wam_predicate_to_clojure_shared(Pred/Arity, 0, WrapperCode),
    format(atom(ClojureCode),
'(def compile-time-atom-seeds ~w)
(def compile-time-functor-seeds ~w)
(def atom-intern-context
  (runtime/build-intern-context compile-time-atom-seeds compile-time-functor-seeds))
(def atom-intern-table (:atom-intern atom-intern-context))
(def atom-deintern-table (:atom-deintern atom-intern-context))
(def functor-arity-table (:functor-arity atom-intern-context))

(def shared-wam-code-raw [
~w
])

(def shared-wam-labels {
~w
})

(def shared-wam-code
  (runtime/resolve-instructions shared-wam-code-raw shared-wam-labels atom-intern-context))

(def foreign-handlers {})

~w
', [AtomSeedsCode, FunctorSeedsCode, RawBody, LabelBody, WrapperCode]).

compile_wam_predicate_to_clojure_shared(Pred/Arity, StartPC, Code) :-
    predicate_clojure_name(Pred, CljName),
    build_clojure_wam_arg_list(Arity, ArgList),
    build_clojure_wam_reg_map(Arity, RegMap),
    format(atom(Code),
'(def ~w-start-pc ~w)

(defn ~w [~w]
  (runtime/run-wam-predicate shared-wam-code shared-wam-labels ~w-start-pc ~w foreign-handlers atom-intern-context))
', [CljName, StartPC, CljName, ArgList, CljName, RegMap]).

compile_wam_predicate_to_clojure_lowered(Pred/Arity, StartPC, Code) :-
    predicate_clojure_name(Pred, CljName),
    clojure_lowered_func_name(Pred/Arity, LoweredName),
    build_clojure_wam_arg_list(Arity, ArgList),
    build_clojure_wam_reg_map(Arity, RegMap),
    format(atom(Code),
'(def ~w-start-pc ~w)

(defn ~w [~w]
  (runtime/run-wam
    (~w
      (runtime/new-state shared-wam-code shared-wam-labels ~w-start-pc ~w foreign-handlers atom-intern-context))))
', [CljName, StartPC, CljName, ArgList, LoweredName, CljName, RegMap]).

wam_code_to_clojure_data(WamCode, BasePC, Entries, LabelPairs, NextPC) :-
    atom_string(WamCode, WamStr),
    split_string(WamStr, "\n", "", Lines),
    wam_lines_to_clojure_data(Lines, BasePC, Entries, LabelPairs, NextPC).

wam_code_to_clojure_intern_seeds(WamCode, AtomSeeds, FunctorSeeds) :-
    atom_string(WamCode, WamStr),
    split_string(WamStr, "\n", "", Lines),
    wam_lines_intern_seeds(Lines, AtomSeeds, FunctorSeeds).

wam_lines_intern_seeds([], [], []).
wam_lines_intern_seeds([Line|Rest], AtomSeeds, FunctorSeeds) :-
    normalize_space(string(Trimmed), Line),
    (   Trimmed == ""
    ->  wam_lines_intern_seeds(Rest, AtomSeeds, FunctorSeeds)
    ;   sub_string(Trimmed, _, 1, 0, ":")
    ->  wam_lines_intern_seeds(Rest, AtomSeeds, FunctorSeeds)
    ;   split_string(Trimmed, " ", "", [Op|ArgParts]),
        atomic_list_concat(ArgParts, ' ', ArgText0),
        normalize_space(string(ArgText), ArgText0),
        (   Op == "switch_on_constant"
        ->  switch_case_atom_values(ArgText, LocalAtomSeeds),
            LocalFunctorSeeds = []
        ;   wam_args(ArgText, Args),
            wam_op_intern_seeds(Op, Args, LocalAtomSeeds, LocalFunctorSeeds)
        ),
        wam_lines_intern_seeds(Rest, RestAtomSeeds, RestFunctorSeeds),
        append(LocalAtomSeeds, RestAtomSeeds, AtomSeeds),
        append(LocalFunctorSeeds, RestFunctorSeeds, FunctorSeeds)
    ).

switch_case_atom_values(CasesText, AtomSeeds) :-
    split_string(CasesText, " ", " ", RawCases),
    findall(AtomText,
            ( member(RawCase, RawCases),
              normalize_space(string(Case), RawCase),
              split_string(Case, ":", "", [Const|_]),
              wam_atom_token_text(Const, AtomText)
            ),
            AtomSeeds).

wam_atom_token_text("''", "") :- !.
wam_atom_token_text(Token, AtomText) :-
    clj_unquote_wam_atom_token(Token, AtomText).

wam_atom_token_literal(Token, Literal) :-
    wam_unquoted_number_token(Token, Num),
    !,
    format(atom(Literal), '~w', [Num]).
wam_atom_token_literal(Token, Literal) :-
    wam_atom_token_text(Token, AtomText),
    clj_string_literal(AtomText, Literal).

wam_unquoted_number_token(Token, Num) :-
    (   number(Token)
    ->  Num = Token
    ;   (   string(Token) -> S = Token ; atom_string(Token, S) ),
        \+ sub_string(S, 0, 1, _, "'"),
        catch(number_string(Num, S), _, fail)
    ).

wam_op_intern_seeds("get_constant", [Const, _], [AtomText], []) :- wam_atom_token_text(Const, AtomText).
wam_op_intern_seeds("put_constant", [Const, _], [AtomText], []) :- wam_atom_token_text(Const, AtomText).
wam_op_intern_seeds("set_constant", [Const], [AtomText], []) :- wam_atom_token_text(Const, AtomText).
wam_op_intern_seeds("unify_constant", [Const], [AtomText], []) :- wam_atom_token_text(Const, AtomText).
wam_op_intern_seeds("put_structure", [Functor, _], [Functor], [Functor]).
wam_op_intern_seeds("get_structure", [Functor, _], [Functor], [Functor]).
wam_op_intern_seeds("put_list", [_], ["[|]/2"], ["[|]/2"]).
wam_op_intern_seeds("get_list", [_], ["[|]/2"], ["[|]/2"]).
wam_op_intern_seeds(_, _, [], []).

wam_lines_to_clojure_data([], PC, [], [], PC).
wam_lines_to_clojure_data([Line|Rest], PC0, Entries, Labels, NextPC) :-
    normalize_space(string(Trimmed), Line),
    (   Trimmed == ""
    ->  wam_lines_to_clojure_data(Rest, PC0, Entries, Labels, NextPC)
    ;   sub_string(Trimmed, _, 1, 0, ":")
    ->  sub_string(Trimmed, 0, _, 1, Label),
        clj_string_literal(Label, LabelLit),
        wam_lines_to_clojure_data(Rest, PC0, Entries, RestLabels, NextPC),
        Labels = [LabelLit-PC0|RestLabels]
    ;   wam_line_to_clojure_literal(Trimmed, Literal),
        PC1 is PC0 + 1,
        wam_lines_to_clojure_data(Rest, PC1, RestEntries, Labels, NextPC),
        Entries = [Literal|RestEntries]
    ).

wam_line_to_clojure_literal(Line, Literal) :-
    split_string(Line, " ", "", [Op|ArgParts]),
    atomic_list_concat(ArgParts, ' ', ArgText0),
    normalize_space(string(ArgText), ArgText0),
    (   Op == "switch_on_constant"
    ->  Args = [ArgText]
    ;   wam_args(ArgText, Args)
    ),
    wam_op_to_clojure_literal(Op, Args, Line, Literal).

wam_args("", []) :- !.
wam_args(ArgText, Args) :-
    split_string(ArgText, ",", " ", RawArgs),
    maplist(normalize_space_string, RawArgs, Args).

normalize_space_string(In, Out) :-
    normalize_space(string(Out), In).

wam_op_to_clojure_literal("call", [Pred, ArityStr], _, Literal) :-
    clj_string_literal(Pred, PredLit),
    number_string(Arity, ArityStr),
    format(atom(Literal), '{:op :call :pred ~w :arity ~w}', [PredLit, Arity]).
wam_op_to_clojure_literal("call_foreign", [Pred, ArityStr], _, Literal) :-
    clj_string_literal(Pred, PredLit),
    number_string(Arity, ArityStr),
    format(atom(Literal), '{:op :call-foreign :pred ~w :arity ~w}', [PredLit, Arity]).
wam_op_to_clojure_literal("execute", [Pred], _, Literal) :-
    clj_string_literal(Pred, PredLit),
    format(atom(Literal), '{:op :execute :pred ~w}', [PredLit]).
wam_op_to_clojure_literal("try_me_else", [Label], _, Literal) :-
    clj_string_literal(Label, LabelLit),
    format(atom(Literal), '{:op :try-me-else :label ~w}', [LabelLit]).
wam_op_to_clojure_literal("retry_me_else", [Label], _, Literal) :-
    clj_string_literal(Label, LabelLit),
    format(atom(Literal), '{:op :retry-me-else :label ~w}', [LabelLit]).
wam_op_to_clojure_literal("trust_me", [], _, '{:op :trust-me}').
wam_op_to_clojure_literal("jump", [Label], _, Literal) :-
    clj_string_literal(Label, LabelLit),
    format(atom(Literal), '{:op :jump :label ~w}', [LabelLit]).
wam_op_to_clojure_literal("proceed", [], _, '{:op :proceed}').
wam_op_to_clojure_literal("allocate", [], _, '{:op :allocate}').
wam_op_to_clojure_literal("deallocate", [], _, '{:op :deallocate}').
wam_op_to_clojure_literal("get_constant", [Const, Reg], _, Literal) :-
    wam_atom_token_literal(Const, ConstLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :get-constant :constant ~w :reg ~w}', [ConstLit, RegLit]).
wam_op_to_clojure_literal("put_constant", [Const, Reg], _, Literal) :-
    wam_atom_token_literal(Const, ConstLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :put-constant :constant ~w :reg ~w}', [ConstLit, RegLit]).
wam_op_to_clojure_literal("get_variable", [Var, Reg], _, Literal) :-
    clj_string_literal(Var, VarLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :get-variable :var ~w :reg ~w}', [VarLit, RegLit]).
wam_op_to_clojure_literal("get_value", [Var, Reg], _, Literal) :-
    clj_string_literal(Var, VarLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :get-value :var ~w :reg ~w}', [VarLit, RegLit]).
wam_op_to_clojure_literal("put_variable", [Var, Reg], _, Literal) :-
    clj_string_literal(Var, VarLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :put-variable :var ~w :reg ~w}', [VarLit, RegLit]).
wam_op_to_clojure_literal("put_value", [Var, Reg], _, Literal) :-
    clj_string_literal(Var, VarLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :put-value :var ~w :reg ~w}', [VarLit, RegLit]).
wam_op_to_clojure_literal("put_structure", [Functor, Reg], _, Literal) :-
    clj_string_literal(Functor, FunctorLit),
    clj_string_literal(Reg, RegLit),
    functor_arity_string(Functor, FunctorArity),
    format(atom(Literal), '{:op :put-structure :functor ~w :reg ~w :arity ~w}', [FunctorLit, RegLit, FunctorArity]).
wam_op_to_clojure_literal("get_structure", [Functor, Reg], _, Literal) :-
    clj_string_literal(Functor, FunctorLit),
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :get-structure :functor ~w :reg ~w}', [FunctorLit, RegLit]).
wam_op_to_clojure_literal("put_list", [Reg], _, Literal) :-
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :put-list :reg ~w}', [RegLit]).
wam_op_to_clojure_literal("get_list", [Reg], _, Literal) :-
    clj_string_literal(Reg, RegLit),
    format(atom(Literal), '{:op :get-list :reg ~w}', [RegLit]).
wam_op_to_clojure_literal("set_variable", [Var], _, Literal) :-
    clj_string_literal(Var, VarLit),
    format(atom(Literal), '{:op :set-variable :var ~w}', [VarLit]).
wam_op_to_clojure_literal("set_value", [Var], _, Literal) :-
    clj_string_literal(Var, VarLit),
    format(atom(Literal), '{:op :set-value :var ~w}', [VarLit]).
wam_op_to_clojure_literal("set_constant", [Const], _, Literal) :-
    wam_atom_token_literal(Const, ConstLit),
    format(atom(Literal), '{:op :set-constant :constant ~w}', [ConstLit]).
wam_op_to_clojure_literal("unify_variable", [Var], _, Literal) :-
    clj_string_literal(Var, VarLit),
    format(atom(Literal), '{:op :unify-variable :var ~w}', [VarLit]).
wam_op_to_clojure_literal("unify_value", [Var], _, Literal) :-
    clj_string_literal(Var, VarLit),
    format(atom(Literal), '{:op :unify-value :var ~w}', [VarLit]).
wam_op_to_clojure_literal("unify_constant", [Const], _, Literal) :-
    wam_atom_token_literal(Const, ConstLit),
    format(atom(Literal), '{:op :unify-constant :constant ~w}', [ConstLit]).
wam_op_to_clojure_literal("switch_on_constant", [CasesText], _, Literal) :-
    parse_switch_cases(CasesText, CaseEntries),
    atomic_list_concat(CaseEntries, ' ', CasesBody),
    format(atom(Literal), '{:op :switch-on-constant :cases [~w]}', [CasesBody]).
wam_op_to_clojure_literal("builtin_call", [Pred, ArityStr], _, Literal) :-
    clj_string_literal(Pred, PredLit),
    number_string(Arity, ArityStr),
    format(atom(Literal), '{:op :builtin-call :pred ~w :arity ~w}', [PredLit, Arity]).
wam_op_to_clojure_literal("begin_aggregate", [Kind, TemplateReg, BagReg], _, Literal) :-
    clj_string_literal(Kind, KindLit),
    clj_string_literal(TemplateReg, TemplateLit),
    clj_string_literal(BagReg, BagLit),
    format(atom(Literal), '{:op :begin-aggregate :kind ~w :template ~w :bag ~w :witnesses []}',
           [KindLit, TemplateLit, BagLit]).
wam_op_to_clojure_literal("begin_aggregate", [Kind, TemplateReg, BagReg, WitnessText], _, Literal) :-
    clj_string_literal(Kind, KindLit),
    clj_string_literal(TemplateReg, TemplateLit),
    clj_string_literal(BagReg, BagLit),
    aggregate_witness_vector_literal(WitnessText, WitnessLit),
    format(atom(Literal), '{:op :begin-aggregate :kind ~w :template ~w :bag ~w :witnesses ~w}',
           [KindLit, TemplateLit, BagLit, WitnessLit]).
wam_op_to_clojure_literal("end_aggregate", [TemplateReg], _, Literal) :-
    clj_string_literal(TemplateReg, TemplateLit),
    format(atom(Literal), '{:op :end-aggregate :template ~w}', [TemplateLit]).
wam_op_to_clojure_literal("cut_ite", [], _, '{:op :cut-ite}').
wam_op_to_clojure_literal(_Op, _Args, Line, Literal) :-
    clj_string_literal(Line, LineLit),
    format(atom(Literal), '{:op :raw :text ~w}', [LineLit]).

parse_switch_cases(CasesText, CaseEntries) :-
    split_string(CasesText, " ", " ", RawCases),
    maplist(parse_switch_case, RawCases, CaseEntries).

parse_switch_case(RawCase, Entry) :-
    normalize_space(string(Case), RawCase),
    (   split_string(Case, ":", "", [Const, Label])
    ->  wam_atom_token_literal(Const, ConstLit),
        clj_string_literal(Label, LabelLit),
        format(atom(Entry), '{:value ~w :label ~w}', [ConstLit, LabelLit])
    ;   clj_string_literal("malformed", ConstLit),
        clj_string_literal("malformed", LabelLit),
        format(atom(Entry), '{:value ~w :label ~w}', [ConstLit, LabelLit])
    ).

aggregate_witness_vector_literal(WitnessText, WitnessLit) :-
    clj_unquote_wam_atom_token(WitnessText, Unquoted),
    (   Unquoted == ""
    ->  Witnesses = []
    ;   split_string(Unquoted, ";", "", Witnesses)
    ),
    emit_clojure_string_vector(Witnesses, WitnessLit).

functor_arity_string(Functor, Arity) :-
    split_string(Functor, "/", "", [_Name, ArityStr]),
    number_string(Arity, ArityStr).

predicate_indicator_parts(Module:Pred/Arity, Module, Pred, Arity) :- !.
predicate_indicator_parts(Pred/Arity, user, Pred, Arity).

predicate_clojure_name(Pred, Name) :-
    atom_string(Pred, PredStr),
    atomic_list_concat(Parts, '_', PredStr),
    atomic_list_concat(Parts, '-', Name).

build_clojure_wam_arg_list(0, "") :- !.
build_clojure_wam_arg_list(Arity, ArgList) :-
    numlist(1, Arity, Indices),
    maplist([I, S]>>format(atom(S), 'a~w', [I]), Indices, Parts),
    atomic_list_concat(Parts, ' ', ArgList).

build_clojure_wam_reg_map(0, "{}") :- !.
build_clojure_wam_reg_map(Arity, RegMap) :-
    numlist(1, Arity, Indices),
    maplist([I, S]>>format(atom(S), '"A~w" a~w', [I, I]), Indices, Parts),
    atomic_list_concat(Parts, ', ', Body),
    format(atom(RegMap), '{~w}', [Body]).

emit_clojure_string_vector([], "[]") :- !.
emit_clojure_string_vector(Strings, Literal) :-
    maplist(clj_string_literal, Strings, Quoted),
    atomic_list_concat(Quoted, ' ', Body),
    format(atom(Literal), '[~w]', [Body]).

write_namespace_file(ProjectDir, Namespace, Content) :-
    namespace_relative_path(Namespace, RelativePath),
    directory_file_path(ProjectDir, 'src', SrcDir),
    directory_file_path(SrcDir, RelativePath, FullPath),
    file_directory_name(FullPath, ParentDir),
    make_directory_path(ParentDir),
    write_file(FullPath, Content).

namespace_relative_path(Namespace, RelativePath) :-
    atomic_list_concat(Parts, '.', Namespace),
    append(DirParts, [FileStem], Parts),
    atomic_list_concat(DirParts, '/', DirPath),
    format(atom(FileName), '~w.clj', [FileStem]),
    (   DirPath == ""
    ->  RelativePath = FileName
    ;   directory_file_path(DirPath, FileName, RelativePath)
    ).

read_template_file(Path, Content) :-
    (   template_abs_path(Path, Abs)
    ->  read_whole_file(Abs, Content)
    ;   format(atom(Content), '; Template not found: ~w', [Path])
    ).

%% template_abs_path(+RelPath, -AbsPath)
%  Resolve a 'templates/...' path. In tests/CLI the cwd is the UnifyWeaver root,
%  so the path resolves as-is. In swipl-wasm (SciREPL) the cwd is a notebook dir
%  but the package is mounted at /user/, so fall back to /user/<path>.
template_abs_path(Path, Path) :- exists_file(Path), !.
template_abs_path(Path, Abs) :- atom_concat('/user/', Path, Abs), exists_file(Abs), !.

write_file(Path, Content) :-
    open(Path, write, Stream),
    format(Stream, '~w', [Content]),
    close(Stream).

clojure_lmdb_helper_java_sources(JavaSources) :-
    maplist(clojure_lmdb_helper_java_source_path,
            [ 'LmdbRow.java',
              'LmdbCacheStats.java',
              'LmdbArtifactManifest.java',
              'LmdbArtifactStore.java',
              'LmdbLookupCache.java',
              'LmdbArtifactReader.java',
              'LmdbArtifactJNI.java'
            ],
            JavaSources).

clojure_lmdb_helper_java_source_path(FileName, QuotedPath) :-
    repo_relative_path('examples/scala_lmdb_jni_probe/src/main/java/generated/lmdb', JavaDir),
    directory_file_path(JavaDir, FileName, SourcePath),
    format(atom(QuotedPath), '"~w"', [SourcePath]).

repo_relative_path(RelativePath, AbsolutePath) :-
    source_file(wam_clojure_target:repo_relative_path(_, _), ThisFile),
    file_directory_name(ThisFile, ThisDir),
    directory_file_path(ThisDir, '..', Parent1),
    directory_file_path(Parent1, '..', Parent2),
    directory_file_path(Parent2, '..', RepoRoot),
    directory_file_path(RepoRoot, RelativePath, Joined),
    absolute_file_name(Joined, AbsolutePath).

run_shell_command_or_throw(Cwd, Command, ErrorFunctor) :-
    process_create(path(sh), ['-c', Command], [cwd(Cwd), process(PID)]),
    process_wait(PID, Status),
    (   Status == exit(0)
    ->  true
    ;   Error =.. [ErrorFunctor, Status, Command],
        throw(error(Error, _))
    ).

clj_string_literal(In, Literal) :-
    (   string(In) -> InStr0 = In ; atom_string(In, InStr0) ),
    escape_clj_string(InStr0, Escaped),
    format(atom(Literal), '"~w"', [Escaped]).

escape_clj_string(In, Out) :-
    string_codes(In, Codes),
    maplist(escape_clj_code, Codes, Parts),
    atomics_to_string(Parts, "", Out).

escape_clj_code(92, "\\\\") :- !.
escape_clj_code(34, "\\\"") :- !.
escape_clj_code(10, "\\n") :- !.
escape_clj_code(13, "\\r") :- !.
escape_clj_code(9, "\\t") :- !.
escape_clj_code(Code, Escaped) :-
    (   Code < 32
    ->  format(string(Escaped), '\\u~|~`0t~16r~4+', [Code])
    ;   char_code(Char, Code),
        string_chars(Escaped, [Char])
    ).

clj_unquote_wam_atom_token(Token, S) :-
    (   string(Token) -> S0 = Token ; atom_string(Token, S0) ),
    sub_string(S0, 0, 1, _, "'"),
    sub_string(S0, _, 1, 0, "'"),
    !,
    sub_string(S0, 1, _, 1, Inner),
    string_codes(Inner, Codes0),
    clj_unescape_wam_codes(Codes0, Codes),
    string_codes(S, Codes).
clj_unquote_wam_atom_token(Token, S) :-
    (   string(Token) -> S = Token ; atom_string(Token, S) ).

clj_unescape_wam_codes([], []).
clj_unescape_wam_codes([92, C|Rest], [C|More]) :- !,
    clj_unescape_wam_codes(Rest, More).
clj_unescape_wam_codes([C|Rest], [C|More]) :-
    clj_unescape_wam_codes(Rest, More).
