:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)
%
% wam_python_lowered_emitter.pl - WAM-to-Python Lowered Emitter
%
% Compiles deterministic (single-clause, no choice points) WAM predicates
% into direct Python functions instead of routing through the run_wam
% dispatch loop. This is the highest-impact optimisation — the Haskell
% equivalent reduced query time from 2518ms to ~193ms.
%
% Design modelled on wam_fsharp_lowered_emitter.pl (646 lines) and
% wam_elixir_lowered_emitter.pl (492 lines).
%
% Key design points:
%   - `call` instructions become direct Python function calls
%   - `execute` (tail position) becomes `return pred_foo_2(state)`
%   - `proceed` becomes `return True`
%   - `fail` becomes `return False`
%   - Predicates with choice points stay in interpreter mode
%   - Function names: pred_{functor}_{arity} (sanitised for Python)

:- module(wam_python_lowered_emitter, [
	emit_lowered_python/4,           % +FunctorArity, +Instrs, +Options, -Lines
	is_deterministic_pred_py/1,      % +Instrs
	python_func_name/2,              % +Functor/Arity, -PythonName
	parse_wam_text_py/2,             % +WamText, -Instrs
	parse_wam_text_py_labeled/2,     % +WamText, -Instrs (keeps label/1 markers)
	is_match_instr_py/1,             % +Instr
	is_ite_block_py/2,               % +Instrs, -Blocks
	emit_ite_block_py/5,             % +FuncName, +Blocks, +Indent, +Opts, -Lines
	py_structured_clause1/2,         % +WamCode, -StructuredInstrs (soft-cut ITE)
	py_multi_clause_1/2,             % +WamCode, -Clause1Instrs (T3 clause-1 slice)
	py_multi_clause_n/2,             % +WamCode, -Clauses (T4 per-clause slices)
	py_clause_func_name/3,           % +Functor/Arity, +K, -Name (T4 clause fn name)
	emit_multi_clause_n_python/4,    % +Functor/Arity, +Clauses, +Opts, -Lines (T4)
	emit_structured_python/4         % +FunctorArity, +Structured, +Opts, -Lines
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module('../targets/wam_text_parser', [wam_classify_constant_token/2]).
:- use_module(wam_ite_structurer, [structure_ite/2]).

% ============================================================================
% Deterministic predicate detection
% ============================================================================

%% is_deterministic_pred_py(+Instrs)
%  True if the instruction list has no choice point instructions.
is_deterministic_pred_py(Instrs) :-
	\+ has_choice_point_instr(Instrs).

has_choice_point_instr(Instrs) :-
	member(I, Instrs),
	choice_point_instr(I),
	!.

choice_point_instr(try_me_else(_)).
choice_point_instr(retry_me_else(_)).
choice_point_instr(trust_me).
choice_point_instr(try(_)).
choice_point_instr(retry(_)).
choice_point_instr(trust(_)).
choice_point_instr(call_indexed_atom_fact2(_)).

% ============================================================================
% Function name generation
% ============================================================================

%% python_func_name(+Functor/Arity, -PythonName)
%  Generate a valid Python function name from a Prolog functor/arity.
%  foo/2 -> 'pred_foo_2'
%  Sanitise: replace non-alphanumeric chars in functor with '_'
python_func_name(Functor/Arity, Name) :-
	atom_string(Functor, FStr),
	sanitize_python_ident(FStr, SanStr),
	format(atom(Name), 'pred_~w_~w', [SanStr, Arity]).

sanitize_python_ident(In, Out) :-
	string_codes(In, Codes),
	maplist(sanitize_code, Codes, OutCodes),
	string_codes(OutStr, OutCodes),
	atom_string(Out, OutStr).

sanitize_code(C, C) :-
	(   C >= 0'a, C =< 0'z -> true
	;   C >= 0'A, C =< 0'Z -> true
	;   C >= 0'0, C =< 0'9 -> true
	;   C =:= 0'_ -> true
	),
	!.
sanitize_code(_, 0'_).

constant_atom_py(C, Atom) :-
	(   atom(C)
	->  Atom = C
	;   string(C)
	->  atom_string(Atom, C)
	;   term_string(C, S),
	    atom_string(Atom, S)
	).

%% constant_number_py(+C, -Number) is semidet.
%
%  Succeeds only when C is a *bare* numeric token (no surrounding
%  single quotes) — quoted atoms whose textual form parses as a
%  number (`'5'`, `'-3.14'`) are atoms, not numbers. Discriminator
%  is the same one used by wam_text_parser:wam_classify_constant_token/2.
constant_number_py(C, Number) :-
	wam_classify_constant_token(C, Class),
	(   Class = integer(Number)
	;   Class = float(Number)
	).

constant_term_py(C, Term) :-
	wam_classify_constant_token(C, Class),
	(   Class = integer(N)
	->  format(string(Term), "Int(~w)", [N])
	;   Class = float(F)
	->  format(string(Term), "Float(~w)", [F])
	;   Class = atom(Name),
	    escape_py(Name, EC),
	    format(string(Term), "Atom(\"~w\")", [EC])
	).

constant_match_condition_py(C, VarExpr, Cond) :-
	wam_classify_constant_token(C, Class),
	(   Class = integer(N)
	->  format(string(Cond), 'isinstance(~w, Int) and ~w.n == ~w',
	        [VarExpr, VarExpr, N])
	;   Class = float(F)
	->  format(string(Cond), 'isinstance(~w, Float) and ~w.f == ~w',
	        [VarExpr, VarExpr, F])
	;   Class = atom(Name),
	    escape_py(Name, EC),
	    format(string(Cond), 'isinstance(~w, Atom) and ~w.name == "~w"',
	        [VarExpr, VarExpr, EC])
	).

% ============================================================================
% WAM text parsing (shared pattern with other emitters)
% ============================================================================

parse_wam_text_py(WamText, Instrs) :-
	atom_string(WamText, S),
	split_string(S, "\n", "", Lines),
	parse_lines_py(Lines, Instrs).

%% parse_wam_text_py_labeled(+WamText, -Instrs)
%  Like parse_wam_text_py/2 but keeps label(Name) markers (as strings, so
%  they unify with the string arguments of try_me_else / jump), so the
%  shared structurer can find the LElse / LCont boundaries of an
%  if-then-else block. Mirrors the Rust/Clojure/LLVM labeled parsers.
parse_wam_text_py_labeled(WamText, Instrs) :-
	atom_string(WamText, S),
	split_string(S, "\n", "", Lines),
	parse_lines_py_labeled(Lines, Instrs).

parse_lines_py_labeled([], []).
parse_lines_py_labeled([Line|Rest], Instrs) :-
	split_string(Line, " \t,", " \t,", Parts),
	delete(Parts, "", CleanParts),
	(   CleanParts == []
	->  parse_lines_py_labeled(Rest, Instrs)
	;   CleanParts = [First|_],
		(   sub_string(First, _, 1, 0, ":")
		->  sub_string(First, 0, _, 1, LabelStr),
			Instrs = [label(LabelStr)|More],
			parse_lines_py_labeled(Rest, More)
		;   instr_from_parts_py(CleanParts, Instr)
		->  Instrs = [Instr|More],
			parse_lines_py_labeled(Rest, More)
		;   parse_lines_py_labeled(Rest, Instrs)
		)
	).

% ============================================================================
% If-then-else / negation / once lowering (shared structurer)
%
% Predicates with a soft-cut block — ( Cond -> Then ; Else ), \+ Goal,
% once/1 — compile to try_me_else(LElse) <cond> cut_ite <then> jump(LCont) ;
% LElse: trust_me <else> ; LCont: <cont>. is_deterministic_pred_py/1
% rejects the internal try_me_else, so previously such predicates stayed in
% the interpreter (sound but not lowered). Folding clause 1 through
% wam_ite_structurer lets them lower to native Python if/else.
%
% Python derefs registers through the binding table, so — like the Rust
% emitter — undoing the trail before the else branch restores any partial
% bindings the condition made; no register snapshot is needed. The runtime
% only trails a binding when state.b >= 0 (a choice point is live), and a
% lowered ITE pushes no choice point, so the emitted code sets state.b to
% the trail mark for the duration of the condition to force trailing, then
% restores it.
% ============================================================================

%% py_structured_clause1(+WamCode, -Structured) is semidet.
%  Parse the label-preserving stream, take clause 1, and fold its ITE
%  blocks. Fails for genuine multi-clause predicates (their try_me_else is
%  the first instruction, or the structurer cannot match a clean block).
py_structured_clause1(WamCode, Structured) :-
	(   is_list(WamCode) -> LInstrs = WamCode
	;   parse_wam_text_py_labeled(WamCode, LInstrs)
	),
	\+ ( LInstrs = [try_me_else(_)|_] ),    % not predicate-level multi-clause
	take_to_proceed_py(LInstrs, C1L),
	structure_ite(C1L, Structured),
	member(ite(_,_,_), Structured),         % there is an ITE to lower
	\+ member(try_me_else(_), Structured),   % nothing unstructured survived
	\+ member(retry_me_else(_), Structured),
	\+ member(trust_me, Structured),
	forall(member(I, Structured), py_supported_structured(I)).

%% py_multi_clause_1(+WamCode, -Clause1Instrs) is semidet.
%  T3 — multi-clause clause-1 fast path. True when the predicate is genuinely
%  multi-clause (parse_wam_text_py has dropped any switch_on_* indexing prefix,
%  so the parsed stream opens with the predicate-level try_me_else, and clauses
%  2+ begin with retry_me_else / trust_me) AND clause 1 is a clean
%  deterministic, fully-supported body. Clause1Instrs is the clause-1 slice
%  (try_me_else stripped, up to and including its proceed/fail), ready for
%  emit_lowered_python. Clauses 2+ are left to the bytecode interpreter,
%  reached by backtracking when the lowered clause 1 fails — see the registrar
%  in wam_python_target.pl, which keeps the leading try_me_else (it pushes the
%  choice point onto clause 2) and the clause-2+ bytecode, replacing only
%  clause 1's body with a call_lowered to this function.
%
%  Single-clause soft-cut ITE predicates also open with try_me_else, but they
%  are claimed by py_structured_clause1 first; the cut_ite/jump guards here
%  decline them defensively.
py_multi_clause_1(WamCode, Clause1Instrs) :-
	( is_list(WamCode) -> Instrs0 = WamCode ; parse_wam_text_py(WamCode, Instrs0) ),
	once(append(_Prefix, [try_me_else(_)|Rest], Instrs0)),
	( member(retry_me_else(_), Rest) ; member(trust_me, Rest) ),
	take_to_proceed_py(Rest, Clause1Instrs),
	\+ has_choice_point_instr(Clause1Instrs),   % clause 1 itself is deterministic
	\+ member(cut_ite, Clause1Instrs),           % not an ITE clause-1 (py_structured handles those)
	\+ member(jump(_), Clause1Instrs),
	forall(member(I, Clause1Instrs), py_supported_structured(I)).

%% take_to_proceed_py(+Instrs, -Clause1) — up to and including the first
%  proceed / fail terminator (label/1 markers pass through to the
%  structurer, which drops them).
take_to_proceed_py([], []).
take_to_proceed_py([proceed|_], [proceed]) :- !.
take_to_proceed_py([fail|_], [fail]) :- !.
take_to_proceed_py([I|Rest], [I|Out]) :- take_to_proceed_py(Rest, Out).

%% py_multi_clause_n(+WamCode, -Clauses) is semidet.
%  T4 — multi-clause, ALL clauses lowered. True when the predicate is genuinely
%  multi-clause (parsed stream opens with the predicate-level try_me_else after
%  any dropped switch_on_* prefix) and EVERY clause is a clean deterministic,
%  fully-supported body ending in proceed/fail. Clauses is the ordered list of
%  per-clause instruction slices (each choice-point marker stripped, up to and
%  including its terminator), one lowered pred_*_cK function per clause.
%
%  Python's runtime is a genuine backtracking WAM (choice points + fail()), so
%  unlike the imperative first-solution T4 targets (lua/rust/…) we must NOT
%  collapse the clauses into a commit-to-first-match function — that would lose
%  intra-query backtracking into later clauses and diverge from the bytecode
%  interpreter. The registrar in wam_python_target.pl therefore keeps the
%  try_me_else / retry_me_else / trust_me dispatch scaffold (which drives the
%  runtime's proven choice-point machinery) and replaces only each clause BODY
%  with a call_lowered to that clause's native function. So every clause body is
%  native, the per-predicate clause dispatch stays in the (tiny) bytecode
%  scaffold, and backtracking is preserved by construction — a hybrid of native
%  bodies over the interpreter's CP dispatch. (A future full-native dispatch
%  path could be slotted in front of this hybrid for shapes that admit it.)
py_multi_clause_n(WamCode, Clauses) :-
	( is_list(WamCode) -> Instrs0 = WamCode ; parse_wam_text_py(WamCode, Instrs0) ),
	once(append(_Prefix, [try_me_else(M)|Rest], Instrs0)),
	py_split_clauses_n([try_me_else(M)|Rest], Clauses),
	Clauses = [_, _ | _],                       % at least two clauses
	forall(member(Cl, Clauses),
	       ( \+ has_choice_point_instr(Cl),     % each clause body is deterministic
	         \+ member(cut_ite, Cl),            % not an ITE clause (defensive)
	         \+ member(jump(_), Cl),
	         last(Cl, Last), ( Last == proceed ; Last == fail ),
	         forall(member(I, Cl), py_supported_structured(I)) )).

%% py_split_clauses_n(+Instrs, -Clauses)
%  Split a predicate-level try/retry/trust chain into per-clause bodies: drop
%  each leading choice-point marker, take the following instructions up to and
%  including the terminator (proceed/fail) as one clause, and recurse. A leading
%  non-marker prefix (e.g. a switch the parser did not drop) is skipped.
py_split_clauses_n([], []).
py_split_clauses_n([M|Rest], [Clause|More]) :-
	clause_start_marker_py(M), !,
	py_take_clause(Rest, Clause, After),
	py_split_clauses_n(After, More).
py_split_clauses_n([_|Rest], Clauses) :-
	py_split_clauses_n(Rest, Clauses).

clause_start_marker_py(try_me_else(_)).
clause_start_marker_py(retry_me_else(_)).
clause_start_marker_py(trust_me).

%% py_take_clause(+Instrs, -Clause, -After) — take up to and including the first
%  proceed/fail; After is what follows (the next clause's marker onward).
py_take_clause([proceed|Rest], [proceed], Rest) :- !.
py_take_clause([fail|Rest], [fail], Rest) :- !.
py_take_clause([I|Rest], [I|Cs], After) :- py_take_clause(Rest, Cs, After).

%% py_clause_func_name(+Functor/Arity, +K, -Name)
%  Per-clause lowered function name: pred_<sanitised>_<arity>_c<K>.
py_clause_func_name(FunctorArity, K, Name) :-
	python_func_name(FunctorArity, Base),
	format(atom(Name), '~w_c~w', [Base, K]).

%% emit_multi_clause_n_python(+Functor/Arity, +Clauses, +Options, -Lines)
%  Emit one lowered `def pred_*_cK(state)` per clause, concatenated. Each clause
%  body is rendered exactly like a deterministic single-clause lowering
%  (proceed -> return True, a failed head match -> return False), so the
%  call_lowered scaffold can try it and fall through / backtrack accordingly.
emit_multi_clause_n_python(FunctorArity, Clauses, _Options, Lines) :-
	FunctorArity = Functor/Arity,
	atom_string(Functor, FStr),
	emit_clause_defs_py(Clauses, FunctorArity, FStr, Arity, 1, DefList),
	atomic_list_concat(DefList, '\n\n', Lines).

emit_clause_defs_py([], _, _, _, _, []).
emit_clause_defs_py([Cl|Rest], FunctorArity, FStr, Arity, K, [Def|More]) :-
	py_clause_func_name(FunctorArity, K, FuncName),
	maplist(emit_instr_py, Cl, InstrLines),
	atomic_list_concat(InstrLines, '\n', Body),
	format(string(Def),
'def ~w(state):
    """Lowered clause ~w of ~w/~w (T4)"""
~w', [FuncName, K, FStr, Arity, Body]),
	K1 is K + 1,
	emit_clause_defs_py(Rest, FunctorArity, FStr, Arity, K1, More).


%% py_supported_structured(+StructuredInstr) — recurse through ite/3; each
%  leaf must be an instruction emit_instr_py/2 can render.
py_supported_structured(ite(C, T, E)) :- !,
	forall(member(I, C), py_supported_structured(I)),
	forall(member(I, T), py_supported_structured(I)),
	forall(member(I, E), py_supported_structured(I)).
py_supported_structured(I) :-
	catch(emit_instr_py(I, _), _, fail).

%% emit_structured_python(+Functor/Arity, +Structured, +Options, -Lines)
%  Render a structured (ITE-folded) clause 1 as a lowered Python function.
emit_structured_python(Functor/Arity, Structured, _Options, Lines) :-
	python_func_name(Functor/Arity, FuncName),
	atom_string(Functor, FStr),
	nb_setval(py_ite_ctr, 0),
	emit_struct_py(Structured, 4, BodyLines0),
	(   BodyLines0 == [] -> BodyLines = ["    return True"] ; BodyLines = BodyLines0 ),
	atomic_list_concat(BodyLines, '\n', Body),
	format(string(Lines),
'def ~w(state):
    """Lowered predicate: ~w/~w (if-then-else / negation / once)"""
~w', [FuncName, FStr, Arity, Body]).

fresh_py_ite(N) :-
	nb_getval(py_ite_ctr, N0), N is N0 + 1, nb_setval(py_ite_ctr, N).

%% emit_struct_py(+Items, +Indent, -Lines) — Lines is a list of Python
%  source lines at absolute indent Indent.
emit_struct_py([], _Indent, []).
emit_struct_py([Item|Rest], Indent, Lines) :-
	emit_struct_item_py(Item, Indent, ItemLines),
	emit_struct_py(Rest, Indent, RestLines),
	append(ItemLines, RestLines, Lines).

emit_struct_item_py(ite(Cond, Then, Else), Indent, Lines) :- !,
	fresh_py_ite(N),
	I1 is Indent + 4,
	indent_str(Indent, Pad),
	indent_str(I1, Pad1),
	emit_struct_py(Cond, I1, CondLines),
	emit_struct_py(Then, I1, ThenLines),
	emit_struct_py(Else, I1, ElseLines),
	format(string(LMark),  "~w_ite_mark~w = state.trail_len", [Pad, N]),
	format(string(LSave),  "~w_ite_savedb~w = state.b", [Pad, N]),
	format(string(LForce), "~wstate.b = _ite_mark~w", [Pad, N]),
	format(string(LDef),   "~wdef _ite_cond~w():", [Pad, N]),
	format(string(LCondT), "~wreturn True", [Pad1]),
	format(string(LIf),    "~wif _ite_cond~w():", [Pad, N]),
	format(string(LThenB), "~wstate.b = _ite_savedb~w", [Pad1, N]),
	format(string(LElse),  "~welse:", [Pad]),
	format(string(LElseB), "~wstate.b = _ite_savedb~w", [Pad1, N]),
	format(string(LUndo),  "~wundo_trail(state, _ite_mark~w)", [Pad1, N]),
	% then-branch body (may be empty -> the state.b restore is the body)
	append([LThenB], ThenLines, ThenBody),
	% else-branch body: restore b, roll back the condition's bindings, run else
	append([LElseB, LUndo], ElseLines, ElseBody),
	append([LMark, LSave, LForce, LDef | CondLines], [LCondT, LIf | ThenBody], Head0),
	append(Head0, [LElse | ElseBody], Lines).
emit_struct_item_py(Instr, Indent, Lines) :-
	emit_instr_py(Instr, Code0),
	reindent_py(Code0, Indent, Lines).

%% reindent_py(+Code, +Indent, -Lines) — split the 4-space-based Code from
%  emit_instr_py/2 into lines and shift each to absolute indent Indent.
reindent_py(Code, Indent, Lines) :-
	Extra is Indent - 4,
	indent_str(Extra, ExtraPad),
	split_string(Code, "\n", "", Raw),
	maplist(shift_line_py(ExtraPad), Raw, Lines).

shift_line_py(_ExtraPad, "", "") :- !.
shift_line_py(ExtraPad, Line, Out) :- string_concat(ExtraPad, Line, Out).

parse_lines_py([], []).
parse_lines_py([Line|Rest], Instrs) :-
	split_string(Line, " \t,", " \t,", Parts),
	delete(Parts, "", CleanParts),
	(   CleanParts == []
	->  parse_lines_py(Rest, Instrs)
	;   CleanParts = [First|_],
		(   sub_string(First, _, 1, 0, ":")
		->  % Label line — skip
			parse_lines_py(Rest, Instrs)
		;   instr_from_parts_py(CleanParts, Instr)
		->  Instrs = [Instr|RestInstrs],
			parse_lines_py(Rest, RestInstrs)
		;   % Unknown — skip
			parse_lines_py(Rest, Instrs)
		)
	).

% ============================================================================
% Instruction parsing (WAM text line → Prolog term)
% ============================================================================

instr_from_parts_py(["get_constant", C, Ai], get_constant(C, Ai)).
instr_from_parts_py(["get_variable", Xn, Ai], get_variable(Xn, Ai)).
instr_from_parts_py(["get_value", Xn, Ai], get_value(Xn, Ai)).
instr_from_parts_py(["get_structure", F, Ai], get_structure(F, Ai)).
instr_from_parts_py(["get_list", Ai], get_list(Ai)).
instr_from_parts_py(["get_nil", Ai], get_nil(Ai)).
instr_from_parts_py(["get_integer", N, Ai], get_integer(N, Ai)).
instr_from_parts_py(["get_float", F, Ai], get_float(F, Ai)).
instr_from_parts_py(["unify_variable", Xn], unify_variable(Xn)).
instr_from_parts_py(["unify_value", Xn], unify_value(Xn)).
instr_from_parts_py(["unify_constant", C], unify_constant(C)).
instr_from_parts_py(["unify_nil"], unify_nil).
instr_from_parts_py(["unify_void", N], unify_void(N)).
% set_* — write-mode structure args after put_structure/put_list. Previously
% dropped (no parse clause), which silently lost arithmetic/structure operands.
instr_from_parts_py(["set_variable", Xn], set_variable(Xn)).
instr_from_parts_py(["set_value", Xn], set_value(Xn)).
instr_from_parts_py(["set_local_value", Xn], set_local_value(Xn)).
instr_from_parts_py(["set_constant", C], set_constant(C)).
instr_from_parts_py(["set_integer", N], set_integer(N)).
instr_from_parts_py(["set_nil"], set_nil).
instr_from_parts_py(["set_void", N], set_void(N)).
instr_from_parts_py(["put_variable", Xn, Ai], put_variable(Xn, Ai)).
instr_from_parts_py(["put_value", Xn, Ai], put_value(Xn, Ai)).
instr_from_parts_py(["put_unsafe_value", Yn, Ai], put_unsafe_value(Yn, Ai)).
instr_from_parts_py(["put_constant", C, Ai], put_constant(C, Ai)).
instr_from_parts_py(["put_nil", Ai], put_nil(Ai)).
instr_from_parts_py(["put_integer", N, Ai], put_integer(N, Ai)).
instr_from_parts_py(["put_float", F, Ai], put_float(F, Ai)).
instr_from_parts_py(["put_structure", F, Ai], put_structure(F, Ai)).
instr_from_parts_py(["put_list", Ai], put_list(Ai)).
instr_from_parts_py(["call", P, N], call(P, N)).
instr_from_parts_py(["execute", P], execute(P)).
instr_from_parts_py(["proceed"], proceed).
instr_from_parts_py(["fail"], fail).
instr_from_parts_py(["halt"], halt).
instr_from_parts_py(["allocate"], allocate).
instr_from_parts_py(["deallocate"], deallocate).
instr_from_parts_py(["try_me_else", Label], try_me_else(Label)).
instr_from_parts_py(["retry_me_else", Label], retry_me_else(Label)).
instr_from_parts_py(["trust_me"], trust_me).
instr_from_parts_py(["try", Label], try(Label)).
instr_from_parts_py(["retry", Label], retry(Label)).
instr_from_parts_py(["trust", Label], trust(Label)).
instr_from_parts_py(["is", Target, Expr], is(Target, Expr)).
instr_from_parts_py(["builtin_call", Op, Ar], builtin_call(Op, Ar)).
instr_from_parts_py(["call_foreign", Pred, Ar], call_foreign(Pred, Ar)).
instr_from_parts_py(["call_indexed_atom_fact2", Pred], call_indexed_atom_fact2(Pred)).
instr_from_parts_py(["base_category_ancestor", CatReg, TargetReg, VisitedReg],
	base_category_ancestor(CatReg, TargetReg, VisitedReg)).
instr_from_parts_py(["base_category_ancestor_bind", CatReg, TargetReg, HopsReg, VisitedReg],
	base_category_ancestor_bind(CatReg, TargetReg, HopsReg, VisitedReg)).
instr_from_parts_py(["recurse_category_ancestor", MidReg, RootReg, ChildHopsReg, VisitedReg, Pred, Skip],
	recurse_category_ancestor(MidReg, RootReg, ChildHopsReg, VisitedReg, Pred, Skip)).
instr_from_parts_py(["return_add1", OutReg, InReg], return_add1(OutReg, InReg)).
instr_from_parts_py(["neck_cut"], neck_cut).
instr_from_parts_py(["get_level", Yn], get_level(Yn)).
instr_from_parts_py(["cut", Yn], cut(Yn)).
% Soft-cut commit and the then-branch's jump-to-continuation. Needed by the
% label-preserving parse + wam_ite_structurer so ( Cond -> Then ; Else ),
% \+ Goal and once/1 fold into ite(Cond,Then,Else). For ordinary
% (non-ITE) predicates these never appear, so adding them here is inert.
instr_from_parts_py(["cut_ite"], cut_ite).
instr_from_parts_py(["jump", L], jump(L)).

% ============================================================================
% ITE (if/then/else) block detection
% ============================================================================

%% is_match_instr_py(+Instr)
%  True if the instruction is a match/test instruction that can serve as
%  the head of an ITE branch (analogous to is_match_instr_fs/1 in the
%  F# lowered emitter).
is_match_instr_py(get_constant(_, _)).
is_match_instr_py(get_integer(_, _)).
is_match_instr_py(get_float(_, _)).
is_match_instr_py(get_nil(_)).
is_match_instr_py(get_structure(_, _)).
is_match_instr_py(get_list(_)).
is_match_instr_py(get_value(_, _)).
is_match_instr_py(switch_on_term(_, _, _, _)).
is_match_instr_py(switch_on_constant(_, _)).
is_match_instr_py(switch_on_structure(_, _)).

%% is_ite_block_py(+Instrs, -Blocks)
%  Detects if Instrs contains a multi-clause ITE pattern: a sequence of
%  [match_instrs..., proceed/execute] pairs that can be rendered as
%  if/elif/else chains.
%
%  Blocks = list of clause_block(MatchInstrs, BodyInstrs).
%  Requires at least 2 blocks to qualify as an ITE pattern.
is_ite_block_py(Instrs, Blocks) :-
	split_ite_clauses_py(Instrs, Blocks),
	length(Blocks, N),
	N >= 2.

%% split_ite_clauses_py(+Instrs, -Blocks)
%  Split a flat instruction list into clause_block(Match, Body) entries.
%  Each clause is: zero or more match instructions followed by a terminator
%  (proceed, execute(_), or fail).
split_ite_clauses_py([], []).
split_ite_clauses_py(Instrs, [clause_block(MatchInstrs, BodyInstrs)|Rest]) :-
	Instrs \= [],
	take_clause_py(Instrs, MatchInstrs, BodyInstrs, Remaining),
	split_ite_clauses_py(Remaining, Rest).

%% take_clause_py(+Instrs, -MatchInstrs, -BodyInstrs, -Remaining)
%  Extract one clause: match instructions up to (and including) the
%  first terminator instruction (proceed, execute/1, fail).
take_clause_py([proceed|Rest], [], [proceed], Rest) :- !.
take_clause_py([execute(P)|Rest], [], [execute(P)], Rest) :- !.
take_clause_py([fail|Rest], [], [fail], Rest) :- !.
take_clause_py([Instr|Rest], [Instr|MatchRest], BodyInstrs, Remaining) :-
	is_match_instr_py(Instr),
	take_clause_py(Rest, MatchRest, BodyInstrs, Remaining).
% Non-match, non-terminator instructions go into body
take_clause_py([Instr|Rest], [], [Instr|BodyRest], Remaining) :-
	\+ is_match_instr_py(Instr),
	Instr \= proceed,
	Instr \= fail,
	\+ (Instr = execute(_)),
	take_body_to_terminator_py(Rest, BodyRest, Remaining).

%% take_body_to_terminator_py(+Instrs, -BodyInstrs, -Remaining)
take_body_to_terminator_py([proceed|Rest], [proceed], Rest) :- !.
take_body_to_terminator_py([execute(P)|Rest], [execute(P)], Rest) :- !.
take_body_to_terminator_py([fail|Rest], [fail], Rest) :- !.
take_body_to_terminator_py([I|Rest], [I|BodyRest], Remaining) :-
	take_body_to_terminator_py(Rest, BodyRest, Remaining).
take_body_to_terminator_py([], [], []).

% ============================================================================
% ITE emission — if/elif/else Python code generation
% ============================================================================

%% emit_ite_block_py(+FuncName, +Blocks, +Indent, +Opts, -Lines)
%  Emits an if/elif/else chain for the detected ITE blocks.
%  Indent is an integer (number of spaces).
emit_ite_block_py(FuncName, Blocks, Indent, _Opts, Lines) :-
	emit_ite_branches_py(Blocks, FuncName, Indent, first, BranchLines),
	% Add else fallthrough
	indent_str(Indent, Pad),
	format(string(ElseLine), "~welse:~n~w    return False", [Pad, Pad]),
	append(BranchLines, [ElseLine], Lines).

%% emit_ite_branches_py(+Blocks, +FuncName, +Indent, +Position, -Lines)
%  Position is 'first' for the first block (emits 'if'),
%  or 'rest' for subsequent blocks (emits 'elif').
emit_ite_branches_py([], _, _, _, []).
emit_ite_branches_py([clause_block(MatchInstrs, BodyInstrs)|Rest], FuncName, Indent, Pos, Lines) :-
	indent_str(Indent, Pad),
	(   Pos = first -> Keyword = "if"
	;   Keyword = "elif"
	),
	% Generate the condition from match instructions
	match_instrs_to_condition_py(MatchInstrs, Condition),
	% Generate the body
	match_instrs_to_binding_py(MatchInstrs, Indent, BindingLines),
	body_instrs_to_code_py(BodyInstrs, Indent, BodyCodeLines),
	append(BindingLines, BodyCodeLines, InnerLines),
	format(string(BranchHeader), "~w~w ~w:", [Pad, Keyword, Condition]),
	(   InnerLines = []
	->  format(string(BranchBody), "~w    pass", [Pad]),
	    BranchAll = [BranchHeader, BranchBody]
	;   BranchAll = [BranchHeader|InnerLines]
	),
	emit_ite_branches_py(Rest, FuncName, Indent, rest, RestLines),
	append(BranchAll, RestLines, Lines).

%% match_instrs_to_condition_py(+MatchInstrs, -Condition)
%  Generate a Python condition expression from match instructions.
match_instrs_to_condition_py([], "True").
match_instrs_to_condition_py([Instr], Cond) :-
	single_match_condition_py(Instr, Cond).
match_instrs_to_condition_py([Instr|Rest], Cond) :-
	Rest \= [],
	single_match_condition_py(Instr, C1),
	match_instrs_to_condition_py(Rest, C2),
	format(string(Cond), "(~w) and (~w)", [C1, C2]).

%% single_match_condition_py(+Instr, -Condition)
%  Generate a Python condition for a single match instruction.
single_match_condition_py(get_constant(C, AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	format(string(VarExpr), "_a~w", [Ai]),
	constant_match_condition_py(C, VarExpr, Cond).
single_match_condition_py(get_integer(NStr, AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	format(string(Cond),
		'isinstance(_a~w, Var) or (isinstance(_a~w, Int) and _a~w.n == ~w)',
		[Ai, Ai, Ai, NStr]).
single_match_condition_py(get_float(FStr, AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	format(string(Cond),
		'isinstance(_a~w, Var) or (isinstance(_a~w, Float) and _a~w.f == ~w)',
		[Ai, Ai, Ai, FStr]).
single_match_condition_py(get_nil(AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	format(string(Cond),
		'isinstance(_a~w, Var) or (isinstance(_a~w, Atom) and _a~w.name == "[]")',
		[Ai, Ai, Ai]).
single_match_condition_py(get_structure(FStr, AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	runtime_functor_py(FStr, FuncName, Arity),
	format(string(Cond),
		'isinstance(_a~w, Var) or (isinstance(_a~w, Compound) and _a~w.functor == "~w" and len(_a~w.args) == ~w)',
		[Ai, Ai, Ai, FuncName, Ai, Arity]).
single_match_condition_py(get_list(AiStr), Cond) :-
	reg_int_py(AiStr, Ai),
	format(string(Cond),
		'isinstance(_a~w, Var) or (isinstance(_a~w, Compound) and _a~w.functor == ".")',
		[Ai, Ai, Ai]).
single_match_condition_py(get_value(XnStr, AiStr), Cond) :-
	reg_int_py(XnStr, Xn), reg_int_py(AiStr, Ai),
	format(string(Cond),
		'unify(deref(state.regs[~w], state), deref(state.regs[~w], state), state)',
		[Ai, Xn]).
% Default fallback for unknown match instructions
single_match_condition_py(_, "True").

%% match_instrs_to_binding_py(+MatchInstrs, +Indent, -Lines)
%  Generate Python binding code for variables encountered during matching.
match_instrs_to_binding_py([], _, []).
match_instrs_to_binding_py([Instr|Rest], Indent, Lines) :-
	single_match_binding_py(Instr, Indent, BindLines),
	match_instrs_to_binding_py(Rest, Indent, RestLines),
	append(BindLines, RestLines, Lines).

%% single_match_binding_py(+Instr, +Indent, -Lines)
single_match_binding_py(get_constant(C, AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	constant_term_py(C, Term),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, ~w, state)",
		[Pad, Ai, Ai, Term]),
	Lines = [DerefLine, BindLine].
single_match_binding_py(get_integer(NStr, AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, Int(~w), state)",
		[Pad, Ai, Ai, NStr]),
	Lines = [DerefLine, BindLine].
single_match_binding_py(get_float(FStr, AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, Float(~w), state)",
		[Pad, Ai, Ai, FStr]),
	Lines = [DerefLine, BindLine].
single_match_binding_py(get_nil(AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, Atom(\"[]\"), state)",
		[Pad, Ai, Ai]),
	Lines = [DerefLine, BindLine].
single_match_binding_py(get_structure(FStr, AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	runtime_functor_py(FStr, FuncName, Arity),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, Compound(\"~w\", [None]*~w), state)",
		[Pad, Ai, Ai, FuncName, Arity]),
	Lines = [DerefLine, BindLine].
single_match_binding_py(get_list(AiStr), Indent, Lines) :-
	reg_int_py(AiStr, Ai),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(DerefLine), "~w_a~w = deref(state.regs[~w], state)", [Pad, Ai, Ai]),
	format(string(BindLine), "~wif isinstance(_a~w, Var): bind(_a~w, Compound(\".\", [None, None]), state)",
		[Pad, Ai, Ai]),
	Lines = [DerefLine, BindLine].
% get_value — no binding needed beyond what's in the condition
single_match_binding_py(get_value(_, _), _, []).
% Default fallback
single_match_binding_py(_, _, []).

%% body_instrs_to_code_py(+BodyInstrs, +Indent, -Lines)
%  Emit the body instructions as Python code inside an ITE branch.
body_instrs_to_code_py([], _, []).
body_instrs_to_code_py([proceed], Indent, [Line]) :-
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(Line), "~wreturn True", [Pad]).
body_instrs_to_code_py([fail], Indent, [Line]) :-
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(Line), "~wreturn False", [Pad]).
body_instrs_to_code_py([execute(PStr)], Indent, [Line]) :-
	pred_to_func_name_py(PStr, FN),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	format(string(Line), "~wreturn ~w(state)", [Pad, FN]).
body_instrs_to_code_py([Instr|Rest], Indent, [Line|Lines]) :-
	Instr \= proceed,
	Instr \= fail,
	\+ (Instr = execute(_)),
	emit_instr_py(Instr, Code),
	Indent1 is Indent + 4,
	indent_str(Indent1, Pad),
	% Re-indent the emitted code to the ITE body level
	split_string(Code, "\n", "", CodeLines),
	reindent_lines(CodeLines, Pad, ReindentedStr),
	Line = ReindentedStr,
	body_instrs_to_code_py(Rest, Indent, Lines).

%% reindent_lines(+Lines, +Pad, -Result)
%  Strip leading whitespace from each line and prepend Pad.
reindent_lines([], _, "").
reindent_lines([L], Pad, Result) :-
	split_string(L, "", " \t", [Trimmed]),
	format(string(Result), "~w~w", [Pad, Trimmed]).
reindent_lines([L|Rest], Pad, Result) :-
	Rest \= [],
	split_string(L, "", " \t", [Trimmed]),
	reindent_lines(Rest, Pad, RestResult),
	format(string(Result), "~w~w\n~w", [Pad, Trimmed, RestResult]).

%% indent_str(+N, -Str)
%  Generate a string of N spaces.
indent_str(0, "") :- !.
indent_str(N, Str) :-
	N > 0,
	length(Codes, N),
	maplist(=(0' ), Codes),
	string_codes(Str, Codes).

% ============================================================================
% Main entry point
% ============================================================================

%% emit_lowered_python(+FunctorArity, +Instrs, +Options, -Lines)
%  Emits a single deterministic predicate as a Python function.
%  FunctorArity: Functor/Arity
%  Instrs: list of WAM instruction terms (parsed)
%  Options: option list
%  Lines: string containing the Python function definition
%
%  If the instructions form an ITE block (multi-clause pattern),
%  emit if/elif/else chains instead of instruction-by-instruction code.
emit_lowered_python(FunctorArity, Instrs, Options, Lines) :-
	is_list(Instrs),
	is_ite_block_py(Instrs, Blocks),
	!,
	python_func_name(FunctorArity, FuncName),
	FunctorArity = Functor/Arity,
	atom_string(Functor, FStr),
	emit_ite_block_py(FuncName, Blocks, 4, Options, BodyLines),
	atomic_list_concat(BodyLines, '\n', Body),
	format(string(Lines),
'def ~w(state):
    """Lowered predicate: ~w/~w (ITE)"""
~w', [FuncName, FStr, Arity, Body]).

emit_lowered_python(FunctorArity, Instrs, _Options, Lines) :-
	is_list(Instrs),
	python_func_name(FunctorArity, FuncName),
	FunctorArity = Functor/Arity,
	atom_string(Functor, FStr),
	maplist(emit_instr_py, Instrs, InstrLines),
	atomic_list_concat(InstrLines, '\n', Body),
	format(string(Lines),
'def ~w(state):
    """Lowered predicate: ~w/~w"""
~w', [FuncName, FStr, Arity, Body]).

%% emit_lowered_python(+FunctorArity, +WamCode, +Options, -Lines)
%  Alternate entry: takes raw WAM text, parses, then emits.
emit_lowered_python(FunctorArity, WamCode, Options, Lines) :-
	atom(WamCode),
	parse_wam_text_py(WamCode, Instrs),
	emit_lowered_python(FunctorArity, Instrs, Options, Lines).

% ============================================================================
% Instruction lowering — one clause per WAM opcode
% ============================================================================

%% emit_instr_py(+Instr, -PythonLine)
%  Emit a single lowered instruction as Python code.

% --- Head unification (get_*) ---

emit_instr_py(get_constant(C, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	constant_term_py(C, Term),
	format(string(VarExpr), "_a~w", [Ai]),
	constant_match_condition_py(C, VarExpr, Cond),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var): bind(_a~w, ~w, state)
    elif not (~w): return False',
		[Ai, Ai, Ai, Ai, Term, Cond]).

emit_instr_py(get_variable(XnStr, AiStr), Code) :-
	reg_int_py(XnStr, Xn), reg_int_py(AiStr, Ai),
	format(string(Code),
'    state.regs[~w] = state.regs[~w]', [Xn, Ai]).

emit_instr_py(get_value(XnStr, AiStr), Code) :-
	reg_int_py(XnStr, Xn), reg_int_py(AiStr, Ai),
	format(string(Code),
'    if not unify(deref(state.regs[~w], state), deref(state.regs[~w], state), state): return False',
		[Ai, Xn]).

emit_instr_py(get_nil(AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var): bind(_a~w, Atom("[]"), state)
    elif not (isinstance(_a~w, Atom) and _a~w.name == "[]"): return False',
		[Ai, Ai, Ai, Ai, Ai, Ai]).

emit_instr_py(get_integer(NStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var): bind(_a~w, Int(~w), state)
    elif not (isinstance(_a~w, Int) and _a~w.n == ~w): return False',
		[Ai, Ai, Ai, Ai, NStr, Ai, Ai, NStr]).

emit_instr_py(get_float(FStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var): bind(_a~w, Float(~w), state)
    elif not (isinstance(_a~w, Float) and _a~w.f == ~w): return False',
		[Ai, Ai, Ai, Ai, FStr, Ai, Ai, FStr]).

emit_instr_py(get_structure(FStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	runtime_functor_py(FStr, RTName, Arity),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var):
        _c = Compound("~w", [None]*~w)
        _addr = heap_put(state, _c)
        bind(_a~w, Ref(_addr), state)
        state.s = _addr
        _begin_write_ctx(state, _c)
    elif isinstance(_a~w, Ref):
        _h = state.heap[_a~w.addr]
        if isinstance(_h, Compound) and _h.functor == "~w" and len(_h.args) == ~w:
            state.s = _a~w.addr
            _begin_read_ctx(state, _h)
        else: return False
    elif isinstance(_a~w, Compound) and _a~w.functor == "~w" and len(_a~w.args) == ~w:
        _begin_read_ctx(state, _a~w)
    else: return False',
		[Ai, Ai, Ai, RTName, Arity, Ai,
		 Ai, Ai, RTName, Arity, Ai,
		 Ai, Ai, RTName, Ai, Arity, Ai]).

emit_instr_py(get_list(AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    _a~w = deref(state.regs[~w], state)
    if isinstance(_a~w, Var):
        _c = Compound(".", [None, None])
        _addr = heap_put(state, _c)
        bind(_a~w, Ref(_addr), state)
        state.s = _addr
        _begin_write_ctx(state, _c)
    elif isinstance(_a~w, Ref):
        _h = state.heap[_a~w.addr]
        if isinstance(_h, Compound) and _is_cons_functor(_h.functor) and len(_h.args) == 2:
            state.s = _a~w.addr
            _begin_read_ctx(state, _h)
        else: return False
    elif isinstance(_a~w, Compound) and _is_cons_functor(_a~w.functor) and len(_a~w.args) == 2:
        _begin_read_ctx(state, _a~w)
    else: return False',
		[Ai, Ai, Ai, Ai, Ai, Ai, Ai, Ai, Ai, Ai, Ai]).

% --- Body construction (put_*) ---

emit_instr_py(put_variable(XnStr, AiStr), Code) :-
	reg_int_py(XnStr, Xn), reg_int_py(AiStr, Ai),
	format(string(Code),
'    _v = state.fresh_var()
    heap_put(state, _v)
    state.regs[~w] = _v; state.regs[~w] = _v', [Xn, Ai]).

emit_instr_py(put_value(XnStr, AiStr), Code) :-
	reg_int_py(XnStr, Xn), reg_int_py(AiStr, Ai),
	format(string(Code),
'    state.regs[~w] = state.regs[~w]', [Ai, Xn]).

emit_instr_py(put_unsafe_value(YnStr, AiStr), Code) :-
	reg_int_py(YnStr, Yn), reg_int_py(AiStr, Ai),
	format(string(Code),
'    _d = deref(state.regs[~w], state)
    if isinstance(_d, Var):
        _nv = state.fresh_var()
        heap_put(state, _nv)
        bind(_d, _nv, state)
        state.regs[~w] = _nv
    else:
        state.regs[~w] = _d', [Yn, Ai, Ai]).

emit_instr_py(put_constant(C, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	constant_term_py(C, Term),
	format(string(Code),
'    state.regs[~w] = ~w', [Ai, Term]).

emit_instr_py(put_nil(AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    state.regs[~w] = Atom("[]")', [Ai]).

emit_instr_py(put_integer(NStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    state.regs[~w] = Int(~w)', [Ai, NStr]).

emit_instr_py(put_float(FStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	format(string(Code),
'    state.regs[~w] = Float(~w)', [Ai, FStr]).

emit_instr_py(put_structure(FStr, AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	runtime_functor_py(FStr, RTName, Arity),
	put_struct_bind_py(Ai, BindLine),
	format(string(Code),
'    _c = Compound("~w", [None]*~w)
    _addr = heap_put(state, _c)
~w    state.regs[~w] = Ref(_addr)
    state.s = _addr
    _begin_write_ctx(state, _c)', [RTName, Arity, BindLine, Ai]).

emit_instr_py(put_list(AiStr), Code) :-
	reg_int_py(AiStr, Ai),
	put_struct_bind_py(Ai, BindLine),
	format(string(Code),
'    _c = Compound(".", [None, None])
    _addr = heap_put(state, _c)
~w    state.regs[~w] = Ref(_addr)
    state.s = _addr
    _begin_write_ctx(state, _c)', [BindLine, Ai]).

% --- Unify instructions ---

emit_instr_py(unify_variable(XnStr), Code) :-
	reg_int_py(XnStr, Xn),
	format(string(Code),
'    if state.mode == "read":
        state.regs[~w] = _read_ctx_get(state)
    else:
        _v = state.fresh_var()
        heap_put(state, _v)
        state.regs[~w] = _v
        _write_ctx_put(state, _v)', [Xn, Xn]).

emit_instr_py(unify_value(XnStr), Code) :-
	reg_int_py(XnStr, Xn),
	format(string(Code),
'    if state.mode == "read":
        _h = _read_ctx_get(state)
        if not unify(state.regs[~w], deref(_h, state), state): return False
    else:
        _write_ctx_put(state, state.regs[~w])', [Xn, Xn]).

emit_instr_py(unify_constant(C), Code) :-
	constant_term_py(C, Term),
	constant_match_condition_py(C, "_h", Cond),
	format(string(Code),
'    if state.mode == "read":
        _h = deref(_read_ctx_get(state), state)
        if isinstance(_h, Var): bind(_h, ~w, state)
        elif not (~w): return False
    else:
        _write_ctx_put(state, ~w)', [Term, Cond, Term]).

emit_instr_py(unify_nil, Code) :-
	Code = '    if state.mode == "read":
        _h = deref(_read_ctx_get(state), state)
        if isinstance(_h, Var): bind(_h, Atom("[]"), state)
        elif not (isinstance(_h, Atom) and _h.name == "[]"): return False
    else:
        _write_ctx_put(state, Atom("[]"))'.

emit_instr_py(unify_void(NStr), Code) :-
	format(string(Code),
'    if state.mode == "read":
        _read_ctx_skip(state, ~w)
    else:
        for _ in range(~w):
            _write_ctx_put(state, state.fresh_var())', [NStr, NStr]).

% --- set_* : always WRITE mode, fill the current structure context ---

emit_instr_py(set_variable(XnStr), Code) :-
	reg_int_py(XnStr, Xn),
	format(string(Code),
'    _v = state.fresh_var()
    _write_ctx_put(state, _v)
    state.regs[~w] = _v', [Xn]).

emit_instr_py(set_value(XnStr), Code) :-
	reg_int_py(XnStr, Xn),
	format(string(Code),
'    _write_ctx_put(state, state.regs[~w])', [Xn]).

emit_instr_py(set_local_value(XnStr), Code) :-
	reg_int_py(XnStr, Xn),
	format(string(Code),
'    _write_ctx_put(state, deref(state.regs[~w], state))', [Xn]).

emit_instr_py(set_constant(C), Code) :-
	constant_term_py(C, Term),
	format(string(Code),
'    _write_ctx_put(state, ~w)', [Term]).

emit_instr_py(set_integer(NStr), Code) :-
	format(string(Code),
'    _write_ctx_put(state, Int(~w))', [NStr]).

emit_instr_py(set_nil, Code) :-
	Code = '    _write_ctx_put(state, Atom("[]"))'.

emit_instr_py(set_void(NStr), Code) :-
	format(string(Code),
'    for _ in range(~w):
        _write_ctx_put(state, state.fresh_var())', [NStr]).

% --- Control instructions ---

emit_instr_py(call(PStr, _NStr), Code) :-
	pred_to_func_name_py(PStr, FN),
	format(string(Code),
'    _saved_cp = state.cp
    if not ~w(state): return False
    state.cp = _saved_cp', [FN]).

emit_instr_py(execute(PStr), Code) :-
	pred_to_func_name_py(PStr, FN),
	format(string(Code),
'    return ~w(state)', [FN]).

emit_instr_py(proceed, Code) :-
	Code = '    return True'.

emit_instr_py(fail, Code) :-
	Code = '    return False'.

emit_instr_py(halt, Code) :-
	Code = '    return True'.

% --- Environment instructions ---

emit_instr_py(allocate, Code) :-
	Code = '    push_environment(state, 0)'.

emit_instr_py(deallocate, Code) :-
	Code = '    pop_environment(state)'.

% --- Arithmetic ---

emit_instr_py(is(TargetStr, ExprStr), Code) :-
	reg_int_py(TargetStr, Target),
	reg_int_py(ExprStr, Expr),
	format(string(Code),
'    _expr = deref(state.regs[~w], state)
    _result = eval_arith(_expr, state)
    _rv = Int(_result) if isinstance(_result, int) else Float(_result)
    if not unify(state.regs[~w], _rv, state): return False', [Expr, Target]).

% --- Built-in calls ---

% A builtin_call dispatches to the SAME builtin implementation the
% interpreter uses (execute_builtin, the public alias of the runtime's
% _execute_builtin). It reads its arguments straight from the A-registers
% (and derefs internally), so no _args list is needed. The previous
% execute_foreign route only knew user-registered foreign predicates and
% raised "Unknown foreign predicate" for every standard builtin (=/2, >/2,
% is/2, true/0, fail/0, ...), so any lowered predicate containing one
% crashed. call_foreign (below) keeps the execute_foreign path — that is
% the genuine foreign-predicate instruction.
emit_instr_py(builtin_call(OpStr, ArStr), Code) :-
	escape_py(OpStr, EOp),
	format(string(Code),
'    if not execute_builtin("~w", ~w, state): return False',
		[EOp, ArStr]).

emit_instr_py(call_foreign(PredStr, ArStr), Code) :-
	escape_py(PredStr, EP),
	format(string(Code),
'    _args = [deref(state.regs[i+1], state) for i in range(~w)]
    if not execute_foreign("~w", ~w, _args, state): return False',
		[ArStr, EP, ArStr]).

emit_instr_py(call_indexed_atom_fact2(PredStr), Code) :-
	escape_py(PredStr, EP),
	format(string(Code),
'    _key = deref(state.regs[1], state)
    if not isinstance(_key, Atom): return False
    _values = state.indexed_atom_fact2.get("~w", {}).get(_key.name, [])
    if not _values: return False
    if not unify(state.regs[2], Atom(_values[0]), state): return False', [EP]).

emit_instr_py(base_category_ancestor(CatRegStr, TargetRegStr, VisitedRegStr), Code) :-
	reg_int_py(CatRegStr, CatReg),
	reg_int_py(TargetRegStr, TargetReg),
	reg_int_py(VisitedRegStr, VisitedReg),
	format(string(Code),
'    _cat = deref(state.regs[~w], state)
    _target = deref(state.regs[~w], state)
    _visited = deref(state.regs[~w], state)
    if not isinstance(_cat, Atom) or not isinstance(_target, Atom): return False
    if _atom_in_cons_list(_target, _visited, state): return False
    if _target.name not in state.indexed_atom_fact2.get("category_parent/2", {}).get(_cat.name, []): return False
    pop_environment(state)
    return True', [CatReg, TargetReg, VisitedReg]).

emit_instr_py(base_category_ancestor_bind(CatRegStr, TargetRegStr, HopsRegStr, VisitedRegStr), Code) :-
	reg_int_py(CatRegStr, CatReg),
	reg_int_py(TargetRegStr, TargetReg),
	reg_int_py(HopsRegStr, HopsReg),
	reg_int_py(VisitedRegStr, VisitedReg),
	format(string(Code),
'    _cat = deref(state.regs[~w], state)
    _target = deref(state.regs[~w], state)
    _visited = deref(state.regs[~w], state)
    if not isinstance(_cat, Atom) or not isinstance(_target, Atom): return False
    if _atom_in_cons_list(_target, _visited, state): return False
    if _target.name not in state.indexed_atom_fact2.get("category_parent/2", {}).get(_cat.name, []): return False
    if not unify(state.regs[~w], Int(1), state): return False
    pop_environment(state)
    return True', [CatReg, TargetReg, VisitedReg, HopsReg]).

emit_instr_py(recurse_category_ancestor(MidRegStr, RootRegStr, ChildHopsRegStr, VisitedRegStr, PredStr, _SkipStr), Code) :-
	reg_int_py(MidRegStr, MidReg),
	reg_int_py(RootRegStr, RootReg),
	reg_int_py(ChildHopsRegStr, ChildHopsReg),
	reg_int_py(VisitedRegStr, VisitedReg),
	pred_to_func_name_py(PredStr, FN),
	format(string(Code),
'    _mid = deref(state.regs[~w], state)
    _root = deref(state.regs[~w], state)
    _visited = deref(state.regs[~w], state)
    _child_hops = state.fresh_var()
    state.regs[~w] = _child_hops
    state.regs[1] = _mid
    state.regs[2] = _root
    state.regs[3] = _child_hops
    state.regs[4] = Compound(".", [_mid, _visited])
    if not ~w(state): return False', [MidReg, RootReg, VisitedReg, ChildHopsReg, FN]).

emit_instr_py(return_add1(OutRegStr, InRegStr), Code) :-
	reg_int_py(OutRegStr, OutReg),
	reg_int_py(InRegStr, InReg),
	format(string(Code),
'    _in = deref(state.regs[~w], state)
    if isinstance(_in, Int):
        _result = Int(_in.n + 1)
    elif isinstance(_in, Float):
        _next = _in.f + 1.0
        _result = Int(int(round(_next))) if abs(round(_next) - _next) < 1e-12 else Float(_next)
    elif isinstance(_in, Atom):
        try:
            _next = float(_in.name) + 1.0
            _result = Int(int(round(_next))) if abs(round(_next) - _next) < 1e-12 else Float(_next)
        except (TypeError, ValueError):
            return False
    else:
        return False
    if not unify(state.regs[~w], _result, state): return False
    pop_environment(state)
    return True', [InReg, OutReg]).

% --- Cut instructions ---

emit_instr_py(neck_cut, Code) :-
	Code = '    state.b = state.cut_b'.

emit_instr_py(get_level(YnStr), Code) :-
	reg_int_py(YnStr, Yn),
	format(string(Code),
'    state.regs[~w] = state.b', [Yn]).

emit_instr_py(cut(YnStr), Code) :-
	reg_int_py(YnStr, Yn),
	format(string(Code),
'    state.b = state.regs[~w]', [Yn]).

% ============================================================================
% Helpers
% ============================================================================

%% reg_int_py(+RegStr, -Int)
%  Parse register string to integer. Handles both numeric strings
%  and symbolic register names (A1, X1, Y1).
reg_int_py(RegStr, Int) :-
	(   number_string(Int, RegStr)
	->  true
	;   atom_string(RegA, RegStr),
		sub_atom(RegA, 0, 1, _, Prefix),
		sub_atom(RegA, 1, _, 0, NumA),
		atom_number(NumA, Num),
		(   Prefix == 'A' -> Int = Num
		;   Prefix == 'X' -> Int is Num + 100
		;   Prefix == 'Y' -> Int is Num + 200
		;   Int = 0
		)
	).

%% parse_functor_arity_py(+FStr, -FuncName, -Arity)
parse_functor_arity_py(FStr, FuncName, Arity) :-
	atom_string(FA, FStr),
	(   sub_atom(FA, B, 1, _, '/')
	->  sub_atom(FA, 0, B, _, FuncName),
		B1 is B + 1,
		sub_atom(FA, B1, _, 0, AS),
		atom_number(AS, Arity)
	;   FuncName = FA, Arity = 0
	).

%% runtime_functor_py(+FStr, -RTName, -Arity)
%  Compound functor name as the runtime stores it (see _runtime_functor_name in
%  WamRuntime.py): cons cells normalise to ".", every other functor keeps its
%  full "name/arity" form (e.g. "+/2"). The lowered emitter must build and match
%  compounds with this exact string so they unify with interpreter-built terms
%  and eval_arith (which strips the arity) sees the right operator.
runtime_functor_py(FStr, RTName, Arity) :-
	(   cons_functor_py(FStr)
	->  RTName = ".", Arity = 2
	;   parse_functor_arity_py(FStr, _F, Arity), RTName = FStr
	).

cons_functor_py(FStr) :- FStr == ".".
cons_functor_py(FStr) :- FStr == "./2".
cons_functor_py(FStr) :- FStr == "[|]/2".

%% put_struct_bind_py(+Ai, -BindLine)
%  put_structure into an X (temporary) register (index > 128, the A1..A128 cap)
%  targets a nested sub-term SLOT placed there by an earlier set_variable /
%  unify_variable, so the freshly built structure must be bound into that slot
%  var to link it to its parent. Into an A (argument) register it is a call
%  output: overwrite without binding (the prior var may alias a live argument —
%  the `X is E` case). Mirrors put_structure in WamRuntime.py.
put_struct_bind_py(Ai, BindLine) :-
	(   Ai > 128
	->  format(string(BindLine),
		"    _old = deref(state.regs[~w], state)\n    if isinstance(_old, Var): bind(_old, Ref(_addr), state)\n",
		[Ai])
	;   BindLine = ""
	).

%% pred_to_func_name_py(+PredStr, -FuncName)
%  Convert a "functor/arity" or "functor" string to a Python function name.
pred_to_func_name_py(PredStr, FuncName) :-
	atom_string(PA, PredStr),
	(   sub_atom(PA, B, 1, _, '/')
	->  sub_atom(PA, 0, B, _, Functor),
		B1 is B + 1,
		sub_atom(PA, B1, _, 0, AS),
		atom_number(AS, Arity)
	;   Functor = PA, Arity = 0
	),
	python_func_name(Functor/Arity, FuncName).

%% escape_py(+Str, -Escaped)
%  Escape a string for Python string literal (backslashes and double quotes).
escape_py(Str, Esc) :-
	atom_string(Str, S),
	split_string(S, "\\", "", Parts),
	atomic_list_concat(Parts, "\\\\", S1),
	split_string(S1, "\"", "", Parts2),
	atomic_list_concat(Parts2, "\\\"", Esc).
