:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)
%
% wam_haskell_target.pl - WAM-to-Haskell Transpilation Target
%
% Compiles WAM instructions to Haskell code using persistent data structures.
% Unlike the Rust WAM target (which interprets instructions at runtime),
% this target natively lowers each WAM instruction to Haskell expressions.
%
% Key design: Data.Map for registers and bindings gives O(1) snapshots
% for choice points (structural sharing), eliminating the clone overhead
% that made the Rust WAM 343x slower than SWI-Prolog.
%
% Architecture:
%   - WamState record with Data.Map fields
%   - Each compiled predicate becomes a Haskell function
%   - TryMeElse/RetryMeElse/TrustMe become choice point list operations
%   - Backtracking = swap to saved Data.Map reference (O(1))
%   - Facts loaded as Data.Map lookup tables (first-argument indexing)
%
% Pipeline:
%   Prolog source → haskell_target.pl (native lowering, preferred)
%                 → wam_target.pl (WAM compilation, fallback)
%                 → wam_haskell_target.pl (THIS FILE: WAM → Haskell)
%
% See: docs/design/WAM_RUST_STATE_MANAGEMENT_RETROSPECTIVE.md

:- module(wam_haskell_target, [
    compile_wam_predicate_to_haskell/4,  % +Pred/Arity, +WamCode, +Options, -HaskellCode
    compile_wam_runtime_to_haskell/3,    % +Options, +DetectedKernels, -HaskellCode
    write_wam_haskell_project/3,         % +Predicates, +Options, +ProjectDir
    wam_haskell_resolve_emit_mode/2,     % +Options, -Mode
    wam_haskell_partition_predicates/5,  % +Mode, +Predicates, +DetectedKernels, -InterpretedList, -LoweredList
    % Phase F1: fact predicate classification
    classify_fact_predicate/4,           % +PredIndicator, +WamLines, +Options, -Info
    haskell_fact_only/2,                 % +Segments, -Bool
    haskell_first_arg_groundness/3,      % +Segments, +Arity, -Status
    haskell_pick_layout/5,              % +PredIndicator, +NClauses, +FactOnly, +Options, -Layout
    split_wam_into_segments/2,           % +Lines, -Segments
    % Phase F3: inline_data emission
    extract_fact_tuples_hs/2,            % +Segments, -Tuples
    haskell_fact_list_name/2,            % +PredName, -ListName
    init_atom_intern_table/0,            % reinitialize atom intern table
    % E2E wiring
    generate_inline_facts_wiring/2,      % +InlineDefs, -Code
    % ISO error config + rewrite (parity with F#/C++/Elixir/Python)
    iso_errors_resolve_options/2,        % +Options, -Config
    iso_errors_load_config/2,            % +File, -Config
    iso_errors_mode_for/3,               % +Config, +PI, -Mode
    iso_errors_warn_multi_module/2,      % +Config, +Predicates
    iso_errors_rewrite/4,                % +Config, +PI, +Items0, -Items
    iso_errors_rewrite_text/4            % +Config, +PI, +WamText0, -WamText
]).

:- use_module(library(lists)).
:- use_module(library(pairs)).
:- use_module(library(option)).
:- use_module(library(filesex), [make_directory_path/1, directory_file_path/3]).
:- use_module('../targets/wam_target', [compile_predicate_to_wam/3]).
:- use_module('../core/recursive_kernel_detection',
             [detect_recursive_kernel/4, kernel_metadata/4, kernel_config/2,
              kernel_register_layout/2, kernel_native_call/2, kernel_template_file/2]).
:- use_module('../core/template_system', [render_template/3]).
:- use_module('../core/purity_certificate',
             [analyze_predicate_purity/2]).
:- use_module('../core/statistics',
             [select_cache_mode/2]).
:- use_module('../core/cost_model',
             [recommend_access_pattern/5, read_mem_available_bytes/1,
              resolve_csr_index_backend/2]).
:- use_module('../core/algorithm_manifest',
             [load_algorithm_manifest/2]).
:- use_module('../targets/wam_text_parser',
              [ wam_classify_constant_token/2,
                wam_tokenize_line/2,
                wam_recognise_instruction/2
              ]).
:- use_module('../targets/wam_runtime_parser_capability',
             [parser_dependent_body_goal/2, wam_target_runtime_parser/3]).
:- use_module('../core/prolog_term_parser').
:- use_module('../core/cpp_runtime_parser_wrappers').
:- use_module('../core/cost_function',
             [validate_cost_function/1, cost_function_with_defaults/2]).
:- use_module('../core/iso_errors',
              [ iso_errors_resolve_options/2,
                iso_errors_load_config/2,
                iso_errors_mode_for/3,
                iso_errors_warn_multi_module/2,
                iso_errors_rewrite/4,
                iso_errors_rewrite_item/3,
                iso_errors_audit_normalise_pi/2,
                iso_errors_audit_walk/5
              ]).

% Phase 3: the real lowerability check and emission helpers live in the
% wam_haskell_lowered_emitter module. We reexport so existing callers can
% still see wam_haskell_lowerable/3 through this module.
:- reexport('wam_haskell_lowered_emitter',
            [wam_haskell_lowerable/3, lower_predicate_to_haskell/4]).

% ============================================================================
% ATOM INTERNING TABLE (compile-time)
% ============================================================================
% Built during WAM → Haskell compilation. Maps atom strings to integer IDs.
% Well-known atoms are pre-assigned: true=0, fail=1, []=2, .=3, ""=4.

:- dynamic atom_intern_id/2.    % atom_intern_id(String, IntId)
:- dynamic atom_intern_next/1.  % atom_intern_next(NextId)

init_atom_intern_table :-
    retractall(atom_intern_id(_, _)),
    retractall(atom_intern_next(_)),
    % Reserve well-known atoms (0-4)
    assertz(atom_intern_id("true", 0)),
    assertz(atom_intern_id("fail", 1)),
    assertz(atom_intern_id("[]", 2)),
    assertz(atom_intern_id(".", 3)),
    assertz(atom_intern_id("", 4)),
    % Reserve ISO error atoms (5-15). IDs MUST match the atomXxx constants
    % in WamTypes.hs (atomError=5 .. atomUnknown=15).
    assertz(atom_intern_id("error", 5)),
    assertz(atom_intern_id("instantiation_error", 6)),
    assertz(atom_intern_id("type_error", 7)),
    assertz(atom_intern_id("domain_error", 8)),
    assertz(atom_intern_id("evaluation_error", 9)),
    assertz(atom_intern_id("evaluable", 10)),
    assertz(atom_intern_id("integer", 11)),
    assertz(atom_intern_id("not_less_than_zero", 12)),
    assertz(atom_intern_id("zero_divisor", 13)),
    assertz(atom_intern_id("/", 14)),
    assertz(atom_intern_id("unknown", 15)),
    assertz(atom_intern_next(16)).

%% intern_atom(+AtomStr, -Id) is det.
%  Assigns a stable integer ID to the given atom string. Idempotent.
intern_atom(AtomStr, Id) :-
    % M150: self-initialize. Standalone callers of the exported
    % lowering API (e.g. tests calling lower_predicate_to_haskell
    % without a full project generation) hit an empty intern table;
    % the retract below then fails SILENTLY and the whole lowering
    % fails with it -- the phase-4 suite's put_structure test failed
    % this way for months without a message.
    (   atom_intern_next(_) -> true ; init_atom_intern_table ),
    atom_string(AtomStr, Str),
    (   atom_intern_id(Str, Id0)
    ->  Id = Id0
    ;   retract(atom_intern_next(Next)),
        Id = Next,
        Next1 is Next + 1,
        assertz(atom_intern_id(Str, Id)),
        assertz(atom_intern_next(Next1))
    ).

%% intern_struct_functor(+FunctorStr, -Id) is det.
%  Intern a get_structure/put_structure functor, normalising the list
%  cons functor to atomDot (".", id 3). The WAM stream names a cons cell
%  "[|]/2" (occasionally "./2"), while get_list/put_list use atomDot —
%  so a put_structure cons (Str "[|]/2") and a put_list cons (VList /
%  Str atomDot) end up with different functor ids and never match or
%  unify. Folding every cons spelling onto atomDot gives lists ONE
%  representation. Accepts either the bare functor ("[|]", ".") or the
%  name/arity form ("[|]/2", "./2").
intern_struct_functor(FunctorStr, Id) :-
    (   is_cons_functor(FunctorStr)
    ->  intern_atom(".", Id)
    ;   intern_atom(FunctorStr, Id)
    ).

is_cons_functor(F) :-
    ( atom(F) -> atom_string(F, S) ; F = S ),
    memberchk(S, ["[|]", "[|]/2", ".", "./2"]).

%% emit_atom_table_haskell(-Code) is det.
%  Emits the compile-time atom table as Haskell code.
emit_atom_table_haskell(Code) :-
    findall(Id-Str, atom_intern_id(Str, Id), Pairs),
    sort(Pairs, Sorted),
    maplist([Id-Str, Entry]>>(
        format(string(Entry), '(~w, "~w")', [Id, Str])
    ), Sorted, Entries),
    atomic_list_concat(Entries, ', ', EntryStr),
    length(Sorted, N),
    format(string(Code),
        'compileTimeAtomTable :: InternTable\ncompileTimeAtomTable = \n  let pairs = [~w]\n  in InternTable (Map.fromList [(s, i) | (i, s) <- pairs])\n                (IM.fromList pairs)\n                ~w\n',
        [EntryStr, N]).

%% ============================================================================
%% emit_mode selector (Phase 1 of WAM-lowered Haskell path)
%% ============================================================================
%%
%% See docs/design/WAM_HASKELL_LOWERED_{PHILOSOPHY,SPECIFICATION,IMPLEMENTATION_PLAN}.md
%%
%% Three modes are recognised:
%%   - interpreter          : every predicate compiles via the existing
%%                            instruction-array interpreter path (default).
%%   - functions            : every predicate attempts lowering to a
%%                            standalone Haskell function. Any predicate
%%                            that fails wam_haskell_lowerable/3 falls back
%%                            to the interpreter automatically.
%%   - mixed(HotPreds)      : the predicates named in HotPreds attempt
%%                            lowering; the rest go to the interpreter.
%%
%% Selector hierarchy, checked in order:
%%   1. emit_mode(Mode) option on the write_wam_haskell_project/3 call
%%   2. user:wam_haskell_emit_mode(Mode) dynamic fact (if defined)
%%   3. default: interpreter
%%
%% Phase 1 ships the plumbing only. wam_haskell_lowerable/3 is a stub that
%% always fails, so all three modes route every predicate to the interpreter.
%% Output is byte-identical to the pre-Phase-1 state. Real lowering starts
%% in Phase 3 of the implementation plan.

:- multifile user:wam_haskell_emit_mode/1.

%% wam_haskell_resolve_emit_mode(+Options, -Mode)
%  Resolve the emit_mode selector using the hierarchy above. Throws a
%  domain_error on an unknown value.
wam_haskell_resolve_emit_mode(Options, Mode) :-
    (   option(emit_mode(M0), Options)
    ->  wam_haskell_validate_emit_mode(M0, Mode)
    ;   catch(user:wam_haskell_emit_mode(M1), _, fail)
    ->  wam_haskell_validate_emit_mode(M1, Mode)
    ;   Mode = interpreter
    ).

wam_haskell_validate_emit_mode(interpreter, interpreter) :- !.
wam_haskell_validate_emit_mode(functions, functions)     :- !.
wam_haskell_validate_emit_mode(mixed(L), mixed(L)) :-
    is_list(L), !.
wam_haskell_validate_emit_mode(Other, _) :-
    throw(error(domain_error(wam_haskell_emit_mode, Other),
                wam_haskell_resolve_emit_mode/2)).

%% wam_haskell_lowerable/3 lives in wam_haskell_lowered_emitter.pl and is
%% re-exported above. Phase 1 shipped a stub that always failed; Phase 3
%% replaces it with a real whitelist check against the WAM instruction
%% sequence.

%% wam_haskell_partition_predicates(+Mode, +Predicates, +DetectedKernels, -InterpretedList, -LoweredList)
%  Partition Predicates into the two sublists based on Mode and the
%  lowerability check. Detected kernels are always excluded from lowering
%  (they use FFI via CallForeign — lowering them would be dead code).
wam_haskell_partition_predicates(interpreter, Predicates, _, Predicates, []) :- !.
wam_haskell_partition_predicates(functions, Predicates, DK, Interpreted, Lowered) :- !,
    pairs_keys(DK, KernelKeys),
    wam_haskell_partition_try_lower(Predicates, KernelKeys, Interpreted, Lowered).
wam_haskell_partition_predicates(mixed(HotPreds), Predicates, DK, Interpreted, Lowered) :- !,
    pairs_keys(DK, KernelKeys),
    wam_haskell_partition_mixed(Predicates, HotPreds, KernelKeys, Interpreted, Lowered).

% functions mode: every non-kernel predicate attempts lowering.
wam_haskell_partition_try_lower([], _, [], []).
wam_haskell_partition_try_lower([P|Rest], KK, Interpreted, Lowered) :-
    pred_key(P, Key),
    (   member(Key, KK)
    ->  % Detected kernel — skip lowering, use FFI
        Interpreted = [P|IR],
        wam_haskell_partition_try_lower(Rest, KK, IR, Lowered)
    ;   wam_haskell_predicate_wamcode(P, WamCode),
        (   wam_haskell_lowerable(P, WamCode, _Reason)
        ->  Lowered = [P|LR],
            wam_haskell_partition_try_lower(Rest, KK, Interpreted, LR)
        ;   Interpreted = [P|IR],
            wam_haskell_partition_try_lower(Rest, KK, IR, Lowered)
        )
    ).

% mixed(HotPreds) mode: predicates in HotPreds attempt lowering; rest are interpreted.
% Detected kernels are always excluded from lowering.
wam_haskell_partition_mixed([], _, _, [], []).
wam_haskell_partition_mixed([P|Rest], HotPreds, KK, Interpreted, Lowered) :-
    pred_key(P, Key),
    (   member(Key, KK)
    ->  % Detected kernel — skip lowering
        Interpreted = [P|IR],
        wam_haskell_partition_mixed(Rest, HotPreds, KK, IR, Lowered)
    ;   wam_haskell_indicator_in_list(P, HotPreds)
    ->  wam_haskell_predicate_wamcode(P, WamCode),
        (   wam_haskell_lowerable(P, WamCode, _Reason)
        ->  Lowered = [P|LR],
            wam_haskell_partition_mixed(Rest, HotPreds, KK, Interpreted, LR)
        ;   Interpreted = [P|IR],
            wam_haskell_partition_mixed(Rest, HotPreds, KK, IR, Lowered)
        )
    ;   Interpreted = [P|IR],
        wam_haskell_partition_mixed(Rest, HotPreds, KK, IR, Lowered)
    ).

pred_key(P, Key) :-
    (P = _Mod:Pred/Arity -> true ; P = Pred/Arity),
    format(atom(Key), '~w/~w', [Pred, Arity]).

% Handle both Module:Pred/Arity and Pred/Arity comparisons against HotPreds.
wam_haskell_indicator_in_list(P, HotPreds) :-
    member(P, HotPreds), !.
wam_haskell_indicator_in_list(_Mod:Pred/Arity, HotPreds) :-
    member(Pred/Arity, HotPreds), !.

% Compile WAM code on demand for the lowerability check and emission.
wam_haskell_predicate_wamcode(PredIndicator, WamCode) :-
    wam_target:compile_predicate_to_wam(PredIndicator, [ite_use_y_level(true)], WamCode).

% ============================================================================
% PHASE F1: FACT PREDICATE CLASSIFICATION
% ============================================================================
% Classifies each predicate as fact-only or rule-bearing and selects a
% layout strategy (compiled, inline_data, external_source). Ports the
% Elixir classification pattern (WAM_FACT_SHAPE_SPEC.md) to the Haskell
% target. In Phase F1 all predicates still emit as `compiled` — this is
% classification infrastructure only, with no behaviour change.

%% classify_fact_predicate(+PredIndicator, +WamLines, +Options, -Info)
%  Info = fact_shape_info(NClauses, FactOnly, FirstArgGroundness, Layout).
%  WamLines is a list of strings from splitting the WAM text on newlines.
classify_fact_predicate(PredIndicator, WamLines, Options, Info) :-
    split_wam_into_segments(WamLines, Segments),
    length(Segments, NClauses),
    haskell_fact_only(Segments, FactOnly),
    (PredIndicator = _:_/Arity -> true ; PredIndicator = _/Arity),
    haskell_first_arg_groundness(Segments, Arity, FirstArg),
    haskell_pick_layout(PredIndicator, NClauses, FactOnly, Options, Layout),
    Info = fact_shape_info(NClauses, FactOnly, FirstArg, Layout).

%% split_wam_into_segments(+Lines, -Segments)
%  Groups WAM text lines into Label-InstrList pairs. Each segment
%  corresponds to one clause entry point. Instructions are parsed into
%  terms like get_constant(C, Reg), call(P, N), etc.
split_wam_into_segments([], []).
split_wam_into_segments([Line|Rest], Segments) :-
    tokenize_wam_line_hs(Line, Parts),
    (   Parts == []
    ->  split_wam_into_segments(Rest, Segments)
    ;   Parts = [First|_], sub_string(First, _, 1, 0, ":")
    ->  sub_string(First, 0, _, 1, LabelName),
        extract_segment_instrs(Rest, Instrs, Remaining),
        Segments = [LabelName-Instrs | RestSegs],
        split_wam_into_segments(Remaining, RestSegs)
    ;   % Instruction line before any label — skip
        split_wam_into_segments(Rest, Segments)
    ).

%% extract_segment_instrs(+Lines, -Instrs, -Remaining)
%  Collects parsed instructions until the next label or end of input.
extract_segment_instrs([], [], []).
extract_segment_instrs([Line|Rest], Instrs, Remaining) :-
    tokenize_wam_line_hs(Line, Parts),
    (   Parts == []
    ->  extract_segment_instrs(Rest, Instrs, Remaining)
    ;   Parts = [First|_], sub_string(First, _, 1, 0, ":")
    ->  Instrs = [], Remaining = [Line|Rest]
    ;   (   parse_wam_instr_hs(Parts, Instr)
        ->  Instrs = [Instr | RestInstrs],
            extract_segment_instrs(Rest, RestInstrs, Remaining)
        ;   % Unrecognized instruction — skip but continue
            extract_segment_instrs(Rest, Instrs, Remaining)
        )
    ).

%% tokenize_wam_line_hs(+Line, -Parts)
%  Simple tokenizer: split on whitespace/comma, remove empties.
%  Does not handle quoted atoms — sufficient for classification.
tokenize_wam_line_hs(Line, Parts) :-
    split_string(Line, " \t,", " \t,", Parts0),
    delete(Parts0, "", Parts).

%% parse_wam_instr_hs(+Parts, -Instr)
%  Parse tokenized WAM line into a structured instruction term.
%  Only instructions relevant to classification need to be recognized.
parse_wam_instr_hs(["get_constant", C, Ai], get_constant(C, Ai)).
parse_wam_instr_hs(["get_variable", Xn, Ai], get_variable(Xn, Ai)).
parse_wam_instr_hs(["get_value", Xn, Ai], get_value(Xn, Ai)).
parse_wam_instr_hs(["get_structure", F, Ai], get_structure(F, Ai)).
parse_wam_instr_hs(["put_constant", C, Ai], put_constant(C, Ai)).
parse_wam_instr_hs(["put_variable", Xn, Ai], put_variable(Xn, Ai)).
parse_wam_instr_hs(["put_value", Xn, Ai], put_value(Xn, Ai)).
parse_wam_instr_hs(["put_structure", F|_], put_structure(F)).
parse_wam_instr_hs(["put_list", Ai], put_list(Ai)).
parse_wam_instr_hs(["unify_variable", Xn], unify_variable(Xn)).
parse_wam_instr_hs(["unify_value", Xn], unify_value(Xn)).
parse_wam_instr_hs(["unify_constant", C], unify_constant(C)).
parse_wam_instr_hs(["call", P, N], call(P, N)).
parse_wam_instr_hs(["execute", P], execute(P)).
parse_wam_instr_hs(["builtin_call", Op, Ar], builtin_call(Op, Ar)).
parse_wam_instr_hs(["proceed"], proceed).
parse_wam_instr_hs(["try_me_else", L], try_me_else(L)).
parse_wam_instr_hs(["retry_me_else", L], retry_me_else(L)).
parse_wam_instr_hs(["trust_me"], trust_me).
parse_wam_instr_hs(["allocate"], allocate).
parse_wam_instr_hs(["deallocate"], deallocate).
parse_wam_instr_hs(["switch_on_constant"|_], switch_on_constant).

%% haskell_fact_only(+Segments, -Bool)
%  `true` iff no clause has a body-level call instruction.
%  Mirrors the Elixir fact_only/2 from wam_elixir_lowered_emitter.pl.
haskell_fact_only(Segments, true) :-
    forall(member(_-Instrs, Segments),
           forall(member(Instr, Instrs),
                  \+ haskell_is_body_call(Instr))), !.
haskell_fact_only(_, false).

haskell_is_body_call(call(_, _)).
haskell_is_body_call(execute(_)).
haskell_is_body_call(builtin_call(_, _)).

%% haskell_first_arg_groundness(+Segments, +Arity, -Status)
%  Status is one of: `none` (arity 0), `all_ground`, `all_variable`, `mixed`.
haskell_first_arg_groundness(_Segments, 0, none) :- !.
haskell_first_arg_groundness(Segments, Arity, Status) :-
    Arity > 0,
    maplist(haskell_clause_arg1_type, Segments, Types),
    haskell_combine_groundness(Types, Status).

%% haskell_clause_arg1_type(+Segment, -Type)
%  Inspects the instructions in a clause segment for the A1 binding.
haskell_clause_arg1_type(_-Instrs, Type) :-
    (   member(get_constant(_, "A1"), Instrs) -> Type = ground
    ;   member(get_structure(_, "A1"), Instrs) -> Type = ground
    ;   member(get_variable(_, "A1"), Instrs) -> Type = variable
    ;   member(get_value(_, "A1"), Instrs)    -> Type = variable
    ;   Type = unknown
    ).

haskell_combine_groundness(Types, all_ground)   :- forall(member(T, Types), T == ground), !.
haskell_combine_groundness(Types, all_variable) :- forall(member(T, Types), T == variable), !.
haskell_combine_groundness(_, mixed).

%% haskell_pick_layout(+PredIndicator, +NClauses, +FactOnly, +Options, -Layout)
%  User override via fact_layout/2 in Options always wins. Otherwise
%  dispatches to the policy (default: auto). Same structure as the Elixir
%  pick_layout but uses the user:fact_layout/2 multifile hook.
:- multifile user:fact_layout/2.
:- multifile user:wam_haskell_layout_policy/5.

haskell_pick_layout(PredIndicator, _NClauses, _FactOnly, Options, Layout) :-
    option(fact_layout(PredIndicator, UserLayout), Options), !,
    Layout = UserLayout.
haskell_pick_layout(PredIndicator, _NClauses, _FactOnly, _Options, Layout) :-
    catch(user:fact_layout(PredIndicator, UserLayout), _, fail), !,
    Layout = UserLayout.
haskell_pick_layout(PredIndicator, NClauses, FactOnly, Options, Layout) :-
    option(fact_layout_policy(PolicyName), Options, auto),
    haskell_layout_policy(PolicyName, PredIndicator, NClauses, FactOnly, Options, Layout).

haskell_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout) :-
    catch(user:wam_haskell_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Layout0),
          _, fail),
    !,
    (   nonvar(Layout0)
    ->  Layout = Layout0
    ;   haskell_builtin_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout)
    ).
haskell_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout) :-
    haskell_builtin_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout).

%% haskell_builtin_layout_policy(+Policy, +PredIndicator, +NClauses, +FactOnly, +Options, -Layout)
%  Built-in layout policies mirroring the Elixir target.
%    auto          — fact-only ∧ count > threshold → inline_data, else compiled
%    compiled_only — always compiled (regression bisection)
%    inline_eager  — fact-only always → inline_data
%    cost_aware    — factors in arity for the threshold
haskell_builtin_layout_policy(auto, _Pred, NClauses, FactOnly, Options, Layout) :-
    option(fact_count_threshold(Threshold), Options, 100),
    (   FactOnly == true, NClauses > Threshold
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).
haskell_builtin_layout_policy(compiled_only, _, _, _, _, compiled).
haskell_builtin_layout_policy(inline_eager, _, _, FactOnly, _, Layout) :-
    (   FactOnly == true
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).
haskell_builtin_layout_policy(cost_aware, _Pred/Arity, NClauses, FactOnly, Options, Layout) :-
    option(fact_cost_threshold(Threshold), Options, 200),
    Mult is max(1, Arity),
    CostScore is NClauses * Mult,
    (   FactOnly == true, CostScore > Threshold
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).

%% format_fact_shape_comment_hs(+PredIndicator, +Info, -Comment)
%  Renders classification info as a Haskell comment line.
format_fact_shape_comment_hs(PredIndicator, fact_shape_info(N, FO, FA, Layout), Comment) :-
    (PredIndicator = _:P/A -> true ; PredIndicator = P/A),
    format(string(Comment),
           '-- ~w/~w: fact_only=~w, clauses=~w, first_arg=~w, layout=~w',
           [P, A, FO, N, FA, Layout]).

% ============================================================================
% LOWERED EMISSION
% ============================================================================

%% lower_all(+LoweredList, +BasePCMap, +DetectedKernels, -LoweredEntries)
%  Run the Phase 3+ emitter over each predicate in LoweredList, using
%  BasePCMap (a list of PredIndicator-StartPC pairs computed from the
%  merged instruction array) to offset local PCs to global PCs.
%  DetectedKernels (Key-Kernel pairs) is passed through so the emitter
%  can emit callForeign for known foreign predicates.
lower_all([], _, _, []).
lower_all([P|Rest], BasePCMap, DetectedKernels, [Entry|RestEntries]) :-
    wam_haskell_predicate_wamcode(P, WamCode),
    predicate_base_pc(P, BasePCMap, BasePC),
    pairs_keys(DetectedKernels, ForeignKeys),
    lower_predicate_to_haskell(P, WamCode,
        [base_pc(BasePC), foreign_preds(ForeignKeys)], Entry),
    lower_all(Rest, BasePCMap, DetectedKernels, RestEntries).

predicate_base_pc(P, Map, PC) :-
    (   P = _Mod:Pred/Arity -> true ; P = Pred/Arity ),
    format(atom(Key), '~w/~w', [Pred, Arity]),
    (   member(Key-PC, Map) -> true ; PC = 1 ).

%% generate_kernel_haskell(+DetectedKernels, -KernelFunctionsCode, -ExecuteForeignCode)
%  Render Mustache templates for detected kernels into Haskell source.
%  DetectedKernels is a list of Key-Kernel pairs from detect_kernels/2.
%  KernelFunctionsCode: native kernel function bodies (one per kernel).
%  ExecuteForeignCode: the executeForeign dispatch function with entries
%  for each detected kernel.
generate_kernel_haskell([], KF, EF) :- !,
    KF = "-- No kernels detected; no native functions generated.",
    EF = "executeForeign :: WamContext -> String -> WamState -> Maybe WamState\nexecuteForeign _ _ _ = Nothing".
generate_kernel_haskell(DetectedKernels, KernelFunctionsCode, ExecuteForeignCode) :-
    % For each detected kernel, find its template and render
    maplist(render_kernel_function, DetectedKernels, KernelParts),
    atomic_list_concat(KernelParts, '\n\n', KernelFunctionsCode),
    % Generate executeForeign with entries for each kernel
    generate_execute_foreign(DetectedKernels, ExecuteForeignCode).

render_kernel_function(Key-Kernel, Code) :-
    Kernel = recursive_kernel(Kind, _, ConfigOps),
    (   kernel_template_file(Kind, TemplateFile)
    ->  read_kernel_template(TemplateFile, Template),
        % Build template vars from config ops
        config_ops_to_template_vars(ConfigOps, TemplateVars),
        render_template(Template, TemplateVars, Code0),
        atom_string(Code0, Code)
    ;   format(atom(Code), '-- Kernel ~w: no template available', [Key])
    ).

%% config_ops_to_template_vars(+ConfigOps, -TemplateVars)
%  Convert kernel config ops to Mustache template key=value pairs.
config_ops_to_template_vars([], []).
config_ops_to_template_vars([Op|Rest], [Key=Value|RestVars]) :-
    Op =.. [Key, RawValue],
    (   RawValue = Pred/_ -> Value = Pred  % edge_pred(foo/2) -> foo
    ;   Value = RawValue
    ),
    config_ops_to_template_vars(Rest, RestVars).

read_kernel_template(FileName, Template) :-
    atom_concat('templates/targets/haskell_wam/', FileName, RelPath),
    %% Resolve the project root from this module's source file rather than
    %% trusting the caller's cwd. Walks up: targets/ → unifyweaver/ → src/
    %% → project root. Uses a callable head (`read_kernel_template/2`) so
    %% source_file/2 actually matches; the bare-atom form was a no-op and
    %% silently fell through to a cwd-relative path.
    (   source_file(read_kernel_template(_,_), SrcFile)
    ->  file_directory_name(SrcFile, SrcDir),
        file_directory_name(SrcDir, TargetsDir),
        file_directory_name(TargetsDir, UnifyWeaverDir),
        file_directory_name(UnifyWeaverDir, ProjectDir),
        atom_concat(ProjectDir, '/', P1),
        atom_concat(P1, RelPath, AbsPath)
    ;   AbsPath = RelPath
    ),
    (   exists_file(AbsPath)
    ->  read_file_to_string(AbsPath, Template, [])
    ;   format(atom(Template), '-- Template not found: ~w', [AbsPath])
    ).

generate_execute_foreign(DetectedKernels, Code) :-
    with_output_to(string(Code), (
        format("executeForeign :: WamContext -> String -> WamState -> Maybe WamState~n"),
        forall(member(KV, DetectedKernels), emit_execute_foreign_entry(KV)),
        format("executeForeign _ _ _ = Nothing~n")
    )).

%% emit_execute_foreign_entry(+Key-Kernel)
%  Generate a single executeForeign clause from kernel metadata.
%  Reads kernel_register_layout and kernel_native_call to produce the
%  register reading, native call, result binding, and choice point code.
emit_execute_foreign_entry(Key-Kernel) :-
    Kernel = recursive_kernel(Kind, _, ConfigOps),
    (   kernel_register_layout(Kind, RegSpecs),
        kernel_native_call(Kind, CallSpec)
    ->  % Resolve config_facts_from references using the kernel's config ops
        resolve_call_spec(CallSpec, ConfigOps, ResolvedCallSpec),
        emit_ef_clause(Key, RegSpecs, ResolvedCallSpec)
    ;   format('-- executeForeign: no metadata for ~w~n', [Key])
    ).

%% resolve_call_spec(+CallSpec, +ConfigOps, -ResolvedCallSpec)
%  Replace config_facts_from(ConfigKey) with config_facts(ActualName)
%  by looking up the ConfigKey in the kernel's config ops.
resolve_call_spec(call(Func, Args), ConfigOps, call(Func, ResolvedArgs)) :-
    maplist(resolve_arg_spec(ConfigOps), Args, ResolvedArgs).

resolve_arg_spec(ConfigOps, config_facts_from(ConfigKey), config_facts(FactName)) :- !,
    % Look up ConfigKey in config ops: e.g., edge_pred(foo/2) → foo
    Op =.. [ConfigKey, RawValue],
    member(Op, ConfigOps),
    (   RawValue = Pred/_ -> FactName = Pred ; FactName = RawValue ).
resolve_arg_spec(ConfigOps, config_weighted_facts_from(ConfigKey), config_weighted_facts(FactName)) :- !,
    % Weighted variant: resolves to wcFfiWeightedFacts lookup at codegen
    Op =.. [ConfigKey, RawValue],
    member(Op, ConfigOps),
    (   RawValue = Pred/_ -> FactName = Pred ; FactName = RawValue ).
resolve_arg_spec(_, Arg, Arg).

emit_ef_clause(Key, RegSpecs, call(FuncName, ArgSpecs)) :-
    % Function header
    format('executeForeign !ctx "~w" s =~n', [Key]),
    % Emit let-bindings for input registers (deref from WAM regs)
    include(is_input_reg, RegSpecs, InputRegs),
    format('  let '),
    emit_input_let_bindings(InputRegs, first),
    % Emit config bindings from ArgSpecs
    emit_config_let_bindings(ArgSpecs),
    % Find output register(s). Single-output kernels (category_ancestor,
    % transitive_closure2) keep the existing fast path; multi-output
    % kernels (transitive_distance3, weighted_shortest_path3) use a
    % tuple-based bindResult that binds multiple registers per solution.
    include(is_output_reg, RegSpecs, OutputRegs),
    % Emit case expression over input regs, then native call + binding inside
    emit_case_and_call(InputRegs, OutputRegs, FuncName, ArgSpecs),
    format('~n').

is_input_reg(input(_, _)).
is_output_reg(output(_, _)).

%% emit_input_let_bindings(+InputRegs, +Position)
%  Emit let-bindings that read and deref each input register.
emit_input_let_bindings([], _).
emit_input_let_bindings([input(RegN, Type)|Rest], Pos) :-
    reg_var_name(RegN, VarName),
    reg_default_value(Type, Default),
    (   Pos = first -> true ; format('      ') ),
    format('~w = derefVar (wsBindings s) $ fromMaybe (~w) (IM.lookup ~w (wsRegs s))~n',
           [VarName, Default, RegN]),
    emit_input_let_bindings(Rest, rest).

reg_var_name(N, Name) :-
    format(atom(Name), 'r~w', [N]).

reg_default_value(atom, 'Atom atomEmpty').
reg_default_value(integer, 'Integer 0').
reg_default_value(vlist_atoms, 'VList []').

%% emit_config_let_bindings(+ArgSpecs)
%  Emit let-bindings for config_facts and config_int arguments.
emit_config_let_bindings([]).
emit_config_let_bindings([config_facts(FactKey)|Rest]) :-
    % FFI facts: check wcEdgeLookups first (LMDB-backed when available),
    % fall back to wrapping wcFfiFacts IntMap as EdgeLookup.
    format('      ~w_facts = case Map.lookup "~w" (wcEdgeLookups ctx) of~n', [FactKey, FactKey]),
    format('        Just lkp -> lkp~n', []),
    format('        Nothing  -> intMapEdgeLookup (fromMaybe IM.empty $ Map.lookup "~w" (wcFfiFacts ctx))~n',
           [FactKey]),
    emit_config_let_bindings(Rest).
emit_config_let_bindings([config_weighted_facts(FactKey)|Rest]) :-
    % Weighted FFI facts: IntMap [(Int, Double)] (target, weight pairs)
    format('      ~w_facts = fromMaybe IM.empty $ Map.lookup "~w" (wcFfiWeightedFacts ctx)~n',
           [FactKey, FactKey]),
    emit_config_let_bindings(Rest).
emit_config_let_bindings([config_int(ConfigKey, Default)|Rest]) :-
    format('      ~w_cfg = fromMaybe ~w $ Map.lookup "~w" (wcForeignConfig ctx)~n',
           [ConfigKey, Default, ConfigKey]),
    emit_config_let_bindings(Rest).
emit_config_let_bindings([_|Rest]) :-
    emit_config_let_bindings(Rest).

%% emit_call_args(+ArgSpecs, +InputRegs)
%  Emit the argument list for the native kernel function call.
emit_call_args([], _).
emit_call_args([Spec|Rest], InputRegs) :-
    format(' '),
    emit_one_call_arg(Spec, InputRegs),
    emit_call_args(Rest, InputRegs).

emit_one_call_arg(config_facts(FactKey), _) :-
    format('~w_facts', [FactKey]).
emit_one_call_arg(config_weighted_facts(FactKey), _) :-
    format('~w_facts', [FactKey]).
emit_one_call_arg(config_int(ConfigKey, _), _) :-
    format('~w_cfg', [ConfigKey]).
emit_one_call_arg(reg(RegN), InputRegs) :-
    member(input(RegN, Type), InputRegs),
    reg_var_name(RegN, VarName),
    emit_reg_extraction(VarName, Type).
emit_one_call_arg(derived(length, RegN), InputRegs) :-
    member(input(RegN, _Type), InputRegs),
    reg_var_name(RegN, VarName),
    format('(length [v | Atom v <- ~wL])', [VarName]).  % v is Int, just counting elements

%% emit_reg_extraction(+VarName, +Type)
%  Emit the extraction expression for a kernel call argument. Atoms and
%  atom lists are interned via wcAtomIntern so the kernel operates on
%  Int IDs instead of Strings (eliminates hashing in the hot loop).
emit_reg_extraction(VarName, atom) :-
    format('~wI', [VarName]).
emit_reg_extraction(VarName, vlist_atoms) :-
    format('[v | Atom v <- ~wL]', [VarName]).
emit_reg_extraction(VarName, integer) :-
    format('~wI', [VarName]).

%% emit_case_and_call(+InputRegs, +OutputRegs, +FuncName, +ArgSpecs)
%  Emit the case expression that pattern-matches inputs, then the native
%  call and stream binding INSIDE the case branch (so extracted string
%  variables are in scope for the call).
emit_case_and_call(InputRegs, OutputRegs, FuncName, ArgSpecs) :-
    length(InputRegs, NInputs),
    (   NInputs =:= 1
    ->  InputRegs = [input(RegN1, _)],
        reg_var_name(RegN1, ScrutName),
        format('  in case ~w of~n', [ScrutName]),
        emit_single_case_branch(InputRegs, OutputRegs, FuncName, ArgSpecs)
    ;   format('  in case ('),
        emit_scrutinee_tuple(InputRegs, first),
        format(') of~n'),
        format('    ('),
        emit_pattern_tuple(InputRegs, first),
        format(') ->~n'),
        emit_native_call_and_binding(OutputRegs, FuncName, ArgSpecs, InputRegs, "      ")
    ),
    format('    _ -> Nothing~n').

emit_single_case_branch([input(RegN, Type)|_], OutputRegs, FuncName, ArgSpecs) :-
    reg_var_name(RegN, VarName),
    type_pattern(Type, VarName, Pattern),
    format('    ~w ->~n', [Pattern]),
    emit_native_call_and_binding(OutputRegs, FuncName, ArgSpecs, [input(RegN, Type)], "      ").

emit_scrutinee_tuple([], _).
emit_scrutinee_tuple([input(RegN, _)|Rest], Pos) :-
    reg_var_name(RegN, VarName),
    (   Pos = first -> true ; format(', ') ),
    format('~w', [VarName]),
    emit_scrutinee_tuple(Rest, rest).

emit_pattern_tuple([], _).
emit_pattern_tuple([input(RegN, Type)|Rest], Pos) :-
    reg_var_name(RegN, VarName),
    type_pattern(Type, VarName, Pattern),
    (   Pos = first -> true ; format(', ') ),
    format('~w', [Pattern]),
    emit_pattern_tuple(Rest, rest).

type_pattern(atom, VarName, Pattern) :-
    format(atom(Pattern), 'Atom ~wI', [VarName]).
type_pattern(integer, VarName, Pattern) :-
    format(atom(Pattern), 'Integer ~wI', [VarName]).
type_pattern(vlist_atoms, VarName, Pattern) :-
    format(atom(Pattern), 'VList ~wL', [VarName]).

%% emit_native_call_and_binding(+OutputRegs, +FuncName, +ArgSpecs, +InputRegs, +Indent)
%  Emit the native function call followed by stream binding, all inside
%  a case branch at the given indentation level.
%
%  All kernels — single- AND multi-output — go through the FFIStreamRetry
%  path. The single-output fast path with HopsRetry was retained for
%  back-compat with category_ancestor/transitive_closure2, but had a
%  latent bug: its resume logic hardcodes `Integer (fromIntegral h)`,
%  which is wrong for atom/float outputs. The multi-output path is
%  type-correct by construction — it carries pre-wrapped Values in the
%  choice point — so it's strictly better for any non-integer output.
%
%  For single-output kernels (length OutputRegs = 1), the emitted code
%  treats the result as a 1-tuple: `bindResult rv_1` (not a tuple
%  pattern; `emit_tuple_pattern(1)` produces just `rv_1`).
emit_native_call_and_binding(OutputRegs, FuncName, ArgSpecs, InputRegs, Indent) :-
    format('~wlet results = ~w', [Indent, FuncName]),
    emit_call_args(ArgSpecs, InputRegs),
    format('~n'),
    emit_stream_binding_multi(OutputRegs, Indent).

%% emit_stream_binding_single(+OutRegN, +OutType, +Indent)
%  Single-output stream binding. Unchanged from the original for
%  back-compat with category_ancestor and transitive_closure2.
emit_stream_binding_single(OutRegN, OutType, Indent) :-
    result_wrap_expr(OutType, WrapExpr),
    format('~w    retPC = wsCP s~n', [Indent]),
    format('~w    outReg = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup ~w (wsRegs s))~n', [Indent, OutRegN]),
    format('~w    bindResult rv =~n', [Indent]),
    format('~w      case outReg of~n', [Indent]),
    format('~w        Unbound vid ->~n', [Indent]),
    format('~w          s { wsPC = retPC~n', [Indent]),
    format('~w            , wsRegs = IM.insert ~w (~w) (wsRegs s)~n', [Indent, OutRegN, WrapExpr]),
    format('~w            , wsBindings = IM.insert vid (~w) (wsBindings s)~n', [Indent, WrapExpr]),
    format('~w            , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s~n', [Indent]),
    format('~w            , wsTrailLen = wsTrailLen s + 1 }~n', [Indent]),
    format('~w        _ -> s { wsPC = retPC, wsRegs = IM.insert ~w (~w) (wsRegs s) }~n', [Indent, OutRegN, WrapExpr]),
    format('~win case results of~n', [Indent]),
    format('~w  [] -> Nothing~n', [Indent]),
    format('~w  [h] -> Just (bindResult h)~n', [Indent]),
    format('~w  (h:restResults) ->~n', [Indent]),
    format('~w    let s1 = bindResult h~n', [Indent]),
    format('~w        outVar = case outReg of { Unbound v -> v; _ -> -1 }~n', [Indent]),
    format('~w        cp = ChoicePoint~n', [Indent]),
    format('~w          { cpNextPC = retPC, cpRegs = wsRegs s, cpStack = wsStack s~n', [Indent]),
    format('~w          , cpCP = wsCP s, cpTrailLen = wsTrailLen s~n', [Indent]),
    format('~w          , cpHeapLen = wsHeapLen s, cpBindings = wsBindings s~n', [Indent]),
    format('~w          , cpCutBar = wsCutBar s, cpAggFrame = Nothing~n', [Indent]),
    format('~w          , cpBuiltin = Just (HopsRetry outVar (map fromIntegral restResults) retPC)~n', [Indent]),
    format('~w          }~n', [Indent]),
    format('~w    in Just (s1 { wsCPs = cp : wsCPs s, wsCPsLen = wsCPsLen s + 1 })~n', [Indent]).

%% emit_stream_binding_multi(+OutputRegs, +Indent)
%  Multi-output stream binding. The kernel returns `[(T1, T2, ...)]` and
%  bindResult takes a tuple, binding each output to its register.
%  Uses FFIStreamRetry to store remaining tuples (as pre-wrapped Values)
%  in the choice point.
emit_stream_binding_multi(OutputRegs, Indent) :-
    length(OutputRegs, NOuts),
    format('~w    retPC = wsCP s~n', [Indent]),
    % Deref each output register
    emit_multi_out_derefs(OutputRegs, Indent),
    % Emit bindResult: pattern matches a tuple, binds each output
    format('~w    bindResult ', [Indent]),
    emit_tuple_pattern(NOuts),
    format(' =~n', []),
    format('~w      let ', [Indent]),
    emit_multi_wrap_bindings(OutputRegs, 1),
    format('~w      in s { wsPC = retPC~n', [Indent]),
    emit_multi_reg_updates(OutputRegs, Indent),
    emit_multi_binding_updates(OutputRegs, Indent),
    emit_multi_trail_updates(OutputRegs, Indent),
    format('~w         , wsTrailLen = wsTrailLen s + ~w~n', [Indent, NOuts]),
    format('~w         }~n', [Indent]),
    % Dispatch over result stream
    format('~win case results of~n', [Indent]),
    format('~w  [] -> Nothing~n', [Indent]),
    format('~w  [h] -> Just (bindResult h)~n', [Indent]),
    format('~w  (h:restResults) ->~n', [Indent]),
    format('~w    let s1 = bindResult h~n', [Indent]),
    emit_multi_outvars(OutputRegs, Indent),
    format('~w        restWrapped = map (\\', [Indent]),
    emit_tuple_pattern(NOuts),
    format(' -> [', []),
    emit_multi_wrap_list(OutputRegs, 1),
    format(']) restResults~n', []),
    format('~w        cp = ChoicePoint~n', [Indent]),
    format('~w          { cpNextPC = retPC, cpRegs = wsRegs s, cpStack = wsStack s~n', [Indent]),
    format('~w          , cpCP = wsCP s, cpTrailLen = wsTrailLen s~n', [Indent]),
    format('~w          , cpHeapLen = wsHeapLen s, cpBindings = wsBindings s~n', [Indent]),
    format('~w          , cpCutBar = wsCutBar s, cpAggFrame = Nothing~n', [Indent]),
    format('~w          , cpBuiltin = Just (FFIStreamRetry ', [Indent]),
    emit_outregs_list(OutputRegs),
    format(' outVars restWrapped retPC)~n', []),
    format('~w          }~n', [Indent]),
    format('~w    in Just (s1 { wsCPs = cp : wsCPs s, wsCPsLen = wsCPsLen s + 1 })~n', [Indent]).

%% Helpers for multi-output emission:

% Emit `outReg_1 = ...`, `outReg_2 = ...`
emit_multi_out_derefs([], _).
emit_multi_out_derefs([output(RegN, _)|Rest], Indent) :-
    format('~w    outReg_~w = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup ~w (wsRegs s))~n',
           [Indent, RegN, RegN]),
    emit_multi_out_derefs(Rest, Indent).

% Emit tuple pattern like (rv_1, rv_2)
emit_tuple_pattern(1) :- format('rv_1', []).
emit_tuple_pattern(N) :-
    N > 1,
    format('(', []),
    emit_tuple_pattern_args(1, N),
    format(')', []).

emit_tuple_pattern_args(I, N) :-
    I < N, !,
    format('rv_~w, ', [I]),
    I1 is I + 1,
    emit_tuple_pattern_args(I1, N).
emit_tuple_pattern_args(N, N) :-
    format('rv_~w', [N]).

% Emit `w_1 = WrapExpr_1; w_2 = WrapExpr_2` for wrapped values
emit_multi_wrap_bindings([], _) :- format('~n', []).
emit_multi_wrap_bindings([output(_, Type)|Rest], I) :-
    result_wrap_expr_for_rv(Type, I, WrapExpr),
    (   I =:= 1
    ->  format('w_~w = ~w', [I, WrapExpr])
    ;   format('; w_~w = ~w', [I, WrapExpr])
    ),
    I1 is I + 1,
    emit_multi_wrap_bindings(Rest, I1).

% Emit `, wsRegs = IM.insert R1 w_1 $ IM.insert R2 w_2 $ wsRegs s`
emit_multi_reg_updates(OutputRegs, Indent) :-
    format('~w         , wsRegs = ', [Indent]),
    emit_reg_insert_chain(OutputRegs, 1),
    format('wsRegs s~n', []).

emit_reg_insert_chain([], _).
emit_reg_insert_chain([output(RegN, _)|Rest], I) :-
    format('IM.insert ~w w_~w $ ', [RegN, I]),
    I1 is I + 1,
    emit_reg_insert_chain(Rest, I1).

% Emit `, wsBindings = IM.insert vid_1 w_1 $ IM.insert vid_2 w_2 $ wsBindings s`
% Only inserts for Unbound outputs; bound outputs are no-ops.
emit_multi_binding_updates(OutputRegs, Indent) :-
    format('~w         , wsBindings = ', [Indent]),
    emit_binding_insert_chain(OutputRegs, 1),
    format('wsBindings s~n', []).

emit_binding_insert_chain([], _).
emit_binding_insert_chain([output(RegN, _)|Rest], I) :-
    format('(case outReg_~w of { Unbound v -> IM.insert v w_~w; _ -> id }) $ ',
           [RegN, I]),
    I1 is I + 1,
    emit_binding_insert_chain(Rest, I1).

% Emit `, wsTrail = TrailEntry vid_1 _ : TrailEntry vid_2 _ : wsTrail s`
emit_multi_trail_updates(OutputRegs, Indent) :-
    format('~w         , wsTrail = ', [Indent]),
    emit_trail_entry_chain(OutputRegs, 1),
    format('wsTrail s~n', []).

emit_trail_entry_chain([], _).
emit_trail_entry_chain([output(RegN, _)|Rest], I) :-
    format('(case outReg_~w of { Unbound v -> (TrailEntry v (IM.lookup v (wsBindings s)) :); _ -> id }) $ ',
           [RegN]),
    I1 is I + 1,
    emit_trail_entry_chain(Rest, I1).

% outVars list: [case outReg_R1 of { Unbound v -> v; _ -> -1 }, ...]
emit_multi_outvars(OutputRegs, Indent) :-
    format('~w        outVars = [', [Indent]),
    emit_outvars_list(OutputRegs, 1),
    format(']~n', []).

emit_outvars_list([], _).
emit_outvars_list([output(RegN, _)|Rest], I) :-
    (   I =:= 1 -> true ; format(', ', []) ),
    format('case outReg_~w of { Unbound v -> v; _ -> -1 }', [RegN]),
    I1 is I + 1,
    emit_outvars_list(Rest, I1).

% Output register numbers list for FFIStreamRetry
emit_outregs_list(OutputRegs) :-
    format('[', []),
    emit_outregs_list_items(OutputRegs, 1),
    format(']', []).

emit_outregs_list_items([], _).
emit_outregs_list_items([output(RegN, _)|Rest], I) :-
    (   I =:= 1 -> true ; format(', ', []) ),
    format('~w', [RegN]),
    I1 is I + 1,
    emit_outregs_list_items(Rest, I1).

% restWrapped list wrapping each tuple value
emit_multi_wrap_list([], _).
emit_multi_wrap_list([output(_, Type)|Rest], I) :-
    result_wrap_expr_for_rv(Type, I, WrapExpr),
    (   I =:= 1 -> true ; format(', ', []) ),
    format('~w', [WrapExpr]),
    I1 is I + 1,
    emit_multi_wrap_list(Rest, I1).

%% result_wrap_expr_for_rv(+Type, +Index, -HaskellExpr)
%  Like result_wrap_expr but using rv_<I> instead of rv.
result_wrap_expr_for_rv(integer, I, Expr) :-
    format(atom(Expr), 'Integer (fromIntegral rv_~w)', [I]).
result_wrap_expr_for_rv(atom, I, Expr) :-
    format(atom(Expr), 'Atom rv_~w', [I]).
result_wrap_expr_for_rv(float, I, Expr) :-
    format(atom(Expr), 'Float rv_~w', [I]).

%% result_wrap_expr(+Type, -HaskellExpr)
%  Haskell expression wrapping `rv` (kernel result) into a Value
%  constructor. For `atom`, the kernel returns Int atom IDs that must
%  be de-interned back to Strings before wrapping in the Atom constructor.
%  For `integer` and `float`, no interning is involved.
result_wrap_expr(integer, 'Integer (fromIntegral rv)').
result_wrap_expr(atom, 'Atom rv').
result_wrap_expr(float, 'Float rv').

%% detect_kernels(+Predicates, -DetectedKernels)
%  Run shared kernel detection on each predicate. Returns a list of
%  Key-Kernel pairs where Key is 'pred/arity' atom and Kernel is the
%  full recursive_kernel(Kind, Pred/Arity, ConfigOps) term.
detect_kernels([], []).
detect_kernels([PI|Rest], Kernels) :-
    (   PI = Mod:Pred/Arity -> true ; PI = Pred/Arity, Mod = user ),
    functor(Head, Pred, Arity),
    (   catch(findall(Head-Body, clause(Mod:Head, Body), Clauses), _, Clauses = [])
    ->  true
    ;   Clauses = []
    ),
    (   Clauses \= [],
        detect_recursive_kernel(Pred, Arity, Clauses, Kernel)
    ->  format(atom(Key), '~w/~w', [Pred, Arity]),
        Kernels = [Key-Kernel|RestKernels]
    ;   Kernels = RestKernels
    ),
    detect_kernels(Rest, RestKernels).

%% compute_base_pcs(+Predicates, -BasePCMap)
%  Compute global start PCs for each predicate, matching the PC
%  assignment in compile_predicates_merged/4. Returns a list of
%  "pred/arity"-StartPC pairs.
compute_base_pcs(Predicates, Map) :-
    compute_base_pcs_(Predicates, 1, Map).

compute_base_pcs_([], _, []).
compute_base_pcs_([PI|Rest], StartPC, [Key-StartPC|RestMap]) :-
    (   PI = _Mod:Pred/Arity -> true ; PI = Pred/Arity ),
    format(atom(Key), '~w/~w', [Pred, Arity]),
    wam_haskell_predicate_wamcode(PI, WamCode),
    count_wam_instructions(WamCode, Count),
    NextPC is StartPC + Count,
    compute_base_pcs_(Rest, NextPC, RestMap).

count_wam_instructions(WamCode, Count) :-
    atom_string(WamCode, S),
    split_string(S, "\n", "", Lines),
    include(is_wam_instruction_line, Lines, InstrLines),
    length(InstrLines, Count).

is_wam_instruction_line(Line) :-
    split_string(Line, "", " \t", [Trimmed]),
    Trimmed \== "",
    \+ sub_string(Trimmed, _, 1, 0, ":").

% ============================================================================
% Haskell WAM Runtime Data Types
% ============================================================================
%
% Generated Haskell code uses these types:
%
%   data Value = Atom String | Integer Int | Float Double
%              | VList [Value] | Str String [Value]
%              | Unbound String | Ref Int
%              deriving (Eq, Ord, Show)
%
%   data WamState = WamState
%     { wsPC        :: !Int
%     , wsRegs      :: !(Map String Value)    -- A/X registers
%     , wsStack     :: ![EnvFrame]            -- environment frames
%     , wsHeap      :: ![Value]               -- term construction
%     , wsTrail     :: ![TrailEntry]           -- binding history
%     , wsCP        :: !Int                    -- continuation pointer
%     , wsCPs       :: ![ChoicePoint]          -- choice point stack
%     , wsBindings  :: !(Map String Value)     -- variable bindings
%     , wsCutBar    :: !Int                    -- cut barrier
%     }
%
%   data EnvFrame = EnvFrame !Int !(Map String Value)  -- saved CP + Y-regs
%
%   data TrailEntry = TrailEntry !String !(Maybe Value)
%
%   data ChoicePoint = ChoicePoint
%     { cpNextPC   :: !Int
%     , cpRegs     :: !(Map String Value)
%     , cpStack    :: ![EnvFrame]
%     , cpCP       :: !Int
%     , cpTrailLen :: !Int
%     , cpHeapLen  :: !Int
%     , cpBindings :: !(Map String Value)     -- O(1) snapshot!
%     , cpCutBar   :: !Int
%     }
%
% The critical insight: Map String Value uses structural sharing.
% When a ChoicePoint saves cpBindings = wsBindings state, no data is copied.
% Both point to the same tree. Mutations create new nodes only along the
% modified path (O(log n) per insert). Backtracking = swap the reference.

% ============================================================================
% PHASE 1: WAM Instruction → Haskell Expression
% ============================================================================

%% wam_to_haskell(+Instruction, -HaskellExpr)
%  Translates a single WAM instruction to a Haskell state transformation.
%  Each instruction is a function: WamState -> Maybe WamState
%  Nothing = failure, Just s = success with new state.

wam_to_haskell(get_constant(C, Ai), Code) :-
    format(string(Code),
'  let val = Map.lookup "~w" (wsRegs s)
  in case val of
    Just v | v == ~w -> Just (s { wsPC = wsPC s + 1 })
    Just (Unbound var) -> Just (s { wsPC = wsPC s + 1
                                  , wsRegs = Map.insert "~w" ~w (wsRegs s)
                                  , wsBindings = Map.insert var ~w (wsBindings s)
                                  , wsTrail = TrailEntry ("__binding__" ++ var) (Map.lookup var (wsBindings s)) : wsTrail s
                                  })
    _ -> Nothing', [Ai, C, Ai, C, C]).

wam_to_haskell(get_variable(Xn, Ai), Code) :-
    format(string(Code),
'  case Map.lookup "~w" (wsRegs s) of
    Just val -> let derefed = derefVar (wsBindings s) val
                    s1 = putReg "~w" derefed s
                in Just (s1 { wsPC = wsPC s + 1 })
    Nothing -> Nothing', [Ai, Xn]).

wam_to_haskell(put_value(Xn, Ai), Code) :-
    format(string(Code),
'  case getReg "~w" s of
    Just val -> Just (s { wsPC = wsPC s + 1
                        , wsRegs = Map.insert "~w" val (wsRegs s)
                        })
    Nothing -> Nothing', [Xn, Ai]).

wam_to_haskell(put_variable(Xn, Ai), Code) :-
    format(string(Code),
'  let var = Unbound ("_V" ++ show (wsPC s))
      s1 = putReg "~w" var s
  in Just (s1 { wsPC = wsPC s + 1
              , wsRegs = Map.insert "~w" var (wsRegs s1)
              })', [Xn, Ai]).

wam_to_haskell(put_constant(C, Ai), Code) :-
    format(string(Code),
'  Just (s { wsPC = wsPC s + 1
           , wsRegs = Map.insert "~w" ~w (wsRegs s)
           })', [Ai, C]).

wam_to_haskell(call(Pred, _Arity), Code) :-
    format(string(Code),
'  Just (s { wsPC = lookupLabel "~w" s
           , wsCP = wsPC s + 1
           })', [Pred]).

wam_to_haskell(proceed, Code) :-
    Code = '  let ret = wsCP s
  in if ret == 0 then Just (s { wsPC = 0 })  -- halt
     else Just (s { wsPC = ret, wsCP = 0 })'.

wam_to_haskell(allocate, Code) :-
    Code = '  let frame = EnvFrame (wsCP s) Map.empty
  in Just (s { wsPC = wsPC s + 1
             , wsStack = frame : wsStack s
             , wsCutBar = length (wsCPs s)
             })'.

wam_to_haskell(deallocate, Code) :-
    Code = '  case wsStack s of
    (EnvFrame oldCP _ : rest) -> Just (s { wsPC = wsPC s + 1
                                         , wsStack = rest
                                         , wsCP = oldCP
                                         })
    _ -> Nothing'.

wam_to_haskell(try_me_else(Label), Code) :-
    format(string(Code),
'  let cp = ChoicePoint
        { cpNextPC   = lookupLabel "~w" s
        , cpRegs     = wsRegs s       -- O(1): shared reference
        , cpStack    = wsStack s      -- O(1): shared reference
        , cpCP       = wsCP s
        , cpTrailLen = length (wsTrail s)
        , cpHeapLen  = length (wsHeap s)
        , cpBindings = wsBindings s   -- O(1): shared reference
        , cpCutBar   = wsCutBar s
        }
  in Just (s { wsPC = wsPC s + 1
             , wsCPs = cp : wsCPs s
             })', [Label]).

wam_to_haskell(trust_me, Code) :-
    Code = '  case wsCPs s of
    (_ : rest) -> Just (s { wsPC = wsPC s + 1, wsCPs = rest })
    [] -> Nothing'.

wam_to_haskell(retry_me_else(Label), Code) :-
    format(string(Code),
'  case wsCPs s of
    (cp : rest) -> let cp'' = cp { cpNextPC = lookupLabel "~w" s }
                   in Just (s { wsPC = wsPC s + 1
                              , wsCPs = cp'' : rest
                              })
    [] -> Nothing', [Label]).

wam_to_haskell(builtin_call('!/0', 0), Code) :-
    Code = '  Just (s { wsPC = wsPC s + 1
             , wsCPs = take (wsCutBar s) (wsCPs s)
             })'.

wam_to_haskell(builtin_call('is/2', 2), Code) :-
    Code = '  let expr = derefVar (wsBindings s) $ fromMaybe (Integer 0) (Map.lookup "A2" (wsRegs s))
      result = evalArith (wcInternTable ctx) (wsBindings s) expr
      lhs = derefVar (wsBindings s) <$> Map.lookup "A1" (wsRegs s)
  in case (lhs, result) of
    (Just (Unbound var), Just r) ->
      let val = if fromIntegral (round r) == r then Integer (round r) else Float r
      in Just (s { wsPC = wsPC s + 1
                 , wsRegs = Map.insert "A1" val (wsRegs s)
                 , wsBindings = Map.insert var val (wsBindings s)
                 , wsTrail = TrailEntry ("__binding__" ++ var) (Map.lookup var (wsBindings s)) : wsTrail s
                 })
    (Just (Integer n), Just r) | fromIntegral n == r -> Just (s { wsPC = wsPC s + 1 })
    (Just (Float f), Just r) | f == r -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing'.

wam_to_haskell(builtin_call('length/2', 2), Code) :-
    Code = '  let listVal = derefVar (wsBindings s) $ fromMaybe (VList []) (Map.lookup "A1" (wsRegs s))
      len = case listVal of VList items -> length items ; _ -> -1
      lhs = derefVar (wsBindings s) <$> Map.lookup "A2" (wsRegs s)
  in if len < 0 then Nothing
     else case lhs of
       Just (Unbound var) ->
         let val = Integer len
         in Just (s { wsPC = wsPC s + 1
                    , wsRegs = Map.insert "A2" val (wsRegs s)
                    , wsBindings = Map.insert var val (wsBindings s)
                    , wsTrail = TrailEntry ("__binding__" ++ var) (Map.lookup var (wsBindings s)) : wsTrail s
                    })
       Just (Integer n) | n == len -> Just (s { wsPC = wsPC s + 1 })
       _ -> Nothing'.

wam_to_haskell(builtin_call('</2', 2), Code) :-
    Code = '  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> Map.lookup "A1" (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> Map.lookup "A2" (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | a < b -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing'.

% Negation-as-failure: fast path for member/2
wam_to_haskell(builtin_call('\\+/1', 1), Code) :-
    Code = '  case derefHeap (wsHeap s) =<< Map.lookup "A1" (wsRegs s) of
    Just (Str "member/2" [needle, haystack]) ->
      let needle'' = derefVar (wsBindings s) needle
          haystack'' = derefVar (wsBindings s) haystack
          found = case haystack'' of
            VList items -> any (\\item -> derefVar (wsBindings s) item == needle'') items
            _ -> False
      in if found then Nothing  -- member succeeded, \\+ fails
         else Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing  -- unsupported goal'.

% ============================================================================
% PHASE 2: Backtrack Function
% ============================================================================

backtrack_haskell(Code) :-
    Code = '-- | Restore state from the top choice point.
-- Dispatches: aggregate frame -> finalize, builtin -> resumeBuiltin, normal -> restore.
backtrack :: WamState -> Maybe WamState
backtrack s = case wsCPs s of
  [] -> Nothing
  (cp : rest) ->
    -- 1. Aggregate frame: finalize
    case cpAggFrame cp of { Just af -> finalizeAggregate (afReturnPC af) s; Nothing ->
    -- 2. Builtin state: resume (fact_retry etc.)
    case cpBuiltin cp of { Just bs -> resumeBuiltin bs cp rest s; Nothing ->
    -- 3. Normal: restore from CP
    let trailLen = cpTrailLen cp
        diff = wsTrailLen s - trailLen
        newEntries = reverse $ take diff (wsTrail s)
        restoredBindings = foldl'' undoBinding (cpBindings cp) newEntries
    in Just s { wsPC       = cpNextPC cp
              , wsRegs     = cpRegs cp
              , wsStack    = cpStack cp
              , wsCP       = cpCP cp
              , wsTrail    = drop diff (wsTrail s)
              , wsTrailLen = trailLen
              , wsHeap     = take (cpHeapLen cp) (wsHeap s)
              , wsHeapLen  = cpHeapLen cp
              , wsBindings = restoredBindings
              , wsCutBar   = cpCutBar cp
              } } }
  where
    undoBinding bindings (TrailEntry vid mOld) =
      case mOld of
        Just old -> IM.insert vid old bindings
        Nothing  -> IM.delete vid bindings

-- | Resume a builtin choice point. Tries next match, updates or pops CP.
resumeBuiltin :: BuiltinState -> ChoicePoint -> [ChoicePoint] -> WamState -> Maybe WamState
resumeBuiltin (FactRetry _ [] _) _ rest s =
  backtrack (s { wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
resumeBuiltin (FactRetry vid (vId:vs) retPC) cp rest s =
  let newBindings = IM.insert vid (Atom vId) (cpBindings cp)
      newRegs = IM.insert 2 (Atom vId) (cpRegs cp)
      newCPs = case vs of
        [] -> rest
        _  -> cp { cpBuiltin = Just (FactRetry vid vs retPC) } : rest
      diff = wsTrailLen s - cpTrailLen cp
  in Just s { wsPC = retPC, wsRegs = newRegs, wsStack = cpStack cp
            , wsCP = cpCP cp
            , wsTrail = drop diff (wsTrail s)
            , wsTrailLen = cpTrailLen cp
            , wsHeap = take (cpHeapLen cp) (wsHeap s)
            , wsHeapLen = cpHeapLen cp
            , wsBindings = newBindings, wsCutBar = cpCutBar cp, wsCPs = newCPs }
resumeBuiltin (HopsRetry _ [] _) _ rest s =
  backtrack (s { wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
resumeBuiltin (HopsRetry vid (h:hs) retPC) cp rest s =
  let newBindings = IM.insert vid (Integer (fromIntegral h)) (cpBindings cp)
      newRegs = IM.insert 3 (Integer (fromIntegral h)) (cpRegs cp)
      newCPs = case hs of
        [] -> rest
        _  -> cp { cpBuiltin = Just (HopsRetry vid hs retPC) } : rest
      diff = wsTrailLen s - cpTrailLen cp
  in Just s { wsPC = retPC, wsRegs = newRegs, wsStack = cpStack cp
            , wsCP = cpCP cp
            , wsTrail = drop diff (wsTrail s)
            , wsTrailLen = cpTrailLen cp
            , wsHeap = take (cpHeapLen cp) (wsHeap s)
            , wsHeapLen = cpHeapLen cp
            , wsBindings = newBindings, wsCutBar = cpCutBar cp, wsCPs = newCPs }

-- Multi-output FFI retry: each remaining tuple is already a list of
-- wrapped Values matching outRegs/outVars in order.
resumeBuiltin (FFIStreamRetry _ _ [] _) _ rest s =
  backtrack (s { wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
resumeBuiltin (FFIStreamRetry outRegs outVars (tuple:rest_tuples) retPC) cp rest s =
  let -- Insert each (reg, value) from the tuple into the registers.
      newRegs = foldr (\\(rN, v) m -> IM.insert rN v m) (cpRegs cp)
                      (zip outRegs tuple)
      -- Insert each (varId, value) into bindings, skipping varId = -1
      -- (meaning the output was originally bound, so no binding update).
      newBindings = foldr (\\(vid, v) m ->
                             if vid == -1 then m else IM.insert vid v m)
                          (cpBindings cp)
                          (zip outVars tuple)
      newCPs = case rest_tuples of
        [] -> rest
        _  -> cp { cpBuiltin = Just (FFIStreamRetry outRegs outVars rest_tuples retPC) } : rest
      diff = wsTrailLen s - cpTrailLen cp
  in Just s { wsPC = retPC, wsRegs = newRegs, wsStack = cpStack cp
            , wsCP = cpCP cp
            , wsTrail = drop diff (wsTrail s)
            , wsTrailLen = cpTrailLen cp
            , wsHeap = take (cpHeapLen cp) (wsHeap s)
            , wsHeapLen = cpHeapLen cp
            , wsBindings = newBindings, wsCutBar = cpCutBar cp, wsCPs = newCPs }

-- Phase F2: FactStream resume — iterate through inline fact tuples.
-- Each (a1, a2) pair is unified against registers A1/A2. Variable IDs
-- var1/var2 indicate which bindings to update (-1 = skip, already bound).
resumeBuiltin (FactStream _ _ [] _) _ rest s =
  backtrack (s { wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
resumeBuiltin (FactStream var1 var2 ((a1,a2):rows) retPC) cp rest s =
  let newRegs0 = IM.insert 1 (Atom a1) (cpRegs cp)
      newRegs  = IM.insert 2 (Atom a2) newRegs0
      newBindings0 = if var1 == -1 then cpBindings cp
                     else IM.insert var1 (Atom a1) (cpBindings cp)
      newBindings  = if var2 == -1 then newBindings0
                     else IM.insert var2 (Atom a2) newBindings0
      newCPs = case rows of
        [] -> rest
        _  -> cp { cpBuiltin = Just (FactStream var1 var2 rows retPC) } : rest
      diff = wsTrailLen s - cpTrailLen cp
  in Just s { wsPC = retPC, wsRegs = newRegs, wsStack = cpStack cp
            , wsCP = cpCP cp
            , wsTrail = drop diff (wsTrail s)
            , wsTrailLen = cpTrailLen cp
            , wsHeap = take (cpHeapLen cp) (wsHeap s)
            , wsHeapLen = cpHeapLen cp
            , wsBindings = newBindings, wsCutBar = cpCutBar cp, wsCPs = newCPs }

-- | Backtrack skipping past the aggregate_frame CP. If the top CP is
-- an aggregate frame, return Nothing (inner solutions exhausted).
-- Otherwise, normal backtrack.
backtrackInner :: Int -> WamState -> Maybe WamState
backtrackInner returnPC s = case wsCPs s of
  (cp : _)
    | Just _ <- cpAggFrame cp -> Nothing  -- reached aggregate frame = done
    | otherwise -> backtrack s
  [] -> Nothing

-- | Finalize an aggregate: pop CPs to the aggregate frame, apply the
-- aggregation function, bind the result register.
-- | Update only the nearest aggregate frame CP with returnPC. O(k) where
-- k is the number of inner CPs above the aggregate frame, not O(n) over all CPs.
updateNearestAggFrame :: Int -> [ChoicePoint] -> [ChoicePoint]
updateNearestAggFrame _ [] = []
updateNearestAggFrame rpc (cp:rest) = case cpAggFrame cp of
  Just af -> cp { cpAggFrame = Just af { afReturnPC = rpc } } : rest
  Nothing -> cp : updateNearestAggFrame rpc rest

finalizeAggregate :: Int -> WamState -> Maybe WamState
finalizeAggregate returnPC s = go (wsCPs s)
  where
    go [] = Nothing
    go (cp : rest) = case cpAggFrame cp of
      Just (AggFrame typ _valReg resReg _ _) ->
        let accum = reverse (wsAggAccum s)
            result = applyAggregation typ accum
            -- Restore the CP snapshot state so we can read Y-registers
            -- from the stack (cpRegs only has A/X registers).
            cpState = s { wsRegs = cpRegs cp, wsStack = cpStack cp
                        , wsBindings = cpBindings cp }
            resVal = derefVar (cpBindings cp) <$> getReg resReg cpState
            -- Restore trail to the CP snapshot (drop entries added since)
            diff = wsTrailLen s - cpTrailLen cp
            restoredTrail = drop diff (wsTrail s)
            (finalRegs, finalBindings, finalStack, finalTrail, finalTrailLen) = case resVal of
              Just (Unbound vid) ->
                ( IM.insert resReg result (cpRegs cp)
                , IM.insert vid result (cpBindings cp)
                , putRegStack resReg result (cpStack cp)
                , TrailEntry vid (IM.lookup vid (cpBindings cp)) : restoredTrail
                , cpTrailLen cp + 1
                )
              _ -> (cpRegs cp, cpBindings cp, cpStack cp, restoredTrail, cpTrailLen cp)
        in Just s { wsPC = returnPC
                  , wsRegs = finalRegs
                  , wsStack = finalStack
                  , wsBindings = finalBindings
                  , wsTrail = finalTrail
                  , wsTrailLen = finalTrailLen
                  , wsHeap = take (cpHeapLen cp) (wsHeap s)
                  , wsHeapLen = cpHeapLen cp
                  , wsCP = cpCP cp
                  , wsCPs = rest
                  , wsCPsLen = wsCPsLen s - 1
                  , wsAggAccum = []
                  }
      Nothing -> go rest  -- skip non-aggregate CPs
    putRegStack rid val [] = []
    putRegStack rid val (EnvFrame ecp yregs : rest) =
      EnvFrame ecp (IM.insert rid val yregs) : rest
    putRegStack rid val (x : rest) = x : putRegStack rid val rest

-- ============================================================================
-- Phase 4.2: Intra-query parallel fork at ParTryMeElse
-- ============================================================================

-- | Entry point for ParTryMeElse execution. Picks fork vs sequential.
-- Accepts either a Left label (pre-resolution) or Right targetPC
-- (post-resolution) for the else branch. The "this branch" always
-- starts at wsPC + 1 regardless of which variant fired.
-- | Phase 4.5: minimum branch count below which the fork is not worth
-- the spark overhead. With fewer than this many branches, the fork
-- falls back to sequential TryMeElse. Default 3: a 2-clause predicate
-- (like category_ancestor base+recursive) stays sequential; a
-- multi-clause predicate with 3+ alternatives forks.
--
-- Rationale: parMap rdeepseq has fixed overhead per spark (~5-10μs on
-- GHC 9.x). With 2 branches where one is trivial, the overhead exceeds
-- the benefit. With 3+ balanced branches, the amortized overhead per
-- branch drops below the per-branch work.
forkMinBranches :: Int
forkMinBranches = 3

forkOrSequential :: WamContext -> WamState -> Either String Int -> Maybe WamState
forkOrSequential !ctx s elseTarget =
  case currentAggMergeStrategy s of
    Just ms | isForkableStrategy ms ->
      let elsePC = case elseTarget of
            Right pc -> pc
            Left lbl -> fromMaybe (-1) (Map.lookup lbl (wcLabels ctx))
      in if elsePC > 0
         then let branches = enumerateParBranches ctx (wsPC s) elsePC
              in if length branches >= forkMinBranches
                 then Just (forkParBranches ctx s ms elsePC)
                 else fallback  -- too few branches; overhead > benefit
         else fallback
    _ -> fallback
  where
    fallback = case elseTarget of
      Left lbl -> step ctx s (TryMeElse lbl)
      Right pc -> step ctx s (TryMeElsePc pc)

-- | Locate the nearest surrounding aggregate frame and return its
-- merge strategy. Returns Nothing when no aggregate frame is active.
currentAggMergeStrategy :: WamState -> Maybe MergeStrategy
currentAggMergeStrategy s = go (wsCPs s)
  where
    go [] = Nothing
    go (cp : rest) = case cpAggFrame cp of
      Just af -> Just (afMergeStrategy af)
      Nothing -> go rest

-- | Forkable merge strategies: sum/count (Phase 4.2) +
-- findall/bag/set (Phase 4.3). Race/negation (4.4) are handled
-- outside the aggregate path and do not appear here.
isForkableStrategy :: MergeStrategy -> Bool
isForkableStrategy MergeSumInt    = True
isForkableStrategy MergeSumDouble = True
isForkableStrategy MergeCount     = True
isForkableStrategy MergeFindall   = True
isForkableStrategy MergeBag       = True
isForkableStrategy MergeSet       = True
isForkableStrategy _              = False

-- | Enumerate the entry PCs of every branch in a Par* choice-point
-- chain. The chain is laid out as:
--
--     ParTryMeElse  L1   <-- starting at parPC (wsPC s)
--     <branch 0 body>
--   L1:
--     ParRetryMeElse L2
--     <branch 1 body>
--   L2:
--     ParTrustMe
--     <branch N body>
--
-- Each branch''s body begins at `chainOpPC + 1`. We walk the chain by
-- following the else-label of each non-terminal op. Returns the entry
-- PC of every branch in chain order.
enumerateParBranches :: WamContext -> Int -> Int -> [Int]
enumerateParBranches ctx parPC elsePC =
    (parPC + 1) : collectRest elsePC
  where
    (lo, hi) = bounds (wcCode ctx)
    collectRest pc
      | pc < lo || pc > hi = []  -- safety: malformed chain
      | otherwise = case wcCode ctx ! pc of
          ParRetryMeElse nextLabel ->
            (pc + 1) : collectRest (fromMaybe (-1) (Map.lookup nextLabel (wcLabels ctx)))
          ParRetryMeElsePc nextPC ->
            (pc + 1) : collectRest nextPC
          ParTrustMe -> [pc + 1]
          -- Pre-Par variants can appear if someone mixed sequential
          -- and parallel chain entries. Treat them as chain
          -- terminators for safety — the fork still covers everything
          -- up to that point.
          RetryMeElse _   -> []
          RetryMeElsePc _ -> []
          TrustMe         -> []
          _ -> []

-- | Run one branch of a forked Par* chain. Starts from the given
-- branch entry PC with a fresh wsAggAccum, reuses the parent''s
-- bindings / CPs / trail. Runs until the branch''s own sub-solutions
-- exhaust. Returns the values the branch contributed to the
-- aggregate — the parent merges these across branches.
--
-- Key invariant: when the branch''s EndAggregate would fire
-- finalizeAggregate (i.e. the outer aggregate CP is next to pop), we
-- instead *stop* and return wsAggAccum. The fork driver then merges
-- all branches'' contributions and calls finalizeAggregate once at
-- the outer level.
runBranchForFork :: WamContext -> WamState -> Int -> [Value]
runBranchForFork !ctx !parent !branchPC =
    let branchInit = parent
          { wsPC = branchPC
          , wsAggAccum = []
          -- Protect parent CPs from being removed by !/0 inside the
          -- branch. The branch''s wsCutBar is set to the parent''s
          -- current CP depth so only CPs the branch itself creates
          -- can be cut. Without this, a clause like
          --   p(…) :- max_depth(M), length(V,D), D<M, !, …
          -- would pop the parent''s aggregate-frame CP.
          , wsCutBar = wsCPsLen parent
          }
    in runBranchLoop branchInit
  where
    runBranchLoop !s
      | wsPC s < fst (bounds (wcCode ctx)) = wsAggAccum s
      | wsPC s > snd (bounds (wcCode ctx)) = wsAggAccum s
      | otherwise =
          let instr = wcCode ctx ! wsPC s
          in case instr of
               EndAggregate valReg ->
                 let val = derefVar (wsBindings s) $
                           fromMaybe (Integer 0) (getReg valReg s)
                     s1 = s { wsAggAccum = val : wsAggAccum s
                            , wsPC = wsPC s + 1 }
                 -- Prefer backtrackInner: if the branch has more
                 -- internal solutions, keep exploring. Otherwise the
                 -- branch is exhausted — return its contribution
                 -- without finalizing the outer aggregate.
                 in case backtrackInner (wsPC s + 1) s1 of
                      Just s2 -> runBranchLoop s2
                      Nothing -> wsAggAccum s1
               -- Suppress nested forks: redirect Par* to sequential
               -- equivalents inside a branch. Only the OUTERMOST
               -- ParTryMeElse (the one that triggered forkParBranches)
               -- actually forks; inner recursive calls to the same
               -- predicate use sequential choice points. Without this,
               -- recursion depth D with branching factor B creates
               -- B^D nested parMap sparks — exponential explosion.
               _ -> let seqInstr = case instr of
                         ParTryMeElse lbl   -> TryMeElse lbl
                         ParTryMeElsePc p   -> TryMeElsePc p
                         ParRetryMeElse lbl -> RetryMeElse lbl
                         ParRetryMeElsePc p -> RetryMeElsePc p
                         ParTrustMe         -> TrustMe
                         other              -> other
                    in case step ctx s seqInstr of
                         Just s2 -> runBranchLoop s2
                         Nothing ->
                           -- Custom backtrack: if the top CP has an
                           -- aggregate frame, DON''T call finalizeAggregate
                           -- (which would clear wsAggAccum). Instead,
                           -- return our accumulated values — the branch
                           -- is done. Without this, the standard
                           -- backtrack function wipes wsAggAccum by
                           -- calling finalizeAggregate when it hits the
                           -- aggregate-frame CP.
                           case wsCPs s of
                             (cp : _) | Just _ <- cpAggFrame cp ->
                               wsAggAccum s
                             _ -> case backtrack s of
                               Just s3 -> runBranchLoop s3
                               Nothing -> wsAggAccum s

-- | Fork every branch of a Par* chain and merge their aggregate
-- contributions via the outer aggregate''s strategy. Returns the
-- post-finalize state (ready to resume after the outer EndAggregate).
forkParBranches :: WamContext -> WamState -> MergeStrategy -> Int -> WamState
forkParBranches !ctx !s _strategy !elsePC =
  let branchPCs = enumerateParBranches ctx (wsPC s) elsePC
      branchResults = parMap rdeepseq (runBranchForFork ctx s) branchPCs
      allValues = concat branchResults
      -- Combine into the current state''s accumulator before
      -- finalizing. finalizeAggregate''s applyAggregation folds
      -- these per the aggregate''s afType (which matches the
      -- strategy — sum folds as sum, count counts, etc.).
      combined = s { wsAggAccum = allValues ++ wsAggAccum s }
      -- finalizeAggregate wants the returnPC. For the outer aggregate
      -- this is the PC just after the matching EndAggregate. We
      -- locate it by scanning forward from wsPC s (the ParTryMeElse)
      -- for the first EndAggregate. All Par* branches share this
      -- returnPC because they share the enclosing BeginAggregate.
      retPC = findOuterEndAggregate ctx (wsPC s)
  in case finalizeAggregate retPC combined of
       Just sf -> sf
       Nothing -> combined  -- shouldn''t happen; defensive

-- | Scan forward from the given PC looking for the first EndAggregate.
-- Returns the PC immediately after it (the aggregate''s return
-- target). Returns 0 on overrun; finalizeAggregate handles that
-- gracefully via its CP walk.
findOuterEndAggregate :: WamContext -> Int -> Int
findOuterEndAggregate !ctx !startPC =
    let (_, hi) = bounds (wcCode ctx)
    in go (startPC + 1) hi
  where
    go !pc !hi
      | pc > hi   = 0
      | otherwise = case wcCode ctx ! pc of
          EndAggregate _ -> pc + 1
          _              -> go (pc + 1) hi

-- | Phase 4.4: parallel negation check with race-to-cancel.
-- Spawn each branch as an async action; the first to return True
-- (goal succeeded → negation fails) wins and all others are cancelled.
-- If all branches return False, negation succeeds. Uses
-- unsafePerformIO to keep the WAM run loop pure — safe because the
-- branches are purity-certified and the only IO effect is thread
-- management.
-- {-# NOINLINE runNegationParallel #-}
runNegationParallel :: WamContext -> WamState -> Int -> Int -> Bool
runNegationParallel !ctx !s !entryPC !elsePC =
    let branchPCs = enumerateParBranches ctx entryPC elsePC
        branchAction pc = evaluate $
          let snapshot = s { wsPC = pc + 1  -- skip past the Par* instruction
                           , wsCP = 0
                           , wsCutBar = 0 }
          in case run ctx snapshot of
               Just _  -> True
               Nothing -> False
    in if length branchPCs >= forkMinBranches
       then unsafePerformIO (raceToTrue (map branchAction branchPCs))
       else case run ctx (s { wsPC = entryPC, wsCP = 0, wsCutBar = 0 }) of
              Just _  -> True
              Nothing -> False

-- | Run a list of IO Bool actions concurrently. Returns True as soon
-- as any action returns True, cancelling all others. If every action
-- returns False, returns False. Uses waitAny to poll completed
-- asyncs and cancel to clean up.
raceToTrue :: [IO Bool] -> IO Bool
raceToTrue [] = return False
raceToTrue actions = do
    asyncs <- mapM async actions
    result <- go asyncs
    mapM_ cancel asyncs
    return result
  where
    go [] = return False
    go as = do
      (completed, val) <- waitAny as
      if val
        then return True
        else go (filter (/= completed) as)

-- | Apply aggregation function to collected values.
applyAggregation :: String -> [Value] -> Value
applyAggregation "sum" vals =
  let toNum (Integer n) = fromIntegral n
      toNum (Float f) = f
      toNum _ = 0
      s = sum (map toNum vals)
  in if fromIntegral (round s :: Int) == s then Integer (round s) else Float s
applyAggregation "count" vals = Integer (length vals)
applyAggregation "collect" vals = VList vals
applyAggregation "bag" vals = VList vals
applyAggregation "set" vals = VList (nub vals)
applyAggregation _ vals = VList vals

-- ============================================================================
-- Foreign Function Interface: native Haskell implementations of expensive
-- recursive predicates. Auto-generated from kernel detection.
-- ============================================================================

{{kernel_functions}}

-- | Execute a foreign predicate call. Computes all results natively,
-- returns first result with CPs for the rest.
-- | Indexed fact dispatch for 2-arg facts via BuiltinState CP.
-- O(1) Map lookup, first match returned, FactRetry CP for the rest.
callIndexedFact2 :: WamContext -> String -> WamState -> Maybe WamState
callIndexedFact2 !ctx pred s =
  let basePred = takeWhile (/= ''/'') pred
      retPC = wsCP s
  in case Map.lookup basePred (wcForeignFacts ctx) of
    Nothing -> Nothing
    Just factIndex ->
      let tbl = wcInternTable ctx
          a1 = derefVar (wsBindings s) $ fromMaybe (Atom atomEmpty) (IM.lookup 1 (wsRegs s))
          a2 = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 2 (wsRegs s))
      in case a1 of
        Atom aid -> case Map.lookup (lookupAtom tbl aid) factIndex of
          Just (v:rest) -> case a2 of
            Unbound vid ->
              let vId = internAtomPure tbl v
                  newRegs = IM.insert 2 (Atom vId) (wsRegs s)
                  newBindings = IM.insert vid (Atom vId) (wsBindings s)
                  newTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                  restIds = map (internAtomPure tbl) rest
                  newCPs = case restIds of
                    [] -> wsCPs s  -- single match, no CP
                    _  -> ChoicePoint
                            { cpNextPC = retPC, cpRegs = wsRegs s, cpStack = wsStack s
                            , cpCP = wsCP s, cpTrailLen = wsTrailLen s
                            , cpHeapLen = wsHeapLen s, cpBindings = wsBindings s
                            , cpCutBar = wsCutBar s, cpAggFrame = Nothing
                            , cpBuiltin = Just (FactRetry vid restIds retPC)
                            } : wsCPs s
                  newCPsLen = case restIds of { [] -> wsCPsLen s; _ -> wsCPsLen s + 1 }
              in Just (s { wsPC = retPC, wsRegs = newRegs, wsBindings = newBindings
                         , wsTrail = newTrail, wsTrailLen = wsTrailLen s + 1
                         , wsCPs = newCPs, wsCPsLen = newCPsLen })
            Atom existingId ->
              let vId2 = internAtomPure tbl v
                  restIds2 = map (internAtomPure tbl) rest
              in if existingId == vId2 then Just (s { wsPC = retPC })
              else case filter (== existingId) restIds2 of
                (_:_) -> Just (s { wsPC = retPC })
                [] -> Nothing
            _ -> Nothing
          _ -> Nothing
        _ -> Nothing

-- | Phase F2/F4: Stream through fact tuples for a 2-arg predicate.
-- Checks wcInlineFacts first (Phase F3 compiled literals), then falls
-- back to wcFactSources (Phase F4 external sources via FactSource).
-- The FactSource path uses unsafePerformIO to bridge IO into the pure
-- WAM interpreter — safe because fact sources are read-only after the
-- force barrier in Main.hs.
streamFacts :: WamContext -> String -> WamState -> Maybe WamState
streamFacts !ctx pred s =
  case Map.lookup pred (wcInlineFacts ctx) of
    Just rows@(_:_) -> streamFactRows rows s
    _ -> case Map.lookup pred (wcFactSources ctx) of
      Nothing -> Nothing
      Just fs ->
        let a1val = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 1 (wsRegs s))
            rows = unsafePerformIO $ case a1val of
              Atom aid -> fsLookupArg1 fs aid
              _        -> fsScan fs
        in streamFactRows rows s

-- | Core row-streaming logic shared by inline and external paths.
streamFactRows :: [(Int, Int)] -> WamState -> Maybe WamState
streamFactRows [] _ = Nothing
streamFactRows rows s =
  let retPC = wsCP s
      a1val = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 1 (wsRegs s))
      a2val = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 2 (wsRegs s))
      var1 = case a1val of { Unbound vid -> vid; _ -> -1 }
      var2 = case a2val of { Unbound vid -> vid; _ -> -1 }
      -- Filter rows by any bound arguments
      filtered = case (a1val, a2val) of
        (Atom aid, Atom bid) -> filter (\\(a, b) -> a == aid && b == bid) rows
        (Atom aid, _)       -> filter (\\(a, _) -> a == aid) rows
        (_, Atom bid)       -> filter (\\(_, b) -> b == bid) rows
        _                   -> rows
  in case filtered of
    [] -> Nothing
    ((a1,a2):rest) ->
      let newRegs = IM.insert 2 (Atom a2) $ IM.insert 1 (Atom a1) (wsRegs s)
          newBindings0 = if var1 == -1 then wsBindings s
                         else IM.insert var1 (Atom a1) (wsBindings s)
          newBindings  = if var2 == -1 then newBindings0
                         else IM.insert var2 (Atom a2) newBindings0
          newTrail0 = if var1 == -1 then wsTrail s
                      else TrailEntry var1 (IM.lookup var1 (wsBindings s)) : wsTrail s
          newTrail  = if var2 == -1 then newTrail0
                      else TrailEntry var2 (IM.lookup var2 newBindings0) : newTrail0
          trailAdded = (if var1 == -1 then 0 else 1) + (if var2 == -1 then 0 else 1)
          newCPs = case rest of
            [] -> wsCPs s
            _  -> ChoicePoint
                    { cpNextPC = retPC, cpRegs = wsRegs s, cpStack = wsStack s
                    , cpCP = wsCP s, cpTrailLen = wsTrailLen s
                    , cpHeapLen = wsHeapLen s, cpBindings = wsBindings s
                    , cpCutBar = wsCutBar s, cpAggFrame = Nothing
                    , cpBuiltin = Just (FactStream var1 var2 rest retPC)
                    } : wsCPs s
          newCPsLen = case rest of { [] -> wsCPsLen s; _ -> wsCPsLen s + 1 }
      in Just (s { wsPC = retPC, wsRegs = newRegs, wsBindings = newBindings
                 , wsTrail = newTrail, wsTrailLen = wsTrailLen s + trailAdded
                 , wsCPs = newCPs, wsCPsLen = newCPsLen })

-- | Phase F4: Build a FactSource from a TSV file with lazy IO.
-- The file is parsed lazily on first fsScan/fsLookupArg1 call.
-- The index (IntMap grouping by arg1) is built on first demand.
tsvFactSource :: InternTable -> FilePath -> IO FactSource
tsvFactSource tbl path = do
    content <- readFile path  -- lazy IO
    let ls = drop 1 (lines content)  -- skip header
        rows = [ (internAtomPure tbl a, internAtomPure tbl b)
               | l <- ls, not (null l)
               , let (a, rest) = break (== ''\\t'') l
               , not (null rest)
               , let b = drop 1 rest  -- skip the tab
               , not (null b)
               ]
        index = IM.fromListWith (++) [(k, [(k, v)]) | (k, v) <- rows]
    return FactSource
      { fsScan       = return rows
      , fsLookupArg1 = \\key -> return $ IM.findWithDefault [] key index
      , fsClose      = return ()
      }

-- | Phase F4: Wrap an existing strict IntMap as a FactSource.
-- Used to bridge the current eager-load path into the FactSource interface.
-- | Phase B1: Wrap an IntMap as an EdgeLookup (default, always available).
intMapEdgeLookup :: IM.IntMap [Int] -> EdgeLookup
intMapEdgeLookup im key = IM.findWithDefault [] key im

intMapFactSource :: IM.IntMap [Int] -> FactSource
intMapFactSource im = FactSource
  { fsScan       = return [(k, v) | (k, vs) <- IM.toList im, v <- vs]
  , fsLookupArg1 = \\key -> return $ map (\\v -> (key, v)) $ IM.findWithDefault [] key im
  , fsClose      = return ()
  }

{{execute_foreign}}

-- | Bind an output register to a value WITHOUT advancing PC.
-- Used by term-inspection builtins that need to bind multiple
-- output positions in sequence before a single PC advance at the
-- end of the case. If the register is already bound to an equal
-- value, succeeds without side-effects; if it''s bound to an
-- unequal value, fails. Otherwise binds and trails.
bindOutput :: Int -> Value -> WamState -> Maybe WamState
bindOutput reg val s = case derefVar (wsBindings s) <$> IM.lookup reg (wsRegs s) of
  Just (Unbound vid) -> Just (s
    { wsRegs = IM.insert reg val (wsRegs s)
    , wsBindings = IM.insert vid val (wsBindings s)
    , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
    , wsTrailLen = wsTrailLen s + 1
    })
  Just existing | existing == val -> Just s
  _ -> Nothing

-- | copy_term/2 walker: recursively copies a Value, mapping each
-- distinct source variable id to exactly one fresh destination
-- variable id to preserve sharing within the copy. Threaded state
-- is (counter, varMap). Atomic values clone as-is.
copyTermWalk :: Int -> IM.IntMap Int -> Value -> (Value, Int, IM.IntMap Int)
copyTermWalk !c !m (Unbound vid) = case IM.lookup vid m of
  Just nv -> (Unbound nv, c, m)
  Nothing -> (Unbound c, c + 1, IM.insert vid c m)
copyTermWalk !c !m (Str fn args) =
  let (newArgs, c1, m1) = copyTermArgs c m args
  in (Str fn newArgs, c1, m1)
copyTermWalk !c !m (VList items) =
  let (newItems, c1, m1) = copyTermArgs c m items
  in (VList newItems, c1, m1)
copyTermWalk !c !m v = (v, c, m)

copyTermArgs :: Int -> IM.IntMap Int -> [Value] -> ([Value], Int, IM.IntMap Int)
copyTermArgs !c !m [] = ([], c, m)
copyTermArgs !c !m (x : xs) =
  let (x1, c1, m1) = copyTermWalk c m x
      (xs1, c2, m2) = copyTermArgs c1 m1 xs
  in (x1 : xs1, c2, m2)

-- | Bind an unbound variable, trailing its previous value.
bindUnbound :: Int -> Value -> WamState -> WamState
bindUnbound vid v s =
  s { wsBindings = IM.insert vid v (wsBindings s)
    , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
    , wsTrailLen = wsTrailLen s + 1
    }

-- | PC-neutral structural unification. Recurses into compound terms
-- (Str / VList), binding and trailing unbound subterms, so a freshly
-- constructed list unifies with an already-ground one. A cons cell may
-- appear as VList or as Str atomDot (codegen normalises the [|]/2
-- functor to atomDot), and [] as Atom atomNil or VList []; all denote
-- the same list structure.
unifyTerms :: Value -> Value -> WamState -> Maybe WamState
unifyTerms x y s =
  unifyDeref (derefVar (wsBindings s) x) (derefVar (wsBindings s) y) s

unifyDeref :: Value -> Value -> WamState -> Maybe WamState
unifyDeref a b s | a == b = Just s
unifyDeref (Unbound vid) v s = Just (bindUnbound vid v s)
unifyDeref v (Unbound vid) s = Just (bindUnbound vid v s)
unifyDeref (Str f1 a1) (Str f2 a2) s
  | f1 == f2 && length a1 == length a2 = unifyArgList a1 a2 s
unifyDeref (VList xs) (VList ys) s
  | length xs == length ys = unifyArgList xs ys s
unifyDeref (VList (x : xs)) (Str f [h, t]) s
  | f == atomDot = unifyTerms x h s >>= unifyTerms (listTailVal xs) t
unifyDeref (Str f [h, t]) (VList (x : xs)) s
  | f == atomDot = unifyTerms h x s >>= unifyTerms t (listTailVal xs)
unifyDeref (VList []) (Atom n) s | n == atomNil = Just s
unifyDeref (Atom n) (VList []) s | n == atomNil = Just s
unifyDeref _ _ _ = Nothing

unifyArgList :: [Value] -> [Value] -> WamState -> Maybe WamState
unifyArgList [] [] s = Just s
unifyArgList (x : xs) (y : ys) s = unifyTerms x y s >>= unifyArgList xs ys
unifyArgList _ _ _ = Nothing

listTailVal :: [Value] -> Value
listTailVal [] = Atom atomNil
listTailVal xs = VList xs

-- | Unify two values, binding unbound variables; advances PC on success
-- (head-match contract). Delegates to the PC-neutral unifyTerms.
unifyVal :: Value -> Value -> WamState -> Maybe WamState
unifyVal a b s = case unifyTerms a b s of
  Just s2 -> Just (s2 { wsPC = wsPC s + 1 })
  Nothing -> Nothing'.

% ============================================================================
% PHASE 3: Step Function + Run Loop
% ============================================================================

step_function_haskell(Code) :-
    Code = '-- | Execute a single WAM instruction.
-- The WamContext argument is read-only and threaded through (does NOT
-- become part of any per-step record allocation).
step :: WamContext -> WamState -> Instruction -> Maybe WamState
step !ctx s (GetConstant c ai) =
  let val = derefVar (wsBindings s) <$> IM.lookup ai (wsRegs s)
  in case val of
    Just v | v == c -> Just (s { wsPC = wsPC s + 1 })
    Just (Unbound vid) ->
      Just (s { wsPC = wsPC s + 1
              , wsRegs = IM.insert ai c (wsRegs s)
              , wsBindings = IM.insert vid c (wsBindings s)
              , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
              , wsTrailLen = wsTrailLen s + 1
              })
    _ -> Nothing

step !ctx s (GetVariable xn ai) =
  case IM.lookup ai (wsRegs s) of
    Just val -> let dv = derefVar (wsBindings s) val
                in Just ((putReg xn dv s) { wsPC = wsPC s + 1 })
    Nothing -> Nothing

step !ctx s (GetValue xn ai) =
  -- Full structural unification of the register value against the
  -- X-register, via unifyVal (which advances PC on success). The old
  -- inline version only matched identity / unbound-binding, so a
  -- structurally-equal-but-differently-represented compound (e.g. a
  -- constructed list vs an already-ground one) fell through to Nothing
  -- -- the append/reverse base-case bug.
  case (IM.lookup ai (wsRegs s), getReg xn s) of
    (Just a, Just x) ->
      unifyVal (derefVar (wsBindings s) a) (derefVar (wsBindings s) x) s
    _ -> Nothing

step !ctx s (PutConstant c ai) =
  Just (s { wsPC = wsPC s + 1, wsRegs = IM.insert ai c (wsRegs s) })

step !ctx s (PutVariable xn ai) =
  let vid = wsVarCounter s
      var = Unbound vid
      s1 = putReg xn var s
  in Just (s1 { wsPC = wsPC s + 1
              , wsRegs = IM.insert ai var (wsRegs s1)
              , wsVarCounter = vid + 1
              })

step !ctx s (PutValue xn ai) =
  case getReg xn s of
    Just val -> Just (s { wsPC = wsPC s + 1, wsRegs = IM.insert ai val (wsRegs s) })
    Nothing -> Nothing

step !ctx s (PutStructure fnId ai arity) =
  let push = pushBuilderIfActive s
  in Just (push { wsPC = wsPC push + 1
                , wsBuilder = BuildStruct fnId ai arity []
                })

-- PutStructureDyn: like PutStructure but functor name and arity come
-- from registers at runtime. Used when the term shape is computed
-- dynamically (e.g., after =../2 or functor/3 with variable args).
step !ctx s (PutStructureDyn nameReg arityReg targetReg) =
  let mName = derefVar (wsBindings s) <$> getReg nameReg s
      mArity = derefVar (wsBindings s) <$> getReg arityReg s
  in case (mName, mArity) of
    (Just (Atom fnId), Just (Integer arity)) | arity >= 0 ->
      Just (s { wsPC = wsPC s + 1
              , wsBuilder = BuildStruct fnId targetReg (fromIntegral arity) []
              })
    _ -> Nothing  -- name must be an atom, arity a non-negative integer

step !ctx s (PutList ai) =
  let push = pushBuilderIfActive s
  in Just (push { wsPC = wsPC push + 1
                , wsBuilder = BuildList ai []
                })

step !ctx s (SetValue xn) =
  case getReg xn s of
    Just val -> addToBuilder val s
    Nothing -> Nothing

step !ctx s (SetVariable xn) =
  let vid = wsVarCounter s
      var = Unbound vid
      s1 = putReg xn var (s { wsVarCounter = vid + 1 })
  in addToBuilder var s1

step !ctx s (SetConstant c) =
  addToBuilder c s

-- GetStructure: read-mode if register holds matching Str, write-mode if Unbound.
step !ctx s (GetStructure fnId ai arity) =
  let push = pushBuilderIfActive s
  in case derefVar (wsBindings push) <$> IM.lookup ai (wsRegs push) of
    Just (Str fn args) | fn == fnId && length args == arity ->
      if arity == 0
      then Just (push { wsPC = wsPC push + 1 })
      else Just (push { wsPC = wsPC push + 1, wsBuilder = ReadArgs args })
    Just (VList (h : t)) | fnId == atomDot && arity == 2 ->
      let tailVal = if null t then Atom atomNil else VList t
      in Just (push { wsPC = wsPC push + 1, wsBuilder = ReadArgs [h, tailVal] })
    Just (Unbound vid) | arity == 0 ->
      let str = Str fnId []
      in Just (push { wsPC = wsPC push + 1
                    , wsRegs = IM.insert ai str (wsRegs push)
                    , wsBindings = IM.insert vid str (wsBindings push)
                    , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings push)) : wsTrail push
                    , wsTrailLen = wsTrailLen push + 1 })
    Just (Unbound _) ->
      Just (push { wsPC = wsPC push + 1
                 , wsBuilder = BuildStruct fnId ai arity [] })
    _ -> Nothing

-- GetList: read-mode if register holds VList/Str cons, write-mode if Unbound.
step !ctx s (GetList ai) =
  let push = pushBuilderIfActive s
  in case derefVar (wsBindings push) <$> IM.lookup ai (wsRegs push) of
    Just (VList (h : t)) ->
      let tailVal = if null t then Atom atomNil else VList t
      in Just (push { wsPC = wsPC push + 1, wsBuilder = ReadArgs [h, tailVal] })
    Just (Str fn [h, t]) | fn == atomDot ->
      Just (push { wsPC = wsPC push + 1, wsBuilder = ReadArgs [h, t] })
    Just (Unbound _) ->
      Just (push { wsPC = wsPC push + 1, wsBuilder = BuildList ai [] })
    _ -> Nothing

-- UnifyVariable: read-mode -> bind register to next arg; write-mode -> create fresh var.
step !ctx s (UnifyVariable xn) =
  case readNextArg s of
    Just (v, s'''') -> Just ((putReg xn v s'''') { wsPC = wsPC s + 1 })
    Nothing ->
      let vid = wsVarCounter s
          var = Unbound vid
          s1 = putReg xn var (s { wsVarCounter = vid + 1 })
      in addToBuilder var s1

-- UnifyValue: read-mode -> unify register with next arg; write-mode -> append to builder.
step !ctx s (UnifyValue xn) =
  case readNextArg s of
    Just (v, s'''') ->
      case getReg xn s of
        Just xv -> case unifyValues (derefVar (wsBindings s) v) (derefVar (wsBindings s) xv) s'''' of
          Just s2 -> Just (s2 { wsPC = wsPC s + 1 })
          Nothing -> Nothing
        Nothing -> Nothing
    Nothing ->
      case getReg xn s of
        Just val -> addToBuilder val s
        Nothing -> Nothing

-- UnifyConstant: read-mode -> unify constant with next arg; write-mode -> append to builder.
step !ctx s (UnifyConstant c) =
  case readNextArg s of
    Just (v, s'''') -> case unifyValues (derefVar (wsBindings s) v) c s'''' of
      Just s2 -> Just (s2 { wsPC = wsPC s + 1 })
      Nothing -> Nothing
    Nothing -> addToBuilder c s

-- Fast path: call has been pre-resolved to a target PC at load time.
-- No string lookup, no foreign/indexed dispatch — just a jump.
step !ctx s (CallResolved pc _arity) =
  Just (s { wsPC = pc, wsCP = wsPC s + 1 })

-- Foreign call: compile-time resolved. executeForeign is the sole dispatch
-- path — Nothing means no solutions (backtrack), never fallthrough.
step !ctx s (CallForeign pred _arity) =
  executeForeign ctx pred (s { wsCP = wsPC s + 1 })

-- Phase F2: FactStream call. Dispatches to streamFacts which iterates
-- inline fact tuples from wcInlineFacts. Nothing = no matching facts.
step !ctx s (CallFactStream pred _arity) =
  streamFacts ctx pred (s { wsCP = wsPC s + 1 })

-- ISO meta-builtins emitted as Call by the WAM compiler.  These predicate
-- names (catch/3, throw/1, is_iso/2, etc.) are not labelled predicates, so
-- normal label lookup would fail.  Route through BuiltinCall dispatch.
step !ctx s (Call pred arity) | isIsoMetaBuiltin pred =
  let sc = s { wsCP = wsPC s + 1, wsCutBar = wsCPsLen s }
  in step ctx sc (BuiltinCall pred arity)

-- Call dispatch for non-foreign, non-resolved predicates. Foreign predicates
-- are handled by CallForeign (resolved at compile time), so executeForeign
-- is NOT checked here — no ambiguity between "unhandled" and "no solutions".
step !ctx s (Call pred _arity) =
  let sc = s { wsCP = wsPC s + 1 }
  in case Map.lookup pred (wcLoweredPredicates ctx) of
    Just fn -> fn ctx sc
    Nothing -> case callIndexedFact2 ctx pred sc of
      Just sr -> Just sr
      Nothing -> case Map.lookup pred (wcLabels ctx) of
        Just pc -> Just (s { wsPC = pc, wsCP = wsPC s + 1 })
        Nothing -> Nothing

-- Jump: unconditional jump to a label (used in if-then-else compilation)
step !ctx s (Jump label) =
  case Map.lookup label (wcLabels ctx) of
    Just pc -> Just (s { wsPC = pc })
    Nothing -> Nothing

-- JumpPc: pre-resolved jump (no label lookup)
step !ctx s (JumpPc pc) = Just (s { wsPC = pc })

-- ExecutePc: pre-resolved tail call (direct PC jump, no wsCP change)
step !ctx s (ExecutePc pc) = Just (s { wsPC = pc })

-- Execute ISO meta-builtin: tail-call dispatch through BuiltinCall, then
-- convert the PC+1 advance to wsCP for proper tail-call return semantics.
step !ctx s (Execute pred) | isIsoMetaBuiltin pred =
  let arity = isoMetaBuiltinArity pred
  in case step ctx s (BuiltinCall pred arity) of
    Just sNext -> Just (sNext { wsPC = wsCP sNext })
    Nothing -> Nothing

-- Execute: tail call, like Call but without setting wsCP
step !ctx s (Execute pred) =
  case Map.lookup pred (wcLoweredPredicates ctx) of
    Just fn -> fn ctx s
    Nothing -> case callIndexedFact2 ctx pred s of
      Just sr -> Just sr
      Nothing -> case Map.lookup pred (wcLabels ctx) of
        Just pc -> Just (s { wsPC = pc })
        Nothing -> Nothing

step !ctx s Proceed =
  let ret = wsCP s
  in if ret == 0 then Just (s { wsPC = 0 })
     else Just (s { wsPC = ret, wsCP = 0 })

step !ctx s Allocate =
  let frame = EnvFrame (wsCP s) IM.empty
  in Just (s { wsPC = wsPC s + 1
             , wsStack = frame : wsStack s
             , wsCutBar = wsCPsLen s
             })

step !ctx s Deallocate =
  case wsStack s of
    (EnvFrame oldCP _ : rest) -> Just (s { wsPC = wsPC s + 1, wsStack = rest, wsCP = oldCP })
    _ -> Nothing

step !ctx s (TryMeElse label) =
  let nextPC = fromMaybe 0 $ Map.lookup label (wcLabels ctx)
      cp = ChoicePoint
        { cpNextPC   = nextPC
        , cpRegs     = wsRegs s
        , cpStack    = wsStack s
        , cpCP       = wsCP s
        , cpTrailLen = wsTrailLen s
        , cpHeapLen  = wsHeapLen s
        , cpBindings = wsBindings s
        , cpCutBar   = wsCutBar s
        , cpAggFrame = Nothing, cpBuiltin = Nothing
        }
  in Just (s { wsPC = wsPC s + 1, wsCPs = cp : wsCPs s, wsCPsLen = wsCPsLen s + 1 })

-- TrustMe / RetryMeElse: when an indexed SwitchOnConstantPc jumps
-- directly to a clause that begins with one of these (the WAM
-- emitter places labels just before Retry/Trust), there''s no
-- choice point to pop or modify — we''re committing deterministically
-- to that clause via indexed dispatch.  Treat the empty-CP case as
-- a no-op advance instead of failing, matching the F# fix from the
-- query-smoke surfaced Bug A (PR #2351 in the F# parity track).
-- Without this, `parent(ann, X)` (clause 3 reachable only via
-- indexed dispatch) returns Nothing instead of binding X = eve.
step !ctx s TrustMe =
  case wsCPs s of
    (_ : rest) -> Just (s { wsPC = wsPC s + 1, wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
    [] -> Just (s { wsPC = wsPC s + 1 })

step !ctx s (RetryMeElse label) =
  case wsCPs s of
    (cp : rest) ->
      let nextPC = fromMaybe 0 $ Map.lookup label (wcLabels ctx)
      in Just (s { wsPC = wsPC s + 1, wsCPs = cp { cpNextPC = nextPC } : rest })
    [] -> Just (s { wsPC = wsPC s + 1 })

-- Pre-resolved variants: direct PC, no label lookup
step !ctx s (TryMeElsePc nextPC) =
  let cp = ChoicePoint
        { cpNextPC   = nextPC
        , cpRegs     = wsRegs s
        , cpStack    = wsStack s
        , cpCP       = wsCP s
        , cpTrailLen = wsTrailLen s
        , cpHeapLen  = wsHeapLen s
        , cpBindings = wsBindings s
        , cpCutBar   = wsCutBar s
        , cpAggFrame = Nothing, cpBuiltin = Nothing
        }
  in Just (s { wsPC = wsPC s + 1, wsCPs = cp : wsCPs s, wsCPsLen = wsCPsLen s + 1 })

-- See TrustMe above for the rationale for the empty-CP no-op-advance.
step !ctx s (RetryMeElsePc nextPC) =
  case wsCPs s of
    (cp : rest) -> Just (s { wsPC = wsPC s + 1, wsCPs = cp { cpNextPC = nextPC } : rest })
    [] -> Just (s { wsPC = wsPC s + 1 })

-- Phase 4.1 parallel-forkable variants. For now they alias their
-- sequential counterparts — the instructions mark the predicate as
-- fork-safe but the runtime doesn''t fork yet. Phase 4.2 will split
-- these handlers off to do actual parMap-based forking at the
-- surrounding aggregate boundary.
--
-- Phase 4.2: when a ParTryMeElse fires inside a fork-compatible
-- aggregate (sum / count), we collect all N alternative branch
-- entry PCs, run each branch in parallel via `parMap rdeepseq`, then
-- merge the accumulated values via the aggregate strategy. Each
-- branch''s EndAggregate is intercepted so it appends to that
-- branch''s local wsAggAccum without finalizing the outer aggregate.
-- Falls back to the sequential TryMeElse handler when the enclosing
-- aggregate is not fork-compatible (or when there is no aggregate at
-- all).
--
-- ParRetryMeElse / ParTrustMe still delegate to their sequential
-- counterparts — once ParTryMeElse has chosen to fork, the runtime
-- never walks through those; they''re only reached if the fork
-- path bailed out to sequential.
step !ctx s (ParTryMeElse label)    = forkOrSequential ctx s (Left label)
step !ctx s (ParRetryMeElse label)  = step ctx s (RetryMeElse label)
step !ctx s ParTrustMe              = step ctx s TrustMe
step !ctx s (ParTryMeElsePc pc)     = forkOrSequential ctx s (Right pc)
step !ctx s (ParRetryMeElsePc pc)   = step ctx s (RetryMeElsePc pc)

-- SwitchOnConstantPc: indexed dispatch on A1.  Hits jump to the
-- matching clause; misses fall through to the next instruction
-- (typically TryMeElse) which then runs the linear chain.  Falling
-- through on miss (rather than returning Nothing) mirrors the WAM
-- compiler''s `tom:default` semantics — `default` labels get dropped
-- by resolveCallInstrs, so the table just lacks an entry, and falling
-- through is the right behavior.  Without this, indexed dispatch
-- fails outright on any A1 not explicitly listed in the table.
-- Matches F# Bug A fix from PR #2351 in the F# parity track.
step !ctx s (SwitchOnConstantPc table) =
  let val = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case val of
    Just (Unbound _) -> Just (s { wsPC = wsPC s + 1 })
    Just (Atom aid) -> case IM.lookup aid table of
      Just pc -> Just (s { wsPC = pc })
      Nothing -> Just (s { wsPC = wsPC s + 1 })
    Just (Integer n) -> case IM.lookup n table of
      Just pc -> Just (s { wsPC = pc })
      Nothing -> Just (s { wsPC = wsPC s + 1 })
    _ -> Just (s { wsPC = wsPC s + 1 })

step !ctx s (BuiltinCall "!/0" _) =
  -- Cut: truncate wsCPs to the barrier depth saved at clause Allocate.
  Just (s { wsPC = wsPC s + 1, wsCPs = take (wsCutBar s) (wsCPs s), wsCPsLen = wsCutBar s })

-- true/0 always succeeds; fail/0 always fails. The WAM compiler emits these
-- for if-then-else and negation bodies (negation of G compiles to
-- (G -> fail ; true)), so the lowered and interpreted paths both need them.
step !ctx s (BuiltinCall "true/0" _) =
  Just (s { wsPC = wsPC s + 1 })

step !ctx s (BuiltinCall "fail/0" _) =
  Nothing

-- CutIte: soft cut for if-then-else — pops exactly the top choice point
-- (the one pushed by try_me_else for the Else branch). Unlike !/0 which
-- truncates to wsCutBar (clause-level), this only removes the immediately
-- enclosing if-then-else CP, preserving aggregate frames and outer CPs.
step !ctx s CutIte =
  case wsCPs s of
    (_cp : rest) -> Just (s { wsPC = wsPC s + 1, wsCPs = rest, wsCPsLen = wsCPsLen s - 1 })
    [] -> Just (s { wsPC = wsPC s + 1 })  -- no CP to pop (shouldn''t happen)

-- M17 soft cut. GetLevel snapshots the current CP-stack depth into a Y
-- register (before an if-then-else / negation try_me_else); Cut truncates
-- the CP stack back to that depth at the commit site, removing the
-- ITE/negation CP AND any CPs the condition pushed above it.
step !ctx s (GetLevel reg) =
  Just (s { wsPC = wsPC s + 1, wsRegs = IM.insert reg (Integer (wsCPsLen s)) (wsRegs s) })

step !ctx s (Cut reg) =
  case IM.lookup reg (wsRegs s) of
    Just (Integer n) -> Just (s { wsPC = wsPC s + 1, wsCPs = take n (wsCPs s), wsCPsLen = n })
    _ -> Just (s { wsPC = wsPC s + 1 })

-- Type-checking builtins
step !ctx s (BuiltinCall "nonvar/1" _) =
  case derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s) of
    Just (Unbound _) -> Nothing
    Just _           -> Just (s { wsPC = wsPC s + 1 })
    Nothing          -> Nothing

step !ctx s (BuiltinCall "var/1" _) =
  case derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s) of
    Just (Unbound _) -> Just (s { wsPC = wsPC s + 1 })
    _                -> Nothing

step !ctx s (BuiltinCall "atom/1" _) =
  case derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s) of
    Just (Atom _) -> Just (s { wsPC = wsPC s + 1 })
    _             -> Nothing

step !ctx s (BuiltinCall "integer/1" _) =
  case derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s) of
    Just (Integer _) -> Just (s { wsPC = wsPC s + 1 })
    _                -> Nothing

step !ctx s (BuiltinCall "number/1" _) =
  case derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s) of
    Just (Integer _) -> Just (s { wsPC = wsPC s + 1 })
    Just (Float _)   -> Just (s { wsPC = wsPC s + 1 })
    _                -> Nothing

step !ctx s (BuiltinCall "is/2" _) =
  let expr = derefVar (wsBindings s) $ fromMaybe (Integer 0) (IM.lookup 2 (wsRegs s))
      result = evalArith (wcInternTable ctx) (wsBindings s) expr
      lhs = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case (lhs, result) of
    (Just (Unbound vid), Just r) ->
      let val = if fromIntegral (round r :: Int) == r then Integer (round r) else Float r
      in Just (s { wsPC = wsPC s + 1
                 , wsRegs = IM.insert 1 val (wsRegs s)
                 , wsBindings = IM.insert vid val (wsBindings s)
                 , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                 , wsTrailLen = wsTrailLen s + 1
                 })
    (Just (Integer n), Just r) | fromIntegral n == r -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- =/2 is term unification (the compiler emits it as a BuiltinCall rather
-- than inline get/put instructions). Route through unifyVal so it handles
-- constants, var binding, and full structural unification of compounds
-- (and advances PC on success). Without this it fell to the default
-- BuiltinCall branch and always failed (cbi_eq(foo) -> false).
step !ctx s (BuiltinCall "=/2" _) =
  case (IM.lookup 1 (wsRegs s), IM.lookup 2 (wsRegs s)) of
    (Just a, Just b) ->
      unifyVal (derefVar (wsBindings s) a) (derefVar (wsBindings s) b) s
    _ -> Nothing

-- Strict (in)equality. Previously missing from the table entirely, so
-- the shared compiler emitted BuiltinCall ==/2 and it fell through to
-- the catch-all Nothing (even X = a, X == a failed) -- the class-7 gap
-- found by the bind-through probe sweep. derefDeep makes the compare
-- structural through the binding table; distinct unbound vids stay
-- unequal, matching ISO ==/2. (Cons-spelling caveat: a VList and an
-- equivalent Str cons chain do not compare equal -- same limitation as
-- unifyVal had before its aliasing arms; acceptable for the guard use.)
step !ctx s (BuiltinCall "==/2" _) =
  case (IM.lookup 1 (wsRegs s), IM.lookup 2 (wsRegs s)) of
    (Just a, Just b)
      | derefDeep (wsBindings s) a == derefDeep (wsBindings s) b ->
          Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

step !ctx s (BuiltinCall "\\\\==/2" _) =
  case (IM.lookup 1 (wsRegs s), IM.lookup 2 (wsRegs s)) of
    (Just a, Just b)
      | derefDeep (wsBindings s) a /= derefDeep (wsBindings s) b ->
          Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

step !ctx s (BuiltinCall "length/2" _) =
  let listVal = derefVar (wsBindings s) $ fromMaybe (VList []) (IM.lookup 1 (wsRegs s))
  in case listVal of
    VList items ->
      let len = length items
          lhs = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
      in case lhs of
        Just (Unbound vid) ->
          let val = Integer len
          in Just (s { wsPC = wsPC s + 1
                     , wsRegs = IM.insert 2 val (wsRegs s)
                     , wsBindings = IM.insert vid val (wsBindings s)
                     , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                     , wsTrailLen = wsTrailLen s + 1
                     })
        Just (Integer n) | n == len -> Just (s { wsPC = wsPC s + 1 })
        _ -> Nothing
    _ -> Nothing

step !ctx s (BuiltinCall "</2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | a < b -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

step !ctx s (BuiltinCall "\\\\+/1" _) =
  let goal = IM.lookup 1 (wsRegs s) >>= derefHeap (wsHeap s)
      tbl = wcInternTable ctx
  in case goal of
    -- Fast path: \\+ member(X, L) — check functor name via reverse lookup
    Just (Str fnId [needle, haystack]) | "member" `isPrefixOf` lookupAtom tbl fnId ->
      let n = derefVar (wsBindings s) needle
          h = derefVar (wsBindings s) haystack
          found = case h of
            VList items -> any (\\item -> derefVar (wsBindings s) item == n) items
            _ -> False
      in if found then Nothing else Just (s { wsPC = wsPC s + 1 })
    -- Fast path: \\+ true always fails, \\+ fail always succeeds
    Just (Atom aid) | aid == atomTrue -> Nothing
    Just (Atom aid) | aid == atomFail -> Just (s { wsPC = wsPC s + 1 })
    -- General path: resolve the goal, snapshot-and-run.
    -- Phase 4.4: if the goal''s entry instruction is ParTryMeElse,
    -- fork branches in parallel via runNegationParallel.
    Just (Str fnId args) ->
      let goalKey = lookupAtom tbl fnId ++ "/" ++ show (length args)
          dArgs = map (derefVar (wsBindings s)) args
      in case Map.lookup goalKey (wcLabels ctx) of
           Just pc ->
             let snap = s { wsRegs = IM.fromList (zip [1..] dArgs) }
                 (lo, hi) = bounds (wcCode ctx)
             in if pc >= lo && pc <= hi
                then case wcCode ctx ! pc of
                  ParTryMeElse elseLabel ->
                    let elsePC = fromMaybe (-1) (Map.lookup elseLabel (wcLabels ctx))
                    in if runNegationParallel ctx snap pc elsePC
                       then Nothing
                       else Just (s { wsPC = wsPC s + 1 })
                  ParTryMeElsePc elsePC ->
                    if runNegationParallel ctx snap pc elsePC
                    then Nothing
                    else Just (s { wsPC = wsPC s + 1 })
                  _ -> -- Sequential: just run normally
                    let snapshot = snap { wsPC = pc, wsCP = 0, wsCutBar = 0 }
                    in case run ctx snapshot of
                         Just _  -> Nothing
                         Nothing -> Just (s { wsPC = wsPC s + 1 })
                else Just (s { wsPC = wsPC s + 1 })
           Nothing -> Just (s { wsPC = wsPC s + 1 })  -- unknown pred; treat as failing goal
    -- Atom as 0-arity goal (e.g. \\+ some_pred)
    Just (Atom fnId) ->
      let goalKey = lookupAtom tbl fnId ++ "/0"
      in case Map.lookup goalKey (wcLabels ctx) of
           Just pc ->
             let snapshot = s { wsPC = pc
                              , wsRegs = wsRegs s
                              , wsCP = 0
                              , wsCutBar = 0 }
             in case run ctx snapshot of
                  Just _  -> Nothing
                  Nothing -> Just (s { wsPC = wsPC s + 1 })
           Nothing -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- SwitchOnConstant: dispatch on A1 value via O(log n) Map lookup
-- See SwitchOnConstantPc above for the fall-through-on-miss rationale.
step !ctx s (SwitchOnConstant table) =
  let val = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case val of
    Just (Unbound _) -> Just (s { wsPC = wsPC s + 1 })  -- unbound: skip
    Just v -> case Map.lookup v table of
      Just label -> case Map.lookup label (wcLabels ctx) of
        Just pc -> Just (s { wsPC = pc })
        Nothing -> Just (s { wsPC = wsPC s + 1 })
      Nothing -> Just (s { wsPC = wsPC s + 1 })  -- no match: fall through
    Nothing -> Just (s { wsPC = wsPC s + 1 })

step !ctx s (BuiltinCall ">/2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | a > b -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- =</2 lax comparison
step !ctx s (BuiltinCall "=</2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | a <= b -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- >=/2 lax comparison
step !ctx s (BuiltinCall ">=/2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | a >= b -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- =:=/2 lax arithmetic equality
step !ctx s (BuiltinCall "=:=/2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | abs (a - b) < 1e-15 -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- =\\=/2 lax arithmetic inequality
step !ctx s (BuiltinCall "=\\\\=/2" _) =
  let v1 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s))
      v2 = evalArith (wcInternTable ctx) (wsBindings s) =<< (derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s))
  in case (v1, v2) of
    (Just a, Just b) | abs (a - b) >= 1e-15 -> Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- is_lax/2 shares body with is/2 (silent failure on bad input)
step !ctx s (BuiltinCall "is_lax/2" _) = step ctx s (BuiltinCall "is/2" 2)

-- is_iso/2: arithmetic eval with ISO error throws on bad input.
--   unbound var in RHS -> instantiation_error
--   non-evaluable atom/functor -> type_error(evaluable, X/N)
step !ctx s (BuiltinCall "is_iso/2" _) =
  let expr = derefVar (wsBindings s) $ fromMaybe (Integer 0) (IM.lookup 2 (wsRegs s))
  in if hasUnboundDeep (wsBindings s) expr
     then throwIsoError s makeInstantiationError
     else case evalArith (wcInternTable ctx) (wsBindings s) expr of
       Nothing -> throwIsoError s (makeTypeError atomEvaluable (arithCulprit (wsBindings s) expr))
       Just r ->
         let lhs = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
         in case lhs of
           Just (Unbound vid) ->
             let val = if fromIntegral (round r :: Int) == r then Integer (round r) else Float r
             in Just (s { wsPC = wsPC s + 1
                        , wsRegs = IM.insert 1 val (wsRegs s)
                        , wsBindings = IM.insert vid val (wsBindings s)
                        , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                        , wsTrailLen = wsTrailLen s + 1 })
           Just (Integer n) | fromIntegral n == r -> Just (s { wsPC = wsPC s + 1 })
           _ -> Nothing

-- ISO arithmetic comparisons: <_iso, >_iso, >=_iso, =<_iso, =:=_iso, =\\=_iso.
-- Throws instantiation_error if either side has unbound vars, type_error(evaluable,...)
-- if eval fails.
step !ctx s instr@(BuiltinCall op _)
  | op == "<_iso/2" || op == ">_iso/2" || op == ">=_iso/2"
    || op == "=<_iso/2" || op == "=:=_iso/2" || op == "=\\\\=_iso/2" =
  let a1 = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
      a2 = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
      unboundA = case a1 of { Just v -> hasUnboundDeep (wsBindings s) v; Nothing -> True }
      unboundB = case a2 of { Just v -> hasUnboundDeep (wsBindings s) v; Nothing -> True }
  in if unboundA || unboundB
     then throwIsoError s makeInstantiationError
     else let r1 = a1 >>= evalArith (wcInternTable ctx) (wsBindings s)
              r2 = a2 >>= evalArith (wcInternTable ctx) (wsBindings s)
          in case (r1, r2) of
            (Nothing, _) ->
              let culprit = case a1 of { Just v -> arithCulprit (wsBindings s) v; Nothing -> makePredIndicator atomUnknown 0 }
              in throwIsoError s (makeTypeError atomEvaluable culprit)
            (_, Nothing) ->
              let culprit = case a2 of { Just v -> arithCulprit (wsBindings s) v; Nothing -> makePredIndicator atomUnknown 0 }
              in throwIsoError s (makeTypeError atomEvaluable culprit)
            (Just a, Just b) ->
              let ok = case op of
                    "<_iso/2"    -> a < b
                    ">_iso/2"    -> a > b
                    ">=_iso/2"   -> a >= b
                    "=<_iso/2"   -> a <= b
                    "=:=_iso/2"  -> abs (a - b) < 1e-15
                    "=\\\\=_iso/2" -> abs (a - b) >= 1e-15
                    _            -> False
              in if ok then Just (s { wsPC = wsPC s + 1 }) else Nothing

-- Lax comparison variants: delegate to their default-form counterparts
step !ctx s (BuiltinCall "<_lax/2" _) = step ctx s (BuiltinCall "</2" 2)
step !ctx s (BuiltinCall ">_lax/2" _) = step ctx s (BuiltinCall ">/2" 2)
step !ctx s (BuiltinCall ">=_lax/2" _) = step ctx s (BuiltinCall ">=/2" 2)
step !ctx s (BuiltinCall "=<_lax/2" _) = step ctx s (BuiltinCall "=</2" 2)
step !ctx s (BuiltinCall "=:=_lax/2" _) = step ctx s (BuiltinCall "=:=/2" 2)
step !ctx s (BuiltinCall "=\\\\=_lax/2" _) = step ctx s (BuiltinCall "=\\\\=/2" 2)

-- throw/1: deep-deref the term and raise WamException.
step !ctx s (BuiltinCall "throw/1" _) =
  case IM.lookup 1 (wsRegs s) of
    Just v -> throw $ WamException (derefDeep (wsBindings s) (derefVar (wsBindings s) v))
    Nothing -> throw $ WamException (Atom atomInstantiationError)

-- catch/3: run goal, catch WamException, unify catcher, run recovery.
-- Uses unsafePerformIO + try to bridge the pure step function with
-- exception catching.
step !ctx s (BuiltinCall "catch/3" _) =
  let goalVal  = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
      catcherTerm  = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 2 (wsRegs s))
      recoveryTerm = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 3 (wsRegs s))
      tbl = wcInternTable ctx
      runGoalInChild gv =
        let resolveGoal v = case v of
              Atom aid ->
                let goalKey = lookupAtom tbl aid ++ "/0"
                in case Map.lookup goalKey (wcLabels ctx) of
                  Just pc ->
                    let child = s { wsPC = pc, wsRegs = IM.empty, wsCP = 0
                                  , wsCutBar = 0 }
                    in run ctx child
                  Nothing -> step ctx (s { wsPC = 0 }) (BuiltinCall goalKey 0)
              Str fnId args ->
                let arity = length args
                    dArgs = map (derefVar (wsBindings s)) args
                    goalKey = lookupAtom tbl fnId ++ "/" ++ show arity
                    childRegs = IM.fromList (zip [1..] dArgs)
                    child = s { wsPC = 0, wsRegs = childRegs, wsCP = 0
                              , wsCutBar = 0 }
                in case Map.lookup goalKey (wcLabels ctx) of
                  Just pc -> run ctx (child { wsPC = pc })
                  Nothing -> step ctx child (BuiltinCall goalKey arity)
              _ -> Nothing
        in case gv of
          Atom aid | lookupAtom tbl aid == "true" -> Just s
          Atom aid | lookupAtom tbl aid == "fail" -> Nothing
          _ -> resolveGoal gv
      runRecovery unified =
        let rv = derefVar (wsBindings unified) recoveryTerm
        in case rv of
          Atom aid | lookupAtom tbl aid == "true" -> Just unified
          Atom aid | lookupAtom tbl aid == "fail" -> Nothing
          Atom aid ->
            let goalKey = lookupAtom tbl aid ++ "/0"
            in case Map.lookup goalKey (wcLabels ctx) of
              Just pc -> run ctx (unified { wsPC = pc, wsCP = 0, wsCutBar = 0 })
              Nothing -> Nothing
          Str fnId args ->
            let arity = length args
                dArgs = map (derefVar (wsBindings unified)) args
                goalKey = lookupAtom tbl fnId ++ "/" ++ show arity
                childRegs = IM.fromList (zip [1..] dArgs)
            in case Map.lookup goalKey (wcLabels ctx) of
              Just pc -> run ctx (unified { wsPC = pc, wsRegs = childRegs, wsCP = 0, wsCutBar = 0 })
              Nothing -> Nothing
          _ -> Nothing
      tryUnify a b st = case (derefVar (wsBindings st) a, derefVar (wsBindings st) b) of
        (Unbound va, Unbound vb) | va == vb -> Just st
        (Unbound vid, v) -> Just (st { wsBindings = IM.insert vid v (wsBindings st)
                                     , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings st)) : wsTrail st
                                     , wsTrailLen = wsTrailLen st + 1 })
        (v, Unbound vid) -> Just (st { wsBindings = IM.insert vid v (wsBindings st)
                                     , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings st)) : wsTrail st
                                     , wsTrailLen = wsTrailLen st + 1 })
        (Atom a1, Atom a2) | a1 == a2 -> Just st
        (Integer i1, Integer i2) | i1 == i2 -> Just st
        (Float f1, Float f2) | f1 == f2 -> Just st
        (Str f1 as1, Str f2 as2) | f1 == f2 && length as1 == length as2 ->
          foldl (\\acc (x, y) -> acc >>= tryUnify x y) (Just st) (zip as1 as2)
        (VList l1, VList l2) | length l1 == length l2 ->
          foldl (\\acc (x, y) -> acc >>= tryUnify x y) (Just st) (zip l1 l2)
        _ -> Nothing
  in case goalVal of
    Nothing -> Nothing
    Just gv -> unsafePerformIO $ do
      result <- try (evaluate (runGoalInChild gv)) :: IO (Either WamException (Maybe WamState))
      case result of
        Right res -> case res of
          Just resultState -> return $ Just (resultState { wsRegs = wsRegs s, wsPC = wsPC s + 1 })
          Nothing -> return Nothing
        Left (WamException thrown) ->
          case tryUnify catcherTerm thrown s of
            Just unified -> case runRecovery unified of
              Just _ -> return $ Just (unified { wsPC = wsPC s + 1 })
              Nothing -> return Nothing
            Nothing -> throw (WamException thrown)

-- succ/2 + succ_lax/2: bidirectional successor (lax semantics).
-- X bound non-negative -> Y=X+1; Y bound positive -> X=Y-1; else fail.
step !ctx s (BuiltinCall "succ/2" _) = succLax s
step !ctx s (BuiltinCall "succ_lax/2" _) = succLax s

-- succ_iso/2: bidirectional successor with ISO error throws.
step !ctx s (BuiltinCall "succ_iso/2" _) =
  let a = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
      b = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
      aUnbound = case a of { Just (Unbound _) -> True; Nothing -> True; _ -> False }
      bUnbound = case b of { Just (Unbound _) -> True; Nothing -> True; _ -> False }
      checkType v = case v of { Integer _ -> (); _ -> throwIsoError s (makeTypeError atomIntegerTy v) }
      bindReg reg value =
        case derefVar (wsBindings s) <$> IM.lookup reg (wsRegs s) of
          Just (Unbound vid) ->
            Just (s { wsPC = wsPC s + 1
                    , wsRegs = IM.insert reg value (wsRegs s)
                    , wsBindings = IM.insert vid value (wsBindings s)
                    , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                    , wsTrailLen = wsTrailLen s + 1 })
          Just bound | bound == value -> Just (s { wsPC = wsPC s + 1 })
          _ -> Nothing
  in if aUnbound && bUnbound
     then throwIsoError s makeInstantiationError
     else case a of
       Just v | not aUnbound -> checkType v `seq` case b of
         Just w | not bUnbound -> checkType w `seq` succIsoBody a b bindReg s
         _ -> succIsoBody a b bindReg s
       _ -> case b of
         Just w | not bUnbound -> checkType w `seq` succIsoBody a b bindReg s
         _ -> succIsoBody a b bindReg s

-- member/2 builtin: A1=Elem, A2=List. Creates choice points for backtracking.
step !ctx s (BuiltinCall "member/2" _) =
  let elem_ = derefVar (wsBindings s) $ fromMaybe (Unbound (-1)) (IM.lookup 1 (wsRegs s))
      list_ = derefVar (wsBindings s) $ fromMaybe (VList []) (IM.lookup 2 (wsRegs s))
  in case list_ of
    VList (x:_) -> unifyVal elem_ x s
    _ -> Nothing

-- begin_aggregate: push aggregate frame CP, initialize accumulator, continue to goal body
step !ctx s (BeginAggregate typ valReg resReg) =
  let cp = ChoicePoint
        { cpNextPC   = wsPC s
        , cpRegs     = wsRegs s
        , cpStack    = wsStack s
        , cpCP       = wsCP s
        , cpTrailLen = wsTrailLen s
        , cpHeapLen  = wsHeapLen s
        , cpBindings = wsBindings s
        , cpCutBar   = wsCutBar s
        , cpAggFrame = Just (AggFrame typ valReg resReg 0
                                      (inferMergeStrategy typ))
        , cpBuiltin = Nothing
        }
  in Just (s { wsPC = wsPC s + 1
             , wsCPs = cp : wsCPs s
             , wsCPsLen = wsCPsLen s + 1
             , wsAggAccum = []
             })

-- end_aggregate: collect value, store returnPC in nearest aggregate frame, force backtrack
step !ctx s (EndAggregate valReg) =
  let val = derefVar (wsBindings s) $ fromMaybe (Integer 0) (getReg valReg s)
      returnPC = wsPC s + 1
      -- Update only the nearest (first) aggregate frame CP, not all CPs
      updatedCPs = updateNearestAggFrame returnPC (wsCPs s)
      s1 = s { wsAggAccum = val : wsAggAccum s, wsCPs = updatedCPs }
  in case backtrackInner returnPC s1 of
    Just s2 -> Just s2
    Nothing -> finalizeAggregate returnPC s1

-- functor/3: A1 = T, A2 = N, A3 = A. Read and construct modes
-- are dispatched on A1''s tag after dereferencing.
step !_ctx s (BuiltinCall "functor/3" _) =
  let t = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case t of
    Just (Unbound vid) ->
      -- Construct mode: need A2 (atom name) and A3 (integer arity).
      let nArg = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
          aArg = derefVar (wsBindings s) <$> IM.lookup 3 (wsRegs s)
      in case (nArg, aArg) of
        (Just nameVal, Just (Integer arity)) | arity >= 0 ->
          let mBuilt = if arity == 0
                then Just (nameVal, wsVarCounter s)
                else case nameVal of
                  Atom fname ->
                    let c0 = wsVarCounter s
                        newArgs = [Unbound (c0 + i) | i <- [0 .. arity - 1]]
                    in Just (Str fname newArgs, c0 + arity)
                  _ -> Nothing
          in case mBuilt of
            Nothing -> Nothing
            Just (built, newCounter) -> Just (s
              { wsPC = wsPC s + 1
              , wsRegs = IM.insert 1 built (wsRegs s)
              , wsBindings = IM.insert vid built (wsBindings s)
              , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
              , wsTrailLen = wsTrailLen s + 1
              , wsVarCounter = newCounter
              })
        _ -> Nothing
    Just tVal ->
      -- Read mode: extract functor name and arity.
      let mInfo = case tVal of
            Str fnId args -> Just (Atom fnId, length args)
            VList [] -> Just (Atom atomNil, 0)
            VList _ -> Just (Atom atomDot, 2)
            Atom _ -> Just (tVal, 0)
            Integer _ -> Just (tVal, 0)
            Float _ -> Just (tVal, 0)
            _ -> Nothing
      in case mInfo of
        Nothing -> Nothing
        Just (name, arity) ->
          case bindOutput 2 name s of
            Nothing -> Nothing
            Just s1 -> case bindOutput 3 (Integer arity) s1 of
              Nothing -> Nothing
              Just s2 -> Just (s2 { wsPC = wsPC s2 + 1 })
    Nothing -> Nothing

-- arg/3: A1 = N (integer, 1-based), A2 = T (compound/list),
-- A3 = output unified with the selected argument.
step !_ctx s (BuiltinCall "arg/3" _) =
  let n = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
      t = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
  in case (n, t) of
    (Just (Integer idx), Just tVal) | idx >= 1 ->
      let mArg = case tVal of
            Str _ args | idx <= length args -> Just (args !! (idx - 1))
            VList (x : _) | idx == 1 -> Just x
            VList (_ : xs) | idx == 2 -> Just (VList xs)
            _ -> Nothing
      in case mArg of
        Nothing -> Nothing
        Just a -> case bindOutput 3 a s of
          Nothing -> Nothing
          Just s1 -> Just (s1 { wsPC = wsPC s1 + 1 })
    _ -> Nothing

-- Specialized arg lowering: Arg N tReg aReg
-- Compile-time N (positive integer), runtime T from tReg, output to
-- aReg. Skips the put_constant/put_value/builtin_call dispatch chain
-- that the generic arg/3 builtin requires. Emitted by the WAM compiler
-- when binding-state analysis proves T is bound and N is a literal int.
step !_ctx s (Arg n tReg aReg) | n >= 1 =
  let mT = derefVar (wsBindings s) <$> IM.lookup tReg (wsRegs s)
  in case mT of
    Just tVal ->
      let mElem = case tVal of
            Str _ args | n <= length args -> Just (args !! (n - 1))
            VList (x : _) | n == 1 -> Just x
            VList (_ : xs) | n == 2 -> Just (VList xs)
            _ -> Nothing
      in case mElem of
        Nothing -> Nothing
        Just elem ->
          let mA = derefVar (wsBindings s) <$> IM.lookup aReg (wsRegs s)
          in case mA of
            Nothing ->
              Just (s { wsPC = wsPC s + 1
                      , wsRegs = IM.insert aReg elem (wsRegs s)
                      })
            Just (Unbound vid) ->
              Just (s { wsPC = wsPC s + 1
                      , wsRegs = IM.insert aReg elem (wsRegs s)
                      , wsBindings = IM.insert vid elem (wsBindings s)
                      , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                      , wsTrailLen = wsTrailLen s + 1
                      })
            Just a | a == elem -> Just (s { wsPC = wsPC s + 1 })
            _ -> Nothing
    Nothing -> Nothing
step !_ctx _ (Arg _ _ _) = Nothing

-- Specialized \\+ member(X, L) lowering: NotMemberList xReg lReg.
-- Skips the put_structure member/2 + set_value + set_value +
-- builtin_call \\+/1 chain (4 dispatches, plus the heap allocation
-- for the goal term) by reading X and L directly from registers and
-- walking L inline. Emitted by the WAM compiler when binding-state
-- analysis proves both X and L are bound at the goal site.
step !_ctx s (NotMemberList xReg lReg) =
  let mX = derefVar (wsBindings s) <$> IM.lookup xReg (wsRegs s)
      mL = derefVar (wsBindings s) <$> IM.lookup lReg (wsRegs s)
  in case (mX, mL) of
    (Just x, Just l) ->
      let found = case l of
            VList items -> any (\\item -> derefVar (wsBindings s) item == x) items
            _ -> False
      in if found then Nothing else Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- Specialized \\+ member(X, [a, b, c]) for compile-time-ground lists.
-- Atoms are interned at codegen, so the instruction carries [Int] of
-- atom IDs. Single dispatch, zero heap allocation. Beats both the
-- unlowered builtin path (N PutStructures + dispatch + N unifications)
-- and the IntSet inline-build path (N SetInserts allocate Patricia
-- nodes per call) at small N typical of source-literal lists.
--
-- Semantics: succeed when X cannot unify with any atom in the baked-in
-- list. For an Atom X, that is "aid notElem atomIds". For a non-Atom
-- ground value (Integer, Float, Str, VList, VSet) X can never unify
-- with any atom, so the check trivially succeeds. For an Unbound X,
-- it COULD unify with some atom (Prolog would succeed via
-- unification), so the check must fail — matches Prolog
-- \\+ member(X, [a,b,c]) semantics when X is unbound.
step !_ctx s (NotMemberConstAtoms xReg atomIds) =
  let mX = derefVar (wsBindings s) <$> IM.lookup xReg (wsRegs s)
  in case mX of
    Just (Atom aid)    -> if aid `elem` atomIds
                            then Nothing
                            else Just (s { wsPC = wsPC s + 1 })
    Just (Unbound _)   -> Nothing  -- could unify with some atom
    Just (Ref _)       -> Nothing  -- unresolved chain — treat as could-unify
    Just _             -> Just (s { wsPC = wsPC s + 1 })  -- non-atom ground: never in list
    Nothing            -> Nothing  -- register not set

-- IntSet visited support: write an empty set into the named register.
-- Used by the WAM compiler at the bootstrap site of a visited-set
-- argument (e.g. the `[Cat]` literal flowing into category_ancestor)
-- so the recursive call sees a VSet rather than a VList.
step !_ctx s (BuildEmptySet r) =
  Just (s { wsPC = wsPC s + 1
          , wsRegs = IM.insert r (VSet IS.empty) (wsRegs s) })

-- IntSet insert: read element from elemReg (must deref to Atom), read
-- the input VSet from inReg, write the inserted set to outReg. Returns
-- Nothing if the element is not an atom or the input is not a VSet.
step !_ctx s (SetInsert eReg inReg outReg) =
  let mE  = derefVar (wsBindings s) <$> IM.lookup eReg (wsRegs s)
      mIn = derefVar (wsBindings s) <$> IM.lookup inReg (wsRegs s)
  in case (mE, mIn) of
    (Just (Atom aid), Just (VSet s0)) ->
      Just (s { wsPC = wsPC s + 1
              , wsRegs = IM.insert outReg (VSet (IS.insert aid s0)) (wsRegs s) })
    _ -> Nothing

-- IntSet membership: succeed when elemReg (an Atom) is NOT in setReg
-- (a VSet). O(log N) lookup, replacing the O(N) walk of NotMemberList
-- on the visited-set hot path.
step !_ctx s (NotMemberSet eReg setReg) =
  let mE   = derefVar (wsBindings s) <$> IM.lookup eReg (wsRegs s)
      mSet = derefVar (wsBindings s) <$> IM.lookup setReg (wsRegs s)
  in case (mE, mSet) of
    (Just (Atom aid), Just (VSet s0)) ->
      if IS.member aid s0 then Nothing else Just (s { wsPC = wsPC s + 1 })
    _ -> Nothing

-- =../2 (univ): A1 = T, A2 = L. Decompose (instantiated A1) or
-- compose (unbound A1, list in A2).
step !_ctx s (BuiltinCall "=../2" _) =
  let t = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case t of
    Just (Unbound vid) ->
      -- Compose mode: read proper list from A2.
      let l = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
      in case l of
        Just (VList items) ->
          let mBuilt = case items of
                [] -> Nothing
                [x] -> Just x
                (Atom fname : rest) -> Just (Str fname rest)
                _ -> Nothing
          in case mBuilt of
            Nothing -> Nothing
            Just built -> Just (s
              { wsPC = wsPC s + 1
              , wsRegs = IM.insert 1 built (wsRegs s)
              , wsBindings = IM.insert vid built (wsBindings s)
              , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
              , wsTrailLen = wsTrailLen s + 1
              })
        _ -> Nothing
    Just tVal ->
      -- Decompose mode: build list from T.
      let mList = case tVal of
            Str fnId args -> Just (VList (Atom fnId : args))
            Atom _ -> Just (VList [tVal])
            Integer _ -> Just (VList [tVal])
            Float _ -> Just (VList [tVal])
            VList [] -> Just (VList [Atom atomNil])
            VList (x : xs) -> Just (VList [Atom atomDot, x, VList xs])
            _ -> Nothing
      in case mList of
        Nothing -> Nothing
        Just lv -> case bindOutput 2 lv s of
          Nothing -> Nothing
          Just s1 -> Just (s1 { wsPC = wsPC s1 + 1 })
    Nothing -> Nothing

-- copy_term/2: A1 = T, A2 = Copy. Walks T with a var map to
-- preserve sharing, bumps wsVarCounter, binds A2 to the fresh copy.
step !_ctx s (BuiltinCall "copy_term/2" _) =
  let t = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
  in case t of
    Just tVal ->
      let (copy, newCounter, _) = copyTermWalk (wsVarCounter s) IM.empty tVal
          s0 = s { wsVarCounter = newCounter }
      in case bindOutput 2 copy s0 of
        Nothing -> Nothing
        Just s1 -> Just (s1 { wsPC = wsPC s1 + 1 })
    Nothing -> Nothing

-- Fallback for unhandled instructions
step _ _ _ = Nothing

-- | Lax succ helper: X>=0 -> Y=X+1; Y>0 -> X=Y-1; else fail.
succLax :: WamState -> Maybe WamState
succLax s =
  let a = derefVar (wsBindings s) <$> IM.lookup 1 (wsRegs s)
      b = derefVar (wsBindings s) <$> IM.lookup 2 (wsRegs s)
      bindReg reg value =
        case derefVar (wsBindings s) <$> IM.lookup reg (wsRegs s) of
          Just (Unbound vid) ->
            Just (s { wsPC = wsPC s + 1
                    , wsRegs = IM.insert reg value (wsRegs s)
                    , wsBindings = IM.insert vid value (wsBindings s)
                    , wsTrail = TrailEntry vid (IM.lookup vid (wsBindings s)) : wsTrail s
                    , wsTrailLen = wsTrailLen s + 1 })
          Just bound | bound == value -> Just (s { wsPC = wsPC s + 1 })
          _ -> Nothing
  in case (a, b) of
    (Just (Integer n), _) | n >= 0 -> bindReg 2 (Integer (n + 1))
    (_, Just (Integer m)) | m > 0  -> bindReg 1 (Integer (m - 1))
    _ -> Nothing

-- | ISO succ body: dispatch after type/instantiation checks passed.
succIsoBody :: Maybe Value -> Maybe Value -> (Int -> Value -> Maybe WamState) -> WamState -> Maybe WamState
succIsoBody a b bindReg s = case (a, b) of
  (Just (Integer n), _) | n < 0 ->
    throwIsoError s (makeTypeError atomNotLessThanZero (Integer n))
  (_, Just (Integer m)) | m <= 0 ->
    throwIsoError s (makeDomainError atomNotLessThanZero (Integer m))
  (Just (Integer n), _) -> bindReg 2 (Integer (n + 1))
  (_, Just (Integer m)) -> bindReg 1 (Integer (m - 1))
  _ -> Nothing

'.

run_loop_haskell(Code) :-
    Code = '-- | Main execution loop. Runs until halt (pc=0) or failure.
-- Uses unsafeFetchInstr to avoid Maybe wrapping in the hot path.
-- Bounds are guaranteed by the WAM compiler: PC=0 is halt, otherwise PC
-- always points to a valid instruction within the code array.
-- The WamContext is read-only and threaded through (no per-step alloc).
run :: WamContext -> WamState -> Maybe WamState
run !ctx !s
  | wsPC s == 0 = Just s  -- halt
  | otherwise =
      let !instr = unsafeFetchInstr (wsPC s) (wcCode ctx)
      in case step ctx s instr of
           Just !s'''' -> run ctx s''''
           Nothing -> case backtrack s of
             Just !s'''' -> run ctx s''''
             Nothing -> Nothing

-- | Phase 3: ST-mode execution with mutable STArray registers.
-- Pure outer interface (via runST), mutable O(1) registers inside.
-- Converts WamState <-> PureWamState at boundaries.
-- 7.66x faster than IntMap on register-heavy workloads (POC validated).
runMutableRegs :: WamContext -> WamState -> Maybe WamState
runMutableRegs !ctx !s0 = runST go
  where
    go :: forall s. ST s (Maybe WamState)
    go = do
      regs <- newArray (1, maxRegId) (Unbound (-1)) :: ST s (STA.STArray s Int Value)
      forM_ (IM.toList (wsRegs s0)) $ \\(k, v) ->
        writeArray regs k v
      let !pw0 = wamStateToPure s0
      result <- runLoopST ctx regs pw0
      case result of
        Nothing -> return Nothing
        Just pw -> do
          regMap <- freezeRegsToIntMap regs
          return (Just (pureToWamState pw regMap))

-- | Internal ST-mode run loop. Tail-recursive, same shape as `run`.
runLoopST :: WamContext -> STA.STArray s Int Value -> PureWamState
          -> ST s (Maybe PureWamState)
runLoopST !ctx regs !pw
  | pwPC pw == 0 = return (Just pw)
  | otherwise = do
      let !instr = unsafeFetchInstr (pwPC pw) (wcCode ctx)
      result <- stepST ctx regs pw instr
      case result of
        Just !pw'''' -> runLoopST ctx regs pw''''
        Nothing -> do
          bt <- backtrackST regs pw
          case bt of
            Just !pw'''' -> runLoopST ctx regs pw''''
            Nothing -> return Nothing

-- | Phase 3: ST-mode step function. Core register arms use direct
-- readArray/writeArray for O(1) access. Complex arms (builtins,
-- aggregates, parallel fork) fall through to the pure step bridge.
stepST :: WamContext -> STA.STArray s Int Value -> PureWamState
       -> Instruction -> ST s (Maybe PureWamState)

stepST _ regs !pw (PutConstant c ai) = do
  writeArray regs ai c
  return $ Just pw { pwPC = pwPC pw + 1 }

stepST _ regs !pw (GetConstant c ai) = do
  v <- readArray regs ai
  let !dv = derefVar (pwBindings pw) v
  if dv == c
    then return $ Just pw { pwPC = pwPC pw + 1 }
    else case dv of
      Unbound vid -> do
        writeArray regs ai c
        return $ Just pw { pwPC = pwPC pw + 1
                         , pwBindings = IM.insert vid c (pwBindings pw)
                         , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                         , pwTrailLen = pwTrailLen pw + 1
                         }
      _ -> return Nothing

stepST _ regs !pw (GetVariable xn ai) = do
  v <- readArray regs ai
  let !dv = derefVar (pwBindings pw) v
  pw'''' <- putRegST regs xn dv pw
  return $ Just pw'''' { pwPC = pwPC pw + 1 }

stepST _ regs !pw (GetValue xn ai) = do
  va0 <- readArray regs ai
  let !va = derefVar (pwBindings pw) va0
  mvx <- getRegST regs xn pw
  case mvx of
    Nothing -> return Nothing
    Just vx
      | va == vx -> return $ Just pw { pwPC = pwPC pw + 1 }
    Just (Unbound vid) ->
      return $ Just pw { pwPC = pwPC pw + 1
                        , pwBindings = IM.insert vid va (pwBindings pw)
                        , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                        , pwTrailLen = pwTrailLen pw + 1
                        }
    Just vx -> case va of
      Unbound vid -> do
        writeArray regs ai vx
        return $ Just pw { pwPC = pwPC pw + 1
                         , pwBindings = IM.insert vid vx (pwBindings pw)
                         , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                         , pwTrailLen = pwTrailLen pw + 1
                         }
      _ -> return Nothing

stepST _ regs !pw (PutVariable xn ai) = do
  let !vid = pwVarCounter pw
      !var = Unbound vid
  pw'''' <- putRegST regs xn var pw
  writeArray regs ai var
  return $ Just pw'''' { pwPC = pwPC pw + 1, pwVarCounter = vid + 1 }

stepST _ regs !pw (PutValue xn ai) = do
  mv <- getRegST regs xn pw
  case mv of
    Just val -> do
      writeArray regs ai val
      return $ Just pw { pwPC = pwPC pw + 1 }
    Nothing -> return Nothing

stepST _ _ !pw (PutStructure fnId ai arity) =
  let push = pushBuilderIfActivePure pw
  in return $ Just push { pwPC = pwPC push + 1
                        , pwBuilder = BuildStruct fnId ai arity [] }

stepST _ _ !pw (PutList ai) =
  let push = pushBuilderIfActivePure pw
  in return $ Just push { pwPC = pwPC push + 1
                        , pwBuilder = BuildList ai [] }

stepST _ _ !pw (CallResolved pc _arity) =
  return $ Just pw { pwPC = pc, pwCP = pwPC pw + 1 }

stepST _ _ !pw (JumpPc pc) =
  return $ Just pw { pwPC = pc }

stepST _ _ !pw (ExecutePc pc) =
  return $ Just pw { pwPC = pc }

stepST _ _ !pw Proceed =
  let ret = pwCP pw
  in if ret == 0 then return $ Just pw { pwPC = 0 }
     else return $ Just pw { pwPC = ret, pwCP = 0 }

stepST _ _ !pw Allocate =
  let frame = EnvFrame (pwCP pw) IM.empty
  in return $ Just pw { pwPC = pwPC pw + 1
                       , pwStack = frame : pwStack pw
                       , pwCutBar = pwCPsLen pw }

stepST _ _ !pw Deallocate =
  case pwStack pw of
    (EnvFrame oldCP _ : rest) ->
      return $ Just pw { pwPC = pwPC pw + 1, pwStack = rest, pwCP = oldCP }
    _ -> return Nothing

stepST _ regs !pw (TryMeElsePc nextPC) = do
  snap <- snapshotRegsST regs
  let mcp = MutableChoicePoint
        { mcpNextPC = nextPC, mcpRegs = snap
        , mcpStack = pwStack pw, mcpCP = pwCP pw
        , mcpTrailLen = pwTrailLen pw, mcpHeapLen = pwHeapLen pw
        , mcpBindings = pwBindings pw, mcpCutBar = pwCutBar pw
        , mcpAggFrame = Nothing, mcpBuiltin = Nothing
        }
  return $ Just pw { pwPC = pwPC pw + 1
                   , pwCPs = mcp : pwCPs pw
                   , pwCPsLen = pwCPsLen pw + 1 }

stepST _ _ !pw TrustMe =
  case pwCPs pw of
    (_ : rest) -> return $ Just pw { pwPC = pwPC pw + 1
                                   , pwCPs = rest
                                   , pwCPsLen = pwCPsLen pw - 1 }
    [] -> return $ Just pw { pwPC = pwPC pw + 1 }

stepST _ _ !pw (RetryMeElsePc nextPC) =
  case pwCPs pw of
    (mcp : rest) ->
      return $ Just pw { pwPC = pwPC pw + 1
                       , pwCPs = mcp { mcpNextPC = nextPC } : rest }
    [] -> return $ Just pw { pwPC = pwPC pw + 1 }

-- Label-based variants (lookup label -> PC)
stepST !ctx regs !pw (TryMeElse label) =
  let nextPC = fromMaybe 0 $ Map.lookup label (wcLabels ctx)
  in stepST ctx regs pw (TryMeElsePc nextPC)

stepST !ctx regs !pw (RetryMeElse label) =
  let nextPC = fromMaybe 0 $ Map.lookup label (wcLabels ctx)
  in stepST ctx regs pw (RetryMeElsePc nextPC)

stepST !ctx _ !pw (Jump label) =
  case Map.lookup label (wcLabels ctx) of
    Just pc -> return $ Just pw { pwPC = pc }
    Nothing -> return Nothing

-- SwitchOnConstantPc: indexed dispatch on A1 register
stepST _ regs !pw (SwitchOnConstantPc table) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Unbound _ -> return $ Just pw { pwPC = pwPC pw + 1 }
    Atom aid -> case IM.lookup aid table of
      Just pc -> return $ Just pw { pwPC = pc }
      Nothing -> return $ Just pw { pwPC = pwPC pw + 1 }
    Integer n -> case IM.lookup n table of
      Just pc -> return $ Just pw { pwPC = pc }
      Nothing -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return $ Just pw { pwPC = pwPC pw + 1 }

-- Cut: truncate choice point stack
stepST _ _ !pw (BuiltinCall "!/0" _) =
  return $ Just pw { pwPC = pwPC pw + 1
                   , pwCPs = take (pwCutBar pw) (pwCPs pw)
                   , pwCPsLen = pwCutBar pw }

-- CutIte: soft cut for if-then-else
stepST _ _ !pw CutIte =
  case pwCPs pw of
    (_ : rest) -> return $ Just pw { pwPC = pwPC pw + 1
                                   , pwCPs = rest, pwCPsLen = pwCPsLen pw - 1 }
    [] -> return $ Just pw { pwPC = pwPC pw + 1 }

-- M17 soft cut (see the pure `step` GetLevel/Cut for semantics).
-- M145: route the register access through putRegST/getRegST. GetLevel''s
-- operand is a Y register (id 201+), which lives in the topmost env
-- frame on the ST path -- the old raw writeArray/readArray hit the
-- STArray sized (1, maxRegId=199) and crashed every if-then-else
-- predicate with an index error.
stepST _ regs !pw (GetLevel reg) = do
  pw'' <- putRegST regs reg (Integer (pwCPsLen pw)) pw
  return $ Just pw'' { pwPC = pwPC pw + 1 }

stepST _ regs !pw (Cut reg) = do
  mv <- getRegST regs reg pw
  case mv of
    Just (Integer n) -> return $ Just pw { pwPC = pwPC pw + 1
                                         , pwCPs = take n (pwCPs pw), pwCPsLen = n }
    _ -> return $ Just pw { pwPC = pwPC pw + 1 }

-- Type-checking builtins
stepST _ regs !pw (BuiltinCall "nonvar/1" _) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Unbound _ -> return Nothing
    _         -> return $ Just pw { pwPC = pwPC pw + 1 }

stepST _ regs !pw (BuiltinCall "var/1" _) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Unbound _ -> return $ Just pw { pwPC = pwPC pw + 1 }
    _         -> return Nothing

stepST _ regs !pw (BuiltinCall "atom/1" _) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Atom _ -> return $ Just pw { pwPC = pwPC pw + 1 }
    _      -> return Nothing

stepST _ regs !pw (BuiltinCall "integer/1" _) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Integer _ -> return $ Just pw { pwPC = pwPC pw + 1 }
    _         -> return Nothing

stepST _ regs !pw (BuiltinCall "number/1" _) = do
  v <- readArray regs 1
  let !dv = derefVar (pwBindings pw) v
  case dv of
    Integer _ -> return $ Just pw { pwPC = pwPC pw + 1 }
    Float _   -> return $ Just pw { pwPC = pwPC pw + 1 }
    _         -> return Nothing

stepST !ctx regs !pw (BuiltinCall "is/2" _) = do
  v2 <- readArray regs 2
  v1 <- readArray regs 1
  let !expr = derefVar (pwBindings pw) v2
      result = evalArith (wcInternTable ctx) (pwBindings pw) expr
      !lhs = derefVar (pwBindings pw) v1
  case (lhs, result) of
    (Unbound vid, Just r) -> do
      let val = if fromIntegral (round r :: Int) == r then Integer (round r) else Float r
      writeArray regs 1 val
      return $ Just pw { pwPC = pwPC pw + 1
                       , pwBindings = IM.insert vid val (pwBindings pw)
                       , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                       , pwTrailLen = pwTrailLen pw + 1
                       }
    (Integer n, Just r) | fromIntegral n == r -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

stepST !ctx regs !pw (BuiltinCall "</2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | a < b -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

stepST !ctx regs !pw (BuiltinCall ">/2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | a > b -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

-- Builder operations: read reg value and pass to addToBuilder (pure helper).
-- addToBuilder is pure and only touches wsBuilder/wsRegs, so we can
-- do the reg read in ST and delegate the builder logic to pure.
stepST _ regs !pw (SetValue xn) = do
  mv <- getRegST regs xn pw
  case mv of
    Nothing -> return Nothing
    Just val -> do
      let s0 = PureWamState { pwPC = pwPC pw, pwStack = pwStack pw
                            , pwHeap = pwHeap pw, pwHeapLen = pwHeapLen pw
                            , pwTrail = pwTrail pw, pwTrailLen = pwTrailLen pw
                            , pwCP = pwCP pw, pwCPs = pwCPs pw, pwCPsLen = pwCPsLen pw
                            , pwBindings = pwBindings pw, pwCutBar = pwCutBar pw
                            , pwBuilder = pwBuilder pw, pwBuilderStack = pwBuilderStack pw
                            , pwVarCounter = pwVarCounter pw
                            , pwAggAccum = pwAggAccum pw }
      -- addToBuilder is pure: only modifies wsBuilder and wsRegs (for struct/list finalize)
      regMap <- freezeRegsToIntMap regs
      let ws = pureToWamState s0 regMap
      case addToBuilder val ws of
        Nothing -> return Nothing
        Just ws'''' -> do
          forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
          return (Just (wamStateToPure ws''''))

stepST _ regs !pw (SetVariable xn) = do
  let !vid = pwVarCounter pw
      !var = Unbound vid
  pw'''' <- putRegST regs xn var pw
  let pw2 = pw'''' { pwVarCounter = vid + 1 }
  -- Delegate builder logic to pure
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw2 regMap
  case addToBuilder var ws of
    Nothing -> return Nothing
    Just ws2 -> do
      forM_ (IM.toList (wsRegs ws2)) $ \\(k, v) -> writeArray regs k v
      return (Just (wamStateToPure ws2))

stepST _ regs !pw (SetConstant c) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case addToBuilder c ws of
    Nothing -> return Nothing
    Just ws'''' -> do
      forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
      return (Just (wamStateToPure ws''''))

-- Call/Execute dispatch (string-based, not pre-resolved)
stepST !ctx regs !pw (Call pred _arity) = do
  let sc = pw { pwCP = pwPC pw + 1 }
  case Map.lookup pred (wcLoweredPredicates ctx) of
    Just fn -> do
      regMap <- freezeRegsToIntMap regs
      let ws = pureToWamState sc regMap
      case fn ctx ws of
        Nothing -> return Nothing
        Just ws'''' -> do
          forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
          return (Just (wamStateToPure ws''''))
    Nothing -> do
      regMap <- freezeRegsToIntMap regs
      let ws = pureToWamState sc regMap
      case callIndexedFact2 ctx pred ws of
        Just sr -> do
          forM_ (IM.toList (wsRegs sr)) $ \\(k, v) -> writeArray regs k v
          return (Just (wamStateToPure sr))
        Nothing -> case Map.lookup pred (wcLabels ctx) of
          Just pc -> return $ Just sc { pwPC = pc }
          Nothing -> return Nothing

stepST !ctx regs !pw (Execute pred) = do
  case Map.lookup pred (wcLoweredPredicates ctx) of
    Just fn -> do
      regMap <- freezeRegsToIntMap regs
      let ws = pureToWamState pw regMap
      case fn ctx ws of
        Nothing -> return Nothing
        Just ws'''' -> do
          forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
          return (Just (wamStateToPure ws''''))
    Nothing -> do
      regMap <- freezeRegsToIntMap regs
      let ws = pureToWamState pw regMap
      case callIndexedFact2 ctx pred ws of
        Just sr -> do
          forM_ (IM.toList (wsRegs sr)) $ \\(k, v) -> writeArray regs k v
          return (Just (wamStateToPure sr))
        Nothing -> case Map.lookup pred (wcLabels ctx) of
          Just pc -> return $ Just pw { pwPC = pc }
          Nothing -> return Nothing

stepST !ctx regs !pw (CallForeign pred _arity) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState (pw { pwCP = pwPC pw + 1 }) regMap
  case executeForeign ctx pred ws of
    Nothing -> return Nothing
    Just ws'''' -> do
      forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
      return (Just (wamStateToPure ws''''))

-- length/2: list length query/check
stepST !ctx regs !pw (BuiltinCall "length/2" _) = do
  v1 <- readArray regs 1
  let !listVal = derefVar (pwBindings pw) v1
  case listVal of
    VList items -> do
      let len = length items
      v2 <- readArray regs 2
      let !lhs = derefVar (pwBindings pw) v2
      case lhs of
        Unbound vid -> do
          let val = Integer len
          writeArray regs 2 val
          return $ Just pw { pwPC = pwPC pw + 1
                           , pwBindings = IM.insert vid val (pwBindings pw)
                           , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                           , pwTrailLen = pwTrailLen pw + 1
                           }
        Integer n | n == len -> return $ Just pw { pwPC = pwPC pw + 1 }
        _ -> return Nothing
    _ -> return Nothing

-- Arg n tReg aReg: extract Nth argument from compound
stepST _ regs !pw (Arg n tReg aReg) | n >= 1 = do
  vT <- readArray regs tReg
  let !tVal = derefVar (pwBindings pw) vT
      mElem = case tVal of
        Str _ args | n <= length args -> Just (args !! (n - 1))
        VList (x : _) | n == 1 -> Just x
        VList (_ : xs) | n == 2 -> Just (VList xs)
        _ -> Nothing
  case mElem of
    Nothing -> return Nothing
    Just el -> do
      vA <- readArray regs aReg
      let !aVal = derefVar (pwBindings pw) vA
      case aVal of
        Unbound vid -> do
          writeArray regs aReg el
          return $ Just pw { pwPC = pwPC pw + 1
                           , pwBindings = IM.insert vid el (pwBindings pw)
                           , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                           , pwTrailLen = pwTrailLen pw + 1
                           }
        _ | aVal == el -> return $ Just pw { pwPC = pwPC pw + 1 }
        _ -> return Nothing

stepST _ _ _ (Arg _ _ _) = return Nothing

-- NotMemberList: specialized \\+ member(X, L)
stepST _ regs !pw (NotMemberList xReg lReg) = do
  vX <- readArray regs xReg
  vL <- readArray regs lReg
  let !x = derefVar (pwBindings pw) vX
      !l = derefVar (pwBindings pw) vL
      found = case l of
        VList items -> any (\\item -> derefVar (pwBindings pw) item == x) items
        _ -> False
  if found then return Nothing else return $ Just pw { pwPC = pwPC pw + 1 }

-- NotMemberConstAtoms: specialized \\+ member(X, [a,b,c])
stepST _ regs !pw (NotMemberConstAtoms xReg atomIds) = do
  vX <- readArray regs xReg
  let !x = derefVar (pwBindings pw) vX
  case x of
    Atom aid   -> if aid `elem` atomIds then return Nothing
                  else return $ Just pw { pwPC = pwPC pw + 1 }
    Unbound _  -> return Nothing
    Ref _      -> return Nothing
    _          -> return $ Just pw { pwPC = pwPC pw + 1 }

-- BuildEmptySet: write empty IntSet to register
stepST _ regs !pw (BuildEmptySet r) = do
  writeArray regs r (VSet IS.empty)
  return $ Just pw { pwPC = pwPC pw + 1 }

-- SetInsert: IntSet insert
stepST _ regs !pw (SetInsert eReg inReg outReg) = do
  vE <- readArray regs eReg
  vIn <- readArray regs inReg
  let !e = derefVar (pwBindings pw) vE
      !inSet = derefVar (pwBindings pw) vIn
  case (e, inSet) of
    (Atom aid, VSet s0) -> do
      writeArray regs outReg (VSet (IS.insert aid s0))
      return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

-- NotMemberSet: IntSet membership check
stepST _ regs !pw (NotMemberSet eReg setReg) = do
  vE <- readArray regs eReg
  vS <- readArray regs setReg
  let !e = derefVar (pwBindings pw) vE
      !s = derefVar (pwBindings pw) vS
  case (e, s) of
    (Atom aid, VSet set) ->
      if IS.member aid set then return Nothing
      else return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

-- PutStructureDyn: dynamic structure (functor/arity from registers)
stepST _ regs !pw (PutStructureDyn nameReg arityReg targetReg) = do
  mvN <- getRegST regs nameReg pw
  mvA <- getRegST regs arityReg pw
  case (mvN, mvA) of
    (Just (Atom fnId), Just (Integer arity)) | arity >= 0 ->
      return $ Just pw { pwPC = pwPC pw + 1
                       , pwBuilder = BuildStruct fnId targetReg (fromIntegral arity) [] }
    _ -> return Nothing

-- Parallel variants delegate to their sequential counterparts
-- GetStructure: read-mode if register holds matching Str, write-mode if Unbound.
-- Delegates to pure bridge for builder interactions.
stepST !ctx regs !pw (GetStructure fnId ai arity) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case step ctx ws (GetStructure fnId ai arity) of
    Nothing -> return Nothing
    Just ws'''' -> do
      forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
      return (Just (wamStateToPure ws''''))

-- GetList: read-mode or write-mode. Delegates to pure bridge.
stepST !ctx regs !pw (GetList ai) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case step ctx ws (GetList ai) of
    Nothing -> return Nothing
    Just ws'''' -> do
      forM_ (IM.toList (wsRegs ws'''')) $ \\(k, v) -> writeArray regs k v
      return (Just (wamStateToPure ws''''))

-- UnifyVariable: read-mode -> bind register, write-mode -> create fresh var + addToBuilder.
stepST _ regs !pw (UnifyVariable xn) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case readNextArg ws of
    Just (v, ws'''') ->
      let ws2 = (putReg xn v ws'''') { wsPC = wsPC ws + 1 }
      in do forM_ (IM.toList (wsRegs ws2)) $ \\(k, val) -> writeArray regs k val
            return (Just (wamStateToPure ws2))
    Nothing ->
      let vid = wsVarCounter ws
          var = Unbound vid
          s1 = putReg xn var (ws { wsVarCounter = vid + 1 })
      in case addToBuilder var s1 of
        Nothing -> return Nothing
        Just ws2 -> do
          forM_ (IM.toList (wsRegs ws2)) $ \\(k, val) -> writeArray regs k val
          return (Just (wamStateToPure ws2))

-- UnifyValue: read-mode -> unify register with next arg, write-mode -> addToBuilder.
stepST _ regs !pw (UnifyValue xn) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case readNextArg ws of
    Just (v, ws'''') ->
      case getReg xn ws of
        Just xv -> case unifyValues (derefVar (wsBindings ws) v) (derefVar (wsBindings ws) xv) ws'''' of
          Just ws2 -> do
            forM_ (IM.toList (wsRegs ws2)) $ \\(k, val) -> writeArray regs k val
            return (Just (wamStateToPure (ws2 { wsPC = wsPC ws + 1 })))
          Nothing -> return Nothing
        Nothing -> return Nothing
    Nothing ->
      case getReg xn ws of
        Just val -> case addToBuilder val ws of
          Nothing -> return Nothing
          Just ws2 -> do
            forM_ (IM.toList (wsRegs ws2)) $ \\(k, val2) -> writeArray regs k val2
            return (Just (wamStateToPure ws2))
        Nothing -> return Nothing

-- UnifyConstant: read-mode -> unify constant with next arg, write-mode -> addToBuilder.
stepST _ regs !pw (UnifyConstant c) = do
  regMap <- freezeRegsToIntMap regs
  let ws = pureToWamState pw regMap
  case readNextArg ws of
    Just (v, ws'''') -> case unifyValues (derefVar (wsBindings ws) v) c ws'''' of
      Just ws2 -> do
        forM_ (IM.toList (wsRegs ws2)) $ \\(k, val) -> writeArray regs k val
        return (Just (wamStateToPure (ws2 { wsPC = wsPC ws + 1 })))
      Nothing -> return Nothing
    Nothing -> case addToBuilder c ws of
      Nothing -> return Nothing
      Just ws2 -> do
        forM_ (IM.toList (wsRegs ws2)) $ \\(k, val) -> writeArray regs k val
        return (Just (wamStateToPure ws2))

-- Missing lax comparisons: =</2, >=/2, =:=/2, =\\=/2 (native ST).
stepST !ctx regs !pw (BuiltinCall "=</2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | a <= b -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

stepST !ctx regs !pw (BuiltinCall ">=/2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | a >= b -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

stepST !ctx regs !pw (BuiltinCall "=:=/2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | abs (a - b) < 1e-15 -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

stepST !ctx regs !pw (BuiltinCall "=\\\\=/2" _) = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let r1 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v1)
      r2 = evalArith (wcInternTable ctx) (pwBindings pw) (derefVar (pwBindings pw) v2)
  case (r1, r2) of
    (Just a, Just b) | abs (a - b) >= 1e-15 -> return $ Just pw { pwPC = pwPC pw + 1 }
    _ -> return Nothing

-- is_lax/2: delegates to is/2 (already has native stepST handler).
stepST !ctx regs !pw (BuiltinCall "is_lax/2" _) = stepST ctx regs pw (BuiltinCall "is/2" 2)

-- Lax comparison variants: delegate to their default-form handlers.
stepST !ctx regs !pw (BuiltinCall "<_lax/2" _) = stepST ctx regs pw (BuiltinCall "</2" 2)
stepST !ctx regs !pw (BuiltinCall ">_lax/2" _) = stepST ctx regs pw (BuiltinCall ">/2" 2)
stepST !ctx regs !pw (BuiltinCall ">=_lax/2" _) = stepST ctx regs pw (BuiltinCall ">=/2" 2)
stepST !ctx regs !pw (BuiltinCall "=<_lax/2" _) = stepST ctx regs pw (BuiltinCall "=</2" 2)
stepST !ctx regs !pw (BuiltinCall "=:=_lax/2" _) = stepST ctx regs pw (BuiltinCall "=:=/2" 2)
stepST !ctx regs !pw (BuiltinCall "=\\\\=_lax/2" _) = stepST ctx regs pw (BuiltinCall "=\\\\=/2" 2)

-- is_iso/2: native ST with ISO error throws.
stepST !ctx regs !pw (BuiltinCall "is_iso/2" _) = do
  v2 <- readArray regs 2
  v1 <- readArray regs 1
  let !expr = derefVar (pwBindings pw) v2
  if hasUnboundDeep (pwBindings pw) expr
    then throwIsoErrorPure pw (makeInstantiationError)
    else case evalArith (wcInternTable ctx) (pwBindings pw) expr of
      Nothing -> throwIsoErrorPure pw (makeTypeError atomEvaluable (arithCulprit (pwBindings pw) expr))
      Just r -> do
        let !lhs = derefVar (pwBindings pw) v1
        case lhs of
          Unbound vid -> do
            let val = if fromIntegral (round r :: Int) == r then Integer (round r) else Float r
            writeArray regs 1 val
            return $ Just pw { pwPC = pwPC pw + 1
                             , pwBindings = IM.insert vid val (pwBindings pw)
                             , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                             , pwTrailLen = pwTrailLen pw + 1 }
          Integer n | fromIntegral n == r -> return $ Just pw { pwPC = pwPC pw + 1 }
          _ -> return Nothing

-- ISO comparison variants: native ST with error throws.
-- Grouped handler for <_iso, >_iso, >=_iso, =<_iso, =:=_iso, =\\=_iso.
stepST !ctx regs !pw instr@(BuiltinCall op _)
  | op == "<_iso/2" || op == ">_iso/2" || op == ">=_iso/2"
    || op == "=<_iso/2" || op == "=:=_iso/2" || op == "=\\\\=_iso/2" = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let a1 = Just (derefVar (pwBindings pw) v1)
      a2 = Just (derefVar (pwBindings pw) v2)
      unboundA = case a1 of { Just v -> hasUnboundDeep (pwBindings pw) v; Nothing -> True }
      unboundB = case a2 of { Just v -> hasUnboundDeep (pwBindings pw) v; Nothing -> True }
  if unboundA || unboundB
    then throwIsoErrorPure pw (makeInstantiationError)
    else do
      let r1 = a1 >>= evalArith (wcInternTable ctx) (pwBindings pw)
          r2 = a2 >>= evalArith (wcInternTable ctx) (pwBindings pw)
      case (r1, r2) of
        (Nothing, _) ->
          let culprit = case a1 of { Just v -> arithCulprit (pwBindings pw) v; Nothing -> makePredIndicator atomUnknown 0 }
          in throwIsoErrorPure pw (makeTypeError atomEvaluable culprit)
        (_, Nothing) ->
          let culprit = case a2 of { Just v -> arithCulprit (pwBindings pw) v; Nothing -> makePredIndicator atomUnknown 0 }
          in throwIsoErrorPure pw (makeTypeError atomEvaluable culprit)
        (Just a, Just b) ->
          let ok = case op of
                "=<_iso/2"    -> a <= b
                ">=_iso/2"    -> a >= b
                "<_iso/2"     -> a < b
                ">_iso/2"     -> a > b
                "=:=_iso/2"   -> abs (a - b) < 1e-15
                "=\\\\=_iso/2" -> abs (a - b) >= 1e-15
                _             -> False
          in if ok then return $ Just pw { pwPC = pwPC pw + 1 } else return Nothing

-- succ/2, succ_lax/2: native ST bidirectional successor.
stepST _ regs !pw (BuiltinCall "succ/2" _) = succLaxST regs pw
stepST _ regs !pw (BuiltinCall "succ_lax/2" _) = succLaxST regs pw

-- succ_iso/2, throw/1, catch/3: delegate to pure bridge.
-- These use throwIsoError/WamException which need the pure WamState,
-- or (catch/3) run sub-goals via unsafePerformIO + try.

stepST !ctx regs !pw (ParTryMeElse label) = stepST ctx regs pw (TryMeElse label)
stepST !ctx regs !pw (ParRetryMeElse label) = stepST ctx regs pw (RetryMeElse label)
stepST !ctx regs !pw ParTrustMe = stepST ctx regs pw TrustMe
stepST !ctx regs !pw (ParTryMeElsePc pc) = stepST ctx regs pw (TryMeElsePc pc)
stepST !ctx regs !pw (ParRetryMeElsePc pc) = stepST ctx regs pw (RetryMeElsePc pc)

-- Fallback: delegate to pure step via bridge (freeze/thaw per call).
-- Handles: member/2, \\+/1, aggregates (BeginAggregate, EndAggregate),
-- SwitchOnConstant (label-based), functor/3, =../2, copy_term/2,
-- CallFactStream.
stepST !ctx regs !pw instr = do
  regMap <- freezeRegsToIntMap regs
  let s = pureToWamState pw regMap
  case step ctx s instr of
    Nothing -> return Nothing
    Just s'''' -> do
      forM_ (IM.toList (wsRegs s'''')) $ \\(k, v) ->
        writeArray regs k v
      return (Just (wamStateToPure s''''))

-- | Phase 3: ST-mode backtrack. Restores registers from MutableChoicePoint.
-- Handles the common case (normal CP restore) directly. Complex cases
-- (aggregate frames, builtin state) fall through to the pure bridge.
backtrackST :: STA.STArray s Int Value -> PureWamState
            -> ST s (Maybe PureWamState)
backtrackST regs pw = case pwCPs pw of
  [] -> return Nothing
  (mcp : rest)
    | isNothing (mcpAggFrame mcp) && isNothing (mcpBuiltin mcp) -> do
      -- Normal choice point: restore registers from frozen snapshot
      restoreRegsST regs (mcpRegs mcp)
      -- Undo trail entries
      let trailLen = mcpTrailLen mcp
          diff = pwTrailLen pw - trailLen
          newEntries = reverse $ take diff (pwTrail pw)
          restoredBindings = foldl'' undoBinding (mcpBindings mcp) newEntries
      return $ Just pw
        { pwPC = mcpNextPC mcp
        , pwStack = mcpStack mcp
        , pwCP = mcpCP mcp
        , pwTrail = drop diff (pwTrail pw)
        , pwTrailLen = trailLen
        , pwHeap = take (mcpHeapLen mcp) (pwHeap pw)
        , pwHeapLen = mcpHeapLen mcp
        , pwBindings = restoredBindings
        , pwCutBar = mcpCutBar mcp
        , pwCPs = rest
        , pwCPsLen = pwCPsLen pw - 1
        }
    | otherwise -> do
      -- Complex case: aggregate/builtin. Delegate to pure bridge.
      regMap <- freezeRegsToIntMap regs
      let s = pureToWamState pw regMap
      case backtrack s of
        Nothing -> return Nothing
        Just s'''' -> do
          forM_ (IM.toList (wsRegs s'''')) $ \\(k, v) ->
            writeArray regs k v
          return (Just (wamStateToPure s''''))
  where
    undoBinding bindings (TrailEntry vid mOld) =
      case mOld of
        Just old -> IM.insert vid old bindings
        Nothing  -> IM.delete vid bindings

-- | Dispatch a Call to another predicate, trying all resolution paths.
-- Used by lowered predicate functions for inter-predicate calls.
-- Non-foreign call dispatch for lowered functions. Foreign predicates
-- are dispatched via callForeign (compile-time resolved), so
-- executeForeign is NOT checked here.
{-# NOINLINE dispatchCall #-}
dispatchCall :: WamContext -> String -> WamState -> Maybe WamState
dispatchCall !ctx pred !sc =
  case Map.lookup pred (wcLoweredPredicates ctx) of
    Just fn -> fn ctx sc
    Nothing -> case callIndexedFact2 ctx pred sc of
      Just sr -> Just sr
      Nothing -> case Map.lookup pred (wcLabels ctx) of
        Just pc -> run ctx (sc { wsPC = pc })
        Nothing -> Nothing

-- Foreign call for lowered functions. Calls executeForeign directly;
-- Nothing means no solutions (backtrack). No fallthrough.
{-# INLINE callForeign #-}
callForeign :: WamContext -> String -> WamState -> Maybe WamState
callForeign !ctx pred !sc = executeForeign ctx pred sc'.

% ============================================================================
% PHASE 4: Project Generation
% ============================================================================

%% write_wam_haskell_project(+Predicates, +Options, +ProjectDir)
%  Generates a complete Haskell project (cabal or stack) with:
%  - WamTypes.hs: data types and utility functions
%  - WamRuntime.hs: run loop and backtracking
%  - Predicates.hs: compiled predicates
%  - Main.hs: benchmark driver
write_wam_haskell_project(Predicates, Options0, ProjectDir) :-
    % Phase 0: merge any declared algorithm manifest into the option
    % list BEFORE the resolvers run, so they see manifest-supplied
    % values as defaults that caller options can still override.
    % No-op (and idempotent — guarded by an internal sentinel) when no
    % decl_algorithm/2 is in scope.
    load_algorithm_manifest(Options0, OptionsM),
    % Resolve `use_lmdb(auto)` (if present) to a concrete true/false
    % BEFORE any downstream `option(use_lmdb(true), ...)` checks fire.
    % Auto consults ghc-pkg for the lmdb package + fact_count threshold;
    % see resolve_auto_use_lmdb/2.
    % Resolve all cost-based auto options (use_lmdb, cache_strategy,
    % lmdb_cache_mode, csr_index_backend) via composed chain.
    resolve_haskell_cost_options(OptionsM, Options),

    % Resolve runtime parser mode (capability hook). When `compiled`
    % is selected, the portable parser predicates + the target-agnostic
    % wrappers are appended to the user's predicate list so the Haskell
    % WAM compiler emits them too. When `none` (default), statically
    % visible parser-dependent bodies are rejected at codegen time.
    wam_target_runtime_parser(wam_haskell, Options, RuntimeParserMode),
    haskell_validate_runtime_parser_mode(Predicates, RuntimeParserMode),
    haskell_project_predicates(Predicates, RuntimeParserMode, ProjectPredicates),

    % Initialize the compile-time atom intern table with well-known atoms
    init_atom_intern_table,
    make_directory_path(ProjectDir),
    directory_file_path(ProjectDir, 'src', SrcDir),
    make_directory_path(SrcDir),

    % Determine map backend: HashMap (faster) or Map (default fallback)
    option(use_hashmap(UseHM), Options, true),

    % Phase B1: split external_source (LMDB-backed) predicates from
    % internal ones. External_source preds have no clauses-at-compile-
    % time to inspect — their data lives in the database — so they
    % must bypass kernel detection, lowering, PC computation, and WAM
    % compilation. They still appear in `Predicates` so
    % compile_predicates_to_haskell emits a skip-comment for each.
    partition(pred_is_external_source(Options), ProjectPredicates, _ExternalPreds, InternalPreds),

    % Detect recursive kernels in the predicate list. Detected kernels
    % are handled by the FFI (executeForeign) at runtime and are excluded
    % from generic lowering. The detected kernel list is used to auto-
    % populate foreignPreds in Main.hs.
    % no_kernels(true) suppresses kernel detection — all predicates go
    % through the WAM interpreter (no FFI). Useful for benchmarking.
    (   option(no_kernels(true), Options)
    ->  DetectedKernels = [],
        format(user_error, '[WAM-Haskell] kernel detection suppressed~n', [])
    ;   detect_kernels(InternalPreds, DetectedKernels0),
        % Upgrade category_ancestor to bidirectional when CSR child
        % lookup is available (csr_path provides category_child).
        (   option(kernel_mode(bidirectional), Options),
            option(csr_path(_), Options)
        ->  maplist(maybe_upgrade_bidirectional, DetectedKernels0, DetectedKernels),
            format(user_error, '[WAM-Haskell] bidirectional kernel upgrade enabled~n', [])
        ;   DetectedKernels = DetectedKernels0
        ),
        (   DetectedKernels \= []
        ->  pairs_keys(DetectedKernels, DetectedKeys),
            format(user_error, '[WAM-Haskell] detected kernels: ~w~n', [DetectedKeys])
        ;   true
        )
    ),

    % Resolve emit_mode and partition predicates. Detected kernels are
    % explicitly excluded from lowering (they use FFI via CallForeign).
    wam_haskell_resolve_emit_mode(Options, EmitMode),
    wam_haskell_partition_predicates(EmitMode, InternalPreds, DetectedKernels, InterpretedList, LoweredList),
    length(InterpretedList, NInterp),
    length(LoweredList, NLower),
    format(user_error,
           '[WAM-Haskell] emit_mode=~w  interpreted=~w  lowered=~w~n',
           [EmitMode, NInterp, NLower]),

    % Generate WamTypes.hs
    generate_wam_types_hs(TypesCode0),
    apply_hashmap_rewrite(UseHM, types, TypesCode0, TypesCode),
    directory_file_path(SrcDir, 'WamTypes.hs', TypesPath),
    write_hs_file(TypesPath, TypesCode),

    % Generate WamRuntime.hs
    compile_wam_runtime_to_haskell(Options, DetectedKernels, RuntimeCode0),
    apply_hashmap_rewrite(UseHM, runtime, RuntimeCode0, RuntimeCode),
    directory_file_path(SrcDir, 'WamRuntime.hs', RuntimePath),
    write_hs_file(RuntimePath, RuntimeCode),

    % ALL predicates go into the interpreter's instruction array — even
    % lowered ones — so backtrack can land on alternate clauses that the
    % lowered function doesn't handle. Phase 4+ lowered functions only
    % inline clause 1; clause 2+ runs through the interpreter on backtrack.
    compile_predicates_to_haskell(InternalPreds, Options, PredsCode0, InlineDefs),
    % Append compile-time atom table to Predicates.hs
    emit_atom_table_haskell(AtomTableCode),
    format(string(PredsCode0WithAtoms), "~w~n~n~w", [PredsCode0, AtomTableCode]),
    apply_hashmap_rewrite(UseHM, generic, PredsCode0WithAtoms, PredsCode),
    directory_file_path(SrcDir, 'Predicates.hs', PredsPath),
    write_hs_file(PredsPath, PredsCode),

    % Lower each predicate in LoweredList via the Phase 3+ emitter.
    % We first compute global base PCs matching the merged instruction
    % array so the lowered functions' PC references (wsCP for Call return
    % addresses, wsPC for step calls) are correct.
    compute_base_pcs(InternalPreds, BasePCMap),
    lower_all(LoweredList, BasePCMap, DetectedKernels, LoweredEntries),
    generate_lowered_hs(LoweredEntries, LoweredCode0),
    apply_hashmap_rewrite(UseHM, generic, LoweredCode0, LoweredCode),
    directory_file_path(SrcDir, 'Lowered.hs', LoweredPath),
    write_hs_file(LoweredPath, LoweredCode),

    % Generate cabal file
    option(module_name(ModName), Options, 'wam-haskell-bench'),
    generate_cabal_file(ModName, UseHM, Options, CabalCode),
    format(atom(CabalFile), '~w.cabal', [ModName]),
    directory_file_path(ProjectDir, CabalFile, CabalPath),
    write_hs_file(CabalPath, CabalCode),

    % Generate Main.hs (InlineDefs from F3 → wcInlineFacts wiring)
    generate_main_hs(InternalPreds, DetectedKernels, InlineDefs, Options, MainCode0),
    apply_hashmap_rewrite(UseHM, main, MainCode0, MainCode),
    directory_file_path(SrcDir, 'Main.hs', MainPath),
    write_hs_file(MainPath, MainCode),

    % Generate CsrReader.hs if csr_path is set
    (   option(csr_path(_CsrPath), Options)
    ->  option(csr_relation(CsrRel), Options, 'category_child'),
        read_kernel_template('csr_reader.hs.mustache', CsrTemplate),
        render_template(CsrTemplate, [csr_relation=CsrRel], CsrCode0),
        atom_string(CsrCode0, CsrCode),
        directory_file_path(SrcDir, 'CsrReader.hs', CsrPath0),
        write_hs_file(CsrPath0, CsrCode),
        format(user_error, '[WAM-Haskell] CSR reader emitted for relation: ~w~n', [CsrRel])
    ;   true
    ),

    format(user_error, '[WAM-Haskell] Generated project at: ~w (hashmap=~w)~n', [ProjectDir, UseHM]).

%% apply_hashmap_rewrite(+UseHM, +Module, +InCode, -OutCode)
%  When UseHM=true, rewrite Data.Map.Strict references to Data.HashMap.Strict.
apply_hashmap_rewrite(false, _, Code, Code) :- !.
apply_hashmap_rewrite(true, Module, Code0, Code) :-
    % Replace import line
    replace_substr(Code0, "import qualified Data.Map.Strict as Map",
                   "import qualified Data.HashMap.Strict as Map", Code1),
    % Replace Map.Map type constructor with Map.HashMap
    replace_substr(Code1, "Map.Map ", "Map.HashMap ", Code2),
    % HashMap has no toAscList — use toList instead (loses ordering, but
    % the only use site builds a SwitchOnConstant which doesn''t need it)
    replace_substr(Code2, "Map.toAscList", "Map.toList", Code3),
    % For WamTypes, add a Hashable instance for Value (needed for HashMap keys).
    % IntSet does not have a Hashable instance in the older dependency set
    % used by the local Cabal build, so hash VSet through its stable list form.
    (   Module == types
    ->  replace_substr(Code3,
            "module WamTypes where\n\nimport qualified Data.HashMap.Strict as Map",
            "module WamTypes where\n\nimport qualified Data.HashMap.Strict as Map\nimport Data.Hashable (Hashable(..))",
            Code4),
        replace_substr(Code4,
            "deriving (Eq, Ord, Show)",
            "deriving (Eq, Ord, Show)\n\ninstance Hashable Value where\n  hashWithSalt salt (Atom n) = hashWithSalt salt (0 :: Int, n)\n  hashWithSalt salt (Integer n) = hashWithSalt salt (1 :: Int, n)\n  hashWithSalt salt (Float f) = hashWithSalt salt (2 :: Int, f)\n  hashWithSalt salt (VList xs) = hashWithSalt salt (3 :: Int, xs)\n  hashWithSalt salt (VSet s) = hashWithSalt salt (4 :: Int, IS.toList s)\n  hashWithSalt salt (Str n args) = hashWithSalt salt (5 :: Int, n, args)\n  hashWithSalt salt (Unbound n) = hashWithSalt salt (6 :: Int, n)\n  hashWithSalt salt (Ref n) = hashWithSalt salt (7 :: Int, n)",
            Code)
    ;   Code = Code3
    ).

%% replace_substr(+Str, +From, +To, -Result)
%  Replace all occurrences of From with To in Str.
replace_substr(Str, From, To, Result) :-
    atom_string(Str, S),
    atom_string(From, FS),
    atom_string(To, TS),
    re_split_replace(S, FS, TS, R),
    atom_string(Result, R).

re_split_replace(S, From, To, Result) :-
    (   sub_string(S, B, _Len, A, From)
    ->  sub_string(S, 0, B, _, Before),
        sub_string(S, _, A, 0, After),
        re_split_replace(After, From, To, AfterR),
        atom_string(BeforeA, Before),
        atom_string(ToA, To),
        atom_string(AfterRA, AfterR),
        atomic_list_concat([BeforeA, ToA, AfterRA], R),
        atom_string(R, Result)
    ;   Result = S
    ).

%% generate_lowered_hs(+LoweredEntries, -Code)
%  Emit the Lowered.hs module containing one function per predicate in
%  LoweredEntries and a loweredPredicates dispatch Map. Each entry is a
%  term lowered(PredName, FuncName, HaskellCode) produced by the
%  wam_haskell_lowered_emitter:lower_predicate_to_haskell/4 helper.
%
%  When the list is empty, emits a skeleton module with
%  loweredPredicates = Map.empty (Phase 2 shape). The Lowered.hs module
%  is emitted unconditionally so Main.hs can unconditionally
%  `import qualified Lowered`.
%
%  See docs/design/WAM_HASKELL_LOWERED_SPECIFICATION.md §2.1.
generate_lowered_hs([], Code) :- !,
    with_output_to(string(Code), (
        format("{-# LANGUAGE BangPatterns #-}~n"),
        format("-- WAM-lowered Haskell predicates (empty — no preds lowered).~n"),
        format("module Lowered where~n~n"),
        format("import qualified Data.Map.Strict as Map~n"),
        format("import qualified Data.IntMap.Strict as IM~n"),
        format("import WamTypes~n"),
        format("import Data.Maybe (fromMaybe, isNothing)~n"),
        format("import WamRuntime~n~n"),
        format("loweredPredicates :: Map.Map String (WamContext -> WamState -> Maybe WamState)~n"),
        format("loweredPredicates = Map.empty~n")
    )).
generate_lowered_hs(LoweredEntries, Code) :-
    LoweredEntries = [_|_],  % non-empty
    with_output_to(string(Code), (
        format("{-# LANGUAGE BangPatterns #-}~n"),
        format("-- WAM-lowered Haskell predicates.~n"),
        format("--~n"),
        format("-- One function per predicate in the lowered partition, plus a~n"),
        format("-- dispatch map wired into WamContext.wcLoweredPredicates by Main.hs.~n"),
        format("module Lowered where~n~n"),
        format("import qualified Data.Map.Strict as Map~n"),
        format("import qualified Data.IntMap.Strict as IM~n"),
        format("import WamTypes~n"),
        format("import Data.Maybe (fromMaybe, isNothing)~n"),
        format("import WamRuntime~n~n"),
        % Function definitions
        forall(member(lowered(_, _, HsCode), LoweredEntries),
               format("~w~n", [HsCode])),
        % Dispatch map
        format("loweredPredicates :: Map.Map String (WamContext -> WamState -> Maybe WamState)~n"),
        format("loweredPredicates = Map.fromList~n"),
        format("    [ "),
        emit_lowered_entries(LoweredEntries),
        format("    ]~n")
    )).

% Emit the Map.fromList entries, one per line with a leading comma on
% all but the first.
emit_lowered_entries([lowered(PredName, FuncName, _)|Rest]) :-
    format("(\"~w\", ~w)~n", [PredName, FuncName]),
    emit_lowered_entries_rest(Rest).
emit_lowered_entries_rest([]).
emit_lowered_entries_rest([lowered(PredName, FuncName, _)|Rest]) :-
    format("    , (\"~w\", ~w)~n", [PredName, FuncName]),
    emit_lowered_entries_rest(Rest).

%% generate_main_hs(+Predicates, +DetectedKernels, +InlineDefs, +Options, -Code)
%  Generates Main.hs — a benchmark driver for effective-distance.
%  Reads main.hs.mustache and populates template variables.
%  InlineDefs from Phase F3: list of inline_fact(PredName, ListName, _)
%  terms that need wcInlineFacts wiring.
%  Options:
%    query_pred(Pred/Arity) — use a WAM-compiled aggregation predicate
%      instead of the default collectSolutions loop. The predicate should
%      accept (Cat, Root, WeightSum) and return the accumulated weight sum.
generate_main_hs(_Predicates, DetectedKernels, InlineDefs, Options, Code) :-
    read_kernel_template('main.hs.mustache', Template),
    detected_kernel_keys(DetectedKernels, Keys),
    format_foreign_preds(Keys, ForeignPredsStr),
    option(benchmark_mode(Mode), Options, wam_haskell_accumulated),
    % When kernels are detected, the query body should use executeForeign
    % dispatch instead of running WAM code (fact code is skipped).
    (   DetectedKernels \= []
    ->  QueryOptions = [use_ffi(true)|Options]
    ;   QueryOptions = Options
    ),
    generate_merged_code_build(DetectedKernels, Options, MergedCodeBuild),
    generate_demand_filter(DetectedKernels, Options, DemandFilter, FactsSource),
    generate_query_body(QueryOptions, RawQueryBody),
    generate_demand_gated_query_body(DemandFilter, RawQueryBody, QueryBody),
    %% When the demand filter is active, parMap iterates over the
    %% pre-filtered seed list (so skipped seeds don't pay spark
    %% synchronization cost). Otherwise it iterates over seedCats as
    %% before. See generate_demand_filter for the filteredSeedCats
    %% binding.
    (   DemandFilter \= ''
    ->  ParmapSeedSource = 'filteredSeedCats'
    ;   ParmapSeedSource = 'seedCats'
    ),
    (   DemandFilter \= ''
    ->  DemandMetrics =
'    hPutStrLn stderr $ "demand_set_size=" ++ show demandSize
    hPutStrLn stderr $ "demand_total_nodes=" ++ show totalNodes
    hPutStrLn stderr $ "demand_filtered_nodes=" ++ show filteredSize
    hPutStrLn stderr $ "demand_skipped_seeds=" ++ show demandSkippedSeeds'
    ;   DemandMetrics = ''
    ),
    % Phase F3/F4: generate wcInlineFacts wiring from InlineDefs
    generate_inline_facts_wiring(InlineDefs, InlineFactsWiring),
    % Phase B1: generate LMDB setup and context wiring
    generate_lmdb_wiring(Options, LmdbSetup, LmdbContext, LmdbImport),
    % Int-atom-seeds path: when use_lmdb(true) and seeds come pre-interned
    % as int32 IDs from the LMDB ingest pipeline, skip the TSV-based
    % seed loading and string interning.  Gated by section blocks in the
    % template; this just exposes the flag to the renderer.
    %
    % Three modes:
    %   int_atom_seeds(false) (default) — TSV mode; full string parsing.
    %   int_atom_seeds(true)            — int_ids.txt files; iAtom = id.
    %   int_atom_seeds(lmdb)            — Phase 2b.1: codegen surface only;
    %                                     runtime panics with a clear
    %                                     "not yet implemented" message
    %                                     pending Phase 2b.2.
    (   option(int_atom_seeds(lmdb), Options)
    ->  IntAtomSeeds = true,
        IntAtomSeedsLmdb = true
    ;   option(int_atom_seeds(true), Options)
    ->  IntAtomSeeds = true,
        IntAtomSeedsLmdb = false
    ;   IntAtomSeeds = false,
        IntAtomSeedsLmdb = false
    ),
    % lmdb_skip_intern_table(true): in int_atom_seeds(lmdb) mode the seeds,
    % edges, and output are all int-keyed (iAtom = id, results printed as raw
    % ids), so the s2i/i2s intern table is dead weight — at enwiki scale it is
    % ~3.78M entries / ~3.8 GB RSS that starves the OS page cache of the LMDB
    % (see WAM_PERF_OPTIMIZATION_LOG.md appendix #18). When set, skip the
    % loadInternTableFromLmdb call and use compileTimeAtomTable (the WAM
    % program's own atoms, all extractDouble needs). Only valid with
    % int_atom_seeds(lmdb); default false preserves de-interning for any
    % consumer that prints category names.
    (   IntAtomSeedsLmdb == true,
        option(lmdb_skip_intern_table(true), Options)
    ->  LmdbSkipInternTable = true
    ;   LmdbSkipInternTable = false
    ),
    % Resolve max_depth at codegen time. Reads user:max_depth/1 (asserted
    % by the workload or overridden by tests) so the generated FFI kernel
    % uses the same depth bound SWI-Prolog would. Defaults to 10 to match
    % the historical hardcoded value when no max_depth/1 fact is present.
    % See effective_distance.pl line 43 for the workload's default.
    resolve_max_depth(Options, MaxDepth),
    % Resolve dimension_n at codegen time. Same instrumentation-bug class
    % as max_depth: a user-asserted user:dimension_n/1 must reach the
    % aggregation formula (n in Hops^(-N) and the inverse exponent), not
    % be silently overridden by a hardcoded 5.0 in the template.
    resolve_dimension_n(Options, DimN),
    %% Phase 2b.3: also resolve demand_bfs_mode so the int_atom_seeds_lmdb
    %% loader block can skip loadForwardEdgesFromLmdb in cursor mode.
    %% Otherwise the 5_000_000-edge guard fires before demand BFS even
    %% runs, defeating the whole purpose of cursor mode at scale.
    resolve_auto_demand_bfs_mode(Options, BfsModeForLoaders),
    (   BfsModeForLoaders == cursor
    ->  DemandBfsModeCursor = true
    ;   DemandBfsModeCursor = false
    ),
    % CSR support: generate import and setup blocks when csr_path is set.
    (   option(csr_path(CsrPathOpt), Options)
    ->  HasCsr = true,
        option(csr_relation(CsrRelOpt), Options, 'category_child'),
        format(atom(CsrSetup),
            '    -- CSR reverse-index setup\n    csrEdgeLookup <- CsrReader.openCsrEdgeLookup (factsDir ++ "/~w") "~w"\n',
            [CsrPathOpt, CsrRelOpt]),
        format(atom(CsrContext),
            '            , wcEdgeLookups = Map.insert "~w" csrEdgeLookup (wcEdgeLookups ctx)\n',
            [CsrRelOpt]),
        CsrImport = 'import qualified CsrReader'
    ;   HasCsr = false,
        CsrSetup = '',
        CsrContext = '',
        CsrImport = ''
    ),
    render_template(Template,
        [ foreign_preds=ForeignPredsStr
        , benchmark_mode=Mode
        , query_body=QueryBody
        , merged_code_build=MergedCodeBuild
        , demand_filter=DemandFilter
        , facts_source=FactsSource
        , demand_metrics=DemandMetrics
        , inline_facts=InlineFactsWiring
        , lmdb_setup=LmdbSetup
        , lmdb_context=LmdbContext
        , lmdb_import=LmdbImport
        , csr_import=CsrImport
        , csr_setup=CsrSetup
        , csr_context=CsrContext
        , has_csr=HasCsr
        , int_atom_seeds=IntAtomSeeds
        , int_atom_seeds_lmdb=IntAtomSeedsLmdb
        , lmdb_skip_intern_table=LmdbSkipInternTable
        , demand_bfs_mode_cursor=DemandBfsModeCursor
        , max_depth=MaxDepth
        , dimension_n=DimN
        , parmap_seed_source=ParmapSeedSource
        ], Code).

%% resolve_max_depth(+Options, -MaxDepth)
%  Determine the FFI kernel's depth bound. Priority order:
%   1. Options list: max_depth(N)
%   2. user:max_depth/1 fact (asserted by the workload)
%   3. Default: 10
%  Always returns a positive integer.
resolve_max_depth(Options, MaxDepth) :-
    (   option(max_depth(M), Options),
        integer(M),
        M >= 1
    ->  MaxDepth = M
    ;   current_predicate(user:max_depth/1),
        user:max_depth(M),
        integer(M),
        M >= 1
    ->  MaxDepth = M
    ;   MaxDepth = 10
    ).

%% resolve_dimension_n(+Options, -DimN)
%  Determine the aggregation formula's dimensionality (the N in
%  d_eff = (sum Hops^(-N))^(-1/N)). Priority order:
%   1. Options list: dimension_n(N)
%   2. user:dimension_n/1 fact (asserted by the workload)
%   3. Default: 5
%  Always returns a positive integer.
resolve_dimension_n(Options, DimN) :-
    (   option(dimension_n(N), Options),
        integer(N),
        N >= 1
    ->  DimN = N
    ;   current_predicate(user:dimension_n/1),
        user:dimension_n(N),
        integer(N),
        N >= 1
    ->  DimN = N
    ;   DimN = 5
    ).

%% generate_inline_facts_wiring(+InlineDefs, -Code)
%  Generates the Haskell code to populate wcInlineFacts in the WamContext.
%  Each inline_fact(PredName, ListName, _) becomes a Map entry.
generate_inline_facts_wiring([], '') :- !.
generate_inline_facts_wiring(InlineDefs, Code) :-
    maplist([inline_fact(PredName, ListName, _), Entry]>>(
        format(string(Entry), '("~w", ~w)', [PredName, ListName])
    ), InlineDefs, Entries),
    atomic_list_concat(Entries, ', ', EntriesStr),
    format(string(Code),
           '            , wcInlineFacts   = Map.fromList [~w]',
           [EntriesStr]).

%% generate_lmdb_wiring(+Options, -SetupCode, -ContextCode, -ImportCode)
%  When use_lmdb(true), generates:
%  - SetupCode: LMDB ingestion + FactSource creation at startup
%  - ContextCode: wcFactSources wiring in the WamContext
%  - ImportCode: System.Directory import for doesDirectoryExist
%  Ingestion is idempotent — skips if the LMDB directory already exists.
%  When not enabled, all are empty strings.
generate_lmdb_wiring(Options, SetupCode, ContextCode, ImportCode) :-
    (   option(use_lmdb(true), Options)
    ->  ImportCode = 'import System.Directory (doesDirectoryExist, createDirectory)\nimport Database.LMDB.Raw (MDB_env)',
        % Three layout/source variants:
        %   - lmdb_layout(dupsort): LMDB is built externally by the
        %     streaming pipeline (no in-process ingest, error if missing).
        %   - lmdb_fact_source_manifest(Dir): standard TSV ingest, but
        %     FactSource opens via manifest.json metadata (UTF-8 keys).
        %   - default: WAM-native packed-Int32 layout, TSV ingest at
        %     startup if missing.
        (   option(lmdb_layout(dupsort), Options)
        ->  SetupCode =
'    -- Phase B1: LMDB fact source setup (dupsort layout, externally ingested)
    let lmdbDir = factsDir ++ "/lmdb"
    lmdbExists <- doesDirectoryExist lmdbDir
    if not lmdbExists then
      error ("LMDB not found at " ++ lmdbDir ++ "; build it via the streaming pipeline first")
    else
      hPutStrLn stderr "LMDB database found (dupsort layout)."
    cpEdgeLookup <- openLmdbEdgeLookup lmdbDir "category_parent"
    cpFactSource <- lmdbFactSource lmdbDir "category_parent"'
        ;   (   option(lmdb_fact_source_manifest(ManifestDir0), Options)
            ->  format(string(FactSourceOpen),
'    cpFactSource <- lmdbFactSourceFromManifest fullInternTable "~w"',
                       [ManifestDir0])
            ;   FactSourceOpen =
'    -- Also open as FactSource for WAM interpreter path
    cpFactSource <- lmdbFactSource lmdbDir "category_parent"'
            ),
            format(string(SetupCode),
'    -- Phase B1/B2: LMDB fact source setup
    let lmdbDir = factsDir ++ "/lmdb"
    -- Ingest TSV into LMDB (idempotent — skips if directory exists)
    lmdbExists <- doesDirectoryExist lmdbDir
    if not lmdbExists then do
      createDirectory lmdbDir
      hPutStrLn stderr "Ingesting TSV into LMDB..."
      ingestTsvToLmdb fullInternTable (factsDir ++ "/category_parent.tsv") lmdbDir "category_parent"
      hPutStrLn stderr "LMDB ingestion complete."
    else
      hPutStrLn stderr "LMDB database found, skipping ingestion."
    cpEdgeLookup <- openLmdbEdgeLookup lmdbDir "category_parent"
~w',
                  [FactSourceOpen])
        ),
        ContextCode =
'            , wcFactSources   = Map.singleton "category_parent" cpFactSource
            , wcEdgeLookups   = Map.singleton "category_parent" cpEdgeLookup'
    ;   SetupCode = '',
        ContextCode = '',
        ImportCode = ''
    ).

%% generate_demand_filter(+DetectedKernels, +Options, -FilterCode, -FactsSource)
%  When demand filtering is enabled (kernels detected with an edge predicate),
%  emit code that builds a DemandFilterSpec, dispatches via runDemandBFS, and
%  filters the parents index. Otherwise emit nothing and use the unfiltered
%  index.
%
%  The DemandFilterSpec is selected by:
%    - declare_demand_filter/2 directive in user code (preferred)
%    - declare_demand_filter(Strategy, Opts) option (override)
%    - default `HopLimit Nothing` (unbounded — matches pre-Phase-2 behaviour)
%
%  See docs/design/WAM_DEMAND_FILTER_SPECIFICATION.md for the type.
generate_demand_filter(DetectedKernels, Options, FilterCode, FactsSource) :-
    (   option(demand_filter(false), Options)
    ->  FilterCode = '',
        FactsSource = 'parentsIndexInterned'
    ;   DetectedKernels \= []
    ->  resolve_demand_filter_spec(Options, SpecHs),
        %% Phase 2b.3 demand_bfs_mode: cursor walks the LMDB
        %% category_child sub-db, no in-memory parentsIndex needed.
        %% Default = in_memory (preserves Phase 2b.2 behaviour for
        %% callers without LMDB or with the pre-load IntMap path).
        %% cursor mode requires int_atom_seeds(lmdb) (so internEnv is
        %% in scope) and the fixture to have been ingested with the
        %% category_child reverse-edge sub-db.
        resolve_auto_demand_bfs_mode(Options, BfsMode),
        (   BfsMode == cursor
        ->  format(string(FilterCode),
'    let !rootId = iAtom root
        !demandFilterSpec = ~w
    !demandFilterResult <- runDemandBFSCursor demandFilterSpec internEnv "category_child" rootId
    let !demandSet = dfrInSet demandFilterResult
        !demandSize = IS.size demandSet
        !totalNodes = -1 :: Int  -- unknown without iterating LMDB
        !filteredSize = -1 :: Int  -- LMDB is the source of truth; no filteredParents map
        !filteredSeedCats = filter (\\cat -> IS.member (iAtom cat) demandSet) seedCats
        !demandSkippedSeeds = length seedCats - length filteredSeedCats',
                [SpecHs]),
            FactsSource = 'parentsIndexInterned'  % unused at runtime in this mode
        ;   format(string(FilterCode),
'    let !rootId = iAtom root
        !demandFilterSpec = ~w
        !demandFilterResult = runDemandBFS demandFilterSpec parentsIndexInterned rootId
        !demandSet = dfrInSet demandFilterResult
        !demandSize = IS.size demandSet
        !totalNodes = IM.size parentsIndexInterned
        !filteredParents = filterByDemand demandSet parentsIndexInterned
        !filteredSize = IM.size filteredParents
        -- Pre-filter seedCats so parMap below only sparks seeds that can
        -- actually reach root. Without this, every skipped seed pays
        -- spark synchronization overhead even though its work is trivial,
        -- which kills parallel speedup at -N>1 on workloads where most
        -- seeds are gated out (e.g. 50k_cats: 49989/50000 skipped).
        !filteredSeedCats = filter (\\cat -> IS.member (iAtom cat) demandSet) seedCats
        !demandSkippedSeeds = length seedCats - length filteredSeedCats',
                [SpecHs]),
            FactsSource = 'filteredParents'
        )
    ;   FilterCode = '',
        FactsSource = 'parentsIndexInterned'
    ).

%% resolve_auto_demand_bfs_mode(+Options, -Mode)
%  Pick the demand BFS implementation. Precedence:
%    1. demand_bfs_mode(in_memory|cursor) explicit option.
%    2. demand_bfs_mode(auto) — pick by fact_count threshold:
%       - fact_count >= 50_000 -> cursor (avoids materialising the full
%         reverse adjacency in memory)
%       - otherwise            -> in_memory (faster at small scale,
%         no per-edge LMDB cursor overhead)
%    3. Default: in_memory (preserves Phase 2b.2 behaviour).
%  Note: cursor mode requires int_atom_seeds(lmdb) AND a fixture with
%  the category_child reverse-edge sub-db. Caller is responsible for
%  ensuring those preconditions hold before opting in.
resolve_auto_demand_bfs_mode(Options, Mode) :-
    (   option(demand_bfs_mode(in_memory), Options)
    ->  Mode = in_memory
    ;   option(demand_bfs_mode(cursor), Options)
    ->  Mode = cursor
    ;   option(demand_bfs_mode(auto), Options)
    ->  (   option(fact_count(N), Options),
            integer(N),
            N >= 50000
        ->  Mode = cursor
        ;   Mode = in_memory
        )
    ;   Mode = in_memory
    ).

%% resolve_auto_cache_strategy(+Options0, -Options) is det.
%
%  Phase 2c opt-in resolver. When `cache_strategy(auto)` is set,
%  consult cost_model:recommend_access_pattern/5 with workload
%  metadata, then translate the pattern recommendation (sort/scan)
%  into a concrete `demand_bfs_mode/1` option that downstream code
%  already understands.
%
%  Inputs read from Options (with defaults):
%
%    - fact_count(N)              — total facts in the source DB
%    - expected_query_count(M)    — anticipated number of queries
%                                   (default: 1)
%    - working_set_fraction(F)    — per-query touched fraction of facts
%                                   (default: 0.05; i.e. each query
%                                   touches ~5% of the data set)
%    - db_size_bytes(B)           — bytes a full scan would touch
%                                   (default: estimate as fact_count
%                                   * 50 bytes/edge)
%    - mem_available_bytes(R)     — override /proc/meminfo probe
%                                   (default: probe MemAvailable;
%                                   1 GB fallback on non-Linux)
%    - cost_model_constants(L)    — override hardware constants list
%                                   passed to cost_model
%                                   (default: cost_model defaults)
%    - cache_strategy_verbose(true) — emit a stderr trace of the
%                                     decision (default: silent)
%
%  Output mapping:
%
%    cost_model says `sort` → demand_bfs_mode(cursor)
%      (cursor BFS = per-key seek pattern)
%    cost_model says `scan` → demand_bfs_mode(in_memory)
%      (pre-load IntMap = sequential scan pattern)
%
%  Footprint guard: when the cost model recommends `scan` but
%  `W > R_free`, the in_memory implementation would materialise an
%  IntMap larger than available RAM. The guard overrides the
%  recommendation to `cursor` in that case. Phase L#11 (Phase 2c
%  validation) surfaced this gap; the cost model decides access
%  patterns but says nothing about working-set footprint.
%
%  Composes with `resolve_auto_demand_bfs_mode/2`: this resolver
%  replaces any existing `demand_bfs_mode/1` term, so the downstream
%  resolver sees a concrete value and is a no-op.
%
%  Behaviour unchanged when `cache_strategy(auto)` is absent.
%
%  See docs/design/CACHE_COST_MODEL_PHILOSOPHY.md and
%  docs/design/WAM_PERF_OPTIMIZATION_LOG.md Phase M appendix #10.
resolve_auto_cache_strategy(Options0, Options) :-
    (   option(cache_strategy(auto), Options0)
    ->  compute_cache_strategy_decision(Options0, BfsMode),
        select(cache_strategy(auto), Options0, AfterStripStrategy),
        exclude(=(demand_bfs_mode(_)), AfterStripStrategy, AfterStripBfs),
        Options = [demand_bfs_mode(BfsMode) | AfterStripBfs]
    ;   Options = Options0
    ).

compute_cache_strategy_decision(Options, BfsMode) :-
    option(fact_count(FactCount), Options, 0),
    option(expected_query_count(_QueryCount), Options, 1),
    option(working_set_fraction(WSF), Options, 0.05),
    (   option(db_size_bytes(DBSize), Options),
        integer(DBSize), DBSize > 0
    ->  WBytes = DBSize
    ;   WBytes is FactCount * 50
    ),
    KKeys is integer(FactCount * WSF),
    (   option(mem_available_bytes(R), Options),
        integer(R), R > 0
    ->  RFree = R
    ;   catch(read_mem_available_bytes(RFree), _, RFree = 1_000_000_000)
    ),
    option(cost_model_constants(Constants), Options, []),
    recommend_access_pattern(KKeys, WBytes, RFree, Constants, Pattern),
    %% Footprint guard: cost_model decides between sort/scan access
    %% patterns, but our `in_memory` implementation materialises the
    %% full edge IntMap (working-set bytes resident in RAM). When
    %% R_free < W the IntMap allocation would blow the available
    %% memory budget — even though the model considers in_memory the
    %% cheaper access pattern, we can't actually run it. Override to
    %% cursor in that case. Documented in Phase L appendix #11
    %% (the cold-regime probe that surfaced this).
    (   Pattern = sort
    ->  BfsMode = cursor,
        Override = none
    ;   WBytes > RFree
    ->  BfsMode = cursor,
        Override = footprint_guard
    ;   BfsMode = in_memory,
        Override = none
    ),
    (   option(cache_strategy_verbose(true), Options)
    ->  (   Override == footprint_guard
        ->  format(user_error,
                   '[WAM-Haskell] cache_strategy(auto): K=~w W=~w R_free=~w → ~w (cursor, footprint guard: W > R_free)~n',
                   [KKeys, WBytes, RFree, Pattern])
        ;   format(user_error,
                   '[WAM-Haskell] cache_strategy(auto): K=~w W=~w R_free=~w → ~w (~w)~n',
                   [KKeys, WBytes, RFree, Pattern, BfsMode])
        )
    ;   true
    ).

%% resolve_auto_lmdb_cache_mode(+Options0, -Options) is det.
%
%  Phase 2c+ opt-in resolver for `lmdb_cache_mode(auto)`. Decides
%  between `none` / `per_hec` (L1) / `sharded` (L2) / `two_level`
%  (L1+L2) from workload metadata.
%
%  Opt-in signal: presence of `workload_locality/1` in Options. Without
%  it, this resolver is a no-op and the existing in-place resolution
%  in `generate_lmdb_functions/2` (via
%  `statistics:select_cache_mode/2`) continues to handle the auto
%  path. With it, the new resolver runs and the in-place path becomes
%  a no-op because `lmdb_cache_mode(auto)` has already been replaced
%  with a concrete value.
%
%  Inputs:
%
%    - `lmdb_cache_mode(auto)`         — triggers resolution
%    - `workload_locality(L)`          — opt-in signal; L ∈
%                                        {intra_thread, cross_thread,
%                                         mixed, unknown}
%    - `expected_query_count(M)`       — defaults to 1
%    - `demand_bfs_mode/1`             — read to compose with
%                                        cache_strategy resolver
%    - `cache_strategy_verbose(true)`  — stderr trace of decision
%
%  Composition with `resolve_auto_cache_strategy/2`:
%
%    If the cache_strategy resolver already picked `in_memory`, the
%    edge IntMap *is* the cache and adding another tier is redundant.
%    Pick `none` in that case regardless of locality / M.
%
%  Memory budget guard (Phase L#13): when R_free is below
%  `cache_tier_floor_bytes(N)` (default 4 MB), pick `none` regardless
%  of locality/M. Symmetric to the working-set footprint guard in
%  `compute_cache_strategy_decision/2` but for the cache layer rather
%  than the BFS state.
%
%  Decision matrix for the cursor path (when memory budget allows):
%
%    M = 1                          → none      (no queries to amortise over)
%    M > 1 & intra_thread          → per_hec   (L1)
%    M > 1 & cross_thread          → sharded   (L2)
%    M > 10 & mixed                → two_level (L1+L2)
%    M > 1 & (mixed but M ≤ 10)    → sharded   (safe default)
%    M > 1 & unknown               → sharded   (safe default;
%                                                matches the existing
%                                                resident_auto hardcode)
%
%  The `unknown → sharded` default mirrors the conventional wisdom
%  documented in the matrix-bench: per-HEC L1 caches duplicate hot
%  edges across threads when sparks have no region affinity, so until
%  MoE-style spark routing lands, sharded is the right floor.
%
%  See docs/design/CACHE_COST_MODEL_PHILOSOPHY.md (decision-matrix
%  section).
resolve_auto_lmdb_cache_mode(Options0, Options) :-
    (   option(lmdb_cache_mode(auto), Options0),
        memberchk(workload_locality(_), Options0)
    ->  compute_lmdb_cache_mode_decision(Options0, Mode),
        select(lmdb_cache_mode(auto), Options0, Rest),
        Options = [lmdb_cache_mode(Mode) | Rest]
    ;   Options = Options0
    ).

compute_lmdb_cache_mode_decision(Options, Mode) :-
    (   option(demand_bfs_mode(in_memory), Options)
    ->  Mode = none,
        Reason = in_memory_path
    ;   cache_tier_memory_budget_short(Options, FloorBytes, RFree)
    ->  Mode = none,
        Reason = memory_budget(RFree, FloorBytes)
    ;   option(expected_query_count(M), Options, 1),
        option(workload_locality(Locality), Options, unknown),
        (   M =< 1
        ->  Mode = none, Reason = m_too_small
        ;   Locality == intra_thread
        ->  Mode = per_hec, Reason = intra_thread
        ;   Locality == cross_thread
        ->  Mode = sharded, Reason = cross_thread
        ;   Locality == mixed, M > 10
        ->  Mode = two_level, Reason = mixed
        ;   Mode = sharded, Reason = default_safe
        )
    ),
    (   option(cache_strategy_verbose(true), Options)
    ->  format(user_error,
               '[WAM-Haskell] lmdb_cache_mode(auto) → ~w (~w)~n',
               [Mode, Reason])
    ;   true
    ).

%% cache_tier_memory_budget_short(+Options, -FloorBytes, -RFree) is semidet.
%
%  True when free RAM is below the minimum needed to host even a
%  modest cache. Reads:
%    - cache_tier_floor_bytes(N): minimum RAM the cache layer needs
%      to be useful. Default 4 MB — enough headroom for a small L2
%      with the default capacity, leaves the budget guard biased
%      toward enabling caching when free RAM is plentiful but
%      protects against OOM under memory pressure.
%    - mem_available_bytes(R): /proc/meminfo:MemAvailable override
%      (same fallback chain as the cache_strategy resolver).
%  Symmetric to the working-set footprint guard in
%  compute_cache_strategy_decision/2 (Phase L#11) but for the cache
%  layer rather than the BFS state.
cache_tier_memory_budget_short(Options, FloorBytes, RFree) :-
    option(cache_tier_floor_bytes(FloorBytes), Options, 4_000_000),
    integer(FloorBytes),
    FloorBytes > 0,
    (   option(mem_available_bytes(R), Options),
        integer(R), R > 0
    ->  RFree = R
    ;   catch(read_mem_available_bytes(RFree), _, RFree = 1_000_000_000)
    ),
    RFree < FloorBytes.

%% =====================================================================
%% Runtime parser integration
%% =====================================================================

%% haskell_project_predicates(+UserPreds, +Mode, -ProjectPreds)
%  In `compiled` mode, append the portable parser + wrapper
%  predicate indicators. In other modes, leave the list untouched.
haskell_project_predicates(Predicates, compiled(prolog_term_parser), ProjectPredicates) :-
    !,
    haskell_runtime_parser_predicates(ParserPreds),
    haskell_runtime_parser_wrapper_predicates(WrapperPreds),
    append([Predicates, ParserPreds, WrapperPreds], Combined),
    sort(Combined, ProjectPredicates).
haskell_project_predicates(Predicates, _RuntimeParserMode, Predicates).

%% haskell_runtime_parser_predicates(-Predicates)
%  Enumerate non-imported predicates of `prolog_term_parser` as
%  `prolog_term_parser:Name/Arity` indicators.
haskell_runtime_parser_predicates(Predicates) :-
    findall(prolog_term_parser:Name/Arity,
            ( current_predicate(prolog_term_parser:Name/Arity),
              functor(Head, Name, Arity),
              once(clause(prolog_term_parser:Head, _)),
              \+ predicate_property(prolog_term_parser:Head, imported_from(_))
            ),
            Raw),
    sort(Raw, Predicates).

%% haskell_runtime_parser_wrapper_predicates(-Predicates)
%  Enumerate non-imported predicates of `cpp_runtime_parser_wrappers`
%  (the module name is C++-historical but the wrappers are target-agnostic).
haskell_runtime_parser_wrapper_predicates(Predicates) :-
    findall(cpp_runtime_parser_wrappers:Name/Arity,
            ( current_predicate(cpp_runtime_parser_wrappers:Name/Arity),
              functor(Head, Name, Arity),
              once(clause(cpp_runtime_parser_wrappers:Head, _)),
              \+ predicate_property(cpp_runtime_parser_wrappers:Head,
                                    imported_from(_))
            ),
            Raw),
    sort(Raw, Predicates).

%% haskell_validate_runtime_parser_mode(+Predicates, +Mode)
%  When the mode is `none`, reject any user predicate whose body
%  statically calls a parser-dependent builtin.
haskell_validate_runtime_parser_mode(Predicates, none) :-
    !,
    (   haskell_predicates_parser_dependency(Predicates, Pred, Builtin)
    ->  throw(error(permission_error(use, runtime_parser, Builtin),
                    context(write_wam_haskell_project/3,
                            parser_disabled_for_predicate(Pred))))
    ;   true
    ).
haskell_validate_runtime_parser_mode(_Predicates, _Mode).

haskell_predicates_parser_dependency(Predicates, Pred, Builtin) :-
    member(Pred, Predicates),
    haskell_predicate_clause(Pred, _Head, Body),
    parser_dependent_body_goal(Body, Builtin),
    !.

haskell_predicate_clause(Module:Name/Arity, Head, Body) :-
    !,
    functor(Head, Name, Arity),
    clause(Module:Head, Body).
haskell_predicate_clause(Name/Arity, Head, Body) :-
    functor(Head, Name, Arity),
    clause(user:Head, Body).

%% =====================================================================
%% CSR auto-resolution and bidirectional kernel upgrade
%% =====================================================================

%% maybe_upgrade_bidirectional(+KV0, -KV)
%  Upgrade a category_ancestor kernel to bidirectional_ancestor.
%  Only applied when kernel_mode(bidirectional) + csr_path are both set.
maybe_upgrade_bidirectional(Key-recursive_kernel(category_ancestor, PI, Config),
                            Key-recursive_kernel(bidirectional_ancestor, PI, Config)) :- !.
maybe_upgrade_bidirectional(KV, KV).

%% resolve_auto_csr_index_backend_hs(+Options0, -Options)
%  Resolve csr_index_backend(auto) by delegating to the shared
%  cost rule in cost_model.pl.
resolve_auto_csr_index_backend_hs(Options0, Options) :-
    (   option(csr_path(_), Options0),
        option(csr_index_backend(auto), Options0)
    ->  resolve_csr_index_backend(Options0, Backend),
        exclude(=(csr_index_backend(_)), Options0, Rest),
        Options = [csr_index_backend(Backend) | Rest]
    ;   Options = Options0
    ).

%% resolve_auto_edge_store_hs(+Options0, -Options)
%  Resolve edge_store(auto) into a concrete store selection.
%  Decides between lmdb_cached, lmdb_eager, csr, or dual_csr based on
%  workload metadata. When edge_store is not auto (or absent), pass through.
%  Mirrors F#'s resolve_auto_edge_store_fs/2.
resolve_auto_edge_store_hs(Options0, Options) :-
    (   option(edge_store(auto), Options0)
    ->  compute_edge_store_hs(Options0, Store),
        exclude(=(edge_store(_)), Options0, Rest),
        apply_edge_store_hs(Store, Rest, Options)
    ;   Options = Options0
    ).

compute_edge_store_hs(Options, Store) :-
    option(expected_query_count(Q), Options, 1),
    option(expected_lookups_per_query(L), Options, 50),
    option(edge_count(E), Options, 0),
    option(graph_mutability(Mut), Options, 'static'),
    option(needs_reverse(NeedsRev), Options, false),
    TotalLookups is Q * L,
    %% Cost model (milliseconds):
    %%   LMDB eager: one-time load E*0.005ms, per-lookup ~0.5us (IntMap.lookup)
    %%   LMDB cached: no load, per-lookup ~2us warm (cursor + L2 cache)
    %%   CSR: build E*0.01ms, per-lookup ~1.5us (binary search on index)
    EagerLoadMs is E * 0.005,
    EagerPerLookupUs is 0.5,
    CachedPerLookupUs is 2.0,
    CsrBuildMs is E * 0.01,
    CsrPerLookupUs is 1.5,
    %% Total wall time per mode (ms):
    EagerTotalMs is EagerLoadMs + TotalLookups * EagerPerLookupUs / 1000,
    CachedTotalMs is TotalLookups * CachedPerLookupUs / 1000,
    CsrTotalMs is CsrBuildMs + TotalLookups * CsrPerLookupUs / 1000,
    (   Mut == 'dynamic'
    ->  Store = lmdb_cached
    ;   NeedsRev == true, CsrTotalMs =< CachedTotalMs
    ->  Store = dual_csr
    ;   (   CsrTotalMs =< EagerTotalMs, CsrTotalMs =< CachedTotalMs
        ->  Store = csr
        ;   EagerTotalMs =< CachedTotalMs
        ->  Store = lmdb_eager
        ;   Store = lmdb_cached
        )
    ),
    (   option(edge_store_verbose(true), Options)
    ->  format(user_error,
               '[WAM-Haskell] edge_store(auto): Q=~w L=~w E=~w eager=~2fms cached=~2fms csr=~2fms -> ~w~n',
               [Q, L, E, EagerTotalMs, CachedTotalMs, CsrTotalMs, Store])
    ;   true
    ).

apply_edge_store_hs(lmdb_cached, Opts, [lmdb_materialisation(cached) | Opts]).
apply_edge_store_hs(lmdb_eager, Opts, [lmdb_materialisation(eager) | Opts]).
apply_edge_store_hs(csr, Opts, Opts).
apply_edge_store_hs(dual_csr, Opts, Opts).

%% resolve_auto_lmdb_materialisation_hs(+Options0, -Options)
%  Resolve lmdb_materialisation(auto) into eager/lazy/cached using
%  the shared cost model. When not auto, pass through.
%  Mirrors F#'s resolve_auto_lmdb_materialisation_fs/2.
resolve_auto_lmdb_materialisation_hs(Options0, Options) :-
    (   option(lmdb_materialisation(auto), Options0)
    ->  compute_lmdb_materialisation_hs(Options0, Mode),
        exclude(=(lmdb_materialisation(_)), Options0, Rest),
        Options = [lmdb_materialisation(Mode) | Rest]
    ;   Options = Options0
    ).

compute_lmdb_materialisation_hs(Options, Mode) :-
    option(fact_count(F), Options, 0),
    option(demand_set_estimate(D), Options, F),
    option(expected_query_count(NQ), Options, 1),
    option(workload_segregated(WS), Options, false),
    option(working_set_fraction(WSF), Options, 0.05),
    EdgeBytes is D * 50,
    (   option(memory_budget(B), Options)
    ->  true
    ;   catch(read_mem_available_bytes(B), _, B = 1_000_000_000)
    ),
    (   EdgeBytes > B
    ->  (WS == true -> Mode = lazy ; Mode = cached)
    ;   KKeys is integer(F * WSF),
        option(cost_model_constants(Constants), Options, []),
        recommend_access_pattern(KKeys, EdgeBytes, B, Constants, Pattern),
        (   Pattern = sort
        ->  (NQ >= 10, F =< 100_000 -> Mode = eager ; Mode = cached)
        ;   (EdgeBytes > B -> Mode = cached ; Mode = eager)
        )
    ),
    (   option(materialisation_verbose(true), Options)
    ->  format(user_error,
               '[WAM-Haskell] lmdb_materialisation(auto): F=~w D=~w B=~w NQ=~w WS=~w -> ~w~n',
               [F, D, B, NQ, WS, Mode])
    ;   true
    ).

%% resolve_haskell_cost_options(+Options0, -Options)
%  Composed resolver chain: runs all auto-resolvers in sequence.
%  Mirrors F#'s resolve_fsharp_cost_options/2.
resolve_haskell_cost_options(Options0, Options) :-
    resolve_auto_edge_store_hs(Options0, Options1),
    resolve_auto_use_lmdb(Options1, Options2),
    resolve_auto_cache_strategy(Options2, Options3),
    resolve_auto_lmdb_materialisation_hs(Options3, Options4),
    resolve_auto_lmdb_cache_mode(Options4, Options5),
    resolve_auto_csr_index_backend_hs(Options5, Options).

%% resolve_demand_filter_spec(+Options, -SpecHs)
%  Pick the DemandFilterSpec literal to emit into Main.hs.
%  Precedence:
%    1. demand_filter_spec(Strategy, Opts) in Options.
%    2. user:demand_filter_spec(Strategy, Opts) declared in workload.
%    3. Default: HopLimit Nothing (unbounded — legacy behaviour).
resolve_demand_filter_spec(Options, SpecHs) :-
    (   option(demand_filter_spec(Strategy, FilterOpts), Options)
    ->  emit_demand_filter_spec(Strategy, FilterOpts, SpecHs)
    ;   catch(user:demand_filter_spec(Strategy, FilterOpts), _, fail)
    ->  emit_demand_filter_spec(Strategy, FilterOpts, SpecHs)
    ;   SpecHs = '(HopLimit Nothing)'
    ).

%% emit_demand_filter_spec(+Strategy, +FilterOpts, -SpecHs)
%  Translate a (Strategy, Options) Prolog term into a Haskell
%  DemandFilterSpec literal. Validates strategy + options.
emit_demand_filter_spec(hop_limit, FilterOpts, SpecHs) :- !,
    (   memberchk(max_hops(N), FilterOpts), integer(N), N >= 0
    ->  format(string(SpecHs), '(HopLimit (Just ~d))', [N])
    ;   memberchk(unbounded, FilterOpts)
    ->  SpecHs = '(HopLimit Nothing)'
    ;   SpecHs = '(HopLimit Nothing)'
    ).
emit_demand_filter_spec(flux, FilterOpts, SpecHs) :- !,
    %% Flux is accepted at codegen but panics at runtime until Phase 2.5.
    (   memberchk(target_count(K), FilterOpts), integer(K), K >= 0
    ->  CacheTopK = K
    ;   memberchk(target_fraction(_F), FilterOpts)
    ->  %% target_fraction needs runtime knowledge of universe size; emit
        %% a placeholder K that the Phase 2.5 implementation will replace.
        CacheTopK = 0
    ;   CacheTopK = 0
    ),
    (   memberchk(sort_sparks(false), FilterOpts)
    ->  SortSparks = 'False'
    ;   SortSparks = 'True'
    ),
    format(string(SpecHs), '(Flux ~d ~w)', [CacheTopK, SortSparks]).
emit_demand_filter_spec(none, _FilterOpts, 'DfNone') :- !.
emit_demand_filter_spec(Strategy, _FilterOpts, _) :-
    format(user_error,
        '[wam_haskell] unknown demand filter strategy: ~w~n', [Strategy]),
    throw(error(domain_error(demand_filter_strategy, Strategy), _)).

%% generate_demand_gated_query_body(+DemandFilter, +RawQueryBody, -QueryBody)
%
%  Historical: PR #1876 wrapped the parMap closure with an inline
%  IS.member check. That kept the spark count equal to seedCats (50k+
%  on enwiki-style fixtures), so 49989/50000 sparks paid synchronization
%  cost while doing trivial work — total parallel scaling broke at -N>1.
%
%  Current: the filter happens BEFORE parMap (in
%  generate_demand_filter via filteredSeedCats), so the closure here
%  no longer needs an inline gate. This predicate is kept as an
%  identity wrapper for backwards compat with the codegen call site.
generate_demand_gated_query_body(_, QueryBody, QueryBody).

%% generate_merged_code_build(+DetectedKernels, +Options, -Code)
%  Emit the merged-code construction block for Main.hs.
%  When an FFI kernel handles fact lookups, the WAM-compiled fact code
%  is never executed — so we skip buildFact2Code to save ~42% of runtime.
%  Options:
%    skip_fact_wam(true|false) — override auto-detection
%  Auto-detection: if any kernel is detected, skip WAM-compilation of
%  all fact predicates (conservative for benchmark template).
generate_merged_code_build(DetectedKernels, Options, Code) :-
    (   option(skip_fact_wam(Skip), Options)
    ->  true
    ;   DetectedKernels \= []
    ->  Skip = true
    ;   Skip = false
    ),
    (   Skip == true
    ->  Code =
'    let mergedCodeRaw = allCode
        mergedLabels = allLabels'
    ;   Code =
'    let baseLen = length allCode
        (cpCode, cpLabels) = buildFact2Code iAtom "category_parent" categoryParents (baseLen + 1)
        cpEnd = baseLen + length cpCode
        (acCode, acLabels) = buildFact2Code iAtom "article_category" articleCategories (cpEnd + 1)
        acEnd = cpEnd + length acCode
        (rcCode, rcLabels) = buildFact1Code iAtom "root_category" roots (acEnd + 1)

        mergedCodeRaw = allCode ++ cpCode ++ acCode ++ rcCode
        mergedLabels = Map.union allLabels
                     $ Map.fromList (cpLabels ++ acLabels ++ rcLabels)'
    ).

generate_query_body(Options, QueryBody) :-
    % Phase 3: select run function. Default is runMutableRegs (STArray,
    % 7.66x faster). Override with register_mode(intmap) for pure path.
    (   member(register_mode(intmap), Options)
    ->  RunFn = 'run'
    ;   RunFn = 'runMutableRegs'
    ),
    % Emit a PURE expression so the seed loop can use `parMap rdeepseq`.
    % We use explicit braces and semicolons on the `let` to avoid Haskell's
    % column-alignment layout rules (the template renderer doesn't re-indent
    % continuation lines to match the {{query_body}} insertion column).
    (   member(query_pred(QueryPred), Options)
    ->  % Optimized: call WAM-compiled aggregation predicate per seed.
        format(atom(QueryPred1), '~w', [QueryPred]),
        format(atom(QueryBody),
'let { wsVarId = 1000000 ; s0 = emptyState { wsPC = fromMaybe 1 $ Map.lookup "~w" mergedLabels, wsRegs = IM.fromList [ (1, Atom (iAtom cat)), (2, Atom (iAtom root)), (3, Unbound wsVarId) ], wsCP = 0 } ; !result = case ~w ctx s0 of { Just s1 -> case IM.lookup wsVarId (wsBindings s1) of { Just v -> case extractDouble fullInternTable (derefVar (wsBindings s1) v) of { Just ws -> ws ; Nothing -> 0.0 } ; Nothing -> 0.0 } ; Nothing -> 0.0 } } in (cat, result)',
            [QueryPred1, RunFn])
    ;   member(use_ffi(true), Options)
    ->  % FFI path: call executeForeign directly instead of running WAM code.
        % When the query predicate has an FFI kernel, the WAM code's internal
        % Call "category_parent/2" would fail (fact code is skipped). Use
        % collectForeignSolutions which calls the native kernel directly.
        QueryBody =
'let { hopsVarId = 1000000 ; s0 = emptyState { wsRegs = IM.fromList [ (1, Atom (iAtom cat)), (2, Atom (iAtom root)), (3, Unbound hopsVarId), (4, VList [Atom (iAtom cat)]) ], wsCP = 0 } ; !solutions = collectForeignSolutions ctx "category_ancestor/4" s0 hopsVarId ; !weightSum = sum [((hops + 1) ** negN) | hops <- solutions] } in (cat, weightSum)'
    ;   % Default: collectSolutions loop for category_ancestor/4.
        % Phase 3: use collectSolutionsST (STArray mutable regs) by default.
        % Override with register_mode(intmap) to use the pure IntMap path.
        (   member(register_mode(intmap), Options)
        ->  CollectFn = 'collectSolutions'
        ;   CollectFn = 'collectSolutionsST'
        ),
        format(atom(QueryBody),
'let { hopsVarId = 1000000 ; s0 = emptyState { wsPC = fromMaybe 1 $ Map.lookup "category_ancestor/4" mergedLabels, wsRegs = IM.fromList [ (1, Atom (iAtom cat)), (2, Atom (iAtom root)), (3, Unbound hopsVarId), (4, VList [Atom (iAtom cat)]) ], wsCP = 0 } ; !solutions = ~w ctx s0 hopsVarId ; !weightSum = sum [((hops + 1) ** negN) | hops <- solutions] } in (cat, weightSum)',
            [CollectFn])
    ).

%% detected_kernel_keys(+DetectedKernels, -Keys)
%  Extract the string keys from Key-Kernel pairs.
detected_kernel_keys([], []).
detected_kernel_keys([Key-_|Rest], [Key|RestKeys]) :-
    detected_kernel_keys(Rest, RestKeys).

%% format_foreign_preds(+Keys, -HaskellListStr)
%  Format a list of predicate indicators as a Haskell list literal body.
%  E.g., ['category_ancestor/4', 'closure/2'] -> '"category_ancestor/4", "closure/2"'
format_foreign_preds([], '').
format_foreign_preds(Keys, Str) :-
    Keys \= [],
    maplist([Key, Quoted]>>(
        format(atom(Quoted), '"~w"', [Key])
    ), Keys, QuotedKeys),
    atomic_list_concat(QuotedKeys, ', ', Str).

build_predicate_loads([], '    let allCode = []\n    let allLabels = Map.empty').
build_predicate_loads(Predicates, Code) :-
    Predicates \= [],
    % Build code concatenation and label union
    maplist([PredInd, FN]>>(
        (PredInd = _M:P/A -> true ; PredInd = P/A),
        format(atom(FN), '~w_~w', [P, A])
    ), Predicates, FuncNames),
    % Generate Haskell code to merge all predicate code/labels
    maplist([FN, Expr]>>(
        format(string(Expr), '~w_code', [FN])
    ), FuncNames, CodeExprs),
    atomic_list_concat(CodeExprs, ' ++ ', CodeConcat),
    maplist([FN, Expr]>>(
        format(string(Expr), '~w_labels', [FN])
    ), FuncNames, LabelExprs),
    % Union with offset adjustment
    % For simplicity, use Map.unions (labels need PC offset per predicate)
    atomic_list_concat(LabelExprs, ' `Map.union` ', LabelUnion),
    format(string(Code),
'    let allCode = ~w
    let allLabels = ~w', [CodeConcat, LabelUnion]).

%% compile_wam_runtime_to_haskell(+Options, +DetectedKernels, -Code)
compile_wam_runtime_to_haskell(Options0, DetectedKernels, Code) :-
    % Phase 0: merge any declared algorithm manifest. Idempotent when
    % the outer write_wam_haskell_project/3 already merged.
    load_algorithm_manifest(Options0, OptionsM),
    % Phase 2c: resolve cache_strategy(auto) into a concrete
    % demand_bfs_mode/1 BEFORE downstream code consults it. No-op
    % when the option is absent.
    resolve_auto_cache_strategy(OptionsM, Options1),
    % Phase 2c+: resolve lmdb_cache_mode(auto) → concrete tier.
    % No-op when workload_locality/1 is absent.
    resolve_auto_lmdb_cache_mode(Options1, Options),
    step_function_haskell(StepCode),
    backtrack_haskell(BacktrackCodeTemplate),
    run_loop_haskell(RunCode),
    % Render kernel-specific Haskell from Mustache templates
    generate_kernel_haskell(DetectedKernels, KernelFunctionsCode, ExecuteForeignCode),
    % Inject into the backtrack_haskell template via {{placeholder}} substitution
    render_template(BacktrackCodeTemplate,
                    [kernel_functions=KernelFunctionsCode,
                     execute_foreign=ExecuteForeignCode],
                    BacktrackCode),
    % Phase B1: conditional LMDB imports and functions
    (   option(use_lmdb(true), Options)
    ->  LmdbImports = "import Database.LMDB.Raw\nimport Foreign.Ptr (Ptr, castPtr, nullPtr)\nimport Foreign.Storable (peek, poke, peekElemOff)\nimport Foreign.Marshal.Alloc (alloca, allocaBytes)\nimport Foreign.Marshal.Array (withArray)\nimport Foreign.C.String (withCStringLen, peekCStringLen)\nimport Foreign.C.Types (CSize(..), CChar)\nimport Data.Int (Int32)\nimport Data.Word (Word8)\nimport Data.Bits ((.&.))\nimport Data.IORef (IORef, newIORef, readIORef, writeIORef, atomicModifyIORef')\nimport qualified Data.Array as A\nimport qualified Data.Array.IO as IOA\nimport qualified Data.ByteString as BS\nimport qualified Data.Text as T\nimport qualified Data.Text.Encoding as TE\nimport qualified Data.Text.Encoding.Error as TEE\nimport qualified Control.Exception as E\nimport Control.Monad (forM_, when, foldM)\nimport Control.Concurrent (runInBoundThread, myThreadId, ThreadId, threadCapability, getNumCapabilities)\nimport Control.Concurrent.Async (mapConcurrently)",
        generate_lmdb_functions(Options, LmdbFunctions)
    ;   LmdbImports = "",
        LmdbFunctions = ""
    ),
    % P1 (scan-strategy): conditional cost-function code.
    % Emitted when option(tree_cost_function(Name, Params), Options) is
    % present. Renders cost_function.hs.mustache and a `theCostFn`
    % binding that selects the concrete CostFn constructor at codegen
    % time. P3+ warm-build code will reference `theCostFn`; in P1 it's
    % a top-level binding that GHC may flag as unused — accepted as
    % a warning since the build still succeeds.
    generate_cost_function_code(Options, CostFunctionCode),
    format(string(Code),
'{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE FlexibleContexts #-}
module WamRuntime where

import qualified Data.Map.Strict as Map
import qualified Data.IntMap.Strict as IM
import qualified Data.IntSet as IS
import Data.Array (Array, listArray, (!), bounds)
import qualified Data.Set as Set
import Data.List (isPrefixOf, foldl'', nub)
import Data.Maybe (fromMaybe, isNothing)
-- Phase 4.2: intra-query parallelism. parMap/rdeepseq spark the
-- alternative clauses of a forkable ParTryMeElse choice point; the
-- WamState NFData instance lives in WamTypes.
import Control.Parallel.Strategies (parMap, rdeepseq)
import Control.DeepSeq (NFData(..), deepseq)
-- Phase 4.4: race-to-cancel for parallel negation. async/waitAny
-- let us cancel remaining branches once one succeeds.
import Control.Concurrent.Async (async, cancel, waitAny)
import Control.Exception (Exception, SomeException, evaluate, throw, try)
import System.IO.Unsafe (unsafePerformIO)
-- Phase 3 (mutable registers): ST monad + STArray for O(1) register access.
import Control.Monad.ST.Strict (ST, runST)
import qualified Data.Array.ST as STA
import Data.Array.MArray (readArray, writeArray, freeze, newArray)
import Data.STRef.Strict (newSTRef, readSTRef, writeSTRef, modifySTRef'')
import Control.Monad (forM_)
import qualified Data.Array as A
~w
import WamTypes

~w

~w

~w
~w

-- | Dereference an Unbound variable through the binding table.
{-# INLINE derefVar #-}
derefVar :: IM.IntMap Value -> Value -> Value
derefVar bindings (Unbound vid) =
  case IM.lookup vid bindings of
    Just val -> derefVar bindings val
    Nothing  -> Unbound vid
derefVar _ v = v

-- | Deep-dereference a value through bindings (resolves all nested Unbounds).
derefDeep :: IM.IntMap Value -> Value -> Value
derefDeep bindings v = case derefVar bindings v of
  Str fn args -> Str fn (map (derefDeep bindings) args)
  VList items -> VList (map (derefDeep bindings) items)
  other -> other

-- | Check if a value contains any unbound variables after dereferencing.
hasUnboundDeep :: IM.IntMap Value -> Value -> Bool
hasUnboundDeep bindings v = case derefVar bindings v of
  Unbound _ -> True
  Str _ args -> any (hasUnboundDeep bindings) args
  VList items -> any (hasUnboundDeep bindings) items
  _ -> False

-- | ISO error term constructors.
makeInstantiationError :: Value
makeInstantiationError = Atom atomInstantiationError

makeTypeError :: Int -> Value -> Value
makeTypeError expected culprit = Str atomTypeError [Atom expected, culprit]

makeDomainError :: Int -> Value -> Value
makeDomainError domain culprit = Str atomDomainError [Atom domain, culprit]

makeEvaluationError :: Int -> Value
makeEvaluationError kind = Str atomEvaluationError [Atom kind]

makePredIndicator :: Int -> Int -> Value
makePredIndicator nameId arity = Str atomSlash [Atom nameId, Integer arity]

-- | Throw a wrapped ISO error: error(ErrorTerm, _Context).
throwIsoError :: WamState -> Value -> a
throwIsoError s errTerm = throw $ WamException $
  Str atomError [derefDeep (wsBindings s) errTerm, Unbound (wsVarCounter s)]

-- | Build the Name/Arity culprit for type_error(evaluable, ...).
arithCulprit :: IM.IntMap Value -> Value -> Value
arithCulprit bindings expr = case derefVar bindings expr of
  Atom aid -> makePredIndicator aid 0
  Str fn args -> makePredIndicator fn (length args)
  _ -> makePredIndicator atomUnknown 0

-- | True for predicate names that are ISO meta-builtins routed through BuiltinCall.
isIsoMetaBuiltin :: String -> Bool
isIsoMetaBuiltin pred = case pred of
  "catch/3" -> True; "throw/1" -> True
  "is_iso/2" -> True; "is_lax/2" -> True
  "<_iso/2" -> True; ">_iso/2" -> True; ">=_iso/2" -> True; "=<_iso/2" -> True
  "=:=_iso/2" -> True; "=\\\\=_iso/2" -> True
  "<_lax/2" -> True; ">_lax/2" -> True; ">=_lax/2" -> True; "=<_lax/2" -> True
  "=:=_lax/2" -> True; "=\\\\=_lax/2" -> True
  "succ/2" -> True; "succ_iso/2" -> True; "succ_lax/2" -> True
  _ -> False

-- | Arity of an ISO meta-builtin.
isoMetaBuiltinArity :: String -> Int
isoMetaBuiltinArity pred = case pred of
  "throw/1" -> 1; "catch/3" -> 3; _ -> 2

-- | Evaluate arithmetic expression. InternTable needed for reverse
-- lookup of atom strings (numeric atom parsing, operator names).
-- Strip a trailing "/<arity>" from a functor name (e.g. "+/2" -> "+",
-- "mod/2" -> "mod"). Must NOT use takeWhile (/= ''/''): operators that
-- contain ''/'' themselves -- "//" (interns as "///2") and "/" ("//2") --
-- would be truncated to "", making integer div and float div evaluate to
-- Nothing and silently failing the whole `is/2` goal.
bareArithOp :: String -> String
bareArithOp name =
  case break (== ''/'') (reverse name) of
    (revArity, ''/'' : revHead)
      | not (null revArity) && all (`elem` "0123456789") revArity -> reverse revHead
    _ -> name

evalArith :: InternTable -> IM.IntMap Value -> Value -> Maybe Double
evalArith _ _ (Integer n) = Just (fromIntegral n)
evalArith _ _ (Float f) = Just f
evalArith tbl _ (Atom aid) = case reads (lookupAtom tbl aid) of
  [(n, "")] -> Just n
  _ -> Nothing
evalArith tbl bindings (Str opId [a]) = do
  va <- evalArith tbl bindings (derefVar bindings a)
  let bareOp = bareArithOp (lookupAtom tbl opId)
  case bareOp of
    "-" -> Just (negate va)
    "abs" -> Just (abs va)
    _ -> Nothing
evalArith tbl bindings (Str opId [a, b]) = do
  va <- evalArith tbl bindings (derefVar bindings a)
  vb <- evalArith tbl bindings (derefVar bindings b)
  let bareOp = bareArithOp (lookupAtom tbl opId)
  case bareOp of
    "+" -> Just (va + vb)
    "-" -> Just (va - vb)
    "*" -> Just (va * vb)
    "**" -> Just (va ** vb)
    "^" -> Just (va ** vb)
    "/" -> if vb /= 0 then Just (va / vb) else Nothing
    "//" -> if vb /= 0 then Just (fromIntegral (truncate va `div` truncate vb :: Int)) else Nothing
    "mod" -> if vb /= 0 then Just (fromIntegral (truncate va `mod` truncate vb :: Int)) else Nothing
    _ -> Nothing
evalArith _ _ _ = Nothing

-- | Get register value. Y-registers (id >= 200) come from the env frame.
{-# INLINE getReg #-}
getReg :: Int -> WamState -> Maybe Value
getReg rid s
  | rid >= 200 = findYReg rid (wsStack s)
  | otherwise = derefVar (wsBindings s) <$> IM.lookup rid (wsRegs s)
  where
    findYReg _ [] = Nothing
    findYReg r (EnvFrame _ yregs : _) = derefVar (wsBindings s) <$> IM.lookup r yregs
    findYReg r (_ : rest) = findYReg r rest

-- | Set register value. Y-registers go to the topmost env frame.
{-# INLINE putReg #-}
putReg :: Int -> Value -> WamState -> WamState
putReg rid val s
  | rid >= 200 = s { wsStack = updateTopEnv rid val (wsStack s) }
  | otherwise = s { wsRegs = IM.insert rid val (wsRegs s) }
  where
    updateTopEnv _ _ [] = []
    updateTopEnv r v (EnvFrame cp yregs : rest) =
      EnvFrame cp (IM.insert r v yregs) : rest
    updateTopEnv r v (x : rest) = x : updateTopEnv r v rest

-- | Dereference a heap reference.
derefHeap :: [Value] -> Value -> Maybe Value
derefHeap heap (Ref addr)
  | addr >= 0 && addr < length heap = Just (heap !! addr)
  | otherwise = Nothing
derefHeap _ (Str fn args) = Just (Str fn args)
derefHeap _ (Unbound n) = Just (Unbound n)
derefHeap _ v = Just v

-- | Add a value to the current structure/list builder.
addToBuilder :: Value -> WamState -> Maybe WamState
addToBuilder val s = case wsBuilder s of
  BuildStruct fn ai arity args ->
    -- Cons to front (O(1)) and reverse only on finalize. Track count via list length
    -- but only when finalizing — args grows from 0 to arity, max arity is small.
    let args'' = val : args
    in if length args'' == arity
       then let term = Str fn (reverse args'')
                -- Outer-first construction (set_variable Xn for a tail,
                -- then put_structure Xn to fill it) leaves that var
                -- embedded in the outer term. Finalising into register ai
                -- must ALSO bind the var ai currently holds, or the outer
                -- term keeps an unbound tail -- the multi-element list bug
                -- that made reverse/append wrong on lists of length >= 2.
                --
                -- A-REGISTER EXCEPTION (M139/M140 bind-through class):
                -- A registers (ai < 100; X = 101+, Y = 201+) are argument
                -- STAGING -- their old occupant is an unrelated variable
                -- (often a clause-head argument), and binding it to the
                -- freshly built term creates a cyclic term (X = f(X)),
                -- wrong-failing a later X = 1. The set_variable
                -- placeholders only ever live in X/Y registers, so the
                -- bind-through is conditioned on the register class --
                -- the same fix the Rust, Go, Scala and Kotlin targets carry.
                sBound = if ai >= 100
                  then case IM.lookup ai (wsRegs s) of
                    Just (Unbound vid) -> bindUnbound vid term s
                    _ -> s
                  else s
            in Just (sBound { wsPC = wsPC s + 1
                            , wsRegs = IM.insert ai term (wsRegs sBound)
                            , wsBuilder = NoBuilder
                            })
       else Just (s { wsPC = wsPC s + 1
                    , wsBuilder = BuildStruct fn ai arity args''
                    })
  BuildList ai args ->
    -- BuildList always has exactly 2 args [head, tail]
    let args'' = val : args
    in if length args'' == 2
       then let [tl, hd] = args''   -- reversed because we cons-built
                list = case tl of
                  VList items -> VList (hd : items)
                  Atom aid | aid == atomNil -> VList [hd]
                  -- A variable / partial tail (set_variable placeholder for
                  -- outer-first construction) is the REST of the list, not an
                  -- element. VList [hd, tl] would wrongly make it a 2-element
                  -- list [hd, tl]; emit a proper cons cell so the tail splices
                  -- in once bound (the [a|X], X=[b] => [a,b] case).
                  _           -> Str atomDot [hd, tl]
                -- Same placeholder-var binding as BuildStruct: a list built
                -- into a register that holds a set_variable placeholder must
                -- bind that var so an enclosing term sees the list. Same
                -- A-register exception as BuildStruct (M139/M140 class).
                sBound = if ai >= 100
                  then case IM.lookup ai (wsRegs s) of
                    Just (Unbound vid) -> bindUnbound vid list s
                    _ -> s
                  else s
            in Just (sBound { wsPC = wsPC s + 1
                       , wsRegs = IM.insert ai list (wsRegs sBound)
                       , wsBuilder = NoBuilder
                       })
       else Just (s { wsPC = wsPC s + 1
                    , wsBuilder = BuildList ai args''
                    })
  NoBuilder ->
    -- No builder active, just push to heap (fallback)
    Just (s { wsPC = wsPC s + 1, wsHeap = wsHeap s ++ [val], wsHeapLen = wsHeapLen s + 1 })

-- | Read the next arg from a ReadArgs builder.
-- Returns (value, new_state) or Nothing if no ReadArgs active.
readNextArg :: WamState -> Maybe (Value, WamState)
readNextArg s = case wsBuilder s of
  ReadArgs (v : rest) ->
    let s'''' = if null rest
              then popBuilderStack s
              else s { wsBuilder = ReadArgs rest }
    in Just (derefVar (wsBindings s) v, s'''')
  _ -> Nothing

-- | Save the current builder (if active) onto the builder stack.
pushBuilderIfActive :: WamState -> WamState
pushBuilderIfActive s = case wsBuilder s of
  NoBuilder -> s
  b -> s { wsBuilder = NoBuilder
         , wsBuilderStack = b : wsBuilderStack s }

-- | PureWamState variant for stepST.
pushBuilderIfActivePure :: PureWamState -> PureWamState
pushBuilderIfActivePure pw = case pwBuilder pw of
  NoBuilder -> pw
  b -> pw { pwBuilder = NoBuilder
          , pwBuilderStack = b : pwBuilderStack pw }

-- | Throw an ISO error from the ST path. Constructs a WamState-shaped
-- error envelope and throws WamException. Works because throw is lazy
-- and can fire from any context (pure or ST).
throwIsoErrorPure :: PureWamState -> Value -> ST s a
throwIsoErrorPure pw errTerm =
  let wrapped = Str atomError [derefDeep (pwBindings pw) errTerm, Unbound (pwVarCounter pw)]
  in throw (WamException wrapped)

-- | ST-mode succLax: read registers directly, avoid freeze/thaw.
succLaxST :: STA.STArray s Int Value -> PureWamState -> ST s (Maybe PureWamState)
succLaxST regs pw = do
  v1 <- readArray regs 1
  v2 <- readArray regs 2
  let a = Just (derefVar (pwBindings pw) v1)
      b = Just (derefVar (pwBindings pw) v2)
      bindReg reg value = do
        let dv = derefVar (pwBindings pw) <$> Just value
        case derefVar (pwBindings pw) <$> IM.lookup reg (pwBindings pw) of
          _ -> return ()
        -- Read current register value to check for Unbound
        rv <- readArray regs reg
        case derefVar (pwBindings pw) rv of
          Unbound vid -> do
            writeArray regs reg value
            return $ Just pw { pwPC = pwPC pw + 1
                             , pwBindings = IM.insert vid value (pwBindings pw)
                             , pwTrail = TrailEntry vid (IM.lookup vid (pwBindings pw)) : pwTrail pw
                             , pwTrailLen = pwTrailLen pw + 1 }
          bound | bound == value -> return $ Just pw { pwPC = pwPC pw + 1 }
          _ -> return Nothing
  case (a, b) of
    (Just (Integer n), _) | n >= 0 -> bindReg 2 (Integer (n + 1))
    (_, Just (Integer m)) | m > 0  -> bindReg 1 (Integer (m - 1))
    _ -> return Nothing

-- | Restore the top builder from the stack.
popBuilderStack :: WamState -> WamState
popBuilderStack s = case wsBuilderStack s of
  (b : rest) -> s { wsBuilder = b, wsBuilderStack = rest }
  [] -> s { wsBuilder = NoBuilder }

-- | Unify two values. Returns updated state on success, Nothing on failure.
-- Full structural unification, PC-neutral (the read-mode callers advance
-- PC themselves). Delegates to the shared unifyTerms defined alongside
-- unifyVal, so head-matching and read-mode unify share one implementation
-- that handles compound terms and the VList / Str-atomDot cons forms.
unifyValues :: Value -> Value -> WamState -> Maybe WamState
unifyValues = unifyTerms

-- | Lookup a label in the label map (now in WamContext).
lookupLabel :: String -> WamContext -> Int
lookupLabel label ctx = fromMaybe 0 $ Map.lookup label (wcLabels ctx)

-- | Fetch instruction at PC (1-indexed). Bounds-checked, returns Maybe.
fetchInstr :: Int -> Array Int Instruction -> Maybe Instruction
fetchInstr pc code
  | let (lo, hi) = bounds code in pc < lo || pc > hi = Nothing
  | otherwise = Just (code ! pc)

-- | Unsafe fetch — no bounds check, no Maybe wrapping. Use only when the
-- caller can prove PC is in bounds (the run loop handles PC=0 as halt
-- separately, and a well-formed WAM program never jumps out of bounds).
{-# INLINE unsafeFetchInstr #-}
unsafeFetchInstr :: Int -> Array Int Instruction -> Instruction
unsafeFetchInstr pc code = code ! pc

-- | Phase 3: ST-mode register helpers.
-- Convert between WamState (IntMap regs) and PureWamState (regs in separate STArray).

wamStateToPure :: WamState -> PureWamState
wamStateToPure s = PureWamState
  { pwPC = wsPC s, pwStack = wsStack s, pwHeap = wsHeap s
  , pwHeapLen = wsHeapLen s, pwTrail = wsTrail s, pwTrailLen = wsTrailLen s
  , pwCP = wsCP s, pwCPs = [], pwCPsLen = 0
  , pwBindings = wsBindings s, pwCutBar = wsCutBar s
  , pwBuilder = wsBuilder s, pwBuilderStack = wsBuilderStack s
  , pwVarCounter = wsVarCounter s
  , pwAggAccum = wsAggAccum s
  }

pureToWamState :: PureWamState -> IM.IntMap Value -> WamState
pureToWamState pw regMap = WamState
  { wsPC = pwPC pw, wsRegs = regMap, wsStack = pwStack pw
  , wsHeap = pwHeap pw, wsHeapLen = pwHeapLen pw
  , wsTrail = pwTrail pw, wsTrailLen = pwTrailLen pw
  , wsCP = pwCP pw, wsCPs = [], wsCPsLen = 0
  , wsBindings = pwBindings pw, wsCutBar = pwCutBar pw
  , wsBuilder = pwBuilder pw, wsBuilderStack = pwBuilderStack pw
  , wsVarCounter = pwVarCounter pw
  , wsAggAccum = pwAggAccum pw
  }

-- | Read a register value in ST mode. Y-registers (>= 200) come from env frame.
{-# INLINE getRegST #-}
getRegST :: STA.STArray s Int Value -> Int -> PureWamState -> ST s (Maybe Value)
getRegST regs rid pw
  | rid >= 200 = return $ findYRegPure rid (pwStack pw)
  | otherwise = do
      v <- readArray regs rid
      return $ Just (derefVar (pwBindings pw) v)
  where
    findYRegPure _ [] = Nothing
    findYRegPure r (EnvFrame _ yregs : _) =
      derefVar (pwBindings pw) <$> IM.lookup r yregs
    findYRegPure r (_ : rest) = findYRegPure r rest

-- | Write a register value in ST mode. Y-registers go to env frame.
{-# INLINE putRegST #-}
putRegST :: STA.STArray s Int Value -> Int -> Value -> PureWamState -> ST s PureWamState
putRegST regs rid val pw
  | rid >= 200 = return $ pw { pwStack = updateTopEnvPure rid val (pwStack pw) }
  | otherwise = do writeArray regs rid val; return pw
  where
    updateTopEnvPure _ _ [] = []
    updateTopEnvPure r v (EnvFrame cp yregs : rest) =
      EnvFrame cp (IM.insert r v yregs) : rest
    updateTopEnvPure r v (x : rest) = x : updateTopEnvPure r v rest

-- | Freeze registers into an immutable snapshot for choice points.
{-# INLINE snapshotRegsST #-}
snapshotRegsST :: STA.STArray s Int Value -> ST s (A.Array Int Value)
snapshotRegsST = freeze

-- | Restore registers from a frozen snapshot (backtrack).
{-# INLINE restoreRegsST #-}
restoreRegsST :: STA.STArray s Int Value -> A.Array Int Value -> ST s ()
restoreRegsST regs snap = forM_ [1..maxRegId] $ \\i ->
  writeArray regs i (snap A.! i)

-- | Freeze STArray registers into an IntMap (for returning WamState).
freezeRegsToIntMap :: STA.STArray s Int Value -> ST s (IM.IntMap Value)
freezeRegsToIntMap regs = do
  arr <- freeze regs
  return $ IM.fromList [(i, arr A.! i) | i <- [1..maxRegId],
                         arr A.! i /= Unbound (-1)]

-- | Resolve Call instructions at project load time:
--   - Foreign predicates (detected kernels) → CallForeign (direct FFI, Nothing = fail)
--   - Known labels → CallResolved (direct PC jump, no dispatch)
--   - Everything else → left as Call (runtime dispatch chain)
resolveCallInstrs :: Map.Map String Int -> [String] -> [Instruction] -> [Instruction]
resolveCallInstrs labels foreignPreds = map resolve
  where
    resolve (Call pred arity)
      | pred `elem` foreignPreds = CallForeign pred arity
      | otherwise = case Map.lookup pred labels of
          Just pc -> CallResolved pc arity
          Nothing -> Call pred arity
    resolve (Execute pred) = case Map.lookup pred labels of
      Just pc -> ExecutePc pc
      Nothing -> Execute pred
    resolve (Jump label) = case Map.lookup label labels of
      Just pc -> JumpPc pc
      Nothing -> Jump label
    resolve (TryMeElse label) = case Map.lookup label labels of
      Just pc -> TryMeElsePc pc
      Nothing -> TryMeElse label
    resolve (RetryMeElse label) = case Map.lookup label labels of
      Just pc -> RetryMeElsePc pc
      Nothing -> RetryMeElse label
    -- Phase 4.1 Par* variants resolve the same way as their sequential
    -- counterparts. The instruction carries forkability intent; label
    -- resolution is orthogonal.
    resolve (ParTryMeElse label) = case Map.lookup label labels of
      Just pc -> ParTryMeElsePc pc
      Nothing -> ParTryMeElse label
    resolve (ParRetryMeElse label) = case Map.lookup label labels of
      Just pc -> ParRetryMeElsePc pc
      Nothing -> ParRetryMeElse label
    resolve (SwitchOnConstant table) =
      let extractId (Atom aid) = aid
          extractId (Integer n) = n  -- integers use their value directly as key
          extractId _ = (-1)
      in SwitchOnConstantPc (IM.fromList [(extractId v, pc) | (v, label) <- Map.toList table,
                                                               Just pc <- [Map.lookup label labels]])
    resolve i = i

~w
', [LmdbImports, StepCode, BacktrackCode, RunCode, LmdbFunctions, CostFunctionCode]).

%% generate_wam_types_hs(-Code)
generate_wam_types_hs(Code) :-
    Code = 'module WamTypes where

import qualified Data.Map.Strict as Map
import qualified Data.IntMap.Strict as IM
import qualified Data.IntSet as IS
import Data.Array (Array, listArray, (!), bounds)
-- Phase 4.2: NFData is needed for parMap rdeepseq to fully evaluate
-- each forked branch''s contribution before the merge step.
import Control.DeepSeq (NFData(..))
-- ISO error handling: WamException is defined here so both WamTypes
-- and WamRuntime can reference it.
import Control.Exception (Exception)

-- | Core value type. Atoms and Str functor names are interned as Ints
-- for O(1) equality. Use lookupAtom/internAtom via the InternTable in
-- WamContext for String conversion.
data Value = Atom !Int          -- interned atom ID
           | Integer !Int
           | Float !Double
           | VList [Value]
           | VSet !IS.IntSet    -- visited-set: IntSet of interned atom IDs
           | Str !Int [Value]   -- interned functor name, args
           | Unbound !Int       -- variable ID (interned via wsVarCounter)
           | Ref Int
           deriving (Eq, Ord, Show)

-- | Atom intern table. Built at compile time, extended at load time
-- with runtime atoms (e.g., from TSV fact data). Read-only after
-- construction — safe for parallelism (shared via WamContext).
data InternTable = InternTable
  { itForward :: !(Map.Map String Int)   -- String -> atom ID
  , itReverse :: !(IM.IntMap String)     -- atom ID -> String
  , itSize    :: !Int                    -- next available ID
  } deriving (Show)

emptyInternTable :: InternTable
emptyInternTable = InternTable Map.empty IM.empty 0

internAtom :: InternTable -> String -> (Int, InternTable)
internAtom tbl s = case Map.lookup s (itForward tbl) of
  Just aid -> (aid, tbl)
  Nothing  -> let aid = itSize tbl
              in (aid, tbl { itForward = Map.insert s aid (itForward tbl)
                           , itReverse = IM.insert aid s (itReverse tbl)
                           , itSize = aid + 1 })

internAtomPure :: InternTable -> String -> Int
internAtomPure tbl s = case Map.lookup s (itForward tbl) of
  Just aid -> aid
  Nothing  -> (-1)  -- should not happen for well-formed programs

lookupAtom :: InternTable -> Int -> String
lookupAtom tbl aid = IM.findWithDefault ("?atom_" ++ show aid) aid (itReverse tbl)

-- | Well-known atom IDs. Reserved during compile-time atom collection.
-- These MUST match the IDs assigned by the Prolog codegen.
atomTrue, atomFail, atomNil, atomDot, atomEmpty :: Int
atomTrue  = 0
atomFail  = 1
atomNil   = 2   -- "[]"
atomDot   = 3   -- "."
atomEmpty = 4   -- ""

atomError, atomInstantiationError, atomTypeError, atomDomainError :: Int
atomEvaluationError, atomEvaluable, atomIntegerTy, atomNotLessThanZero :: Int
atomZeroDivisor, atomSlash, atomUnknown :: Int
atomError = 5
atomInstantiationError = 6
atomTypeError = 7
atomDomainError = 8
atomEvaluationError = 9
atomEvaluable = 10
atomIntegerTy = 11
atomNotLessThanZero = 12
atomZeroDivisor = 13
atomSlash = 14
atomUnknown = 15

-- | ISO exception type for throw/1 and catch/3.
data WamException = WamException !Value deriving (Show)
instance Exception WamException

data EnvFrame = EnvFrame {-# UNPACK #-} !Int !(IM.IntMap Value)
              deriving (Show)

data TrailEntry = TrailEntry {-# UNPACK #-} !Int !(Maybe Value)
                deriving (Show)

data ChoicePoint = ChoicePoint
  { cpNextPC   :: {-# UNPACK #-} !Int
  , cpRegs     :: !(IM.IntMap Value)
  , cpStack    :: ![EnvFrame]
  , cpCP       :: {-# UNPACK #-} !Int
  , cpTrailLen :: {-# UNPACK #-} !Int
  , cpHeapLen  :: {-# UNPACK #-} !Int
  , cpBindings :: !(IM.IntMap Value)
  , cpCutBar   :: {-# UNPACK #-} !Int
  , cpAggFrame :: !(Maybe AggFrame)
  , cpBuiltin  :: !(Maybe BuiltinState)
  } deriving (Show)

-- | Builtin state for choice points that need custom retry logic.
data BuiltinState
  = FactRetry !Int ![Int] !Int     -- variable ID, remaining interned atom IDs, returnPC
  | HopsRetry !Int ![Int] !Int     -- variable ID, remaining Hops values, returnPC
    -- Multi-output FFI kernel retry. Each remaining tuple is already
    -- wrapped as a list of Values (pre-interned / wrapped at call site).
    -- outRegs and outVars are parallel lists (same length as each tuple).
    -- outVars contains -1 for originally-bound outputs (no binding update).
  | FFIStreamRetry ![Int] ![Int] ![[Value]] !Int  -- outRegs, outVars, remaining tuples, returnPC
    -- Phase F2: FactStream for inline_data fact predicates.
    -- Iterates interned (arg1, arg2) tuples via backtracking.
    -- var1/var2 are variable IDs for binding (-1 = already bound, skip).
  | FactStream !Int !Int ![(Int, Int)] !Int  -- var1, var2, remaining rows, returnPC
  deriving (Show)

-- | Aggregate frame for begin_aggregate/end_aggregate.
data AggFrame = AggFrame
  { afType      :: !String         -- "sum", "count", "collect", etc.
  , afValueReg  :: !Int            -- register ID holding value per solution
  , afResultReg :: !Int            -- register ID for final result
  , afReturnPC  :: !Int            -- PC after end_aggregate
  , afMergeStrategy :: !MergeStrategy  -- Phase 4.2: derived from afType;
                                       -- carried on the frame so inner
                                       -- ParTryMeElse choice points can
                                       -- decide whether to fork without
                                       -- re-parsing the type string.
  } deriving (Show)

-- | Phase 4.2: how to combine per-branch aggregate values when forking.
-- Commutative-and-associative strategies (sum/count) go in Phase 4.2;
-- findall/bag/set arrive in Phase 4.3; race/negation in 4.4. Unknown
-- aggregate types yield MergeSequential, which disables forking.
data MergeStrategy
  = MergeSumInt
  | MergeSumDouble
  | MergeCount
  | MergeFindall       -- Phase 4.3
  | MergeBag           -- Phase 4.3
  | MergeSet           -- Phase 4.3
  | MergeRace          -- Phase 4.4
  | MergeNegation      -- Phase 4.4
  | MergeSequential    -- Default fallback; fork disabled
  deriving (Show, Eq)

-- | Phase 4.2: fork context threaded from BeginAggregate through to the
-- inner ParTryMeElse choice point that does the actual fork.
data ForkContext = ForkContext
  { fcMergeStrategy :: !MergeStrategy
  , fcWorkEstimate  :: !(Maybe Double)  -- microseconds, Phase 4.5
  } deriving (Show)

-- | Parse a MergeStrategy from the aggregate type string (as stored in
-- AggFrame.afType). Returns MergeSequential for anything we don''t
-- recognize, which causes the ParTryMeElse fork to fall back to the
-- sequential TryMeElse handler.
inferMergeStrategy :: String -> MergeStrategy
inferMergeStrategy "sum"   = MergeSumDouble
inferMergeStrategy "count" = MergeCount
inferMergeStrategy "bag"   = MergeBag
inferMergeStrategy "set"   = MergeSet
inferMergeStrategy "findall" = MergeFindall
inferMergeStrategy "collect" = MergeFindall
inferMergeStrategy _       = MergeSequential

-- | Phase 4.2: NFData instances so parMap rdeepseq can spark forked
-- branches. We need this only for the types that end up in a parMap
-- result — for us that''s `[Value]` (each branch''s contributed
-- aggregate values). Everything is first-order / strict already;
-- these definitions just walk the structure to force evaluation.
instance NFData Value where
  rnf (Atom n)         = rnf n
  rnf (Integer n)      = rnf n
  rnf (Float f)        = rnf f
  rnf (VList xs)       = rnf xs
  rnf (VSet s)         = rnf (IS.size s)  -- IntSet has no NFData; force size
  rnf (Str n args)     = rnf n `seq` rnf args
  rnf (Unbound n)      = rnf n
  rnf (Ref n)          = rnf n

-- | Builder for PutStructure/PutList + SetValue/SetConstant sequences.
data Builder = BuildStruct !Int !Int !Int ![Value]  -- interned functor ID, target reg ID, arity, collected args
             | BuildList !Int ![Value]               -- target reg ID, collected [head, tail]
             | ReadArgs ![Value]                     -- remaining args to read from structure (get_structure read mode)
             | NoBuilder
             deriving (Show)

-- | Phase F4: FactSource abstraction for external fact data.
-- Mirrors the Elixir FactSource behaviour (fsScan, fsLookupArg1, fsClose).
-- Concrete implementations: TsvFactSource (lazy IO), IntMapFactSource
-- (wraps existing strict IntMap). MmapFactSource deferred to Phase F6.
data FactSource = FactSource
  { fsScan       :: IO [(Int, Int)]         -- full scan (lazy)
  , fsLookupArg1 :: Int -> IO [(Int, Int)]  -- indexed by first arg
  , fsClose      :: IO ()                   -- release resources
  }

-- | Read-only context. Threaded through the run loop / step function as
-- a separate argument so it doesn''t pay the per-step record-update cost
-- on the mutable WamState. Built once at startup, never modified.
data WamContext = WamContext
  { wcCode          :: !(Array Int Instruction)
  , wcLabels        :: !(Map.Map String Int)
  , wcForeignFacts  :: !(Map.Map String (Map.Map String [String]))
  , wcForeignConfig :: !(Map.Map String Int)
  , wcLoweredPredicates :: !(Map.Map String (WamContext -> WamState -> Maybe WamState))
  -- | System-wide atom intern table. Built at compile time, extended
  -- at load time with runtime atoms. Used for Value → String display,
  -- evalArith reverse lookup, and FFI boundary interning.
  , wcInternTable   :: !InternTable
  -- | Fact indexes keyed by interned Int atoms. Used exclusively by the
  -- FFI kernel path. Populated per-kernel from edge_pred config.
  , wcFfiFacts      :: !(Map.Map String (IM.IntMap [Int]))
  -- | Weighted fact indexes for kernels that need (target, weight)
  -- pairs per edge (e.g., weighted_shortest_path3 / Dijkstra). Used
  -- exclusively by the FFI kernel path. Populated from 3-column fact
  -- sources — not wired into the default Main.hs template yet, so
  -- standalone benchmarks build this directly.
  , wcFfiWeightedFacts :: !(Map.Map String (IM.IntMap [(Int, Double)]))
  -- | Phase F2: inline fact data for FactStream predicates. Keyed by
  -- predicate name (e.g., "category_parent"). Each entry is a list of
  -- interned (arg1, arg2) tuples. Populated by Phase F3 code generation;
  -- empty until then.
  , wcInlineFacts :: !(Map.Map String [(Int, Int)])
  -- | Phase F4: external fact sources keyed by predicate name.
  -- Each entry is a FactSource adaptor (TsvFactSource, IntMapFactSource,
  -- etc.) that provides scan and indexed lookup. Populated at startup
  -- from fact_layout declarations.
  -- Phase F5 strictness: the strict (!) annotation forces the Map spine
  -- at construction. FactSource records are WHNF (IO actions are values).
  -- The !ctx bang pattern in Main.hs ensures the entire WamContext is
  -- evaluated before parMap. Within each spark, streamFacts uses
  -- unsafePerformIO per-call — no cross-spark lazy IO sharing.
  , wcFactSources :: !(Map.Map String FactSource)
  -- | Phase B1: LMDB-backed edge lookups for FFI kernels.
  -- When populated, kernels use these instead of wcFfiFacts IntMaps.
  -- Each entry is an EdgeLookup function (Int -> [Int]) that may be
  -- backed by an IntMap (intMapEdgeLookup) or LMDB (lmdbEdgeLookup).
  , wcEdgeLookups :: !(Map.Map String EdgeLookup)
  }
-- Note: no `deriving (Show)` because wcLoweredPredicates,
-- wcFactSources, and wcEdgeLookups are function-valued.
-- and functions have no Show instance. Add a manual instance if needed.

-- | Mutable state. Updated on every WAM step. Held separate from WamContext
-- so each step transition only allocates a record with the fields that
-- actually change.
data WamState = WamState
  { wsPC       :: {-# UNPACK #-} !Int
  , wsRegs     :: !(IM.IntMap Value)
  , wsStack    :: ![EnvFrame]
  , wsHeap     :: ![Value]
  , wsHeapLen  :: {-# UNPACK #-} !Int
  , wsTrail    :: ![TrailEntry]
  , wsTrailLen :: {-# UNPACK #-} !Int
  , wsCP       :: {-# UNPACK #-} !Int
  , wsCPs      :: ![ChoicePoint]
  , wsCPsLen   :: {-# UNPACK #-} !Int
  , wsBindings :: !(IM.IntMap Value)
  , wsCutBar   :: {-# UNPACK #-} !Int
  , wsBuilder      :: !Builder
  , wsBuilderStack :: ![Builder]    -- saved builders for nested get_structure
  , wsVarCounter   :: {-# UNPACK #-} !Int
  , wsAggAccum :: ![Value]
  } deriving (Show)

-- | Maximum register ID. A1-A99=1-99, X1-X99=101-199, Y handled via stack.
maxRegId :: Int
maxRegId = 199

-- | Pure WAM state for ST-mode execution. All fields except registers.
-- Registers live in a separate mutable STArray, passed alongside this record.
-- See WAM_HASKELL_MUTABLE_REGISTERS_SPECIFICATION.md.
data PureWamState = PureWamState
  { pwPC        :: {-# UNPACK #-} !Int
  , pwStack     :: ![EnvFrame]
  , pwHeap      :: ![Value]
  , pwHeapLen   :: {-# UNPACK #-} !Int
  , pwTrail     :: ![TrailEntry]
  , pwTrailLen  :: {-# UNPACK #-} !Int
  , pwCP        :: {-# UNPACK #-} !Int
  , pwCPs       :: ![MutableChoicePoint]
  , pwCPsLen    :: {-# UNPACK #-} !Int
  , pwBindings  :: !(IM.IntMap Value)
  , pwCutBar    :: {-# UNPACK #-} !Int
  , pwBuilder      :: !Builder
  , pwBuilderStack :: ![Builder]    -- saved builders for nested get_structure
  , pwVarCounter   :: {-# UNPACK #-} !Int
  , pwAggAccum     :: ![Value]
  }

-- | Choice point with frozen register snapshot (for ST-mode execution).
data MutableChoicePoint = MutableChoicePoint
  { mcpNextPC    :: {-# UNPACK #-} !Int
  , mcpRegs      :: !(Array Int Value)
  , mcpStack     :: ![EnvFrame]
  , mcpCP        :: {-# UNPACK #-} !Int
  , mcpTrailLen  :: {-# UNPACK #-} !Int
  , mcpHeapLen   :: {-# UNPACK #-} !Int
  , mcpBindings  :: !(IM.IntMap Value)
  , mcpCutBar    :: {-# UNPACK #-} !Int
  , mcpAggFrame  :: !(Maybe AggFrame)
  , mcpBuiltin   :: !(Maybe BuiltinState)
  }

-- | Instruction type for the WAM.
-- | Register IDs are pre-interned at compile time as Ints to avoid string
-- hashing on register access. Encoding:
--   A1-A99: 1-99
--   X1-X99: 101-199
--   Y1-Y99: 201-299
type RegId = Int

-- | Phase B1: abstract edge lookup function. Kernels use this instead
-- of IM.IntMap [Int] directly, allowing the backing store to be either
-- an in-memory IntMap or an LMDB database.
type EdgeLookup = Int -> [Int]

data Instruction
  = GetConstant Value !RegId
  | GetVariable !RegId !RegId
  | GetValue !RegId !RegId
  | PutConstant Value !RegId
  | PutVariable !RegId !RegId
  | PutValue !RegId !RegId
  | PutStructure !Int !RegId !Int     -- interned functor ID, target reg, arity
  | PutStructureDyn !RegId !RegId !RegId  -- nameReg, arityReg, targetReg (runtime-parsed)
  | PutList !RegId
  | SetValue !RegId
  | SetVariable !RegId                  -- builder slot = fresh unbound; also write to register
  | SetConstant Value
  | GetStructure !Int !RegId !Int   -- interned functor ID, target reg, arity
  | GetList !RegId                  -- target reg
  | UnifyVariable !RegId            -- target register to bind
  | UnifyValue !RegId               -- register whose value to unify with
  | UnifyConstant Value             -- constant to unify with
  | Allocate
  | Deallocate
  | Call String !Int                  -- pre-resolution form (string-keyed)
  | CallResolved !Int !Int            -- post-resolution: target PC + arity
  | CallForeign String !Int           -- compile-time resolved foreign pred (Nothing = fail)
  | Execute String
  | ExecutePc !Int                      -- post-resolution: direct PC jump (tail call)
  | Jump String                         -- unconditional jump to label
  | JumpPc !Int                         -- post-resolution: direct PC jump
  | CutIte                              -- soft cut: pop one CP (if-then-else)
  | GetLevel !Int                       -- M17: snapshot CP-stack depth into a Y reg
  | Cut !Int                            -- M17: truncate CP stack to a saved depth
  | Proceed
  | TryMeElsePc !Int                   -- post-resolution: direct PC for else branch
  | RetryMeElsePc !Int                 -- post-resolution: direct PC for next branch
  | SwitchOnConstantPc !(IM.IntMap Int)      -- post-resolution: interned atom ID -> PC
  | BuiltinCall String !Int
  | Arg !Int !RegId !RegId            -- specialized arg/3: literal N, term reg, output reg
  | NotMemberList !RegId !RegId       -- specialized \\+ member(X, L): X reg, L reg
  | NotMemberConstAtoms !RegId ![Int] -- \\+ member(X, [a,b,c,...]): X reg, baked-in interned atom IDs
  | BuildEmptySet !RegId              -- write VSet IS.empty into the named register
  | SetInsert !RegId !RegId !RegId    -- elemReg, inSetReg, outSetReg
  | NotMemberSet !RegId !RegId        -- elemReg, setReg: O(log N) member check
  | TryMeElse String
  | RetryMeElse String
  | TrustMe
  -- Phase 4.1: parallel-forkable variants. Emitted by the compiler
  -- when the predicate has a pure purity certificate. At Phase 4.1
  -- they dispatch to the same sequential handlers as the non-Par
  -- variants — the instructions carry intent, not behavior. Phase 4.2
  -- will add the runtime fork. See
  -- docs/design/WAM_HASKELL_INTRA_QUERY_SPEC.md §2.
  | ParTryMeElse String
  | ParRetryMeElse String
  | ParTrustMe
  | ParTryMeElsePc !Int
  | ParRetryMeElsePc !Int
  | SwitchOnConstant (Map.Map Value String)   -- pre-built Map for O(log n) dispatch
  | BeginAggregate String !RegId !RegId   -- type, valueReg, resultReg
  | EndAggregate !RegId                   -- valueReg
  | CallFactStream String !Int            -- Phase F2: predicate name, arity
  deriving (Show, Eq)

-- | Build the read-only context from compiled code and labels. Called
-- once at project startup. The context is then threaded into runLoop
-- and step as a separate argument.
mkContext :: [Instruction] -> Map.Map String Int -> WamContext
mkContext codeList labels =
  let n = length codeList
      code = listArray (1, n) codeList
  in WamContext
    { wcCode          = code
    , wcLabels        = labels
    , wcForeignFacts  = Map.empty
    , wcForeignConfig = Map.empty
    , wcLoweredPredicates = Map.empty
    , wcInternTable   = emptyInternTable
    , wcFfiFacts      = Map.empty
    , wcFfiWeightedFacts = Map.empty
    , wcInlineFacts   = Map.empty
    , wcFactSources   = Map.empty
    , wcEdgeLookups   = Map.empty
    }

-- | Create initial empty mutable state. The cold fields (code, labels,
-- foreign facts/config) live in WamContext now.
emptyState :: WamState
emptyState = WamState
  { wsPC       = 1
  , wsRegs     = IM.empty
  , wsStack    = []
  , wsHeap     = []
  , wsHeapLen  = 0
  , wsTrail    = []
  , wsTrailLen = 0
  , wsCP       = 0
  , wsCPs      = []
  , wsCPsLen   = 0
  , wsBindings = IM.empty
  , wsCutBar   = 0
  , wsBuilder  = NoBuilder
  , wsBuilderStack = []
  , wsVarCounter = 0
  , wsAggAccum = []
  }
'.

%% generate_cabal_file(+Name, +UseHM, +Options, -Code)
%  Options: profiling(true) adds -prof -fprof-auto -rtsopts for GHC profiling.
generate_cabal_file(Name, UseHM, Options, Code) :-
    % deepseq + parallel for seed-level parMap rdeepseq
    % async for Phase 4.4 race-to-cancel negation
    (   UseHM == true
    ->  BaseDeps = "base >= 4.12, containers >= 0.6, array, time >= 1.8, unordered-containers >= 0.2, hashable >= 1.2, deepseq >= 1.4, parallel >= 3.2, async >= 2.2"
    ;   BaseDeps = "base >= 4.12, containers >= 0.6, array, time >= 1.8, deepseq >= 1.4, parallel >= 3.2, async >= 2.2"
    ),
    % Phase B1: conditional LMDB dependency.
    % bytestring + text are added with use_lmdb(true) so peekStringBytes
    % can decode UTF-8 — the byte loop got mojibake on non-ASCII fixtures
    % (e.g. accented Wikipedia categorylinks).
    (   option(use_lmdb(true), Options)
    ->  format(string(Deps), "~w, lmdb >= 0.2.5, directory >= 1.3, bytestring >= 0.10, text >= 1.2", [BaseDeps])
    ;   Deps = BaseDeps
    ),
    % -threaded enables multi-core runtime (+RTS -N to use cores).
    % -rtsopts is needed so +RTS flags are accepted at runtime.
    (   option(profiling(true), Options)
    ->  BaseGhcOpts = "-O2 -threaded -rtsopts -prof -fprof-auto"
    ;   BaseGhcOpts = "-O2 -threaded -rtsopts"
    ),
    %% with_rtsopts(Flags): bake default RTS flags into the executable
    %% so +RTS args don't need to be passed every run. Caller-supplied
    %% +RTS flags still override (per GHC's "last flag wins" rule).
    %% Used by the matrix bench to default -A64M (Phase L appendix #6
    %% in WAM_PERF_OPTIMIZATION_LOG.md): the GC-pressure win at -N>=2
    %% is large enough that we'd rather pay the small -N1 regression
    %% than make every bench user pass +RTS flags. Cost-model-driven
    %% selection (à la C# target's source-mode resolver) is deferred.
    (   option(with_rtsopts(RtsFlags), Options),
        RtsFlags \= ''
    ->  format(string(GhcOpts), '~w "-with-rtsopts=~w"', [BaseGhcOpts, RtsFlags])
    ;   GhcOpts = BaseGhcOpts
    ),
    format(string(Code),
'cabal-version: 2.4
name:          ~w
version:       0.1.0.0
build-type:    Simple

executable ~w
  main-is:          Main.hs
  hs-source-dirs:   src
  other-modules:    WamTypes, WamRuntime, Predicates, Lowered
  build-depends:    ~w
  default-language: Haskell2010
  ghc-options:      ~w
', [Name, Name, Deps, GhcOpts]).

%% compile_predicates_to_haskell(+Predicates, +Options, -Code)
%  Compiles all predicates into a single merged code array and label map,
%  with proper PC offsets for each predicate. Phase F1: also classifies
%  each predicate and emits classification comments in Predicates.hs.
compile_predicates_to_haskell(Predicates, Options, Code) :-
    compile_predicates_to_haskell(Predicates, Options, Code, _InlineDefs).

%% compile_predicates_to_haskell(+Predicates, +Options, -Code, -InlineDefs)
%  Extended version that also returns inline fact definitions for Main.hs wiring.
compile_predicates_to_haskell(Predicates, Options, Code, InlineDefs) :-
    compile_predicates_merged(Predicates, 1, Options, AllInstrs, AllLabels, ShapeComments, InlineDefs),
    atomic_list_concat(AllInstrs, '\n    , ', InstrCode),
    atomic_list_concat(AllLabels, '\n    , ', LabelCode),
    (   ShapeComments == []
    ->  ShapeBlock = ""
    ;   atomic_list_concat(ShapeComments, '\n', ShapeLines),
        format(string(ShapeBlock), '\n-- Fact shape classification:\n~w\n', [ShapeLines])
    ),
    % Phase F3: collect inline fact literal definitions
    (   InlineDefs == []
    ->  InlineBlock = ""
    ;   maplist([inline_fact(_, _, DefCode), DefCode]>>true, InlineDefs, DefCodes),
        atomic_list_concat(DefCodes, '\n', InlineCode),
        format(string(InlineBlock), '\n-- | Phase F3: inline fact data for FactStream predicates.\n~w\n', [InlineCode])
    ),
    format(string(Code),
'module Predicates where

import qualified Data.Map.Strict as Map
import qualified Data.IntMap.Strict as IM
import WamTypes
~w
-- | Merged WAM code for all predicates.
allCode :: [Instruction]
allCode =
    [ ~w
    ]

-- | Merged label map for all predicates.
allLabels :: Map.Map String Int
allLabels = Map.fromList
    [ ~w
    ]
~w', [ShapeBlock, InstrCode, LabelCode, InlineBlock]).

%% use_external_source(+Pred/Arity, +Options)
%  True when this predicate's data lives in an external store (LMDB)
%  rather than compiled WAM code. Default allow-list is [category_parent/2]
%  because the LMDB ingestion wiring in generate_lmdb_wiring/4 is
%  hardcoded to that predicate. Override with option
%  lmdb_backed_facts([P1/A1, P2/A2, ...]) when additional predicates
%  are also LMDB-ingested.
use_external_source(Pred/Arity, Options) :-
    option(use_lmdb(true), Options),
    option(lmdb_backed_facts(LmdbPreds), Options, [category_parent/2]),
    memberchk(Pred/Arity, LmdbPreds).

%% pred_is_external_source(+Options, +PredIndicator)
%  partition/4 adapter for use_external_source/2. Accepts either
%  Module:Pred/Arity or Pred/Arity form.
pred_is_external_source(Options, PredIndicator) :-
    (   PredIndicator = _Module:Pred/Arity -> true
    ;   PredIndicator = Pred/Arity
    ),
    use_external_source(Pred/Arity, Options).

compile_predicates_merged([], _, _, [], [], [], []).
compile_predicates_merged([PredIndicator|Rest], StartPC, Options, AllInstrs, AllLabels, AllComments, AllInlineDefs) :-
    (   PredIndicator = _Module:Pred/Arity -> true
    ;   PredIndicator = Pred/Arity
    ),
    % Phase B1 optimization: predicates whose data lives in an external
    % store (LMDB) are resolved at runtime via wcEdgeLookups, so the
    % WAM bytecode for each fact is dead weight. Skip compilation
    % entirely for those.
    (   use_external_source(Pred/Arity, Options)
    ->  format(user_error,
               '  ~w/~w: external_source — skipping WAM compilation (LMDB-backed)~n',
               [Pred, Arity]),
        format(string(Comment),
               '-- ~w/~w: fact_only=true, layout=external_source (data in LMDB)',
               [Pred, Arity]),
        InstrExprs = [],
        LabelExprs = [],
        InlineDefs = [],
        NextPC = StartPC,
        compile_predicates_merged(Rest, NextPC, Options, RestInstrs, RestLabels, RestComments, RestInlineDefs),
        append(InstrExprs, RestInstrs, AllInstrs),
        append(LabelExprs, RestLabels, AllLabels),
        AllComments = [Comment | RestComments],
        append(InlineDefs, RestInlineDefs, AllInlineDefs)
    ;   compile_predicates_merged_normal(PredIndicator, Pred, Arity, Rest, StartPC, Options,
                                         AllInstrs, AllLabels, AllComments, AllInlineDefs)
    ).

compile_predicates_merged_normal(PredIndicator, Pred, Arity, Rest, StartPC, Options,
                                 AllInstrs, AllLabels, AllComments, AllInlineDefs) :-
    wam_target:compile_predicate_to_wam(PredIndicator, [ite_use_y_level(true)], WamCode),
    format(user_error, '  ~w/~w: compiled to WAM (PC=~w)~n', [Pred, Arity, StartPC]),
    atom_string(WamCode, WamStr),
    split_string(WamStr, "\n", "", Lines),
    % Phase F1: classify the predicate from WAM text
    classify_fact_predicate(Pred/Arity, Lines, Options, ShapeInfo),
    format_fact_shape_comment_hs(Pred/Arity, ShapeInfo, Comment),
    format(user_error, '    ~w~n', [Comment]),
    ShapeInfo = fact_shape_info(_, _, _, Layout),
    % Phase F3: if inline_data, emit fact literal + CallFactStream instead of WAM
    (   Layout = inline_data(_), Arity == 2
    ->  split_wam_into_segments(Lines, Segments),
        extract_fact_tuples_hs(Segments, FactTuples),
        length(FactTuples, NTuples),
        format(atom(PredNameAtom), '~w', [Pred]),
        atom_string(PredNameAtom, PredNameStr),
        haskell_fact_list_name(PredNameStr, ListName),
        emit_inline_fact_literal(ListName, FactTuples, InlineDefCode),
        format(string(LabelExpr), '("~w/~w", ~w)', [Pred, Arity, StartPC]),
        format(string(InstrExpr), 'CallFactStream "~w" ~w', [Pred, Arity]),
        InstrExprs = [InstrExpr],
        LabelExprs = [LabelExpr],
        NextPC is StartPC + 1,
        InlineDefs = [inline_fact(PredNameStr, ListName, InlineDefCode)],
        format(user_error, '    [F3] ~w/~w: emitting inline_data (~w tuples)~n',
               [Pred, Arity, NTuples])
    ;   % Normal compiled path
        wam_lines_to_haskell(Lines, StartPC, InstrExprs0, LabelExprs, NextPC),
        maybe_parallelize_instrs(PredIndicator, Options, InstrExprs0, InstrExprs),
        InlineDefs = []
    ),
    compile_predicates_merged(Rest, NextPC, Options, RestInstrs, RestLabels, RestComments, RestInlineDefs),
    append(InstrExprs, RestInstrs, AllInstrs),
    append(LabelExprs, RestLabels, AllLabels),
    AllComments = [Comment | RestComments],
    append(InlineDefs, RestInlineDefs, AllInlineDefs).

%% extract_fact_tuples_hs(+Segments, -Tuples)
%  Extracts (InternedA1, InternedA2) pairs from classified fact segments.
%  Each segment should contain get_constant instructions for A1 and A2.
%  Atoms are interned via the compile-time intern table.
extract_fact_tuples_hs(Segments, Tuples) :-
    findall((Id1, Id2), (
        member(_-Instrs, Segments),
        member(get_constant(Val1, "A1"), Instrs),
        member(get_constant(Val2, "A2"), Instrs),
        intern_atom(Val1, Id1),
        intern_atom(Val2, Id2)
    ), Tuples).

%% haskell_fact_list_name(+PredName, -ListName)
%  Generate a Haskell identifier for the inline fact list.
%  e.g., "category_parent" -> "categoryParentFacts"
haskell_fact_list_name(PredName, ListName) :-
    split_string(PredName, "_", "", Parts),
    Parts = [First|Rest],
    maplist([In, Out]>>(
        string_chars(In, [C|Cs]),
        upcase_atom(C, UC),
        atom_chars(UC, [UCC]),
        string_chars(Out, [UCC|Cs])
    ), Rest, CamelRest),
    atomic_list_concat([First|CamelRest], '', CamelName),
    format(atom(ListName), '~wFacts', [CamelName]).

%% emit_inline_fact_literal(+ListName, +Tuples, -Code)
%  Emits a Haskell top-level definition for an inline fact list with
%  interned atom ID tuples.
emit_inline_fact_literal(ListName, Tuples, Code) :-
    maplist([(Id1, Id2), Entry]>>(
        format(string(Entry), '(~w, ~w)', [Id1, Id2])
    ), Tuples, Entries),
    (   Entries = []
    ->  format(string(Code), '~w :: [(Int, Int)]\n~w = []\n', [ListName, ListName])
    ;   Entries = [First|Rest],
        format(string(FirstLine), '    [ ~w', [First]),
        maplist([E, L]>>format(string(L), '    , ~w', [E]), Rest, RestLines),
        append([FirstLine], RestLines, AllLines),
        atomic_list_concat(AllLines, '\n', Body),
        format(string(Code), '~w :: [(Int, Int)]\n~w =\n~w\n    ]\n', [ListName, ListName, Body])
    ).

%% generate_lmdb_functions(+Options, -Code)
%  Loads the LMDB FactSource functions from the Mustache template,
%  rendering the layout-specific section blocks.
%  Only called when use_lmdb(true).
%
%  Options:
%    lmdb_layout(default) — packed-Int32 array per key (WAM-native ingest)
%    lmdb_layout(dupsort) — named "main" subdb with MDB_DUPSORT, one
%                           entry per (key, value) pair (streaming-
%                           pipeline ingest)
%    lmdb_cache_mode(memoize) — DEPRECATED synonym for sharded.  Kept
%                           for backwards compatibility with PR #1637.
%                           Internally identical to the sharded mode
%                           it was renamed to.  See PARALLELISM
%                           CAVEAT below — the original IntMap-based
%                           memoize regressed under -N>1; the new
%                           IOArray-based sharded mode does not.
%
%    lmdb_cache_mode(per_hec) — Phase 1 — per-HEC L1 cache (PR #1640).
%                           Each capability owns its own mutable
%                           IOArray with no synchronisation on the
%                           hot path.  Trade-off: cache hits don't
%                           share across threads, so a key seen by
%                           two workers pays the LMDB miss twice.
%                           Right call when intra-thread reuse
%                           dominates (most DFS-style workloads).
%
%    lmdb_cache_mode(sharded) — Phase 2 — shared L2 cache.  A single
%                           IOArray shared across all HECs.  Lock-
%                           free racy writes (correct because LMDB
%                           is read-only).  Cross-HEC sharing without
%                           atomicModifyIORef contention.  Memory
%                           budget computed from /proc/meminfo on
%                           Linux: min(half-available, available -
%                           500 MB), bounded [1024, 1M] entries.
%
%    lmdb_cache_mode(two_level) — Phase 2 — L1 + L2 composed.  Per-
%                           HEC L1 in front of shared L2.  L1 hits
%                           skip L2; L2 hits promote to L1; LMDB
%                           misses fill both.  The workload-portable
%                           choice: low-overlap workloads mostly hit
%                           L1, high-overlap workloads benefit from
%                           cross-HEC sharing via L2.
%
%    lmdb_cache_l2_capacity_bytes(N) — override the auto-detected
%                           L2 capacity.  N is the desired byte
%                           budget; the runtime divides by ~32
%                           bytes per entry and rounds down to a
%                           power of two.  Only meaningful when L2
%                           is active (sharded or two_level);
%                           ignored otherwise.  Useful when the
%                           /proc/meminfo-based default is too small
%                           (server with 64 GB RAM but auto caps at
%                           1M entries) or too large (memory-tight
%                           container).
%
%    lmdb_cache_mode(auto) — Phase 3 hook: defer the choice of
%                           cache mode to statistics:select_cache_mode/2.
%                           Users populate workload-level hints via
%                           statistics:declare_cache_hints/1 (see
%                           reuse_axis → mode mapping in
%                           src/unifyweaver/core/statistics.pl).
%                           When no hints are declared, falls back
%                           to `none` (no cache).  Infrastructure-
%                           only: codegen does not currently compute
%                           the hints; future work will add an
%                           analyzer that derives them from a
%                           sample run.
%
%    All cache modes are gated by lmdb_layout(dupsort); ignored
%    otherwise.  Modes are mutually exclusive; precedence when
%    multiple flags are set is two_level > sharded > memoize >
%    per_hec.
%
%    PARALLELISM CAVEAT (legacy memoize): the original IntMap-based
%    memoize cache (PR #1637) used atomicModifyIORef' on every miss,
%    which serialised across cores and regressed 7x at -N4 on
%    low-hit-rate workloads.  The current sharded implementation
%    uses a lock-free IOArray and does not have this problem.  The
%    PARALLELISM CAVEAT applies only if you explicitly want the
%    legacy behaviour.
%% resolve_auto_cache_mode(-Mode)
%  Phase 3 hook: consult statistics:select_cache_mode/2 with the
%  default fallback `none`.  Users populate workload-level hints via
%  statistics:declare_cache_hints/1 before invoking the codegen;
%  when no hints are declared, this returns `none` and the user
%  effectively gets the bare dupsort path.
%
%  Kept as a thin wrapper here (rather than inlined) so the
%  default fallback policy is documented in one place and easy to
%  change later (e.g. flip the default from `none` to `sharded`
%  once auto-detection of workload class is added).
resolve_auto_cache_mode(Mode) :-
    select_cache_mode(none, Mode).

%% resolve_auto_use_lmdb(+Options0, -Options)
%
%  Normalize `use_lmdb(auto)` to a concrete `use_lmdb(true)` or
%  `use_lmdb(false)`. Decision order:
%
%    1. Hackage/cabal availability of the `lmdb` package — checked via
%       `ghc-pkg list --simple-output lmdb`. If not installed, fall
%       back to `false` with a stderr warning so the user knows why
%       the auto mode declined LMDB.
%    2. Fact-count threshold. When `option(fact_count(N), ...)` is in
%       scope and `N > option(lmdb_auto_threshold(T), ..., 50000)`,
%       pick `true`; otherwise `false`. The default 50000 lands
%       between the IntMap-wins-clearly regime (≤10k facts in the
%       prior crossover study) and the LMDB+cache-wins regime
%       (≥100k); both endpoints documented in
%       `project_wam_haskell_fact_access.md`. Override-able per call
%       site.
%    3. If `fact_count` is absent (caller doesn't know the size),
%       conservatively default to `false` so we don't auto-pick the
%       heavier path without justification.
%
%  When `use_lmdb(true)` or `use_lmdb(false)` is explicitly set,
%  returns Options unchanged. When `use_lmdb` is absent entirely,
%  returns Options unchanged (downstream defaults to IntMap).
%
%  Firewall integration is deliberately *not* in this first cut —
%  cabal's own dependency resolution is the safety gate. A future
%  optional firewall hook (consult `firewall_check(use_lmdb, R)`
%  before step 1) can layer on top without changing the resolver's
%  contract.
resolve_auto_use_lmdb(Options0, Options) :-
    (   select(use_lmdb(auto), Options0, Rest)
    ->  resolve_auto_use_lmdb_decision(Rest, Decision),
        Options = [use_lmdb(Decision) | Rest]
    ;   Options = Options0
    ).

resolve_auto_use_lmdb_decision(Options, Decision) :-
    (   \+ lmdb_haskell_package_available
    ->  format(user_error,
               '[WAM-Haskell] use_lmdb(auto): ghc-pkg does not list lmdb; falling back to IntMap~n', []),
        Decision = false
    ;   option(fact_count(N), Options),
        integer(N), N >= 1,
        option(lmdb_auto_threshold(T), Options, 50000),
        integer(T), T >= 1,
        N > T
    ->  Decision = true
    ;   Decision = false
    ).

%% lmdb_haskell_package_available
%
%  True iff the Haskell `lmdb` package is reachable from the current
%  toolchain. Probes two sources, in order:
%
%  1. `ghc-pkg list --simple-output lmdb` — catches global / user
%     package db installs (the conventional case after
%     `cabal install --lib lmdb`).
%
%  2. `ghc-pkg --package-db ~/.cabal/store/ghc-<ver>/package.db list
%     --simple-output lmdb` — catches `cabal v2-build` /
%     `cabal v2-install --lib` installs that land in the cabal store
%     rather than user db. Common with cabal ≥ 2.4.
%
%  Conservative: any process error or absent ghc-pkg makes this fail
%  (silently), which propagates as `Decision=false` rather than
%  crashing the codegen on an environmental issue.
lmdb_haskell_package_available :-
    ghc_pkg_lists_lmdb([]).
lmdb_haskell_package_available :-
    cabal_store_package_db(StoreDb),
    ghc_pkg_lists_lmdb(['--package-db', StoreDb]).

ghc_pkg_lists_lmdb(ExtraArgs) :-
    append(ExtraArgs, ['list', '--simple-output', 'lmdb'], Args),
    catch(
        (   process_create(path('ghc-pkg'), Args,
                [stdout(pipe(Out)), stderr(null), process(Pid)]),
            read_string(Out, _, OutStr),
            close(Out),
            process_wait(Pid, _),
            sub_string(OutStr, _, _, _, "lmdb")
        ),
        _, fail).

%% cabal_store_package_db(-StoreDb) is semidet.
%
%  Resolve the path of the cabal store's package db for the user's
%  current GHC. Fails if `ghc --numeric-version` doesn't run or the
%  store directory doesn't exist on disk.
cabal_store_package_db(StoreDb) :-
    catch(
        (   process_create(path('ghc'), ['--numeric-version'],
                [stdout(pipe(GhcOut)), stderr(null), process(GhcPid)]),
            read_string(GhcOut, _, GhcVerRaw),
            close(GhcOut),
            process_wait(GhcPid, _),
            split_string(GhcVerRaw, "\n", "\n\r", [GhcVer|_]),
            GhcVer \== "",
            expand_file_name('~/.cabal/store', [Store]),
            format(string(StoreDb),
                   '~w/ghc-~w/package.db', [Store, GhcVer]),
            exists_directory(StoreDb)
        ),
        _, fail).

generate_lmdb_functions(Options, Code) :-
    read_kernel_template('lmdb_fact_source.hs.mustache', Template),
    (   option(lmdb_layout(dupsort), Options)
    ->  Dupsort = true
    ;   Dupsort = false
    ),
    % Two-level wins over all single-tier modes; sharded next; then
    % per_hec; the deprecated memoize is treated like sharded for
    % the new IOArray implementation (older IntMap is gone).
    %
    % `auto` consults statistics:select_cache_mode/2 with default
    % `none`; users can populate workload hints via
    % statistics:declare_cache_hints/1.  See Phase 3 in
    % docs/proposals/WAM_HASKELL_LMDB_CACHE_TIERS.md.
    (   option(lmdb_cache_mode(auto), Options),
        Dupsort == true
    ->  resolve_auto_cache_mode(ChosenMode)
    ;   option(lmdb_cache_mode(Mode), Options),
        member(Mode, [two_level, sharded, per_hec, memoize, none]),
        Dupsort == true
    ->  ChosenMode = Mode
    ;   ChosenMode = none
    ),
    % Mode → flag mapping for the template:
    %   two_level  → l1 + l2 + two_level
    %   sharded    → l2
    %   memoize    → l2 (deprecated synonym; same impl)
    %   per_hec    → l1
    %   none       → no cache
    (   (ChosenMode == per_hec ; ChosenMode == two_level)
    ->  CacheL1 = true
    ;   CacheL1 = false
    ),
    (   (ChosenMode == sharded ; ChosenMode == memoize ; ChosenMode == two_level)
    ->  CacheL2 = true
    ;   CacheL2 = false
    ),
    (   ChosenMode == two_level
    ->  CacheTwoLevel = true
    ;   CacheTwoLevel = false
    ),
    % Legacy memoize section in the template is not used in Phase 2;
    % the sharded IOArray implementation lives under lmdb_cache_l2.
    CacheMemoize   = false,
    % L2 capacity user override (bytes).  0 means "use the
    % memory-aware default"; any positive integer overrides it.
    % Mustache treats 0 as falsy so the {{#lmdb_l2_capacity_bytes}}
    % section only fires for the override case.
    (   option(lmdb_cache_l2_capacity_bytes(Bytes), Options),
        integer(Bytes), Bytes > 0,
        CacheL2 == true
    ->  L2CapacityBytes = Bytes
    ;   L2CapacityBytes = 0
    ),
    render_template(Template,
                    [lmdb_dupsort=Dupsort,
                     lmdb_cache_memoize=CacheMemoize,
                     lmdb_cache_l1=CacheL1,
                     lmdb_cache_l2=CacheL2,
                     lmdb_cache_two_level=CacheTwoLevel,
                     lmdb_l2_capacity_bytes=L2CapacityBytes],
                    Code).

%% generate_cost_function_code(+Options, -Code) is det.
%
%  Phase 1 (scan-strategy). When option(tree_cost_function(Name, Params),
%  Options) is present, emit:
%    1. The cost_function.hs.mustache template (CostFn record + concrete
%       constructors hopDistanceCostFn / fluxCostFn / semanticCostFn).
%    2. A `theCostFn :: CostFn` binding that selects the appropriate
%       constructor with the chosen parameters.
%
%  The chosen tree_cost_function term is validated and filled with
%  defaults via cost_function:cost_function_with_defaults/2. Bad terms
%  (unknown name, wrong types, missing required params) throw at
%  codegen time — no silent acceptance.
%
%  When the option is absent, returns the empty string. Existing
%  workloads see no Haskell-level change.
generate_cost_function_code(Options, Code) :-
    (   option(tree_cost_function(Name, ProvidedParams), Options)
    ->  validate_cost_function(tree_cost_function(Name, ProvidedParams)),
        cost_function_with_defaults(
            tree_cost_function(Name, ProvidedParams),
            tree_cost_function(Name, FullParams)),
        read_kernel_template('cost_function.hs.mustache', Template),
        cost_function_haskell_constructor(Name, FullParams, ConstructorExpr),
        format(string(Code),
'-- ==================================================================
-- Cost-function strategy slot (scan-strategy P1).
-- ==================================================================

~w

-- | Cost function selected at codegen time from
-- tree_cost_function(~w, ...) in workload options. P3+ warm-build
-- consumes this to rank candidate nodes during tree construction.
theCostFn :: CostFn
theCostFn = ~w
',                  [Template, Name, ConstructorExpr])
    ;   Code = ""
    ).

%% cost_function_haskell_constructor(+Name, +Params, -Expr)
%
%  Map a (validated, defaults-filled) tree_cost_function/2 term into
%  the Haskell expression that constructs the corresponding CostFn.
cost_function_haskell_constructor(hop_distance, Params, Expr) :- !,
    option(max_hops(MaxHops), Params),
    format(string(Expr), 'hopDistanceCostFn ~d', [MaxHops]).
cost_function_haskell_constructor(flux, Params, Expr) :- !,
    option(parent_decay(PD), Params),
    option(child_decay(CD), Params),
    %% Third arg is currently a placeholder for the flux_merge mode;
    %% the panic stub ignores it. P3+ will define a sensible encoding.
    format(string(Expr), 'fluxCostFn ~w ~w 0.0', [PD, CD]).
cost_function_haskell_constructor(semantic_similarity, Params, Expr) :- !,
    option(dim(Dim), Params),
    option(embedding_path(Path), Params),
    format(string(Expr), 'semanticCostFn ~d "~w"', [Dim, Path]).

%% maybe_parallelize_instrs(+PredIndicator, +Options, +InstrExprs0, -InstrExprs)
%  Rewrite TryMeElse → ParTryMeElse etc. when the predicate certifies
%  pure with confidence >= 0.85 and intra_query_parallel/1 hasn't
%  been disabled. Otherwise leaves instructions alone.
%
%  Confidence threshold: 0.85 — catches user-declared (1.0),
%  kernel-registry-certified (1.0), and blacklist-clean (0.9) as
%  forkable. Inferred / low-confidence verdicts fall back to sequential.
maybe_parallelize_instrs(PredIndicator, Options, InstrExprs0, InstrExprs) :-
    (   option(intra_query_parallel(false), Options)
    ->  InstrExprs = InstrExprs0
    ;   purity_certificate:analyze_predicate_purity(
            PredIndicator,
            purity_cert(pure, _, Conf, _)),
        Conf >= 0.85
    ->  maplist(parallelize_choice_instr, InstrExprs0, InstrExprs),
        ( InstrExprs \== InstrExprs0
        -> ( PredIndicator = _:Pred/Arity -> true ; PredIndicator = Pred/Arity ),
           format(user_error,
                  '    [Par] ~w/~w: emitting Par* for forkable choice points~n',
                  [Pred, Arity])
        ; true
        )
    ;   InstrExprs = InstrExprs0
    ).

%% parallelize_choice_instr(+InstrStr0, -InstrStr)
%  String-level rewrite of choice-point instructions:
%    TryMeElse   "…"  →  ParTryMeElse   "…"
%    RetryMeElse "…"  →  ParRetryMeElse "…"
%    TrustMe          →  ParTrustMe
%
%  Accepts either atom or string input; returns the same type so
%  callers and tests can mix representations without surprises.
parallelize_choice_instr(S0, S) :-
    atom_string(A0, S0),
    ( sub_atom(A0, 0, _, _, 'TryMeElse ')
    -> atom_concat('Par', A0, A)
    ; sub_atom(A0, 0, _, _, 'RetryMeElse ')
    -> atom_concat('Par', A0, A)
    ; A0 == 'TrustMe'
    -> A = 'ParTrustMe'
    ; A = A0
    ),
    ( atom(S0) -> S = A ; atom_string(A, S) ).

compile_single_predicate_to_haskell(PredIndicator, _Options, Code) :-
    (   PredIndicator = _Module:Pred/Arity -> true
    ;   PredIndicator = Pred/Arity
    ),
    wam_target:compile_predicate_to_wam(PredIndicator, [ite_use_y_level(true)], WamCode),
    format(user_error, '  ~w/~w: compiled to WAM~n', [Pred, Arity]),
    % Parse WAM text into Haskell instruction list and label map
    atom_string(WamCode, WamStr),
    split_string(WamStr, "\n", "", Lines),
    wam_lines_to_haskell(Lines, 1, InstrExprs, LabelExprs),
    atomic_list_concat(InstrExprs, '\n    , ', InstrCode),
    atomic_list_concat(LabelExprs, '\n    , ', LabelCode),
    format(atom(FuncName), '~w_~w', [Pred, Arity]),
    format(string(Code),
'-- WAM-compiled predicate: ~w/~w
~w_code :: [Instruction]
~w_code =
    [ ~w
    ]

~w_labels :: Map.Map String Int
~w_labels = Map.fromList
    [ ~w
    ]', [Pred, Arity, FuncName, FuncName, InstrCode, FuncName, FuncName, LabelCode]).

compile_wam_predicate_to_haskell(PredIndicator, WamCode, _Options, Code) :-
    (   PredIndicator = _Module:Pred/Arity -> true
    ;   PredIndicator = Pred/Arity
    ),
    (   string(WamCode)
    ->  WamStr = WamCode
    ;   atom_string(WamCode, WamStr)
    ),
    split_string(WamStr, "\n", "", Lines),
    wam_lines_to_haskell(Lines, 1, InstrExprs, LabelExprs),
    atomic_list_concat(InstrExprs, '\n    , ', InstrCode),
    atomic_list_concat(LabelExprs, '\n    , ', LabelCode),
    format(atom(FuncName), '~w_~w', [Pred, Arity]),
    format(string(Code),
'-- WAM-compiled predicate: ~w/~w
~w_code :: [Instruction]
~w_code =
    [ ~w
    ]

~w_labels :: Map.Map String Int
~w_labels = Map.fromList
    [ ~w
    ]', [Pred, Arity, FuncName, FuncName, InstrCode, FuncName, FuncName, LabelCode]).

%% wam_lines_to_haskell(+Lines, +PC, -InstrExprs, -LabelExprs, -NextPC)
%  Parses WAM assembly lines into Haskell Instruction constructor expressions
%  and label (String, Int) pairs. Returns NextPC for merging multiple predicates.
wam_lines_to_haskell([], PC, [], [], PC).
wam_lines_to_haskell([Line|Rest], PC, Instrs, Labels, FinalPC) :-
    split_string(Line, " \t,", " \t,", Parts),
    delete(Parts, "", CleanParts),
    (   CleanParts == []
    ->  wam_lines_to_haskell(Rest, PC, Instrs, Labels, FinalPC)
    ;   CleanParts = [First|_],
        (   sub_string(First, _, 1, 0, ":")
        ->  sub_string(First, 0, _, 1, LabelName),
            format(string(LabelExpr), '("~w", ~w)', [LabelName, PC]),
            Labels = [LabelExpr|RestLabels],
            wam_lines_to_haskell(Rest, PC, Instrs, RestLabels, FinalPC)
        ;   wam_instr_to_haskell(CleanParts, HsExpr),
            NPC is PC + 1,
            Instrs = [HsExpr|RestInstrs],
            wam_lines_to_haskell(Rest, NPC, RestInstrs, Labels, FinalPC)
        )
    ).

%% reg_name_to_int(+RegName, -Int)
%  Encode register name string to integer ID for IntMap-based register storage.
%  A1-A99 -> 1-99, X1-X99 -> 101-199, Y1-Y99 -> 201-299.
reg_name_to_int(Reg, Int) :-
    atom_string(RegA, Reg),
    sub_atom(RegA, 0, 1, _, Bank),
    sub_atom(RegA, 1, _, 0, NumA),
    atom_number(NumA, Num),
    (   Bank == 'A' -> Int = Num
    ;   Bank == 'X' -> Int is Num + 100
    ;   Bank == 'Y' -> Int is Num + 200
    ;   Int = 0
    ).

%% wam_instr_to_haskell(+Parts, -HaskellExpr)
%  Converts parsed WAM instruction parts to a Haskell Instruction constructor.
wam_instr_to_haskell(["get_constant", C, Ai], Hs) :-
    clean_comma(C, CC), clean_comma(Ai, CAi),
    wam_value_to_haskell(CC, HsVal),
    reg_name_to_int(CAi, AiI),
    format(string(Hs), 'GetConstant (~w) ~w', [HsVal, AiI]).
wam_instr_to_haskell(["get_variable", Xn, Ai], Hs) :-
    clean_comma(Xn, CXn), clean_comma(Ai, CAi),
    reg_name_to_int(CXn, XnI), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'GetVariable ~w ~w', [XnI, AiI]).
wam_instr_to_haskell(["get_value", Xn, Ai], Hs) :-
    clean_comma(Xn, CXn), clean_comma(Ai, CAi),
    reg_name_to_int(CXn, XnI), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'GetValue ~w ~w', [XnI, AiI]).
wam_instr_to_haskell(["put_constant", C, Ai], Hs) :-
    clean_comma(C, CC), clean_comma(Ai, CAi),
    wam_value_to_haskell(CC, HsVal),
    reg_name_to_int(CAi, AiI),
    format(string(Hs), 'PutConstant (~w) ~w', [HsVal, AiI]).
wam_instr_to_haskell(["put_variable", Xn, Ai], Hs) :-
    clean_comma(Xn, CXn), clean_comma(Ai, CAi),
    reg_name_to_int(CXn, XnI), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'PutVariable ~w ~w', [XnI, AiI]).
wam_instr_to_haskell(["put_value", Xn, Ai], Hs) :-
    clean_comma(Xn, CXn), clean_comma(Ai, CAi),
    reg_name_to_int(CXn, XnI), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'PutValue ~w ~w', [XnI, AiI]).
wam_instr_to_haskell(["put_structure", FN, Ai], Hs) :-
    clean_comma(FN, CFN), clean_comma(Ai, CAi),
    parse_functor_arity(CFN, Arity),
    reg_name_to_int(CAi, AiI),
    intern_struct_functor(CFN, FnId),
    format(string(Hs), 'PutStructure ~w ~w ~w', [FnId, AiI, Arity]).
wam_instr_to_haskell(["put_structure_dyn", NameReg, ArityReg, TargetReg], Hs) :-
    clean_comma(NameReg, CN), clean_comma(ArityReg, CA), clean_comma(TargetReg, CT),
    reg_name_to_int(CN, NI), reg_name_to_int(CA, AI), reg_name_to_int(CT, TI),
    format(string(Hs), 'PutStructureDyn ~w ~w ~w', [NI, AI, TI]).
wam_instr_to_haskell(["arg", N, TReg, AReg], Hs) :-
    clean_comma(N, CN), clean_comma(TReg, CT), clean_comma(AReg, CA),
    number_string(NI, CN),
    reg_name_to_int(CT, TI), reg_name_to_int(CA, AI),
    format(string(Hs), 'Arg ~w ~w ~w', [NI, TI, AI]).
wam_instr_to_haskell(["not_member_list", XReg, LReg], Hs) :-
    clean_comma(XReg, CX), clean_comma(LReg, CL),
    reg_name_to_int(CX, XI), reg_name_to_int(CL, LI),
    format(string(Hs), 'NotMemberList ~w ~w', [XI, LI]).
%% Variable-arity: not_member_const_atoms XReg Atom1 Atom2 ... AtomN
wam_instr_to_haskell(["not_member_const_atoms", XReg | AtomTokens], Hs) :-
    AtomTokens \= [],
    clean_comma(XReg, CX), reg_name_to_int(CX, XI),
    maplist([T, Id]>>(
        clean_comma(T, CT),
        intern_atom(CT, Id)
    ), AtomTokens, Ids),
    atomic_list_concat(Ids, ',', IdsAtom),
    format(string(Hs), 'NotMemberConstAtoms ~w [~w]', [XI, IdsAtom]).
wam_instr_to_haskell(["build_empty_set", Reg], Hs) :-
    clean_comma(Reg, CR), reg_name_to_int(CR, RI),
    format(string(Hs), 'BuildEmptySet ~w', [RI]).
wam_instr_to_haskell(["set_insert", EReg, InReg, OutReg], Hs) :-
    clean_comma(EReg, CE), clean_comma(InReg, CI), clean_comma(OutReg, CO),
    reg_name_to_int(CE, EI), reg_name_to_int(CI, II), reg_name_to_int(CO, OI),
    format(string(Hs), 'SetInsert ~w ~w ~w', [EI, II, OI]).
wam_instr_to_haskell(["not_member_set", EReg, SReg], Hs) :-
    clean_comma(EReg, CE), clean_comma(SReg, CS),
    reg_name_to_int(CE, EI), reg_name_to_int(CS, SI),
    format(string(Hs), 'NotMemberSet ~w ~w', [EI, SI]).
wam_instr_to_haskell(["put_list", Ai], Hs) :-
    clean_comma(Ai, CAi), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'PutList ~w', [AiI]).
wam_instr_to_haskell(["set_value", Xn], Hs) :-
    clean_comma(Xn, CXn), reg_name_to_int(CXn, XnI),
    format(string(Hs), 'SetValue ~w', [XnI]).
wam_instr_to_haskell(["set_constant", C], Hs) :-
    wam_value_to_haskell(C, HsVal),
    format(string(Hs), 'SetConstant (~w)', [HsVal]).
wam_instr_to_haskell(["allocate"], "Allocate").
wam_instr_to_haskell(["deallocate"], "Deallocate").
wam_instr_to_haskell(["call", P, N], Hs) :-
    clean_comma(P, CP), clean_comma(N, CN),
    (   number_string(Num, CN) -> true ; Num = 0 ),
    format(string(Hs), 'Call "~w" ~w', [CP, Num]).
wam_instr_to_haskell(["execute", P], Hs) :-
    format(string(Hs), 'Execute "~w"', [P]).
wam_instr_to_haskell(["proceed"], "Proceed").
wam_instr_to_haskell(["jump", Label], Hs) :-
    format(string(Hs), 'Jump "~w"', [Label]).
wam_instr_to_haskell(["cut_ite"], "CutIte").
wam_instr_to_haskell(["get_level", Yn], Hs) :-
    clean_comma(Yn, CYn), reg_name_to_int(CYn, YnI),
    format(string(Hs), 'GetLevel ~w', [YnI]).
wam_instr_to_haskell(["cut", Yn], Hs) :-
    clean_comma(Yn, CYn), reg_name_to_int(CYn, YnI),
    format(string(Hs), 'Cut ~w', [YnI]).
wam_instr_to_haskell(["builtin_call", Op, N], Hs) :-
    clean_comma(Op, COp), clean_comma(N, CN),
    (   number_string(Num, CN) -> true ; Num = 0 ),
    escape_haskell_string(COp, ECOp),
    format(string(Hs), 'BuiltinCall "~w" ~w', [ECOp, Num]).
wam_instr_to_haskell(["try_me_else", Label], Hs) :-
    format(string(Hs), 'TryMeElse "~w"', [Label]).
wam_instr_to_haskell(["trust_me"], "TrustMe").
wam_instr_to_haskell(["retry_me_else", Label], Hs) :-
    format(string(Hs), 'RetryMeElse "~w"', [Label]).
wam_instr_to_haskell(["set_variable", Xn], Hs) :-
    clean_comma(Xn, CXn), reg_name_to_int(CXn, XnI),
    format(string(Hs), 'SetVariable ~w', [XnI]).
%% switch_on_constant key1:label1, key2:label2, ...
wam_instr_to_haskell(["switch_on_constant"|Entries], Hs) :-
    parse_switch_entries(Entries, HsPairs),
    atomic_list_concat(HsPairs, ', ', PairsStr),
    format(string(Hs), 'SwitchOnConstant (Map.fromList [~w])', [PairsStr]).
wam_instr_to_haskell(["switch_on_constant_a2"|Entries], Hs) :-
    parse_switch_entries(Entries, HsPairs),
    atomic_list_concat(HsPairs, ', ', PairsStr),
    format(string(Hs), 'SwitchOnConstant (Map.fromList [~w])', [PairsStr]).
% First-argument-indexing variants that previously fell through to the
% catch-all and emitted `Proceed` — which returns from the predicate
% immediately, so first-arg-indexed predicates (e.g. member/2, which emits
% switch_on_term_a2) succeeded unconditionally. Indexing is an optimization:
% each switch is followed by the try_me_else/retry/trust chain, which alone
% yields correct results, and SwitchOnConstantPc already falls through to
% that chain on a miss.
%   - The constant fallthrough variants are shape-compatible with
%     switch_on_constant (the `default` label is dropped at resolve, leaving
%     the table to fall through), so translate them the same way.
wam_instr_to_haskell(["switch_on_constant_fallthrough"|Entries], Hs) :-
    parse_switch_entries(Entries, HsPairs),
    atomic_list_concat(HsPairs, ', ', PairsStr),
    format(string(Hs), 'SwitchOnConstant (Map.fromList [~w])', [PairsStr]).
wam_instr_to_haskell(["switch_on_constant_a2_fallthrough"|Entries], Hs) :-
    parse_switch_entries(Entries, HsPairs),
    atomic_list_concat(HsPairs, ', ', PairsStr),
    format(string(Hs), 'SwitchOnConstant (Map.fromList [~w])', [PairsStr]).
%   - The type/structure indexing variants (switch_on_term[_a2],
%     switch_on_structure[_a2]) carry non-constant entries and index on A2,
%     so translating them to an A1 SwitchOnConstant could mis-route. Emit an
%     EMPTY SwitchOnConstant, which always falls through to the try_me_else
%     chain — correct, just unindexed.
wam_instr_to_haskell(["switch_on_term"|_], 'SwitchOnConstant (Map.fromList [])').
wam_instr_to_haskell(["switch_on_term_a2"|_], 'SwitchOnConstant (Map.fromList [])').
wam_instr_to_haskell(["switch_on_structure"|_], 'SwitchOnConstant (Map.fromList [])').
wam_instr_to_haskell(["switch_on_structure_a2"|_], 'SwitchOnConstant (Map.fromList [])').
wam_instr_to_haskell(["begin_aggregate", Type, ValReg, ResReg], Hs) :-
    clean_comma(Type, CT), clean_comma(ValReg, CV), clean_comma(ResReg, CR),
    reg_name_to_int(CV, VI), reg_name_to_int(CR, RI),
    format(string(Hs), 'BeginAggregate "~w" ~w ~w', [CT, VI, RI]).
wam_instr_to_haskell(["end_aggregate", ValReg], Hs) :-
    clean_comma(ValReg, CV),
    reg_name_to_int(CV, VI),
    format(string(Hs), 'EndAggregate ~w', [VI]).
wam_instr_to_haskell(["get_structure", FN, Ai], Hs) :-
    clean_comma(FN, CFN), clean_comma(Ai, CAi),
    parse_functor_arity(CFN, Arity),
    reg_name_to_int(CAi, AiI),
    intern_struct_functor(CFN, FnId),
    format(string(Hs), 'GetStructure ~w ~w ~w', [FnId, AiI, Arity]).
wam_instr_to_haskell(["get_list", Ai], Hs) :-
    clean_comma(Ai, CAi), reg_name_to_int(CAi, AiI),
    format(string(Hs), 'GetList ~w', [AiI]).
wam_instr_to_haskell(["get_nil", Ai], Hs) :-
    clean_comma(Ai, CAi), reg_name_to_int(CAi, AiI),
    intern_atom("[]", NilId),
    format(string(Hs), 'GetConstant (Atom ~w) ~w', [NilId, AiI]).
wam_instr_to_haskell(["get_integer", N, Ai], Hs) :-
    clean_comma(N, CN), clean_comma(Ai, CAi),
    (number_string(NI, CN) -> true ; NI = 0),
    reg_name_to_int(CAi, AiI),
    format(string(Hs), 'GetConstant (Integer ~w) ~w', [NI, AiI]).
wam_instr_to_haskell(["unify_variable", Xn], Hs) :-
    clean_comma(Xn, CXn), reg_name_to_int(CXn, XnI),
    format(string(Hs), 'UnifyVariable ~w', [XnI]).
wam_instr_to_haskell(["unify_value", Xn], Hs) :-
    clean_comma(Xn, CXn), reg_name_to_int(CXn, XnI),
    format(string(Hs), 'UnifyValue ~w', [XnI]).
wam_instr_to_haskell(["unify_constant", C], Hs) :-
    wam_value_to_haskell(C, HsVal),
    format(string(Hs), 'UnifyConstant (~w)', [HsVal]).
% Fallback for unknown instructions
wam_instr_to_haskell(Parts, Hs) :-
    atomic_list_concat(Parts, ' ', Joined),
    format(string(Hs), '-- UNKNOWN: ~w\n    Proceed', [Joined]).

%% parse_functor_arity(+FunctorString, -Arity)
%  Extract the arity from "name/N" format. Defaults to 0 if no slash.
parse_functor_arity(FN, Arity) :-
    atom_string(FNA, FN),
    (   sub_atom(FNA, Before, 1, _, '/'),
        After is Before + 1,
        sub_atom(FNA, After, _, 0, ArityStr),
        atom_number(ArityStr, Arity)
    ->  true
    ;   Arity = 0
    ).

%% wam_value_to_haskell(+WamVal, -HaskellExpr)
%  Converts a WAM constant to a Haskell Value constructor.
%
%  Atom-vs-number disambiguation goes through
%  wam_text_parser:wam_classify_constant_token/2: a bare token `5`
%  is the integer 5, a quoted token `'5'` is the atom whose name
%  is "5". Without the classifier, intern_atom would intern the
%  atom with the outer quotes attached.
wam_value_to_haskell(Val, Hs) :-
    atom_string(Val, ValStr),
    wam_classify_constant_token(ValStr, Class),
    (   Class = integer(N)
    ->  % Wrap negative integers in parens so Haskell parses correctly:
        % Integer (-5) not Integer -5
        (   N < 0
        ->  format(string(Hs), 'Integer (~w)', [N])
        ;   format(string(Hs), 'Integer ~w', [N])
        )
    ;   Class = float(F)
    ->  (   F < 0
        ->  format(string(Hs), 'Float (~w)', [F])
        ;   format(string(Hs), 'Float ~w', [F])
        )
    ;   Class = atom(Name),
        intern_atom(Name, AtomId),
        format(string(Hs), 'Atom ~w', [AtomId])
    ).

%% clean_comma(+Str, -Clean) — strip trailing comma
clean_comma(Str, Clean) :-
    (   sub_string(Str, _, 1, 0, ",")
    ->  sub_string(Str, 0, _, 1, Clean)
    ;   Clean = Str
    ).

%% parse_switch_entries(+Entries, -HaskellPairs)
%  Parse "key:label" pairs from switch_on_constant instruction.
parse_switch_entries([], []).
parse_switch_entries([Entry|Rest], [HsPair|HsRest]) :-
    clean_comma(Entry, CEntry),
    (   sub_atom(CEntry, Before, 1, _, ':')
    ->  sub_atom(CEntry, 0, Before, _, Key),
        After is Before + 1,
        sub_atom(CEntry, After, _, 0, Label),
        wam_value_to_haskell(Key, HsKey),
        format(string(HsPair), '(~w, "~w")', [HsKey, Label])
    ;   intern_atom(CEntry, DefId),
        format(string(HsPair), '(Atom ~w, "default")', [DefId])
    ),
    parse_switch_entries(Rest, HsRest).

%% escape_haskell_string(+In, -Out) — escape backslashes for Haskell string literals
escape_haskell_string(In, Out) :-
    atom_string(In, S),
    split_string(S, "\\", "", Parts),
    atomic_list_concat(Parts, "\\\\", Out).

% ============================================================================
% ISO error tables: default-to-iso and default-to-lax rewrites.
% These must match the BuiltinCall step arms above. See
% docs/design/WAM_ISO_ERRORS_CROSS_TARGET_STATUS.md.
% ============================================================================

iso_errors:iso_errors_default_to_iso("is/2", "is_iso/2").
iso_errors:iso_errors_default_to_iso(">/2", ">_iso/2").
iso_errors:iso_errors_default_to_iso("</2", "<_iso/2").
iso_errors:iso_errors_default_to_iso(">=/2", ">=_iso/2").
iso_errors:iso_errors_default_to_iso("=</2", "=<_iso/2").
iso_errors:iso_errors_default_to_iso("=:=/2", "=:=_iso/2").
iso_errors:iso_errors_default_to_iso("=\\=/2", "=\\=_iso/2").
iso_errors:iso_errors_default_to_iso("succ/2", "succ_iso/2").

iso_errors:iso_errors_default_to_lax("is/2", "is_lax/2").
iso_errors:iso_errors_default_to_lax(">/2", ">_lax/2").
iso_errors:iso_errors_default_to_lax("</2", "<_lax/2").
iso_errors:iso_errors_default_to_lax(">=/2", ">=_lax/2").
iso_errors:iso_errors_default_to_lax("=</2", "=<_lax/2").
iso_errors:iso_errors_default_to_lax("=:=/2", "=:=_lax/2").
iso_errors:iso_errors_default_to_lax("=\\=/2", "=\\=_lax/2").
iso_errors:iso_errors_default_to_lax("succ/2", "succ_lax/2").

%% iso_errors_rewrite_text(+Config, +PI, +WamText, -RewrittenText)
%  Text-level ISO rewrite routed through the shared items pipeline.
%  Mirrors the Elixir / F# / Python migration: each line is tokenized
%  with the shared quote-aware tokenizer, recognised to a structured
%  item, rewritten by the shared iso_errors_rewrite_item/3, and the
%  swapped key is spliced back into the original line (whitespace
%  preserved byte-for-byte).
%
%  iso_errors_mode_for/3 may yield the atom `default` (the third-valued
%  config default the Haskell target supports) in addition to
%  true/false; only true/false drive a rewrite, anything else passes
%  the text through unchanged.
%
%  Previously this target only rewrote `builtin_call` keys. The shared
%  iso_errors_rewrite_item/3 also covers put_structure / call / execute,
%  but the only keys in the ISO/lax tables are arithmetic builtins
%  (is/2, the six comparisons, succ/2) which the WAM compiler always
%  emits as builtin_call — so the broader coverage is a harmless
%  superset that keeps Haskell consistent with the other targets.
iso_errors_rewrite_text(Config, PI, WamText, RewrittenText) :-
    iso_errors_mode_for(Config, PI, Mode),
    (   ( Mode == true ; Mode == false )
    ->  atom_string(WamText, WamStr),
        split_string(WamStr, "\n", "", Lines),
        maplist(iso_errors_rewrite_line(Mode), Lines, NewLines),
        atomic_list_concat(NewLines, "\n", RewrittenText)
    ;   RewrittenText = WamText
    ).

% Rewrite one line via the shared items pipeline. Any failure along the
% chain (unrecognised line, key not in the ISO/lax tables, splice miss)
% falls through to OutLine = Line. All four rewritable shapes carry the
% key as their first argument, so arg(1, ...) extracts old/new keys
% generically.
iso_errors_rewrite_line(Mode, Line, OutLine) :-
    (   wam_tokenize_line(Line, Tokens),
        wam_recognise_instruction(Tokens, Item0),
        iso_errors_rewrite_item(Mode, Item0, Item1),
        Item0 \== Item1,
        arg(1, Item0, OldKey),
        arg(1, Item1, NewKey),
        iso_errors_splice_line(Line, OldKey, NewKey, OutLine)
    ->  true
    ;   OutLine = Line
    ).

% Replace the first occurrence of Key in Line with NewKey, preserving
% surrounding whitespace. Same helper the other targets use.
iso_errors_splice_line(Line, Key, NewKey, OutLine) :-
    sub_string(Line, Before, KLen, _After, Key),
    string_length(Key, KLen),
    sub_string(Line, 0, Before, _, Pre),
    PostStart is Before + KLen,
    sub_string(Line, PostStart, _, 0, Post),
    string_concat(Pre, NewKey, T1),
    string_concat(T1, Post, OutLine),
    !.

%% write_hs_file(+Path, +Content)
write_hs_file(Path, Content) :-
    % The generated module embeds UTF-8 characters from runtime
    % templates (arrows, dashes in comments), so the stream must be
    % UTF-8 regardless of the process locale (POSIX/ASCII in many CI
    % containers) -- otherwise format/3 raises an encoding error.
    setup_call_cleanup(
        open(Path, write, Stream, [encoding(utf8)]),
        format(Stream, "~w", [Content]),
        close(Stream)
    ).
