:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2026 John William Creighton (@s243a)
%
% wam_lua_target.pl - WAM-to-Lua Hybrid Transpilation Target
%
% Generates a Lua project with an instruction-array WAM interpreter plus
% optional lowered per-predicate Lua functions. The architecture mirrors
% the R/Scala/Haskell hybrid WAM targets while using Lua tables for both
% terms and instructions.

:- module(wam_lua_target, [
    compile_wam_predicate_to_lua/4,
    write_wam_lua_project/3,
    lua_foreign_predicate/3,
    init_lua_atom_intern_table/0,
    tokenize_wam_line/2,
    wam_parts_to_lua/3,
    parse_functor_arity/3,
    reg_to_int/2,
    constant_to_lua_term/2,
    intern_lua_atom/2,
    lua_string_literal/2,
    wam_lua_resolve_emit_mode/2
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module(library(filesex), [make_directory_path/1, directory_file_path/3]).
:- use_module('../targets/wam_target', [
    compile_predicate_to_wam_text/3,
    compile_predicate_to_wam_items/3
]).
:- use_module('../core/template_system', [render_template/3]).
:- use_module(wam_ir_mode, [wam_ir_mode/4]).
:- use_module(wam_text_parser, [
    wam_tokenize_line/2,
    wam_recognise_label/2,
    wam_recognise_instruction/2,
    wam_classify_constant_token/2
]).
:- use_module(wam_lua_lowered_emitter, [
    wam_lua_lowerable/3,
    lower_predicate_to_lua/4
]).
:- use_module(wam_runtime_parser_capability, [
    parser_dependent_body_goal/2,
    wam_target_runtime_parser/3
]).

:- multifile user:wam_lua_emit_mode/1.

wam_lua_resolve_emit_mode(Options, Mode) :-
    (   option(emit_mode(M0), Options)
    ->  validate_emit_mode(M0, Mode)
    ;   catch(user:wam_lua_emit_mode(M1), _, fail)
    ->  validate_emit_mode(M1, Mode)
    ;   Mode = interpreter
    ).

validate_emit_mode(interpreter, interpreter) :- !.
validate_emit_mode(functions, functions) :- !.
validate_emit_mode(mixed(L), mixed(L)) :- is_list(L), !.
validate_emit_mode(Other, _) :-
    throw(error(domain_error(wam_lua_emit_mode, Other),
                wam_lua_resolve_emit_mode/2)).

wam_lua_emit_ir_mode(Options, EmitMode, IrMode) :-
    wam_ir_mode(wam_lua, EmitMode, Options, IrMode),
    (   IrMode == direct_target
    ->  throw(error(domain_error(wam_lua_ir_mode, direct_target),
                    wam_lua_emit_ir_mode/3))
    ;   IrMode == wam_items_native
    ->  throw(error(existence_error(wam_ir_mode, wam_items_native),
                    wam_lua_emit_ir_mode/3))
    ;   true
    ).

should_try_lower(functions, _, _) :- !.
should_try_lower(mixed(HotPreds), P, A) :-
    member(P/A, HotPreds), !.
should_try_lower(_, _, _) :- fail.

% ============================================================================
% Atom interning
% ============================================================================

:- dynamic lua_atom_intern_id/2.
:- dynamic lua_atom_intern_next/1.

init_lua_atom_intern_table :-
    retractall(lua_atom_intern_id(_, _)),
    retractall(lua_atom_intern_next(_)),
    assertz(lua_atom_intern_id("true", 0)),
    assertz(lua_atom_intern_id("fail", 1)),
    assertz(lua_atom_intern_id("[]", 2)),
    assertz(lua_atom_intern_id(".", 3)),
    assertz(lua_atom_intern_id("", 4)),
    assertz(lua_atom_intern_id("[|]", 5)),
    assertz(lua_atom_intern_next(6)).

intern_lua_atom(AtomStr, Id) :-
    (   lua_atom_intern_next(_)
    ->  true
    ;   init_lua_atom_intern_table
    ),
    text_to_string(AtomStr, Str),
    (   lua_atom_intern_id(Str, Id0)
    ->  Id = Id0
    ;   retract(lua_atom_intern_next(Next)),
        Id = Next,
        Next1 is Next + 1,
        assertz(lua_atom_intern_id(Str, Id)),
        assertz(lua_atom_intern_next(Next1))
    ).

emit_lua_intern_table(Code) :-
    findall(Id-Str, lua_atom_intern_id(Str, Id), Pairs),
    sort(Pairs, Sorted),
    maplist([_Id-Str, E]>>(
        lua_string_literal(Str, Lit),
        format(string(E), '  ~w', [Lit])
    ), Sorted, Entries),
    atomic_list_concat(Entries, ',\n', Code).

% ============================================================================
% WAM tokens and literals
% ============================================================================

reg_to_int(Reg, Int) :-
    atom_string(RegA, Reg),
    sub_atom(RegA, 0, 1, _, Prefix),
    sub_atom(RegA, 1, _, 0, NumA),
    atom_number(NumA, Num),
    (   Prefix == 'A' -> Int = Num
    ;   Prefix == 'X' -> Int is Num + 100
    ;   Prefix == 'Y' -> Int is Num + 200
    ;   Int = 0
    ).

% Compatibility wrapper retained for the lowered emitter. The actual
% tokenization rules live in wam_text_parser so Lua stays aligned with
% C++ and future WAM-target migrations.
tokenize_wam_line(Line, Tokens) :-
    wam_tokenize_line(Line, Tokens).

strip_operand_comma(Token0, Token) :-
    sub_string(Token0, _, 1, 0, ","), !,
    sub_string(Token0, 0, _, 1, Token).
strip_operand_comma(Token, Token).

wam_parts_to_lua(["call", PredArity], Options, Lit) :-
    parse_functor_arity(PredArity, PredName, Arity),
    lua_foreign_predicate(PredName, Arity, Options), !,
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.CallForeign(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["call", Pred, ArityStr], Options, Lit) :-
    number_string(Arity, ArityStr),
    strip_arity_suffix(Pred, PredName),
    lua_foreign_predicate(PredName, Arity, Options), !,
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.CallForeign(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["execute", PredArity], Options, Lit) :-
    parse_functor_arity(PredArity, PredName, Arity),
    lua_foreign_predicate(PredName, Arity, Options), !,
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.ExecuteForeign(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["execute", Pred, ArityStr], Options, Lit) :-
    number_string(Arity, ArityStr),
    strip_arity_suffix(Pred, PredName),
    lua_foreign_predicate(PredName, Arity, Options), !,
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.ExecuteForeign(~w, ~w)', [P, Arity]).
wam_parts_to_lua(Parts, _Options, Lit) :-
    wam_parts_to_lua(Parts, Lit).

wam_parts_to_lua(["call", PredArity], Lit) :-
    parse_functor_arity(PredArity, PredName, Arity),
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.Call(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["call", Pred, ArityStr], Lit) :-
    number_string(Arity, ArityStr),
    strip_arity_suffix(Pred, PredName),
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.Call(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["execute", PredArity], Lit) :-
    parse_functor_arity(PredArity, PredName, Arity),
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.Execute(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["execute", Pred, ArityStr], Lit) :-
    number_string(Arity, ArityStr),
    strip_arity_suffix(Pred, PredName),
    lua_string_literal(PredName, P),
    format(string(Lit), 'I.Execute(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["proceed"], 'I.Proceed()').
wam_parts_to_lua(["fail"], 'I.Fail()').
wam_parts_to_lua(["jump", Label], Lit) :-
    lua_string_literal(Label, L),
    format(string(Lit), 'I.Jump(~w)', [L]).
wam_parts_to_lua(["try_me_else", Label], Lit) :-
    lua_string_literal(Label, L),
    format(string(Lit), 'I.TryMeElse(~w)', [L]).
wam_parts_to_lua(["retry_me_else", Label], Lit) :-
    lua_string_literal(Label, L),
    format(string(Lit), 'I.RetryMeElse(~w)', [L]).
wam_parts_to_lua(["trust_me"], 'I.TrustMe()').
wam_parts_to_lua(["allocate"], 'I.Allocate()').
wam_parts_to_lua(["deallocate"], 'I.Deallocate()').
wam_parts_to_lua(["get_constant", C, Reg], Lit) :-
    reg_to_int(Reg, R), constant_to_lua_term(C, T),
    format(string(Lit), 'I.GetConstant(~w, ~w)', [T, R]).
wam_parts_to_lua(["get_variable", X, A], Lit) :-
    reg_to_int(X, XI), reg_to_int(A, AI),
    format(string(Lit), 'I.GetVariable(~w, ~w)', [XI, AI]).
wam_parts_to_lua(["get_value", X, A], Lit) :-
    reg_to_int(X, XI), reg_to_int(A, AI),
    format(string(Lit), 'I.GetValue(~w, ~w)', [XI, AI]).
wam_parts_to_lua(["put_constant", C, Reg], Lit) :-
    reg_to_int(Reg, R), constant_to_lua_term(C, T),
    format(string(Lit), 'I.PutConstant(~w, ~w)', [T, R]).
wam_parts_to_lua(["put_variable", X, A], Lit) :-
    reg_to_int(X, XI), reg_to_int(A, AI),
    format(string(Lit), 'I.PutVariable(~w, ~w)', [XI, AI]).
wam_parts_to_lua(["put_value", X, A], Lit) :-
    reg_to_int(X, XI), reg_to_int(A, AI),
    format(string(Lit), 'I.PutValue(~w, ~w)', [XI, AI]).
wam_parts_to_lua(["put_structure", F, Reg], Lit) :-
    reg_to_int(Reg, R), parse_functor_arity(F, Name, Arity),
    intern_lua_atom(Name, Id),
    format(string(Lit), 'I.PutStructure(~w, ~w, ~w)', [Id, R, Arity]).
wam_parts_to_lua(["get_structure", F, Reg], Lit) :-
    reg_to_int(Reg, R), parse_functor_arity(F, Name, Arity),
    intern_lua_atom(Name, Id),
    format(string(Lit), 'I.GetStructure(~w, ~w, ~w)', [Id, R, Arity]).
wam_parts_to_lua(["put_list", Reg], Lit) :-
    reg_to_int(Reg, R), intern_lua_atom("[|]", Id),
    format(string(Lit), 'I.PutList(~w, ~w)', [R, Id]).
wam_parts_to_lua(["get_list", Reg], Lit) :-
    reg_to_int(Reg, R), intern_lua_atom("[|]", Id),
    format(string(Lit), 'I.GetList(~w, ~w)', [R, Id]).
wam_parts_to_lua(["set_variable", X], Lit) :-
    reg_to_int(X, XI), format(string(Lit), 'I.SetVariable(~w)', [XI]).
wam_parts_to_lua(["set_value", X], Lit) :-
    reg_to_int(X, XI), format(string(Lit), 'I.SetValue(~w)', [XI]).
wam_parts_to_lua(["set_constant", C], Lit) :-
    constant_to_lua_term(C, T), format(string(Lit), 'I.SetConstant(~w)', [T]).
wam_parts_to_lua(["unify_variable", X], Lit) :-
    reg_to_int(X, XI), format(string(Lit), 'I.UnifyVariable(~w)', [XI]).
wam_parts_to_lua(["unify_value", X], Lit) :-
    reg_to_int(X, XI), format(string(Lit), 'I.UnifyValue(~w)', [XI]).
wam_parts_to_lua(["unify_constant", C], Lit) :-
    constant_to_lua_term(C, T), format(string(Lit), 'I.UnifyConstant(~w)', [T]).
wam_parts_to_lua(["builtin_call", Pred, ArityStr], Lit) :-
    number_string(Arity, ArityStr), lua_string_literal(Pred, P),
    format(string(Lit), 'I.BuiltinCall(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["call_foreign", Pred, ArityStr], Lit) :-
    number_string(Arity, ArityStr), lua_string_literal(Pred, P),
    format(string(Lit), 'I.CallForeign(~w, ~w)', [P, Arity]).
wam_parts_to_lua(["call_indexed_atom_fact2", Pred], Lit) :-
    strip_operand_comma(Pred, CleanPred),
    lua_string_literal(CleanPred, P),
    format(string(Lit), 'I.CallIndexedAtomFact2(~w)', [P]).
wam_parts_to_lua(["arg", NStr, RegStr, OutRegStr], Lit) :-
    number_string(N, NStr), reg_to_int(RegStr, R), reg_to_int(OutRegStr, O),
    format(string(Lit), 'I.ArgInstr(~w, ~w, ~w)', [N, R, O]).
wam_parts_to_lua(["switch_on_constant" | Cases], Lit) :-
    normalize_switch_case_tokens(Cases, Norm),
    parse_switch_cases(Norm, CaseLits),
    atomic_list_concat(CaseLits, ', ', CasesStr),
    format(string(Lit), 'I.SwitchOnConstant({~w})', [CasesStr]).
wam_parts_to_lua(["switch_on_constant_a2" | Cases], Lit) :-
    normalize_switch_case_tokens(Cases, Norm),
    parse_switch_cases(Norm, CaseLits),
    atomic_list_concat(CaseLits, ', ', CasesStr),
    format(string(Lit), 'I.SwitchOnConstantA2({~w})', [CasesStr]).
wam_parts_to_lua(["switch_on_structure" | Cases], Lit) :-
    normalize_switch_case_tokens(Cases, Norm),
    parse_struct_switch_cases(Norm, CaseLits),
    atomic_list_concat(CaseLits, ', ', CasesStr),
    format(string(Lit), 'I.SwitchOnStructure({~w})', [CasesStr]).
wam_parts_to_lua(["cut_ite"], 'I.CutIte()').
wam_parts_to_lua(["get_level", Yn], Lit) :-
    reg_to_int(Yn, R),
    format(string(Lit), 'I.GetLevel(~w)', [R]).
wam_parts_to_lua(["cut", Yn], Lit) :-
    reg_to_int(Yn, R),
    format(string(Lit), 'I.Cut(~w)', [R]).
wam_parts_to_lua(["begin_aggregate", Kind, TemplateReg, BagReg], Lit) :-
    reg_to_int(TemplateReg, TIdx),
    reg_to_int(BagReg, BIdx),
    lua_string_literal(Kind, K),
    format(string(Lit), 'I.BeginAggregate(~w, ~w, ~w)', [K, TIdx, BIdx]).
wam_parts_to_lua(["end_aggregate", TemplateReg], Lit) :-
    reg_to_int(TemplateReg, TIdx),
    format(string(Lit), 'I.EndAggregate(~w)', [TIdx]).
wam_parts_to_lua(Parts, Lit) :-
    atomic_list_concat(Parts, ' ', Text),
    lua_string_literal(Text, Q),
    format(string(Lit), 'I.Raw(~w)', [Q]).

parse_switch_cases([], []).
parse_switch_cases([Token|Rest], [Lit|More]) :-
    split_at_first_colon(Token, ValStr, LabelStr),
    intern_lua_atom(ValStr, AtomId),
    lua_string_literal(LabelStr, L),
    format(string(Lit), '{value = V.Atom(~w), label = ~w}', [AtomId, L]),
    parse_switch_cases(Rest, More).

parse_struct_switch_cases([], []).
parse_struct_switch_cases([Token|Rest], [Lit|More]) :-
    split_at_first_colon(Token, FAStr, LabelStr),
    parse_functor_arity(FAStr, FName, FArity),
    intern_lua_atom(FName, FId),
    lua_string_literal(LabelStr, L),
    format(string(Lit), '{fid = ~w, arity = ~w, label = ~w}', [FId, FArity, L]),
    parse_struct_switch_cases(Rest, More).

normalize_switch_case_tokens([], []).
normalize_switch_case_tokens([Value, Label0|Rest], [Token|More]) :-
    \+ sub_string(Value, _, 1, _, ":"),
    sub_string(Label0, 0, 1, _, ":"), !,
    sub_string(Label0, 1, _, 0, Label),
    string_concat(Value, ":", Prefix),
    string_concat(Prefix, Label, Token),
    normalize_switch_case_tokens(Rest, More).
normalize_switch_case_tokens([Token|Rest], [Token|More]) :-
    normalize_switch_case_tokens(Rest, More).

constant_to_lua_term(C, Lit) :-
    wam_classify_constant_token(C, Class),
    (   Class = integer(N)
    ->  format(string(Lit), 'V.Int(~w)', [N])
    ;   Class = float(F)
    ->  format(string(Lit), 'V.Float(~w)', [F])
    ;   Class = atom(Name),
        intern_lua_atom(Name, Id),
        format(string(Lit), 'V.Atom(~w)', [Id])
    ).

parse_functor_arity(FStr, Name, Arity) :-
    atom_string(FA, FStr),
    (   last_slash_index(FA, B)
    ->  sub_atom(FA, 0, B, _, Name),
        B1 is B + 1,
        sub_atom(FA, B1, _, 0, AS),
        atom_number(AS, Arity)
    ;   Name = FA, Arity = 0
    ).

last_slash_index(Atom, Index) :-
    findall(B, sub_atom(Atom, B, 1, _, '/'), Bs),
    Bs \= [],
    last(Bs, Index).

split_at_first_colon(Token, Before, After) :-
    sub_string(Token, B, 1, _, ":"), !,
    sub_string(Token, 0, B, _, Before),
    B1 is B + 1,
    sub_string(Token, B1, _, 0, After).

strip_arity_suffix(Pred, Name) :-
    (sub_string(Pred, B, 1, _, "/") -> sub_string(Pred, 0, B, _, Name) ; Name = Pred).

lua_string_literal(Raw, Quoted) :-
    text_to_string(Raw, S),
    string_chars(S, Chars),
    maplist(lua_string_escape_char, Chars, EscapedLists),
    append(EscapedLists, EscChars),
    string_chars(EscBody, EscChars),
    format(string(Quoted), '"~w"', [EscBody]).

lua_string_escape_char('\\', ['\\', '\\']) :- !.
lua_string_escape_char('"', ['\\', '"']) :- !.
lua_string_escape_char('\n', ['\\', 'n']) :- !.
lua_string_escape_char('\t', ['\\', 't']) :- !.
lua_string_escape_char(C, [C]).

text_to_string(Value, Str) :-
    (   string(Value)
    ->  Str = Value
    ;   atom(Value)
    ->  atom_string(Value, Str)
    ;   term_string(Value, Str)
    ).

% ============================================================================
% Program assembly
% ============================================================================

wam_code_to_lua_data(WamCode, Options, Instructions, LabelEntries) :-
    wam_code_to_lua_items(WamCode, Items),
    wam_items_to_data(Items, Options, 1, Instructions, LabelEntries).

wam_code_to_lua_items(WamCode, Items) :-
    is_list(WamCode), !,
    Items = WamCode.
wam_code_to_lua_items(WamCode, Items) :-
    lua_wam_text_to_items(WamCode, Items).

% C++ is the reference here: accept in-memory items when callers have
% them, otherwise parse legacy WAM text through the shared recognisers.
% Lua keeps only its extension recognisers for instructions that are not
% part of the standard WAM item catalogue.
lua_wam_text_to_items(WamText, Items) :-
    atom_string(WamText, S),
    split_string(S, "\n", "", Lines),
    lua_wam_lines_to_items(Lines, Items).

lua_wam_lines_to_items([], []).
lua_wam_lines_to_items([Line|Rest], Items) :-
    tokenize_wam_line(Line, Tokens),
    (   Tokens == []
    ->  lua_wam_lines_to_items(Rest, Items)
    ;   wam_recognise_label(Tokens, Name)
    ->  Items = [label(Name)|More],
        lua_wam_lines_to_items(Rest, More)
    ;   wam_recognise_instruction(Tokens, Item)
    ->  Items = [Item|More],
        lua_wam_lines_to_items(Rest, More)
    ;   lua_recognise_instruction(Tokens, Item)
    ->  Items = [Item|More],
        lua_wam_lines_to_items(Rest, More)
    ;   lua_wam_lines_to_items(Rest, Items)
    ).

lua_recognise_instruction(["arg", N, Reg, OutReg], arg(N, Reg, OutReg)).
lua_recognise_instruction(["call_indexed_atom_fact2", Pred], call_indexed_atom_fact2(Pred)).

wam_items_to_data([], _, _, [], []).
wam_items_to_data([label(LabelName)|Rest], Options, PC, Instructions, LabelEntries) :- !,
        lua_string_literal(LabelName, L),
        format(string(LEntry), '  [~w] = ~w', [L, PC]),
        LabelEntries = [LEntry|LE2],
        wam_items_to_data(Rest, Options, PC, Instructions, LE2).
wam_items_to_data([Item|Rest], Options, PC, [Lit|I2], LabelEntries) :-
    wam_item_parts(Item, Parts),
    wam_parts_to_lua(Parts, Options, Lit),
    PC1 is PC + 1,
    wam_items_to_data(Rest, Options, PC1, I2, LabelEntries).

compile_wam_predicate_to_lua(_Pred, _WamCode, _Options, "").

compile_predicates_for_project(Predicates, Options,
                               AllInstrs, TopLabels, AllLabels,
                               WrapperCode, LoweredCode, InlineFactsCode, FactSourcesCode) :-
    init_lua_atom_intern_table,
    option(intern_atoms(ExtraAtoms), Options, []),
    forall(member(A, ExtraAtoms), (atom_string(A, S), intern_lua_atom(S, _))),
    option(foreign_predicates(ForeignPredicates), Options, []),
    append_missing_foreign_predicates(Predicates, ForeignPredicates, CompilePreds),
    wam_lua_resolve_emit_mode(Options, EmitMode),
    wam_lua_emit_ir_mode(Options, EmitMode, IrMode),
    compile_all_predicates(CompilePreds, Options, EmitMode, IrMode, 1,
        [], [], [], [], [], [], [],
        AllInstrs, TopLabels, AllLabels, Wrappers, LoweredEntries, InlineFacts, FactSources),
    atomic_list_concat(Wrappers, '\n', WrapperCode),
    atomic_list_concat(LoweredEntries, '\n', LoweredCode),
    atomic_list_concat(InlineFacts, ',\n', InlineFactsCode),
    atomic_list_concat(FactSources, ',\n', FactSourcesCode).

append_missing_foreign_predicates(Predicates, ForeignPredicates, CompilePredicates) :-
    findall(F, (member(F, ForeignPredicates), \+ (member(P, Predicates), same_pi(P, F))), Missing),
    append(Predicates, Missing, CompilePredicates).

same_pi(P0, P1) :- pi_key(P0, K), pi_key(P1, K).
pi_key(_:P/A, P/A) :- !.
pi_key(P/A, P/A).

compile_all_predicates([], _, _, _, _, Instrs, TopLabels, AllLabels, Wrappers, Lowered, InlineFacts, FactSources,
                       Instrs, TopLabels, AllLabels, Wrappers, Lowered, InlineFacts, FactSources).
compile_all_predicates([Pred|Rest], Options, EmitMode, IrMode, BasePC,
                       InstrAcc, TopLabelAcc, AllLabelAcc, WrapperAcc, LoweredAcc, InlineFactAcc, FactSourceAcc,
                       AllInstrs, TopLabels, AllLabels, Wrappers, Lowered, InlineFacts, FactSources) :-
    (Pred = _M:P/Arity -> true ; Pred = P/Arity),
    (   lua_fact_source_spec(P, Arity, Options, SourceSpec)
    ->  format(string(Key), '~w/~w', [P, Arity]),
        lua_string_literal(Key, KeyQ),
        format(string(FLit), 'I.CallFactStream(~w, ~w)', [KeyQ, Arity]),
        PredInstrs = [FLit, 'I.Proceed()'],
        WamCode = "",
        PredSubLabelEntries0 = [],
        InlineFactEntry = none,
        lua_fact_source_entry(Key, SourceSpec, FactSourceEntry)
    ;   lua_foreign_predicate(P, Arity, Options)
    ->  lua_string_literal(P, PQ),
        format(string(FLit), 'I.CallForeign(~w, ~w)', [PQ, Arity]),
        PredInstrs = [FLit, 'I.Proceed()'],
        WamCode = "",
        PredSubLabelEntries0 = [],
        InlineFactEntry = none,
        FactSourceEntry = none
    ;   compile_lua_predicate_wam(P/Arity, IrMode, WamCode),
        (   Arity == 2,
            lua_inline_fact_tuples(WamCode, Tuples),
            Tuples \= []
        ->  format(string(Key), '~w/~w', [P, Arity]),
            lua_string_literal(Key, KeyQ),
            format(string(FLit), 'I.CallFactStream(~w, ~w)', [KeyQ, Arity]),
            PredInstrs = [FLit, 'I.Proceed()'],
            PredSubLabelEntries0 = [],
            lua_inline_fact_entry(Key, Tuples, InlineFactEntry),
            FactSourceEntry = none
        ;   wam_code_to_lua_data(WamCode, Options, PredInstrs, PredSubLabelEntries0),
            InlineFactEntry = none,
            FactSourceEntry = none
        )
    ),
    length(PredInstrs, PredLen),
    append(InstrAcc, PredInstrs, NewInstrs),
    NewPC is BasePC + PredLen,
    Offset is BasePC - 1,
    (   lua_foreign_predicate(P, Arity, Options)
    ->  PredSubLabelEntries = []
    ;   maplist(offset_label_entry(Offset), PredSubLabelEntries0, PredSubLabelEntries1),
        format(string(MainKey), '~w/~w', [P, Arity]),
        exclude(is_pred_label(MainKey), PredSubLabelEntries1, PredSubLabelEntries)
    ),
    format(string(Key), '~w/~w', [P, Arity]),
    lua_string_literal(Key, KeyQ),
    format(string(MainEntry), '  [~w] = ~w', [KeyQ, BasePC]),
    NewTopLabels = [MainEntry|TopLabelAcc],
    append([MainEntry|PredSubLabelEntries], AllLabelAcc, NewAllLabels),
    (   should_try_lower(EmitMode, P, Arity),
        WamCode \= "",
        InlineFactEntry == none,
        catch(wam_lua_lowerable(Pred, WamCode, _), _, fail),
        catch(lower_predicate_to_lua(Pred, WamCode, [],
                                     lowered(_, FuncName, LoweredLua)), _, fail)
    ->  NewLoweredAcc = [LoweredLua|LoweredAcc],
        emit_lua_lowered_wrapper(P, Arity, FuncName, Wrapper)
    ;   NewLoweredAcc = LoweredAcc,
        emit_lua_wrapper(P, Arity, BasePC, Wrapper)
    ),
    (InlineFactEntry == none -> NewInlineFactAcc = InlineFactAcc ; NewInlineFactAcc = [InlineFactEntry|InlineFactAcc]),
    (FactSourceEntry == none -> NewFactSourceAcc = FactSourceAcc ; NewFactSourceAcc = [FactSourceEntry|FactSourceAcc]),
    compile_all_predicates(Rest, Options, EmitMode, IrMode, NewPC,
        NewInstrs, NewTopLabels, NewAllLabels, [Wrapper|WrapperAcc], NewLoweredAcc, NewInlineFactAcc, NewFactSourceAcc,
        AllInstrs, TopLabels, AllLabels, Wrappers, Lowered, InlineFacts, FactSources).

compile_lua_predicate_wam(PredIndicator, wam_text, WamCode) :-
    compile_predicate_to_wam_text(PredIndicator, [ite_use_y_level(true)], WamCode).
compile_lua_predicate_wam(PredIndicator, wam_items_bridge, WamCode) :-
    compile_predicate_to_wam_items(PredIndicator, [ite_use_y_level(true)], WamCode).

lua_fact_source_spec(P, Arity, Options, Spec) :-
    Arity =:= 2,
    option(lua_fact_sources(Sources), Options, []),
    member(source(PI, Spec), Sources),
    fact_source_pi_match(PI, P, Arity).

fact_source_pi_match(_:Name/Ar, P, Arity) :- !,
    Name == P, Ar =:= Arity.
fact_source_pi_match(Name/Ar, P, Arity) :-
    Name == P, Ar =:= Arity.

lua_fact_source_entry(Key, file(Path), Entry) :-
    atom_string(Path, PathStr),
    (   absolute_file_name(PathStr, AbsPath, [access(read), file_errors(fail)])
    ->  SourcePath = AbsPath
    ;   SourcePath = PathStr
    ),
    lua_string_literal(Key, KeyQ),
    lua_string_literal(SourcePath, PathQ),
    format(string(Entry), '  [~w] = { path = ~w }', [KeyQ, PathQ]).

lua_inline_fact_tuples(WamCode, Tuples) :-
    wam_code_to_lua_items(WamCode, Items),
    lua_wam_segments(Items, Segments),
    Segments \= [],
    lua_fact_only_segments(Segments),
    findall(A1-A2, (
        member(Instrs, Segments),
        member(["get_constant", A1, "A1"], Instrs),
        member(["get_constant", A2, "A2"], Instrs)
    ), Tuples).

lua_wam_segments([], []).
lua_wam_segments([label(_)|Rest], Segments) :- !,
    lua_segment_instrs(Rest, Instrs, Remaining),
        Segments = [Instrs|More],
    lua_wam_segments(Remaining, More).
lua_wam_segments([_|Rest], Segments) :-
    lua_wam_segments(Rest, Segments).

lua_segment_instrs([], [], []).
lua_segment_instrs([label(_)|Rest], [], [label(_)|Rest]) :- !.
lua_segment_instrs([Item|Rest], [Parts|More], Remaining) :-
    % once/1: wam_item_parts/2 has a catch-all clause that overlaps every
    % specific clause, so each item yields multiple solutions. Without
    % committing to the first (specific) one, lua_inline_fact_tuples
    % backtracks through every item's choicepoint when a segment turns out
    % not to be fact-only (any predicate containing a builtin_call), which
    % is exponential in the number of segments — a nested if-then-else
    % (5 segments) effectively hangs. The first solution is always the
    % intended one, so the segmentation is unchanged.
    once(wam_item_parts(Item, Parts)),
    lua_segment_instrs(Rest, More, Remaining).

lua_fact_only_segments(Segments) :-
    forall(member(Instrs, Segments),
           forall(member(Parts, Instrs), \+ lua_body_call_instr(Parts))).

lua_body_call_instr(["call"|_]).
lua_body_call_instr(["execute"|_]).
lua_body_call_instr(["builtin_call"|_]).

wam_item_parts(get_constant(C, Ai), ["get_constant", C, Ai]).
wam_item_parts(get_variable(Xn, Ai), ["get_variable", Xn, Ai]).
wam_item_parts(get_value(Xn, Ai), ["get_value", Xn, Ai]).
wam_item_parts(get_structure(F, Ai), ["get_structure", F, Ai]).
wam_item_parts(get_list(Ai), ["get_list", Ai]).
wam_item_parts(get_nil(Ai), ["get_nil", Ai]).
wam_item_parts(get_integer(N, Ai), ["get_integer", N, Ai]).
wam_item_parts(unify_variable(Xn), ["unify_variable", Xn]).
wam_item_parts(unify_value(Xn), ["unify_value", Xn]).
wam_item_parts(unify_constant(C), ["unify_constant", C]).
wam_item_parts(put_variable(Xn, Ai), ["put_variable", Xn, Ai]).
wam_item_parts(put_value(Xn, Ai), ["put_value", Xn, Ai]).
wam_item_parts(put_constant(C, Ai), ["put_constant", C, Ai]).
wam_item_parts(put_structure(F, Ai), ["put_structure", F, Ai]).
wam_item_parts(put_list(Ai), ["put_list", Ai]).
wam_item_parts(set_variable(Xn), ["set_variable", Xn]).
wam_item_parts(set_value(Xn), ["set_value", Xn]).
wam_item_parts(set_constant(C), ["set_constant", C]).
wam_item_parts(call(P, N), ["call", P, N]).
wam_item_parts(execute(P), ["execute", P]).
wam_item_parts(proceed, ["proceed"]).
wam_item_parts(fail, ["fail"]).
wam_item_parts(allocate, ["allocate"]).
wam_item_parts(deallocate, ["deallocate"]).
wam_item_parts(builtin_call(Op, Ar), ["builtin_call", Op, Ar]).
wam_item_parts(call_foreign(Pred, Ar), ["call_foreign", Pred, Ar]).
wam_item_parts(arg(N, Reg, OutReg), ["arg", N, Reg, OutReg]).
wam_item_parts(call_indexed_atom_fact2(Pred), ["call_indexed_atom_fact2", Pred]).
wam_item_parts(try_me_else(L), ["try_me_else", L]).
wam_item_parts(retry_me_else(L), ["retry_me_else", L]).
wam_item_parts(trust_me, ["trust_me"]).
wam_item_parts(jump(L), ["jump", L]).
wam_item_parts(cut_ite, ["cut_ite"]).
wam_item_parts(get_level(Yn), ["get_level", Yn]).
wam_item_parts(cut(Yn), ["cut", Yn]).
wam_item_parts(begin_aggregate(K, V, R), ["begin_aggregate", K, V, R]).
wam_item_parts(end_aggregate(R), ["end_aggregate", R]).
wam_item_parts(switch_on_constant(Es), ["switch_on_constant"|Es]).
wam_item_parts(switch_on_constant_a2(Es), ["switch_on_constant_a2"|Es]).
wam_item_parts(switch_on_structure(Es), ["switch_on_structure"|Es]).
wam_item_parts(Item, Parts) :-
    Item =.. [Name|Args],
    atom_string(Name, NameStr),
    maplist(lua_item_arg_string, Args, ArgStrs),
    Parts = [NameStr|ArgStrs].

lua_item_arg_string(Value, Str) :-
    text_to_string(Value, Str).

lua_inline_fact_entry(Key, Tuples, Entry) :-
    lua_string_literal(Key, KeyQ),
    maplist(lua_inline_fact_tuple_lit, Tuples, TupleLits),
    atomic_list_concat(TupleLits, ', ', TuplesText),
    format(string(Entry), '  [~w] = {~w}', [KeyQ, TuplesText]).

lua_inline_fact_tuple_lit(A1-A2, Lit) :-
    intern_lua_atom(A1, I1),
    intern_lua_atom(A2, I2),
    format(string(Lit), '{V.Atom(~w), V.Atom(~w)}', [I1, I2]).

offset_label_entry(Offset, Entry0, Entry) :-
    atom_string(Entry0, S),
    (   sub_string(S, B, 3, _, "] =")
    ->  B1 is B + 4,
        sub_string(S, 0, B1, _, Prefix),
        sub_string(S, B1, _, 0, PCStr),
        number_string(PC0, PCStr),
        PC is PC0 + Offset,
        format(string(Entry), '~w~w', [Prefix, PC])
    ;   Entry = Entry0
    ).

is_pred_label(PredKey, Entry) :-
    atom_string(Entry, S),
    sub_string(S, _, _, _, PredKey).

emit_lua_wrapper(Pred, Arity, StartPc, Code) :-
    pred_arg_strings(Arity, ArgDecl, ArgList),
    lua_pred_name(Pred, Name),
    format(string(Code),
'function M.~w(~w)
  return Runtime.run_predicate(shared_program, ~w, ~w)
end
', [Name, ArgDecl, StartPc, ArgList]).

emit_lua_lowered_wrapper(Pred, Arity, FuncName, Code) :-
    pred_arg_strings(Arity, ArgDecl, ArgList),
    lua_pred_name(Pred, Name),
    format(string(Code),
'function M.~w(~w)
  local state = Runtime.new_state()
  local args = ~w
  for i, arg in ipairs(args) do Runtime.put_reg(state, i, arg) end
  state.cp = 0
  return ~w(shared_program, state) == true
end
', [Name, ArgDecl, ArgList, FuncName]).

pred_arg_strings(0, '', '{}') :- !.
pred_arg_strings(Arity, ArgDecl, ArgList) :-
    numlist(1, Arity, Ns),
    maplist([N, A]>>(format(string(A), 'a~w', [N])), Ns, Args),
    atomic_list_concat(Args, ', ', ArgDecl),
    format(string(ArgList), '{~w}', [ArgDecl]).

lua_pred_name(Pred, Name) :-
    atom_string(Pred, S),
    string_codes(S, Codes),
    maplist(lua_safe_code, Codes, Safe),
    string_codes(SafeS, Safe),
    (   Safe = [C|_], C >= 0'0, C =< 0'9
    ->  string_concat("p_", SafeS, Out)
    ;   Out = SafeS
    ),
    atom_string(Name, Out).

lua_safe_code(C, C) :-
    (C >= 0'a, C =< 0'z ; C >= 0'A, C =< 0'Z ; C >= 0'0, C =< 0'9 ; C =:= 0'_), !.
lua_safe_code(_, 0'_).

lua_foreign_predicate(Pred, Arity, Options) :-
    (string(Pred) -> atom_string(PA, Pred) ; PA = Pred),
    option(foreign_predicates(FPs), Options, []),
    (member(PA/Arity, FPs) ; member(_:PA/Arity, FPs)), !.

lua_foreign_handlers_code(Options, Code) :-
    option(lua_foreign_handlers(Handlers), Options, []),
    maplist(lua_foreign_handler_entry, Handlers, Entries),
    atomic_list_concat(Entries, ',\n', Code).

lua_foreign_handler_entry(handler(Pred/Arity, HandlerCode), Entry) :-
    format(string(Key), '~w/~w', [Pred, Arity]),
    lua_string_literal(Key, Q),
    format(string(Entry), '  [~w] = ~w', [Q, HandlerCode]).

write_wam_lua_project(Predicates, Options, ProjectDir) :-
    wam_target_runtime_parser(wam_lua, Options, RuntimeParserMode),
    validate_lua_runtime_parser_mode(Predicates, RuntimeParserMode),
    lua_runtime_parser_mode_literal(RuntimeParserMode, RuntimeParserModeCode),
    make_directory_path(ProjectDir),
    directory_file_path(ProjectDir, 'lua', LuaDir),
    make_directory_path(LuaDir),
    compile_predicates_for_project(Predicates, Options,
        AllInstrs, TopLabels, AllLabels, WrapperCode, LoweredCode, InlineFactsCode, FactSourcesCode),
    emit_lua_intern_table(InternSeed),
    maplist([I, Line]>>(format(string(Line), '  ~w', [I])), AllInstrs, InstrLines),
    atomic_list_concat(InstrLines, ',\n', InstrBody),
    atomic_list_concat(TopLabels, ',\n', DispatchBody),
    atomic_list_concat(AllLabels, ',\n', LabelBody),
    lua_foreign_handlers_code(Options, ForeignHandlers),
    write_runtime_source(LuaDir),
    write_program_source(LuaDir, InstrBody, LabelBody, DispatchBody,
                         WrapperCode, InternSeed, ForeignHandlers, LoweredCode, InlineFactsCode, FactSourcesCode,
                         RuntimeParserModeCode).

write_runtime_source(LuaDir) :-
    find_template('templates/targets/lua_wam/runtime.lua.mustache', Template),
    get_time(T), format_time(string(Date), "%Y-%m-%d", T),
    render_template(Template, ['date'=Date], Content),
    directory_file_path(LuaDir, 'wam_runtime.lua', Path),
    write_file(Path, Content).

write_program_source(LuaDir, InstrBody, LabelBody, DispatchBody,
                     WrapperCode, InternSeed, ForeignHandlers, LoweredCode, InlineFactsCode, FactSourcesCode,
                     RuntimeParserModeCode) :-
    find_template('templates/targets/lua_wam/program.lua.mustache', Template),
    get_time(T), format_time(string(Date), "%Y-%m-%d", T),
    render_template(Template,
        ['date'=Date,
         'instructions'=InstrBody,
         'labels'=LabelBody,
         'dispatch'=DispatchBody,
         'wrappers'=WrapperCode,
         'intern_id_to_string'=InternSeed,
         'foreign_handlers'=ForeignHandlers,
         'lowered_functions'=LoweredCode,
         'inline_facts'=InlineFactsCode,
         'fact_sources'=FactSourcesCode,
         'runtime_parser_mode'=RuntimeParserModeCode], Content),
    directory_file_path(LuaDir, 'generated_program.lua', Path),
    write_file(Path, Content).

lua_runtime_parser_mode_literal(none,
    '{ kind = "none", entry = nil, source = nil }') :- !.
lua_runtime_parser_mode_literal(native(Entry), Code) :-
    !,
    lua_string_literal(Entry, EntryLit),
    format(string(Code),
           '{ kind = "native", entry = ~w, source = nil }',
           [EntryLit]).
lua_runtime_parser_mode_literal(compiled(SourceModule), Code) :-
    lua_string_literal(SourceModule, SourceLit),
    format(string(Code),
           '{ kind = "compiled", entry = nil, source = ~w }',
           [SourceLit]).

validate_lua_runtime_parser_mode(Predicates, none) :-
    !,
    (   lua_predicates_parser_dependency(Predicates, Pred, Builtin)
    ->  throw(error(permission_error(use, runtime_parser, Builtin),
                    context(write_wam_lua_project/3,
                            parser_disabled_for_predicate(Pred))))
    ;   true
    ).
validate_lua_runtime_parser_mode(_Predicates, _Mode).

lua_predicates_parser_dependency(Predicates, Pred, Builtin) :-
    member(Pred, Predicates),
    lua_predicate_clause(Pred, _Head, Body),
    parser_dependent_body_goal(Body, Builtin),
    !.

lua_predicate_clause(Module:Name/Arity, Head, Body) :-
    !,
    functor(Head, Name, Arity),
    clause(Module:Head, Body).
lua_predicate_clause(Name/Arity, Head, Body) :-
    functor(Head, Name, Arity),
    clause(user:Head, Body).

write_file(Path, Content) :-
    % UTF-8 so the runtime/generated sources (which contain non-ASCII
    % characters) write correctly regardless of the process locale
    % (POSIX/ASCII in many CI containers); otherwise write/2 raises an
    % encoding error.
    setup_call_cleanup(open(Path, write, Stream, [encoding(utf8)]),
                       write(Stream, Content), close(Stream)).

find_template(RelPath, Template) :-
    (   source_file(wam_lua_target, SrcFile)
    ->  file_directory_name(SrcFile, SrcDir),
        file_directory_name(SrcDir, TargetsDir),
        file_directory_name(TargetsDir, Root),
        atomic_list_concat([Root, '/', RelPath], AbsPath)
    ;   AbsPath = RelPath
    ),
    read_file_to_string(AbsPath, Template, []).
