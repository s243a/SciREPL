:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)
%
% rust_target.pl - Rust Target for UnifyWeaver
% Generates standalone Rust programs for record/field processing.
% Phase 3: JSON support (serde_json crate).

:- module(rust_target, [
    compile_predicate_to_rust/3,      % +Predicate, +Options, -RustCode
    compile_facts_to_rust/3,          % +Pred, +Arity, -RustCode  -- NEW
    write_rust_program/2,             % +RustCode, +FilePath
    write_rust_project/2,             % +RustCode, +Dir
    json_schema/2,                    % +SchemaName, +Fields (directive)
    get_json_schema/2,                % +SchemaName, -Fields (lookup)
    init_rust_target/0,               % Initialize bindings
    compile_rust_pipeline/3,          % +Predicates, +Options, -RustCode
    test_rust_pipeline_generator/0,   % Unit tests for pipeline generator mode
    % Enhanced pipeline chaining exports
    compile_rust_enhanced_pipeline/3, % +Stages, +Options, -RustCode
    rust_enhanced_helpers/2,          % +ParallelMode, -Code
    generate_rust_enhanced_connector/3, % +Stages, +PipelineName, -Code
    test_rust_enhanced_chaining/0,    % Test enhanced pipeline chaining
    % Client-server architecture exports (Phase 9)
    compile_service_to_rust/2,        % +Service, -RustCode
    generate_service_handler_rust/2,  % +HandlerSpec, -RustCode
    % Phase 2: Cross-process services
    compile_unix_socket_service_rust/2,   % +Service, -RustCode
    compile_unix_socket_client_rust/3,    % +ServiceName, +SocketPath, -RustCode
    % Phase 3: Network services
    compile_tcp_service_rust/2,           % +Service, -RustCode
    compile_tcp_client_rust/4,            % +ServiceName, +Host, +Port, -RustCode
    compile_http_service_rust/2,          % +Service, -RustCode
    compile_http_client_rust/3,           % +ServiceName, +Endpoint, -RustCode
    compile_http_client_rust/4,           % +ServiceName, +Endpoint, +Options, -RustCode
    % Phase 4: Service mesh
    compile_service_mesh_rust/2,          % +Service, -RustCode
    % Phase 5: Polyglot services
    compile_polyglot_service_rust/2,      % +Service, -RustCode
    generate_service_client_rust/3,       % +ServiceName, +Endpoint, -RustCode
    % Phase 6: Distributed services
    compile_distributed_service_rust/2,   % +Service, -RustCode
    generate_sharding_rust/2,             % +Strategy, -RustCode
    generate_replication_rust/2,          % +ReplicationFactor, -RustCode
    % Phase 7: Service Discovery
    compile_discovery_service_rust/2,     % +Service, -RustCode
    generate_health_check_rust/2,         % +Config, -RustCode
    generate_service_registry_rust/2,     % +Backend, -RustCode
    % Phase 8: Service Tracing
    compile_traced_service_rust/2,        % +Service, -RustCode
    generate_tracer_rust/2,               % +Config, -RustCode
    generate_span_context_rust/2,         % +Context, -RustCode
    % KG Topology Phase 3: Kleinberg routing
    compile_kleinberg_router_rust/2,      % +Options, -RustCode
    % KG Topology Phase 4: Federated queries
    compile_federated_query_rust/2,       % +Options, -RustCode
    % KG Topology Phase 5: Advanced federation
    compile_adaptive_federation_rust/2,   % +Options, -RustCode
    compile_query_planner_rust/2,         % +Options, -RustCode
    compile_hierarchical_federation_rust/2, % +Options, -RustCode
    compile_streaming_federation_rust/2   % +Options, -RustCode
]).

:- use_module(library(lists)).
:- use_module(library(filesex)).
:- use_module(library(gensym)). % For generating unique variable names
:- use_module(library(yall)).
:- use_module('../core/binding_registry').
:- use_module('../bindings/rust_bindings').
:- use_module('../core/pipeline_validation').
:- use_module('../core/service_validation').
:- use_module('../core/optimizer').
:- use_module('../core/template_system', [render_template/3]).
:- use_module('../targets/wam_target', [compile_predicate_to_wam/3]).
:- use_module('../targets/wam_rust_target', [compile_wam_predicate_to_rust/4]).
:- use_module('../core/constraint_analyzer', [get_constraints/2]).

% Component system integration (ported from Go target)
:- use_module('../core/component_registry').
:- use_module('rust_runtime/custom_rust', []).

% Native clause body lowering (shared analysis infrastructure)
:- use_module('../core/clause_body_analysis', except([translate_expr/3])).

:- use_module('../core/semantic_compiler', except([is_semantic_predicate/1])).

%% semantic_compiler:semantic_dispatch(+Target, +Goal, +ProviderInfo, +VarMap, -Code)
%  Target-specific implementation for semantic search.
%  Handles candle and onnx providers with device-aware initialization.
semantic_compiler:semantic_dispatch(rust, Goal, Provider, VarMap, Code) :-
    Goal =.. [_, Query, TopK | _],
    option(provider(candle), Provider),
    !,
    option(model(Model), Provider, 'all-MiniLM-L6-v2'),
    option(device(Device), Provider, auto),

    % Lookup variable names in VarMap
    (   member(Query=QueryVar, VarMap) -> QueryExpr = QueryVar ; QueryExpr = Query ),
    (   member(TopK=TopKVar, VarMap) -> TopKExpr = TopKVar ; TopKExpr = TopK ),

    % Device feature selection for candle
    (   Device == gpu
    ->  DeviceInit = 'let device = candle_core::Device::new_cuda(0)\n        .unwrap_or_else(|_| { eprintln!("Warning: CUDA not available, falling back to CPU"); candle_core::Device::Cpu });'
    ;   Device == cpu
    ->  DeviceInit = 'let device = candle_core::Device::Cpu;'
    ;   DeviceInit = 'let device = candle_core::Device::cuda_if_available(0).unwrap_or(candle_core::Device::Cpu);'
    ),

    format(string(Code), '
    // Initialize candle searcher with model ~w
    ~w
    let searcher = PtSearcher::new("data.redb", "~w", &device)?;
    let results = searcher.text_search("~w", ~w)?;
    println!("{}", serde_json::to_string_pretty(&results)?);
', [Model, DeviceInit, Model, QueryExpr, TopKExpr]).

semantic_compiler:semantic_dispatch(rust, Goal, Provider, VarMap, Code) :-
    Goal =.. [_, Query, TopK | _],
    option(provider(onnx), Provider),
    !,
    option(model(Model), Provider, 'all-MiniLM-L6-v2'),
    option(device(Device), Provider, auto),

    % Lookup variable names in VarMap
    (   member(Query=QueryVar, VarMap) -> QueryExpr = QueryVar ; QueryExpr = Query ),
    (   member(TopK=TopKVar, VarMap) -> TopKExpr = TopKVar ; TopKExpr = TopK ),

    % Device selection for ONNX Runtime
    (   Device == gpu
    ->  DeviceInit = 'let env = ort::Environment::builder().with_execution_providers([ort::CUDAExecutionProvider::default().build()]).build()?;'
    ;   DeviceInit = 'let env = ort::Environment::builder().build()?;'
    ),

    format(string(Code), '
    // Initialize ONNX searcher with model ~w
    ~w
    let searcher = OnnxSearcher::new("data.redb", "models/~w-onnx", &env)?;
    let results = searcher.text_search("~w", ~w)?;
', [Model, DeviceInit, Model, QueryExpr, TopKExpr]).

% ============================================================================
% FUZZY LOGIC DISPATCH (Rust target)
% ============================================================================
%
% Generates inline Rust code for fuzzy operations. Assumes `term_scores`
% (HashMap<String, f64>) is in scope from the surrounding search context.

:- multifile semantic_compiler:fuzzy_dispatch/3.

%% f_and: Fuzzy AND (product t-norm)
semantic_compiler:fuzzy_dispatch(rust, f_and(Terms, _Result), Code) :-
    generate_rust_product_terms(Terms, TermCode),
    format(string(Code),
'    // Fuzzy AND (product t-norm)
    let mut result: f64 = 1.0;
~w', [TermCode]).

%% f_or: Fuzzy OR (probabilistic sum)
semantic_compiler:fuzzy_dispatch(rust, f_or(Terms, _Result), Code) :-
    generate_rust_complement_terms(Terms, TermCode),
    format(string(Code),
'    // Fuzzy OR (probabilistic sum)
    let mut complement: f64 = 1.0;
~w    let result = 1.0 - complement;
', [TermCode]).

%% f_dist_or: Distributed OR
semantic_compiler:fuzzy_dispatch(rust, f_dist_or(BaseScore, Terms, _Result), Code) :-
    (number(BaseScore) -> format(string(BaseExpr), "~w", [BaseScore]) ; BaseExpr = BaseScore),
    generate_rust_dist_complement_terms(BaseExpr, Terms, TermCode),
    format(string(Code),
'    // Fuzzy distributed OR
    let mut complement: f64 = 1.0;
~w    let result = 1.0 - complement;
', [TermCode]).

%% f_union: Non-distributed OR (base * OR result)
semantic_compiler:fuzzy_dispatch(rust, f_union(BaseScore, Terms, _Result), Code) :-
    (number(BaseScore) -> format(string(BaseExpr), "~w", [BaseScore]) ; BaseExpr = BaseScore),
    generate_rust_complement_terms(Terms, TermCode),
    format(string(Code),
'    // Fuzzy union (base * OR)
    let mut complement: f64 = 1.0;
~w    let result = ~w * (1.0 - complement);
', [TermCode, BaseExpr]).

%% f_not: Fuzzy NOT (complement)
semantic_compiler:fuzzy_dispatch(rust, f_not(Score, _Result), Code) :-
    (number(Score) -> format(string(ScoreExpr), "~w", [Score]) ; format(string(ScoreExpr), "~w", [Score])),
    format(string(Code), '    let result = 1.0 - ~w;\n', [ScoreExpr]).

%% blend_scores: Weighted interpolation using iterators
semantic_compiler:fuzzy_dispatch(rust, blend_scores(Alpha, Scores1, Scores2, _Result), Code) :-
    (number(Alpha) -> format(string(AExpr), "~w_f64", [Alpha]) ; AExpr = Alpha),
    format(string(Code),
'    // Blend scores: alpha*s1 + (1-alpha)*s2
    let result: Vec<f64> = ~w.iter().zip(~w.iter())
        .map(|(s1, s2)| ~w * s1 + (1.0 - ~w) * s2)
        .collect();
', [Scores1, Scores2, AExpr, AExpr]).

%% top_k: Get top K items by score
semantic_compiler:fuzzy_dispatch(rust, top_k(Items, K, _Result), Code) :-
    format(string(Code),
'    // Top-K selection
    let mut scored: Vec<_> = ~w.clone();
    scored.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
    let result = scored.into_iter().take(~w).collect::<Vec<_>>();
', [Items, K]).

% ---- Helpers for generating per-term Rust code ----

generate_rust_product_terms([], '').
generate_rust_product_terms([w(Term, Weight)|Rest], Code) :-
    generate_rust_product_terms(Rest, RestCode),
    format(string(Line), '    result *= ~w * term_scores.get("~w").copied().unwrap_or(0.5);\n', [Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_rust_product_terms([Term|Rest], Code) :-
    atom(Term),
    generate_rust_product_terms(Rest, RestCode),
    format(string(Line), '    result *= term_scores.get("~w").copied().unwrap_or(0.5);\n', [Term]),
    string_concat(Line, RestCode, Code).

generate_rust_complement_terms([], '').
generate_rust_complement_terms([w(Term, Weight)|Rest], Code) :-
    generate_rust_complement_terms(Rest, RestCode),
    format(string(Line), '    complement *= 1.0 - ~w * term_scores.get("~w").copied().unwrap_or(0.5);\n', [Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_rust_complement_terms([Term|Rest], Code) :-
    atom(Term),
    generate_rust_complement_terms(Rest, RestCode),
    format(string(Line), '    complement *= 1.0 - term_scores.get("~w").copied().unwrap_or(0.5);\n', [Term]),
    string_concat(Line, RestCode, Code).

generate_rust_dist_complement_terms(_, [], '').
generate_rust_dist_complement_terms(BaseExpr, [w(Term, Weight)|Rest], Code) :-
    generate_rust_dist_complement_terms(BaseExpr, Rest, RestCode),
    format(string(Line), '    complement *= 1.0 - ~w * ~w * term_scores.get("~w").copied().unwrap_or(0.5);\n', [BaseExpr, Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_rust_dist_complement_terms(BaseExpr, [Term|Rest], Code) :-
    atom(Term),
    generate_rust_dist_complement_terms(BaseExpr, Rest, RestCode),
    format(string(Line), '    complement *= 1.0 - ~w * term_scores.get("~w").copied().unwrap_or(0.5);\n', [BaseExpr, Term]),
    string_concat(Line, RestCode, Code).

% ---- Batch fuzzy operations (Vec<f64>) ----

%% f_and_batch: Batch product t-norm over Vec<f64>
semantic_compiler:fuzzy_dispatch(rust, f_and_batch(Terms, _ScoresBatch, _Result), Code) :-
    generate_rust_batch_product_terms(Terms, TermCode),
    format(string(Code),
'    // Batch fuzzy AND (product t-norm)
    let n = batch_len(&term_scores_batch);
    let mut result: Vec<f64> = vec![1.0; n];
~w', [TermCode]).

%% f_or_batch: Batch probabilistic sum
semantic_compiler:fuzzy_dispatch(rust, f_or_batch(Terms, _ScoresBatch, _Result), Code) :-
    generate_rust_batch_complement_terms(Terms, TermCode),
    format(string(Code),
'    // Batch fuzzy OR (probabilistic sum)
    let n = batch_len(&term_scores_batch);
    let mut complement: Vec<f64> = vec![1.0; n];
~w    let result: Vec<f64> = complement.iter().map(|c| 1.0 - c).collect();
', [TermCode]).

%% f_dist_or_batch: Batch distributed OR
semantic_compiler:fuzzy_dispatch(rust, f_dist_or_batch(BaseScores, Terms, _ScoresBatch, _Result), Code) :-
    generate_rust_batch_dist_complement_terms(Terms, TermCode),
    format(string(Code),
'    // Batch fuzzy distributed OR
    let n = ~w.len();
    let mut complement: Vec<f64> = vec![1.0; n];
~w    let result: Vec<f64> = complement.iter().map(|c| 1.0 - c).collect();
', [BaseScores, TermCode]).

%% f_union_batch: Batch non-distributed OR
semantic_compiler:fuzzy_dispatch(rust, f_union_batch(BaseScores, Terms, _ScoresBatch, _Result), Code) :-
    generate_rust_batch_complement_terms(Terms, TermCode),
    format(string(Code),
'    // Batch fuzzy union (base * OR)
    let n = ~w.len();
    let mut complement: Vec<f64> = vec![1.0; n];
~w    let result: Vec<f64> = ~w.iter().zip(complement.iter())
        .map(|(b, c)| b * (1.0 - c))
        .collect();
', [BaseScores, TermCode, BaseScores]).

% ---- Batch helpers ----

generate_rust_batch_product_terms([], '').
generate_rust_batch_product_terms([w(Term, Weight)|Rest], Code) :-
    generate_rust_batch_product_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for (r, s) in result.iter_mut().zip(scores.iter()) { *r *= ~w * s; }
    }
', [Term, Weight]),
    string_concat(Line, RestCode, Code).
generate_rust_batch_product_terms([Term|Rest], Code) :-
    atom(Term),
    generate_rust_batch_product_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for (r, s) in result.iter_mut().zip(scores.iter()) { *r *= s; }
    }
', [Term]),
    string_concat(Line, RestCode, Code).

generate_rust_batch_complement_terms([], '').
generate_rust_batch_complement_terms([w(Term, Weight)|Rest], Code) :-
    generate_rust_batch_complement_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for (c, s) in complement.iter_mut().zip(scores.iter()) { *c *= 1.0 - ~w * s; }
    }
', [Term, Weight]),
    string_concat(Line, RestCode, Code).
generate_rust_batch_complement_terms([Term|Rest], Code) :-
    atom(Term),
    generate_rust_batch_complement_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for (c, s) in complement.iter_mut().zip(scores.iter()) { *c *= 1.0 - s; }
    }
', [Term]),
    string_concat(Line, RestCode, Code).

generate_rust_batch_dist_complement_terms([], '').
generate_rust_batch_dist_complement_terms([w(Term, Weight)|Rest], Code) :-
    generate_rust_batch_dist_complement_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for ((c, s), b) in complement.iter_mut().zip(scores.iter()).zip(base_scores.iter()) { *c *= 1.0 - b * ~w * s; }
    }
', [Term, Weight]),
    string_concat(Line, RestCode, Code).
generate_rust_batch_dist_complement_terms([Term|Rest], Code) :-
    atom(Term),
    generate_rust_batch_dist_complement_terms(Rest, RestCode),
    format(string(Line),
'    if let Some(scores) = term_scores_batch.get("~w") {
        for ((c, s), b) in complement.iter_mut().zip(scores.iter()).zip(base_scores.iter()) { *c *= 1.0 - b * s; }
    }
', [Term]),
    string_concat(Line, RestCode, Code).

% Per-path visited pattern detection
:- use_module('../core/advanced/pattern_matchers', [
    is_per_path_visited_pattern/4,
    parse_table_spec/2,
    classify_aggregate/2,
    classify_aggregate_goal/2
]).

% Track collected components for code generation
:- dynamic collected_component/2.

%% init_rust_target
%  Initialize the Rust target by loading bindings and components.
init_rust_target :-
    retractall(collected_component(_, _)),
    init_rust_bindings.

%% collect_declared_component(+Category, +Name)
%  Record that a component is used in the code
collect_declared_component(Category, Name) :-
    (   collected_component(Category, Name)
    ->  true
    ;   assertz(collected_component(Category, Name))
    ).

%% compile_collected_components(-Code)
%  Generate Rust code for all collected components
compile_collected_components(Code) :-
    findall(CompCode, (
        collected_component(Category, Name),
        component_registry:compile_component(Category, Name, [], CompCode)
    ), CompCodes),
    (   CompCodes = []
    ->  Code = ''
    ;   atomic_list_concat(CompCodes, '\n\n', Code)
    ).

%% ============================================ 
%% JSON SCHEMA SUPPORT
%% ============================================ 

:- dynamic json_schema_def/2.

json_schema(SchemaName, Fields) :-
    (   validate_schema_fields(Fields)
    ->  retractall(json_schema_def(SchemaName, _)),
        assertz(json_schema_def(SchemaName, Fields)),
        format('Schema defined: ~w with ~w fields~n', [SchemaName, Fields])
    ;   format('ERROR: Invalid schema definition for ~w: ~w~n', [SchemaName, Fields]),
        fail
    ).

%% validate_schema_fields(+Fields)
%  Validate that all fields have correct format: field(Name, Type) or field(Name, Type, Options)
validate_schema_fields([]).
validate_schema_fields([field(Name, Type)|Rest]) :-
    atom(Name),
    valid_json_type(Type),
    validate_schema_fields(Rest).
validate_schema_fields([field(Name, Type, Options)|Rest]) :-
    atom(Name),
    valid_json_type(Type),
    is_list(Options),
    validate_field_options(Options),
    validate_schema_fields(Rest).
validate_schema_fields([Invalid|_]) :-
    format('ERROR: Invalid field specification: ~w~n', [Invalid]),
    fail.

%% validate_field_options(+Options)
%  Validate field options: min(N), max(N), format(F), required, optional
validate_field_options([]).
validate_field_options([Option|Rest]) :-
    validate_field_option(Option),
    validate_field_options(Rest).

validate_field_option(min(N)) :- number(N).
validate_field_option(max(N)) :- number(N).
validate_field_option(format(F)) :- atom(F).
validate_field_option(required).
validate_field_option(optional).
validate_field_option(Invalid) :-
    format('ERROR: Invalid field option: ~w~n', [Invalid]),
    fail.

%% valid_json_type(+Type)
%  Check if a type is valid for JSON schemas
valid_json_type(string).
valid_json_type(integer).
valid_json_type(float).
valid_json_type(boolean).
valid_json_type(array).
valid_json_type(array(Type)) :- valid_json_type(Type).
valid_json_type(object).
valid_json_type(object(SchemaName)) :- atom(SchemaName).
valid_json_type(any).

get_json_schema(SchemaName, Fields) :-
    json_schema_def(SchemaName, Fields), !.
get_json_schema(SchemaName, _) :-
    format('ERROR: Schema not found: ~w~n', [SchemaName]),
    fail.

%% get_field_info(+SchemaName, +FieldName, -Type, -Options)
%  Get the type and options of a specific field from a schema
get_field_info(SchemaName, FieldName, Type, Options) :-
    get_json_schema(SchemaName, Fields),
    (   member(field(FieldName, Type, Options), Fields) -> true
    ;   member(field(FieldName, Type), Fields) -> Options = []
    ), !.
get_field_info(SchemaName, FieldName, any, []) :-
    format('WARNING: Field ~w not in schema ~w, defaulting to type ''any''~n', [FieldName, SchemaName]).

get_field_type(SchemaName, FieldName, Type) :-
    get_json_schema(SchemaName, Fields),
    (   member(field(FieldName, Type, _), Fields) -> true
    ;   member(field(FieldName, Type), Fields) -> true
    ), !.
get_field_type(_SchemaName, _FieldName, serde_json_value).

%% ============================================
%% SCHEMA VALIDATION CODE GENERATION
%% ============================================

%% generate_rust_schema_validator(+SchemaName, -Code)
%  Generate a Rust function to validate a schema
generate_rust_schema_validator(SchemaName, Code) :-
    get_json_schema(SchemaName, Fields),
    format(atom(FuncName), 'validate_~w', [SchemaName]),

    findall(CheckCode, (
        member(FieldDef, Fields),
        generate_rust_field_check(FieldDef, CheckCode)
    ), CheckCodes),
    atomic_list_concat(CheckCodes, '\n', Body),

    format(string(Code), '
fn ~w(data: &serde_json::Value) -> bool {
    let obj = match data.as_object() {
        Some(o) => o,
        None => return false,
    };
~s
    true
}', [FuncName, Body]).

generate_rust_field_check(field(Name, Type, Options), Code) :- !,
    generate_rust_field_check_logic(Name, Type, Options, Code).
generate_rust_field_check(field(Name, Type), Code) :-
    generate_rust_field_check_logic(Name, Type, [], Code).

generate_rust_field_check_logic(Name, Type, Options, Code) :-
    atom_string(Name, NameStr),
    (   member(optional, Options) -> Optional = true ; Optional = false ),

    % Type Check
    (   Type = string -> TypeCheck = 'val.is_string()'
    ;   Type = integer -> TypeCheck = 'val.is_i64() || val.is_u64()'
    ;   Type = float -> TypeCheck = 'val.is_f64()'
    ;   Type = boolean -> TypeCheck = 'val.is_boolean()'
    ;   Type = array -> TypeCheck = 'val.is_array()'
    ;   Type = array(_) -> TypeCheck = 'val.is_array()'
    ;   Type = object -> TypeCheck = 'val.is_object()'
    ;   Type = object(SubSchema) ->
        format(atom(TypeCheck), 'val.is_object() && validate_~w(val)', [SubSchema])
    ;   TypeCheck = 'true'  % any type
    ),

    % Generate constraint checks
    generate_rust_validator_constraints(Type, Options, ConstraintCode),

    % Build the validation code
    (   Optional = true
    ->  format(string(Code), '
    if let Some(val) = obj.get("~s") {
        if !(~s) { return false; }
~s
    }', [NameStr, TypeCheck, ConstraintCode])
    ;   format(string(Code), '
    match obj.get("~s") {
        Some(val) => {
            if !(~s) { return false; }
~s
        }
        None => return false,
    }', [NameStr, TypeCheck, ConstraintCode])
    ).

%% generate_rust_validator_constraints(+Type, +Options, -Code)
%  Generate Rust constraint validation code
generate_rust_validator_constraints(Type, Options, Code) :-
    findall(Check,
        (   member(Option, Options),
            generate_rust_validator_check(Type, Option, Check)
        ),
        Checks),
    atomic_list_concat(Checks, '\n', Code).

generate_rust_validator_check(integer, min(Min), Check) :-
    format(atom(Check), '        if val.as_i64().map(|v| v < ~w).unwrap_or(false) { return false; }', [Min]).
generate_rust_validator_check(integer, max(Max), Check) :-
    format(atom(Check), '        if val.as_i64().map(|v| v > ~w).unwrap_or(false) { return false; }', [Max]).
generate_rust_validator_check(float, min(Min), Check) :-
    format(atom(Check), '        if val.as_f64().map(|v| v < ~w).unwrap_or(false) { return false; }', [Min]).
generate_rust_validator_check(float, max(Max), Check) :-
    format(atom(Check), '        if val.as_f64().map(|v| v > ~w).unwrap_or(false) { return false; }', [Max]).
generate_rust_validator_check(string, min(Min), Check) :-
    format(atom(Check), '        if val.as_str().map(|s| s.len() < ~w).unwrap_or(false) { return false; }', [Min]).
generate_rust_validator_check(string, max(Max), Check) :-
    format(atom(Check), '        if val.as_str().map(|s| s.len() > ~w).unwrap_or(false) { return false; }', [Max]).
generate_rust_validator_check(string, format(email), Check) :-
    Check = '        if val.as_str().map(|s| !s.contains(\"@\")).unwrap_or(false) { return false; }'.
generate_rust_validator_check(string, format(date), Check) :-
    Check = '        // Date format validation (basic check for YYYY-MM-DD pattern)
        if val.as_str().map(|s| s.len() != 10 || s.chars().nth(4) != Some(\'-\') || s.chars().nth(7) != Some(\'-\')).unwrap_or(false) { return false; }'.
generate_rust_validator_check(_, _, '').

%% ============================================
%% XML PROCESSING SUPPORT (ported from Go target)
%% ============================================

%% compile_rust_xml_mode(+Pred, +Arity, +Options, -RustCode)
%  Compile predicate for XML input (streaming + flattening)
compile_rust_xml_mode(Pred, Arity, Options, RustCode) :-
    % Get options
    option(field_delimiter(FieldDelim), Options, colon),
    option(unique(Unique), Options, true),

    % Get predicate clauses
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),

    (   Clauses = [SingleHead-SingleBody] ->
        % Extract mappings
        extract_rust_xml_field_mappings(SingleBody, FieldMappings),
        format('DEBUG: XML FieldMappings = ~w~n', [FieldMappings]),

        % Generate XML processing
        SingleHead =.. [_|HeadArgs],
        compile_rust_xml_body(HeadArgs, FieldMappings, FieldDelim, Unique, Options, CoreBody)
    ;   format('ERROR: XML mode supports single clause only~n'),
        fail
    ),

    % Generate XML helpers
    generate_rust_xml_helpers(XmlHelpers),

    % Build complete code
    format(string(RustCode), '
use std::io::{self, BufRead, Read};
use std::collections::HashMap;
use quick_xml::Reader;
use quick_xml::events::Event;

~s

fn main() {
~s
}', [XmlHelpers, CoreBody]).

%% extract_rust_xml_field_mappings(+Body, -Mappings)
%  Extract field mappings from rule body for XML processing
extract_rust_xml_field_mappings(Body, Mappings) :-
    (   Body = (Goal, _)
    ->  extract_xml_mapping_from_goal(Goal, Mappings)
    ;   extract_xml_mapping_from_goal(Body, Mappings)
    ).

extract_xml_mapping_from_goal(xml_record(Fields), Fields) :- !.
extract_xml_mapping_from_goal(xml_field(Field, Var), [xml_field(Field, Var)]) :- !.
extract_xml_mapping_from_goal(_, []).

%% compile_rust_xml_body(+HeadArgs, +FieldMappings, +FieldDelim, +Unique, +Options, -RustCode)
compile_rust_xml_body(HeadArgs, FieldMappings, FieldDelim, Unique, Options, RustCode) :-
    % Map delimiter
    (   FieldDelim = colon -> DelimChar = ":"
    ;   FieldDelim = tab -> DelimChar = "\\t"
    ;   FieldDelim = comma -> DelimChar = ","
    ;   FieldDelim = pipe -> DelimChar = "|"
    ;   DelimChar = ":"
    ),

    % Generate field extraction code
    generate_rust_xml_field_extractions(FieldMappings, HeadArgs, ExtractCode),
    generate_rust_xml_output_expr(HeadArgs, DelimChar, OutputExpr),

    % Get XML file and tags
    option(xml_file(XmlFile), Options, stdin),

    (   XmlFile == stdin
    ->  FileOpenCode = '    let mut input = String::new();
    io::stdin().read_to_string(&mut input).expect("Failed to read stdin");
    let mut reader = Reader::from_str(&input);'
    ;   format(string(FileOpenCode), '    let mut reader = Reader::from_file("~w").expect("Failed to open XML file");', [XmlFile])
    ),

    (   option(tags(Tags), Options)
    ->  true
    ;   option(tag(Tag), Options)
    ->  Tags = [Tag]
    ;   Tags = []
    ),

    % Build tag check
    (   Tags = []
    ->  TagCheck = 'true'
    ;   maplist(rust_tag_to_cond, Tags, Conds),
        atomic_list_concat(Conds, ' || ', TagCheck)
    ),

    % Build main loop
    (   Unique = true ->
        SeenDecl = '    let mut seen = std::collections::HashSet::new();',
        UniqueCheck = '
            if seen.insert(result.clone()) {
                println!("{}", result);
            }'
    ;   SeenDecl = '',
        UniqueCheck = '
            println!("{}", result);'
    ),

    format(string(RustCode), '
~s
    reader.trim_text(true);
~s
    let mut buf = Vec::new();
    let mut current_element = String::new();
    let mut element_data: HashMap<String, String> = HashMap::new();
    let mut depth = 0;

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(ref e)) => {
                let name = String::from_utf8_lossy(e.name().as_ref()).to_string();
                if depth == 0 && (~s) {
                    current_element = name.clone();
                    element_data.clear();
                    // Extract attributes
                    for attr in e.attributes().filter_map(|a| a.ok()) {
                        let key = format!("@{}", String::from_utf8_lossy(attr.key.as_ref()));
                        let val = String::from_utf8_lossy(&attr.value).to_string();
                        element_data.insert(key, val);
                    }
                }
                depth += 1;
            }
            Ok(Event::Text(ref e)) => {
                if depth > 0 {
                    let text = e.unescape().unwrap_or_default().trim().to_string();
                    if !text.is_empty() {
                        element_data.insert("text".to_string(), text);
                    }
                }
            }
            Ok(Event::End(ref e)) => {
                depth -= 1;
                let name = String::from_utf8_lossy(e.name().as_ref()).to_string();
                if depth == 0 && name == current_element {
                    // Process element
                    let data = &element_data;
~s
                    let result = ~s;
~s
                }
            }
            Ok(Event::Eof) => break,
            Err(e) => {
                eprintln!("XML parse error: {:?}", e);
                break;
            }
            _ => {}
        }
        buf.clear();
    }', [FileOpenCode, SeenDecl, TagCheck, ExtractCode, OutputExpr, UniqueCheck]).

rust_tag_to_cond(Tag, Cond) :-
    format(atom(Cond), 'name == "~w"', [Tag]).

%% generate_rust_xml_field_extractions(+FieldMappings, +HeadArgs, -Code)
generate_rust_xml_field_extractions(FieldMappings, HeadArgs, Code) :-
    findall(ExtractLine, (
        nth1(Pos, HeadArgs, Arg),
        format(atom(ValVar), 'val_~w', [Pos]),
        (   member(xml_field(XmlField, Arg), FieldMappings) ->
            format(string(ExtractLine), '                    let ~w = data.get("~w").cloned().unwrap_or_default();', [ValVar, XmlField])
        ;   format(string(ExtractLine), '                    let ~w = String::new();', [ValVar])
        )
    ), ExtractLines),
    atomic_list_concat(ExtractLines, '\n', Code).

%% generate_rust_xml_output_expr(+HeadArgs, +DelimChar, -Expr)
generate_rust_xml_output_expr(HeadArgs, DelimChar, Expr) :-
    length(HeadArgs, Arity),
    findall(Fmt, (between(1, Arity, _), Fmt = '{}'), Fmts),
    atomic_list_concat(Fmts, DelimChar, FmtStr),
    findall(ValVar, (nth1(Pos, HeadArgs, _), format(atom(ValVar), 'val_~w', [Pos])), ValVars),
    atomic_list_concat(ValVars, ', ', VarList),
    format(atom(Expr), 'format!("~s", ~w)', [FmtStr, VarList]).

%% generate_rust_xml_helpers(+Code)
generate_rust_xml_helpers(Code) :-
    Code = '
// XML flattening helper
fn flatten_xml_element(reader: &mut Reader<&[u8]>, start_name: &str) -> HashMap<String, String> {
    let mut result = HashMap::new();
    let mut buf = Vec::new();
    let mut depth = 1;

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(ref e)) => {
                depth += 1;
            }
            Ok(Event::Text(ref e)) => {
                if let Ok(text) = e.unescape() {
                    let trimmed = text.trim().to_string();
                    if !trimmed.is_empty() {
                        result.insert("text".to_string(), trimmed);
                    }
                }
            }
            Ok(Event::End(_)) => {
                depth -= 1;
                if depth == 0 { break; }
            }
            Ok(Event::Eof) => break,
            _ => {}
        }
        buf.clear();
    }
    result
}'.

%% ============================================
%% SERVICE COMPILATION (Client-Server Phase 1)
%% ============================================

%% compile_service_to_rust(+Service, -RustCode)
%  Compile a service definition to a Rust struct and impl.
%  Dispatches based on transport type: in_process, unix_socket, etc.
compile_service_to_rust(service(Name, HandlerSpec), RustCode) :-
    !,
    compile_service_to_rust(service(Name, [], HandlerSpec), RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    member(transport(unix_socket(_Path)), Options),
    !,
    % Phase 2: Unix socket service
    compile_unix_socket_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    member(transport(tcp(_Host, _Port)), Options),
    !,
    % Phase 3: TCP service
    compile_tcp_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    member(transport(http(_Endpoint)), Options),
    !,
    % Phase 3: HTTP service
    compile_http_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    member(transport(http(_Endpoint, _HttpOptions)), Options),
    !,
    % Phase 3: HTTP service with options
    compile_http_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    ( member(load_balance(_), Options)
    ; member(load_balance(_, _), Options)
    ; member(circuit_breaker(_, _), Options)
    ; member(circuit_breaker(_), Options)
    ; member(retry(_, _), Options)
    ; member(retry(_, _, _), Options)
    ),
    !,
    % Phase 4: Service mesh service
    compile_service_mesh_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    ( member(polyglot(true), Options)
    ; member(depends_on(Deps), Options), Deps \= []
    ),
    !,
    % Phase 5: Polyglot service
    compile_polyglot_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    ( member(distributed(true), Options)
    ; member(sharding(_), Options)
    ; member(replication(_), Options)
    ; member(cluster(_), Options)
    ),
    !,
    % Phase 6: Distributed service
    compile_distributed_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    ( member(discovery_enabled(true), Options)
    ; member(discovery_backend(_), Options)
    ; member(health_check(_), Options)
    ),
    !,
    % Phase 7: Service Discovery
    compile_discovery_service_rust(Service, RustCode).

compile_service_to_rust(Service, RustCode) :-
    Service = service(_Name, Options, _HandlerSpec),
    ( member(tracing(true), Options)
    ; member(trace_exporter(_), Options)
    ; member(trace_sampling(_), Options)
    ),
    !,
    % Phase 8: Service Tracing
    compile_traced_service_rust(Service, RustCode).

compile_service_to_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Phase 1: In-process service (default)
    % Determine if service is stateful
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name (capitalize first letter)
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Generate the service struct
    ( Stateful = true ->
        format(string(RustCode),
"/// ~wService implements the Service trait for ~w.
pub struct ~wService {
    state: std::sync::RwLock<std::collections::HashMap<String, serde_json::Value>>,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            state: std::sync::RwLock::new(std::collections::HashMap::new()),
        }
    }

    fn state_get(&self, key: &str) -> Option<serde_json::Value> {
        self.state.read().ok()?.get(key).cloned()
    }

    fn state_put(&self, key: &str, value: serde_json::Value) {
        if let Ok(mut state) = self.state.write() {
            state.insert(key.to_string(), value);
        }
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: serde_json::Value) -> Result<serde_json::Value, ServiceError> {
~w
    }
}

// Register ~w service
lazy_static::lazy_static! {
    static ref ~w_SERVICE: std::sync::Arc<~wService> = {
        let service = std::sync::Arc::new(~wService::new());
        register_service(\"~w\", service.clone());
        service
    };
}
", [StructNameAtom, Name, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name, HandlerCode, Name, StructNameAtom, StructNameAtom, StructNameAtom, Name])
    ;
        format(string(RustCode),
"/// ~wService implements the Service trait for ~w.
pub struct ~wService;

impl ~wService {
    pub fn new() -> Self {
        ~wService
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: serde_json::Value) -> Result<serde_json::Value, ServiceError> {
~w
    }
}

// Register ~w service
lazy_static::lazy_static! {
    static ref ~w_SERVICE: std::sync::Arc<~wService> = {
        let service = std::sync::Arc::new(~wService::new());
        register_service(\"~w\", service.clone());
        service
    };
}
", [StructNameAtom, Name, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name, HandlerCode, Name, StructNameAtom, StructNameAtom, StructNameAtom, Name])
    ).

%% generate_service_handler_rust(+HandlerSpec, -Code)
%  Generate Rust handler code from handler specification.
generate_service_handler_rust([], "        Ok(serde_json::Value::Null)").
generate_service_handler_rust(HandlerSpec, Code) :-
    HandlerSpec \= [],
    generate_handler_ops_rust(HandlerSpec, OpsCode),
    format(string(Code), "~w", [OpsCode]).

%% generate_handler_ops_rust(+Ops, -Code)
%  Generate Rust code for handler operations.
generate_handler_ops_rust([], "").
generate_handler_ops_rust([Op|Rest], Code) :-
    generate_handler_op_rust(Op, OpCode),
    generate_handler_ops_rust(Rest, RestCode),
    ( RestCode = "" ->
        Code = OpCode
    ;
        format(string(Code), "~w~n~w", [OpCode, RestCode])
    ).

%% generate_handler_op_rust(+Op, -Code)
%  Generate Rust code for a single handler operation.
generate_handler_op_rust(receive(_Var), Code) :-
    format(string(Code), "        // Bind request", []).

generate_handler_op_rust(respond(Value), Code) :-
    ( var(Value) ->
        format(string(Code), "        Ok(response)", [])
    ; atom(Value) ->
        format(string(Code), "        Ok(serde_json::json!(~w))", [Value])
    ; number(Value) ->
        format(string(Code), "        Ok(serde_json::json!(~w))", [Value])
    ;
        format(string(Code), "        Ok(request)", [])
    ).

generate_handler_op_rust(respond_error(Error), Code) :-
    format(string(Code), "        Err(ServiceError { service: self.name().to_string(), message: \"~w\".to_string() })", [Error]).

generate_handler_op_rust(transform(_In, _Out, Goal), Code) :-
    format(string(Code), "        // transform: ~w", [Goal]).

generate_handler_op_rust(transform(_In, _Out), Code) :-
    format(string(Code), "        // transform", []).

generate_handler_op_rust(state_get(Key, _Var), Code) :-
    format(string(Code), "        let _ = self.state_get(\"~w\");", [Key]).

generate_handler_op_rust(state_put(Key, Value), Code) :-
    ( var(Value) ->
        format(string(Code), "        self.state_put(\"~w\", request.clone());", [Key])
    ;
        format(string(Code), "        self.state_put(\"~w\", serde_json::json!(~w));", [Key, Value])
    ).

generate_handler_op_rust(call_service(ServiceName, _Req, _Resp), Code) :-
    format(string(Code), "        let _ = call_service_impl(\"~w\", request.clone(), &CallServiceOptions::default());", [ServiceName]).

generate_handler_op_rust(Pred/Arity, Code) :-
    format(string(Code), "        // Call predicate: ~w/~w", [Pred, Arity]).

generate_handler_op_rust(Pred, Code) :-
    atom(Pred),
    Pred \= receive, Pred \= respond, Pred \= respond_error,
    format(string(Code), "        // Execute predicate: ~w", [Pred]).

generate_handler_op_rust(_, "        // Unknown operation").

%% ============================================
%% PHASE 2: CROSS-PROCESS SERVICES (Unix Socket)
%% ============================================

%% compile_unix_socket_service_rust(+Service, -RustCode)
%  Generate Rust code for a Unix socket service server.
compile_unix_socket_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract socket path
    member(transport(unix_socket(SocketPath)), Options),
    % Determine if service is stateful
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    % Extract timeout (default 30000ms)
    ( member(timeout(TimeoutMs), Options) -> Timeout = TimeoutMs ; Timeout = 30000 ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name (capitalize first letter)
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    upcase_atom(Name, UpperAtom),
    % Generate the Unix socket service
    ( Stateful = true ->
        format(string(RustCode),
"use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::sync::{Arc, Mutex, RwLock};
use std::collections::HashMap;
use std::thread;
use std::time::Duration;
use serde_json::{json, Value};

/// ~wService implements a Unix socket server for ~w.
pub struct ~wService {
    state: RwLock<HashMap<String, Value>>,
    socket_path: String,
    timeout_ms: u64,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            state: RwLock::new(HashMap::new()),
            socket_path: \"~w\".to_string(),
            timeout_ms: ~w,
        }
    }

    fn state_get(&self, key: &str) -> Option<Value> {
        self.state.read().ok()?.get(key).cloned()
    }

    fn state_put(&self, key: &str, value: Value) {
        if let Ok(mut state) = self.state.write() {
            state.insert(key.to_string(), value);
        }
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }
}

/// Unix socket server implementation
impl ~wService {
    pub fn start_server(&self) -> std::io::Result<()> {
        // Remove existing socket file
        let _ = std::fs::remove_file(&self.socket_path);

        let listener = UnixListener::bind(&self.socket_path)?;
        eprintln!(\"[~w] Server listening on {}\", self.socket_path);

        for stream in listener.incoming() {
            match stream {
                Ok(stream) => {
                    let service = Arc::new(self);
                    thread::spawn(move || {
                        if let Err(e) = handle_connection(stream, service.as_ref()) {
                            eprintln!(\"Connection error: {}\", e);
                        }
                    });
                }
                Err(e) => eprintln!(\"Accept error: {}\", e),
            }
        }
        Ok(())
    }
}

fn handle_connection(stream: UnixStream, service: &~wService) -> std::io::Result<()> {
    stream.set_read_timeout(Some(Duration::from_millis(service.timeout_ms)))?;
    let reader = BufReader::new(&stream);
    let mut writer = &stream;

    for line in reader.lines() {
        match line {
            Ok(line) => {
                let request: Value = match serde_json::from_str(&line) {
                    Ok(v) => v,
                    Err(e) => {
                        send_error(&mut writer, \"parse_error\", &e.to_string())?;
                        continue;
                    }
                };

                let request_id = request.get(\"_id\").and_then(|v| v.as_str()).unwrap_or(\"\");
                let payload = request.get(\"_payload\").cloned().unwrap_or(request.clone());

                match service.call(payload) {
                    Ok(response) => send_response(&mut writer, request_id, response)?,
                    Err(e) => send_error(&mut writer, \"service_error\", &e.message)?,
                }
            }
            Err(_) => break,
        }
    }
    Ok(())
}

fn send_response(writer: &mut &UnixStream, request_id: &str, response: Value) -> std::io::Result<()> {
    let msg = json!({
        \"_id\": request_id,
        \"_status\": \"ok\",
        \"_payload\": response
    });
    writeln!(writer, \"{}\", msg)?;
    writer.flush()
}

fn send_error(writer: &mut &UnixStream, error_type: &str, message: &str) -> std::io::Result<()> {
    let msg = json!({
        \"_status\": \"error\",
        \"_error_type\": error_type,
        \"_message\": message
    });
    writeln!(writer, \"{}\", msg)?;
    writer.flush()
}

lazy_static::lazy_static! {
    static ref ~w_SERVICE: Arc<~wService> = Arc::new(~wService::new());
}

fn main() {
    ctrlc::set_handler(|| {
        eprintln!(\"\\n[~w] Shutting down...\");
        std::process::exit(0);
    }).expect(\"Error setting Ctrl-C handler\");

    ~w_SERVICE.start_server().expect(\"Failed to start server\");
}
", [StructNameAtom, Name, StructNameAtom, StructNameAtom, StructNameAtom, SocketPath, Timeout,
    StructNameAtom, Name, HandlerCode, StructNameAtom, Name, StructNameAtom, UpperAtom, StructNameAtom, StructNameAtom, Name, UpperAtom])
    ;
        % Non-stateful version
        format(string(RustCode),
"use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::sync::Arc;
use std::thread;
use std::time::Duration;
use serde_json::{json, Value};

/// ~wService implements a Unix socket server for ~w.
pub struct ~wService {
    socket_path: String,
    timeout_ms: u64,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            socket_path: \"~w\".to_string(),
            timeout_ms: ~w,
        }
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }
}

/// Unix socket server implementation
impl ~wService {
    pub fn start_server(&self) -> std::io::Result<()> {
        // Remove existing socket file
        let _ = std::fs::remove_file(&self.socket_path);

        let listener = UnixListener::bind(&self.socket_path)?;
        eprintln!(\"[~w] Server listening on {}\", self.socket_path);

        for stream in listener.incoming() {
            match stream {
                Ok(stream) => {
                    let timeout_ms = self.timeout_ms;
                    thread::spawn(move || {
                        if let Err(e) = handle_connection_stateless(stream, timeout_ms) {
                            eprintln!(\"Connection error: {}\", e);
                        }
                    });
                }
                Err(e) => eprintln!(\"Accept error: {}\", e),
            }
        }
        Ok(())
    }
}

fn handle_connection_stateless(stream: UnixStream, timeout_ms: u64) -> std::io::Result<()> {
    stream.set_read_timeout(Some(Duration::from_millis(timeout_ms)))?;
    let reader = BufReader::new(&stream);
    let mut writer = &stream;
    let service = ~wService::new();

    for line in reader.lines() {
        match line {
            Ok(line) => {
                let request: Value = match serde_json::from_str(&line) {
                    Ok(v) => v,
                    Err(e) => {
                        send_error_stateless(&mut writer, \"parse_error\", &e.to_string())?;
                        continue;
                    }
                };

                let request_id = request.get(\"_id\").and_then(|v| v.as_str()).unwrap_or(\"\");
                let payload = request.get(\"_payload\").cloned().unwrap_or(request.clone());

                match service.call(payload) {
                    Ok(response) => send_response_stateless(&mut writer, request_id, response)?,
                    Err(e) => send_error_stateless(&mut writer, \"service_error\", &e.message)?,
                }
            }
            Err(_) => break,
        }
    }
    Ok(())
}

fn send_response_stateless(writer: &mut &UnixStream, request_id: &str, response: Value) -> std::io::Result<()> {
    let msg = json!({
        \"_id\": request_id,
        \"_status\": \"ok\",
        \"_payload\": response
    });
    writeln!(writer, \"{}\", msg)?;
    writer.flush()
}

fn send_error_stateless(writer: &mut &UnixStream, error_type: &str, message: &str) -> std::io::Result<()> {
    let msg = json!({
        \"_status\": \"error\",
        \"_error_type\": error_type,
        \"_message\": message
    });
    writeln!(writer, \"{}\", msg)?;
    writer.flush()
}

lazy_static::lazy_static! {
    static ref ~w_SERVICE: Arc<~wService> = Arc::new(~wService::new());
}

fn main() {
    ctrlc::set_handler(|| {
        eprintln!(\"\\n[~w] Shutting down...\");
        std::process::exit(0);
    }).expect(\"Error setting Ctrl-C handler\");

    ~w_SERVICE.start_server().expect(\"Failed to start server\");
}
", [StructNameAtom, Name, StructNameAtom, StructNameAtom, SocketPath, Timeout, StructNameAtom, Name, HandlerCode,
    StructNameAtom, Name, StructNameAtom, UpperAtom, StructNameAtom, StructNameAtom, Name, UpperAtom, UpperAtom])
    ).

%% compile_unix_socket_client_rust(+ServiceName, +SocketPath, -RustCode)
%  Generate Rust code for a Unix socket service client.
compile_unix_socket_client_rust(Name, SocketPath, RustCode) :-
    % Format the struct name (capitalize first letter)
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    upcase_atom(Name, UpperAtom),
    format(string(RustCode),
"use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;
use std::time::Duration;
use serde_json::{json, Value};
use uuid::Uuid;

/// ~wClient is a client for the ~w Unix socket service.
pub struct ~wClient {
    socket_path: String,
    timeout: Duration,
    stream: Option<UnixStream>,
}

impl ~wClient {
    pub fn new(socket_path: &str, timeout: Duration) -> Self {
        ~wClient {
            socket_path: socket_path.to_string(),
            timeout,
            stream: None,
        }
    }

    pub fn connect(&mut self) -> std::io::Result<()> {
        let stream = UnixStream::connect(&self.socket_path)?;
        stream.set_read_timeout(Some(self.timeout))?;
        stream.set_write_timeout(Some(self.timeout))?;
        self.stream = Some(stream);
        Ok(())
    }

    pub fn disconnect(&mut self) {
        self.stream = None;
    }

    pub fn call(&mut self, request: Value) -> Result<Value, ServiceError> {
        if self.stream.is_none() {
            self.connect().map_err(|e| ServiceError {
                service: \"~w\".to_string(),
                message: e.to_string(),
            })?;
        }

        let stream = self.stream.as_mut().unwrap();
        let request_id = Uuid::new_v4().to_string();
        let msg = json!({
            \"_id\": request_id,
            \"_payload\": request
        });

        writeln!(stream, \"{}\", msg).map_err(|e| ServiceError {
            service: \"~w\".to_string(),
            message: e.to_string(),
        })?;
        stream.flush().map_err(|e| ServiceError {
            service: \"~w\".to_string(),
            message: e.to_string(),
        })?;

        let mut reader = BufReader::new(stream);
        let mut line = String::new();
        reader.read_line(&mut line).map_err(|e| ServiceError {
            service: \"~w\".to_string(),
            message: e.to_string(),
        })?;

        let response: Value = serde_json::from_str(&line).map_err(|e| ServiceError {
            service: \"~w\".to_string(),
            message: e.to_string(),
        })?;

        if response.get(\"_status\").and_then(|v| v.as_str()) == Some(\"ok\") {
            Ok(response.get(\"_payload\").cloned().unwrap_or(Value::Null))
        } else {
            Err(ServiceError {
                service: \"~w\".to_string(),
                message: response.get(\"_message\")
                    .and_then(|v| v.as_str())
                    .unwrap_or(\"Unknown error\")
                    .to_string(),
            })
        }
    }
}

/// Convenience function to call ~w service.
pub fn call_~w(request: Value, socket_path: &str, timeout: Duration) -> Result<Value, ServiceError> {
    let mut client = ~wClient::new(socket_path, timeout);
    client.call(request)
}

lazy_static::lazy_static! {
    static ref DEFAULT_~w_CLIENT: std::sync::Mutex<~wClient> =
        std::sync::Mutex::new(~wClient::new(\"~w\", Duration::from_secs(30)));
}

/// ~wRemoteService wraps the client for use with call_service_impl.
pub struct ~wRemoteService {
    socket_path: String,
}

impl ~wRemoteService {
    pub fn new(socket_path: &str) -> Self {
        ~wRemoteService {
            socket_path: socket_path.to_string(),
        }
    }
}

impl Service for ~wRemoteService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
        call_~w(request, &self.socket_path, Duration::from_secs(30))
    }
}
", [StructNameAtom, Name, StructNameAtom, StructNameAtom, StructNameAtom, Name, Name, Name, Name, Name, Name, Name, Name, StructNameAtom, UpperAtom, StructNameAtom, StructNameAtom, SocketPath, StructNameAtom, StructNameAtom, StructNameAtom, Name, Name, Name, Name]).

%% ============================================
%% PHASE 3: NETWORK SERVICES (TCP)
%% ============================================

%% compile_tcp_service_rust(+Service, -RustCode)
%  Generate Rust code for a TCP network service server.
compile_tcp_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract host and port
    member(transport(tcp(Host, Port)), Options),
    % Determine if service is stateful
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Generate the TCP service
    ( Stateful = true ->
        format(string(RustCode),
"use std::collections::HashMap;
use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, RwLock};
use std::thread;
use serde_json::Value;

pub struct ~wService {
    name: String,
    host: String,
    port: u16,
    state: Arc<RwLock<HashMap<String, Value>>>,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            host: \"~w\".to_string(),
            port: ~w,
            state: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }

    pub fn state_get(&self, key: &str) -> Option<Value> {
        self.state.read().unwrap().get(key).cloned()
    }

    pub fn state_put(&self, key: &str, value: Value) {
        self.state.write().unwrap().insert(key.to_string(), value);
    }

    pub fn start_server(&self) -> std::io::Result<()> {
        let addr = format!(\"{}:{}\", self.host, self.port);
        let listener = TcpListener::bind(&addr)?;
        eprintln!(\"[~w] Server listening on {}\", addr);

        for stream in listener.incoming() {
            match stream {
                Ok(stream) => {
                    let state = Arc::clone(&self.state);
                    thread::spawn(move || {
                        Self::handle_connection(stream, state);
                    });
                }
                Err(e) => eprintln!(\"[~w] Accept error: {}\", e),
            }
        }
        Ok(())
    }

    fn handle_connection(mut stream: TcpStream, _state: Arc<RwLock<HashMap<String, Value>>>) {
        let reader = BufReader::new(stream.try_clone().unwrap());
        for line in reader.lines() {
            match line {
                Ok(line) => {
                    if let Ok(request) = serde_json::from_str::<Value>(&line) {
                        let request_id = request.get(\"_id\").and_then(|v| v.as_str()).unwrap_or(\"\");
                        let payload = request.get(\"_payload\").unwrap_or(&request);
                        // Process request (simplified)
                        let response = serde_json::json!({
                            \"_id\": request_id,
                            \"_status\": \"ok\",
                            \"_payload\": payload
                        });
                        let _ = writeln!(stream, \"{}\", response);
                    }
                }
                Err(_) => break,
            }
        }
    }
}

fn main() {
    let service = ~wService::new();
    if let Err(e) = service.start_server() {
        eprintln!(\"Failed to start server: {}\", e);
        std::process::exit(1);
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Name, Host, Port, HandlerCode, Name, Name, StructNameAtom])
    ;
        format(string(RustCode),
"use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::thread;
use serde_json::Value;

pub struct ~wService {
    name: String,
    host: String,
    port: u16,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            host: \"~w\".to_string(),
            port: ~w,
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }

    pub fn start_server(&self) -> std::io::Result<()> {
        let addr = format!(\"{}:{}\", self.host, self.port);
        let listener = TcpListener::bind(&addr)?;
        eprintln!(\"[~w] Server listening on {}\", addr);

        for stream in listener.incoming() {
            match stream {
                Ok(stream) => {
                    thread::spawn(move || {
                        Self::handle_connection(stream);
                    });
                }
                Err(e) => eprintln!(\"[~w] Accept error: {}\", e),
            }
        }
        Ok(())
    }

    fn handle_connection(mut stream: TcpStream) {
        let reader = BufReader::new(stream.try_clone().unwrap());
        for line in reader.lines() {
            match line {
                Ok(line) => {
                    if let Ok(request) = serde_json::from_str::<Value>(&line) {
                        let request_id = request.get(\"_id\").and_then(|v| v.as_str()).unwrap_or(\"\");
                        let payload = request.get(\"_payload\").unwrap_or(&request);
                        // Process request (simplified)
                        let response = serde_json::json!({
                            \"_id\": request_id,
                            \"_status\": \"ok\",
                            \"_payload\": payload
                        });
                        let _ = writeln!(stream, \"{}\", response);
                    }
                }
                Err(_) => break,
            }
        }
    }
}

fn main() {
    let service = ~wService::new();
    if let Err(e) = service.start_server() {
        eprintln!(\"Failed to start server: {}\", e);
        std::process::exit(1);
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Name, Host, Port, HandlerCode, Name, Name, StructNameAtom])
    ).

%% compile_tcp_client_rust(+ServiceName, +Host, +Port, -RustCode)
%  Generate Rust code for a TCP network service client.
compile_tcp_client_rust(Name, Host, Port, RustCode) :-
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    format(string(RustCode),
"use std::io::{BufRead, BufReader, Write};
use std::net::TcpStream;
use std::time::Duration;
use serde_json::Value;
use uuid::Uuid;

pub struct ~wClient {
    host: String,
    port: u16,
    timeout: Duration,
}

impl ~wClient {
    pub fn new(host: &str, port: u16) -> Self {
        ~wClient {
            host: host.to_string(),
            port,
            timeout: Duration::from_secs(30),
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
        let addr = format!(\"{}:{}\", self.host, self.port);
        let mut stream = TcpStream::connect(&addr)?;
        stream.set_read_timeout(Some(self.timeout))?;
        stream.set_write_timeout(Some(self.timeout))?;

        let request_id = Uuid::new_v4().to_string();
        let msg = serde_json::json!({
            \"_id\": request_id,
            \"_payload\": request
        });
        writeln!(stream, \"{}\", msg)?;

        let reader = BufReader::new(&stream);
        if let Some(Ok(line)) = reader.lines().next() {
            let response: Value = serde_json::from_str(&line)?;
            if response.get(\"_status\").and_then(|v| v.as_str()) == Some(\"ok\") {
                Ok(response.get(\"_payload\").cloned().unwrap_or(Value::Null))
            } else {
                Err(ServiceError::new(
                    \"~w\",
                    response.get(\"_message\").and_then(|v| v.as_str()).unwrap_or(\"Unknown error\")
                ))
            }
        } else {
            Err(ServiceError::new(\"~w\", \"No response from server\"))
        }
    }
}

pub fn call_~w(request: Value) -> Result<Value, ServiceError> {
    let client = ~wClient::new(\"~w\", ~w);
    client.call(request)
}

pub struct ~wRemoteService {
    client: ~wClient,
}

impl ~wRemoteService {
    pub fn new(host: &str, port: u16) -> Self {
        ~wRemoteService {
            client: ~wClient::new(host, port),
        }
    }
}

impl Service for ~wRemoteService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
        self.client.call(request)
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Name, Name, Name, StructNameAtom, Host, Port,
    StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name]).

%% ============================================
%% PHASE 3: NETWORK SERVICES (HTTP/REST)
%% ============================================

%% compile_http_service_rust(+Service, -RustCode)
%  Generate Rust code for an HTTP REST service server.
compile_http_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract endpoint (and optional HTTP options)
    ( member(transport(http(Endpoint, HttpOptions)), Options) ->
        true
    ; member(transport(http(Endpoint)), Options) ->
        HttpOptions = []
    ),
    % Extract host and port from options or use defaults
    ( member(host(Host), HttpOptions) -> true ; Host = '0.0.0.0' ),
    ( member(port(Port), HttpOptions) -> true ; Port = 8080 ),
    % Determine if service is stateful
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Generate the HTTP service (using tiny_http for simplicity)
    ( Stateful = true ->
        format(string(RustCode),
"use std::collections::HashMap;
use std::io::Read;
use std::sync::{Arc, RwLock};
use serde_json::{json, Value};
use tiny_http::{Server, Response, Method, Header};

pub struct ~wService {
    name: String,
    host: String,
    port: u16,
    endpoint: String,
    state: Arc<RwLock<HashMap<String, Value>>>,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            host: \"~w\".to_string(),
            port: ~w,
            endpoint: \"~w\".to_string(),
            state: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }

    pub fn state_get(&self, key: &str) -> Option<Value> {
        self.state.read().unwrap().get(key).cloned()
    }

    pub fn state_put(&self, key: &str, value: Value) {
        self.state.write().unwrap().insert(key.to_string(), value);
    }

    pub fn start_server(&self) -> Result<(), Box<dyn std::error::Error>> {
        let addr = format!(\"{}:{}\", self.host, self.port);
        let server = Server::http(&addr)?;
        eprintln!(\"[~w] HTTP server listening on http://{}{}\", addr, self.endpoint);

        for mut request in server.incoming_requests() {
            let path = request.url().to_string();
            if !path.starts_with(&self.endpoint) {
                let response = Response::from_string(json!({\"error\": \"Not found\"}).to_string())
                    .with_status_code(404)
                    .with_header(Header::from_bytes(&b\"Content-Type\"[..], &b\"application/json\"[..]).unwrap());
                let _ = request.respond(response);
                continue;
            }

            let method = request.method().to_string();
            let mut body = String::new();
            if matches!(request.method(), Method::Post | Method::Put) {
                let _ = request.as_reader().read_to_string(&mut body);
            }

            let req = json!({
                \"method\": method,
                \"path\": path,
                \"body\": if body.is_empty() { Value::Null } else { serde_json::from_str(&body).unwrap_or(Value::Null) }
            });

            let result = self.call(req);
            let (status, response_body) = match result {
                Ok(payload) => (200, json!({\"_status\": \"ok\", \"_payload\": payload})),
                Err(e) => (400, json!({\"_status\": \"error\", \"_message\": e.to_string()})),
            };

            let response = Response::from_string(response_body.to_string())
                .with_status_code(status)
                .with_header(Header::from_bytes(&b\"Content-Type\"[..], &b\"application/json\"[..]).unwrap());
            let _ = request.respond(response);
        }
        Ok(())
    }
}

fn main() {
    let service = ~wService::new();
    if let Err(e) = service.start_server() {
        eprintln!(\"Failed to start server: {}\", e);
        std::process::exit(1);
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Name, Host, Port, Endpoint, HandlerCode, Name, StructNameAtom])
    ;
        format(string(RustCode),
"use std::io::Read;
use serde_json::{json, Value};
use tiny_http::{Server, Response, Method, Header};

pub struct ~wService {
    name: String,
    host: String,
    port: u16,
    endpoint: String,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            host: \"~w\".to_string(),
            port: ~w,
            endpoint: \"~w\".to_string(),
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }

    pub fn start_server(&self) -> Result<(), Box<dyn std::error::Error>> {
        let addr = format!(\"{}:{}\", self.host, self.port);
        let server = Server::http(&addr)?;
        eprintln!(\"[~w] HTTP server listening on http://{}{}\", addr, self.endpoint);

        for mut request in server.incoming_requests() {
            let path = request.url().to_string();
            if !path.starts_with(&self.endpoint) {
                let response = Response::from_string(json!({\"error\": \"Not found\"}).to_string())
                    .with_status_code(404)
                    .with_header(Header::from_bytes(&b\"Content-Type\"[..], &b\"application/json\"[..]).unwrap());
                let _ = request.respond(response);
                continue;
            }

            let method = request.method().to_string();
            let mut body = String::new();
            if matches!(request.method(), Method::Post | Method::Put) {
                let _ = request.as_reader().read_to_string(&mut body);
            }

            let req = json!({
                \"method\": method,
                \"path\": path,
                \"body\": if body.is_empty() { Value::Null } else { serde_json::from_str(&body).unwrap_or(Value::Null) }
            });

            let result = self.call(req);
            let (status, response_body) = match result {
                Ok(payload) => (200, json!({\"_status\": \"ok\", \"_payload\": payload})),
                Err(e) => (400, json!({\"_status\": \"error\", \"_message\": e.to_string()})),
            };

            let response = Response::from_string(response_body.to_string())
                .with_status_code(status)
                .with_header(Header::from_bytes(&b\"Content-Type\"[..], &b\"application/json\"[..]).unwrap());
            let _ = request.respond(response);
        }
        Ok(())
    }
}

fn main() {
    let service = ~wService::new();
    if let Err(e) = service.start_server() {
        eprintln!(\"Failed to start server: {}\", e);
        std::process::exit(1);
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Name, Host, Port, Endpoint, HandlerCode, Name, StructNameAtom])
    ).

%% compile_http_client_rust(+ServiceName, +Endpoint, -RustCode)
%  Generate Rust code for an HTTP REST service client.
compile_http_client_rust(Name, Endpoint, RustCode) :-
    compile_http_client_rust(Name, Endpoint, [], RustCode).

compile_http_client_rust(Name, Endpoint, HttpOptions, RustCode) :-
    % Extract host and port from options or use defaults
    ( member(host(Host), HttpOptions) -> true ; Host = 'localhost' ),
    ( member(port(Port), HttpOptions) -> true ; Port = 8080 ),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    format(string(RustCode),
"use reqwest::blocking::Client;
use serde_json::Value;
use std::time::Duration;

pub struct ~wClient {
    base_url: String,
    client: Client,
}

impl ~wClient {
    pub fn new(host: &str, port: u16) -> Self {
        ~wClient {
            base_url: format!(\"http://{}:{}~w\", host, port),
            client: Client::builder()
                .timeout(Duration::from_secs(30))
                .build()
                .unwrap(),
        }
    }

    pub fn get(&self, path: &str) -> Result<Value, ServiceError> {
        let url = format!(\"{}{}\", self.base_url, path);
        let response = self.client.get(&url).send()?;
        let result: Value = response.json()?;
        if result.get(\"_status\").and_then(|v| v.as_str()) == Some(\"ok\") {
            Ok(result.get(\"_payload\").cloned().unwrap_or(Value::Null))
        } else {
            Err(ServiceError::new(\"~w\", result.get(\"_message\").and_then(|v| v.as_str()).unwrap_or(\"Unknown error\")))
        }
    }

    pub fn post(&self, path: &str, data: Value) -> Result<Value, ServiceError> {
        let url = format!(\"{}{}\", self.base_url, path);
        let response = self.client.post(&url).json(&data).send()?;
        let result: Value = response.json()?;
        if result.get(\"_status\").and_then(|v| v.as_str()) == Some(\"ok\") {
            Ok(result.get(\"_payload\").cloned().unwrap_or(Value::Null))
        } else {
            Err(ServiceError::new(\"~w\", result.get(\"_message\").and_then(|v| v.as_str()).unwrap_or(\"Unknown error\")))
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
        let method = request.get(\"method\").and_then(|v| v.as_str()).unwrap_or(\"POST\");
        let path = request.get(\"path\").and_then(|v| v.as_str()).unwrap_or(\"\");
        let data = request.get(\"body\").cloned().or_else(|| request.get(\"data\").cloned());

        match method {
            \"GET\" => self.get(path),
            _ => self.post(path, data.unwrap_or(Value::Null)),
        }
    }
}

pub fn call_~w(request: Value) -> Result<Value, ServiceError> {
    let client = ~wClient::new(\"~w\", ~w);
    client.call(request)
}

pub struct ~wRemoteService {
    client: ~wClient,
}

impl ~wRemoteService {
    pub fn new(host: &str, port: u16) -> Self {
        ~wRemoteService {
            client: ~wClient::new(host, port),
        }
    }
}

impl Service for ~wRemoteService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
        self.client.call(request)
    }
}
", [StructNameAtom, StructNameAtom, StructNameAtom, Endpoint, Name, Name, Name, StructNameAtom, Host, Port,
    StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name]).

%% ============================================
%% PHASE 4: SERVICE MESH
%% ============================================

%% compile_service_mesh_rust(+Service, -RustCode)
%  Generate Rust code for a service mesh service.
compile_service_mesh_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Extract configurations
    ( ( member(load_balance(LBStrategy), Options) ; member(load_balance(LBStrategy, _), Options) ) ->
        atom_string(LBStrategy, LBStrategyStr)
    ;
        LBStrategyStr = "none"
    ),
    ( ( member(circuit_breaker(threshold(CBThreshold), timeout(CBTimeout)), Options)
      ; ( member(circuit_breaker(CBOpts), Options), is_list(CBOpts),
          ( member(threshold(CBThreshold), CBOpts) -> true ; CBThreshold = 5 ),
          ( member(timeout(CBTimeout), CBOpts) -> true ; CBTimeout = 30000 ) ) ) ->
        true
    ;
        CBThreshold = 5,
        CBTimeout = 30000
    ),
    ( ( member(retry(RetryN, RetryStrategy, RetryOpts), Options) ->
          ( member(delay(RetryDelay), RetryOpts) -> true ; RetryDelay = 100 ),
          ( member(max_delay(RetryMaxDelay), RetryOpts) -> true ; RetryMaxDelay = 30000 )
      ; member(retry(RetryN, RetryStrategy), Options) ->
          RetryDelay = 100,
          RetryMaxDelay = 30000
      ) ->
        atom_string(RetryStrategy, RetryStrategyStr)
    ;
        RetryN = 0,
        RetryStrategyStr = "none",
        RetryDelay = 100,
        RetryMaxDelay = 30000
    ),
    format(string(RustCode),
"use std::sync::atomic::{AtomicU32, AtomicI32, Ordering};
use std::sync::RwLock;
use std::time::{Duration, Instant};
use std::thread;
use serde_json::Value;
use rand::Rng;

#[derive(Clone, Copy, PartialEq)]
pub enum CircuitState {
    Closed,
    Open,
    HalfOpen,
}

pub struct Backend {
    pub name: String,
    pub transport: String,
}

/// ~wService is a service mesh service
pub struct ~wService {
    name: String,
    backends: Vec<Backend>,
    lb_strategy: String,
    cb_threshold: i32,
    cb_timeout: Duration,
    retry_max: i32,
    retry_strategy: String,
    retry_delay: Duration,
    retry_max_delay: Duration,
    circuit_state: RwLock<CircuitState>,
    failure_count: AtomicI32,
    last_failure_time: RwLock<Option<Instant>>,
    rr_index: AtomicU32,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            backends: Vec::new(),
            lb_strategy: \"~w\".to_string(),
            cb_threshold: ~w,
            cb_timeout: Duration::from_millis(~w),
            retry_max: ~w,
            retry_strategy: \"~w\".to_string(),
            retry_delay: Duration::from_millis(~w),
            retry_max_delay: Duration::from_millis(~w),
            circuit_state: RwLock::new(CircuitState::Closed),
            failure_count: AtomicI32::new(0),
            last_failure_time: RwLock::new(None),
            rr_index: AtomicU32::new(0),
        }
    }

    fn select_backend(&self) -> Option<&Backend> {
        if self.backends.is_empty() {
            return None;
        }
        match self.lb_strategy.as_str() {
            \"round_robin\" => {
                let idx = self.rr_index.fetch_add(1, Ordering::SeqCst) as usize;
                Some(&self.backends[idx %% self.backends.len()])
            }
            \"random\" => {
                let idx = rand::thread_rng().gen_range(0..self.backends.len());
                Some(&self.backends[idx])
            }
            _ => Some(&self.backends[0]),
        }
    }

    fn check_circuit(&self) -> bool {
        let state = *self.circuit_state.read().unwrap();
        if state == CircuitState::Open {
            if let Some(last_failure) = *self.last_failure_time.read().unwrap() {
                if last_failure.elapsed() > self.cb_timeout {
                    *self.circuit_state.write().unwrap() = CircuitState::HalfOpen;
                    return true;
                }
            }
            return false;
        }
        true
    }

    fn record_success(&self) {
        let state = *self.circuit_state.read().unwrap();
        if state == CircuitState::HalfOpen {
            *self.circuit_state.write().unwrap() = CircuitState::Closed;
        }
        self.failure_count.store(0, Ordering::SeqCst);
    }

    fn record_failure(&self) {
        let count = self.failure_count.fetch_add(1, Ordering::SeqCst) + 1;
        *self.last_failure_time.write().unwrap() = Some(Instant::now());
        if count >= self.cb_threshold {
            *self.circuit_state.write().unwrap() = CircuitState::Open;
        }
    }

    fn calculate_delay(&self, attempt: i32) -> Duration {
        match self.retry_strategy.as_str() {
            \"fixed\" => self.retry_delay,
            \"linear\" => {
                let d = self.retry_delay * (attempt + 1) as u32;
                d.min(self.retry_max_delay)
            }
            \"exponential\" => {
                let d = self.retry_delay * (1 << attempt) as u32;
                d.min(self.retry_max_delay)
            }
            _ => self.retry_delay,
        }
    }

    fn handle_request(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
        if !self.check_circuit() {
            return Err(ServiceError::new(\"~w\", \"circuit breaker is open\"));
        }
        let max_attempts = (self.retry_max + 1).max(1);
        let mut last_err = None;
        for attempt in 0..max_attempts {
            let _ = self.select_backend();
            match self.handle_request(request.clone()) {
                Ok(result) => {
                    self.record_success();
                    return Ok(result);
                }
                Err(e) => {
                    last_err = Some(e);
                    self.record_failure();
                    if attempt < max_attempts - 1 {
                        thread::sleep(self.calculate_delay(attempt));
                    }
                }
            }
        }
        Err(last_err.unwrap_or_else(|| ServiceError::new(\"~w\", \"all retries exhausted\")))
    }
}

lazy_static::lazy_static! {
    static ref ~w_SERVICE: ~wService = ~wService::new();
}
", [StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name, LBStrategyStr, CBThreshold, CBTimeout, RetryN, RetryStrategyStr, RetryDelay, RetryMaxDelay,
    HandlerCode, StructNameAtom, Name, Name, Name, StructNameAtom, StructNameAtom, StructNameAtom]).

%% ============================================
%% POLYGLOT SERVICES (Phase 5)
%% ============================================

%% compile_polyglot_service_rust(+Service, -RustCode)
%  Generate Rust code for a polyglot service that can call services in other languages.
compile_polyglot_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract target language and dependencies
    ( member(target_language(Lang), Options) -> atom_string(Lang, LangStr) ; LangStr = "rust" ),
    ( member(depends_on(Deps), Options) -> Deps = Dependencies ; Dependencies = [] ),
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    ( member(timeout(Timeout), Options) -> true ; Timeout = 30000 ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name (capitalize first letter)
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Generate service client code for each dependency
    generate_dependency_clients_rust(Dependencies, ClientsCode),
    % Build dependency list string
    build_deps_list_rust(Dependencies, DepsListStr),
    % Build state field and initialization
    ( Stateful = true ->
        StateField = "    state: RwLock<HashMap<String, Value>>,",
        StateInit = "            state: RwLock::new(HashMap::new()),\n"
    ;
        StateField = "",
        StateInit = ""
    ),
    % Generate the polyglot service
    format(string(RustCode),
"use std::collections::HashMap;
use std::sync::RwLock;
use serde::{Deserialize, Serialize};
use serde_json::Value;

/// ServiceClient for calling remote services via HTTP
pub struct ServiceClient {
    name: String,
    endpoint: String,
    language: String,
    client: reqwest::blocking::Client,
}

impl ServiceClient {
    pub fn new(name: &str, endpoint: &str, language: &str) -> Self {
        ServiceClient {
            name: name.to_string(),
            endpoint: endpoint.to_string(),
            language: language.to_string(),
            client: reqwest::blocking::Client::new(),
        }
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
        let response = self.client
            .post(&self.endpoint)
            .json(&request)
            .send()
            .map_err(|e| ServiceError::new(&self.name, &e.to_string()))?;

        if response.status().is_success() {
            response.json::<Value>()
                .map_err(|e| ServiceError::new(&self.name, &e.to_string()))
        } else {
            Err(ServiceError::new(&self.name, &format!(\"HTTP error: {}\", response.status())))
        }
    }
}

/// ServiceRegistry for managing local and remote services
pub struct ServiceRegistry {
    local_services: RwLock<HashMap<String, Box<dyn Service + Send + Sync>>>,
    remote_services: RwLock<HashMap<String, ServiceClient>>,
}

impl ServiceRegistry {
    pub fn new() -> Self {
        ServiceRegistry {
            local_services: RwLock::new(HashMap::new()),
            remote_services: RwLock::new(HashMap::new()),
        }
    }

    pub fn register_local<S: Service + Send + Sync + 'static>(&self, name: &str, service: S) {
        self.local_services.write().unwrap()
            .insert(name.to_string(), Box::new(service));
    }

    pub fn register_remote(&self, name: &str, endpoint: &str, language: &str) {
        self.remote_services.write().unwrap()
            .insert(name.to_string(), ServiceClient::new(name, endpoint, language));
    }

    pub fn call_service(&self, name: &str, request: Value) -> Result<Value, ServiceError> {
        // Try local first
        if let Some(service) = self.local_services.read().unwrap().get(name) {
            return service.call(request);
        }
        // Try remote
        if let Some(client) = self.remote_services.read().unwrap().get(name) {
            return client.call(request);
        }
        Err(ServiceError::new(name, \"Service not found\"))
    }
}

lazy_static::lazy_static! {
    pub static ref SERVICE_REGISTRY: ServiceRegistry = ServiceRegistry::new();
}

~w

/// ~wService is a polyglot service (language: ~w)
pub struct ~wService {
    name: String,
    language: String,
    dependencies: Vec<String>,
    stateful: bool,
    timeout_ms: u64,
~w}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            language: \"~w\".to_string(),
            dependencies: vec![~w],
            stateful: ~w,
            timeout_ms: ~w,
~w        }
    }

    fn call_service(&self, name: &str, request: Value) -> Result<Value, ServiceError> {
        SERVICE_REGISTRY.call_service(name, request)
    }

    fn handle_request(&self, request: Value) -> Result<Value, ServiceError> {
~w
    }
}

impl Service for ~wService {
    fn name(&self) -> &str {
        \"~w\"
    }

    fn call(&self, request: Value) -> Result<Value, ServiceError> {
        self.handle_request(request)
    }
}

lazy_static::lazy_static! {
    pub static ref ~w_SERVICE: ~wService = ~wService::new();
}
", [ClientsCode, StructNameAtom, LangStr, StructNameAtom,
    StateField,
    StructNameAtom, StructNameAtom, Name, LangStr, DepsListStr, Stateful, Timeout,
    StateInit,
    HandlerCode, StructNameAtom, Name, StructNameAtom, StructNameAtom, StructNameAtom]).

%% generate_service_client_rust(+ServiceName, +Endpoint, -RustCode)
%  Generate Rust code for a service client.
generate_service_client_rust(ServiceName, Endpoint, RustCode) :-
    atom_string(ServiceName, ServiceNameStr),
    format(string(RustCode),
"ServiceClient::new(\"~w\", \"~w\", \"remote\")
", [ServiceNameStr, Endpoint]).

%% generate_dependency_clients_rust(+Dependencies, -Code)
%  Generate service client initialization code for dependencies.
generate_dependency_clients_rust([], "").
generate_dependency_clients_rust(Dependencies, Code) :-
    Dependencies \= [],
    maplist(generate_dep_registration_rust, Dependencies, RegCodes),
    atomic_list_concat(RegCodes, '\n', Code).

generate_dep_registration_rust(dep(Name, Lang, Transport), Code) :-
    atom_string(Name, NameStr),
    atom_string(Lang, LangStr),
    extract_endpoint_rust(Transport, Endpoint),
    format(string(Code),
"// Register ~w service (~w)
lazy_static::lazy_static! {
    static ref INIT_~w: () = {
        SERVICE_REGISTRY.register_remote(\"~w\", \"~w\", \"~w\");
        ()
    };
}
", [NameStr, LangStr, Name, NameStr, Endpoint, LangStr]).

extract_endpoint_rust(tcp(Host, Port), Endpoint) :-
    format(string(Endpoint), "http://~w:~w", [Host, Port]).
extract_endpoint_rust(http(Path), Endpoint) :-
    format(string(Endpoint), "http://localhost~w", [Path]).
extract_endpoint_rust(http(Host, Port, Path), Endpoint) :-
    format(string(Endpoint), "http://~w:~w~w", [Host, Port, Path]).
extract_endpoint_rust(unix_socket(Path), Endpoint) :-
    format(string(Endpoint), "unix://~w", [Path]).
extract_endpoint_rust(_, "http://localhost:8080").

%% build_deps_list_rust(+Dependencies, -ListStr)
%  Build a Rust vector literal of dependency names.
build_deps_list_rust([], "").
build_deps_list_rust(Dependencies, ListStr) :-
    Dependencies \= [],
    maplist(dep_to_rust_string, Dependencies, DepStrs),
    atomic_list_concat(DepStrs, ', ', ListStr).

dep_to_rust_string(dep(Name, _, _), Str) :-
    format(string(Str), "\"~w\".to_string()", [Name]).

%% ============================================
%% DISTRIBUTED SERVICES (Phase 6)
%% ============================================

%% compile_distributed_service_rust(+Service, -RustCode)
%  Generate Rust code for a distributed service with sharding and replication.
compile_distributed_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract distributed configuration
    ( member(sharding(ShardStrategy), Options) -> true ; ShardStrategy = hash ),
    ( member(partition_key(PartitionKey), Options) -> true ; PartitionKey = id ),
    ( member(replication(ReplicationFactor), Options) -> true ; ReplicationFactor = 1 ),
    ( member(consistency(ConsistencyLevel), Options) -> true ; ConsistencyLevel = eventual ),
    ( member(cluster(ClusterConfig), Options) -> true ; ClusterConfig = [] ),
    ( member(stateful(true), Options) -> Stateful = true ; Stateful = false ),
    ( member(timeout(Timeout), Options) -> true ; Timeout = 30000 ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Convert atoms to strings
    atom_string(ShardStrategy, ShardStrategyStr),
    atom_string(PartitionKey, PartitionKeyStr),
    atom_string(ConsistencyLevel, ConsistencyStr),
    % Generate cluster nodes
    generate_cluster_nodes_rust(ClusterConfig, NodesCode),
    % Generate the distributed service
    format(string(RustCode),
"use std::collections::{HashMap, BTreeMap};
use std::sync::{Arc, RwLock, atomic::{AtomicU64, AtomicI64, Ordering}};
use std::hash::{Hash, Hasher};
use std::collections::hash_map::DefaultHasher;
use serde::{Deserialize, Serialize};
use serde_json::Value;

// Phase 6: Distributed Service Support

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum ShardingStrategy {
    Hash,
    Range,
    ConsistentHash,
    Geographic,
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum ConsistencyLevel {
    Eventual,
    Strong,
    Quorum,
    ReadYourWrites,
    Causal,
}

#[derive(Clone, Debug)]
pub struct ClusterNode {
    pub node_id: String,
    pub host: String,
    pub port: u16,
    pub region: String,
    pub weight: u32,
    pub healthy: bool,
}

impl ClusterNode {
    pub fn new(node_id: &str, host: &str, port: u16) -> Self {
        ClusterNode {
            node_id: node_id.to_string(),
            host: host.to_string(),
            port,
            region: \"default\".to_string(),
            weight: 1,
            healthy: true,
        }
    }
}

#[derive(Clone, Debug)]
pub struct ShardInfo {
    pub shard_id: u32,
    pub primary_node: String,
    pub replica_nodes: Vec<String>,
    pub key_range: Option<(Value, Value)>,
}

/// Consistent hash ring for distributed routing
pub struct ConsistentHashRing {
    replicas: usize,
    ring: BTreeMap<u64, String>,
}

impl ConsistentHashRing {
    pub fn new(replicas: usize) -> Self {
        ConsistentHashRing {
            replicas,
            ring: BTreeMap::new(),
        }
    }

    fn hash(&self, key: &str) -> u64 {
        let mut hasher = DefaultHasher::new();
        key.hash(&mut hasher);
        hasher.finish()
    }

    pub fn add_node(&mut self, node_id: &str) {
        for i in 0..self.replicas {
            let key = self.hash(&format!(\"{}:{}\", node_id, i));
            self.ring.insert(key, node_id.to_string());
        }
    }

    pub fn remove_node(&mut self, node_id: &str) {
        for i in 0..self.replicas {
            let key = self.hash(&format!(\"{}:{}\", node_id, i));
            self.ring.remove(&key);
        }
    }

    pub fn get_node(&self, key: &str) -> Option<&String> {
        if self.ring.is_empty() {
            return None;
        }
        let h = self.hash(key);
        self.ring.range(h..).next()
            .or_else(|| self.ring.iter().next())
            .map(|(_, v)| v)
    }
}

/// Routes requests to appropriate shards
pub struct ShardRouter {
    pub strategy: ShardingStrategy,
    pub num_shards: u32,
    pub hash_ring: ConsistentHashRing,
    pub range_boundaries: Vec<Value>,
}

impl ShardRouter {
    pub fn new(strategy: ShardingStrategy, num_shards: u32) -> Self {
        ShardRouter {
            strategy,
            num_shards,
            hash_ring: ConsistentHashRing::new(100),
            range_boundaries: Vec::new(),
        }
    }

    pub fn get_shard(&self, partition_key: &Value) -> u32 {
        match self.strategy {
            ShardingStrategy::Hash => self.hash_shard(partition_key),
            ShardingStrategy::ConsistentHash => self.consistent_hash_shard(partition_key),
            ShardingStrategy::Range => self.range_shard(partition_key),
            ShardingStrategy::Geographic => self.hash_shard(partition_key),
        }
    }

    fn hash_shard(&self, key: &Value) -> u32 {
        let mut hasher = DefaultHasher::new();
        format!(\"{}\", key).hash(&mut hasher);
        (hasher.finish() %% self.num_shards as u64) as u32
    }

    fn consistent_hash_shard(&self, key: &Value) -> u32 {
        if let Some(node) = self.hash_ring.get_node(&format!(\"{}\", key)) {
            let mut hasher = DefaultHasher::new();
            node.hash(&mut hasher);
            (hasher.finish() %% self.num_shards as u64) as u32
        } else {
            0
        }
    }

    fn range_shard(&self, key: &Value) -> u32 {
        for (i, boundary) in self.range_boundaries.iter().enumerate() {
            if format!(\"{}\", key) < format!(\"{}\", boundary) {
                return i as u32;
            }
        }
        self.range_boundaries.len() as u32
    }
}

/// Manages data replication
pub struct ReplicationManager {
    pub replication_factor: u32,
    pub consistency: ConsistencyLevel,
}

impl ReplicationManager {
    pub fn new(factor: u32, consistency: ConsistencyLevel) -> Self {
        ReplicationManager {
            replication_factor: factor,
            consistency,
        }
    }

    pub fn write_quorum(&self) -> u32 {
        match self.consistency {
            ConsistencyLevel::Strong => self.replication_factor,
            ConsistencyLevel::Quorum => (self.replication_factor / 2) + 1,
            _ => 1,
        }
    }

    pub fn read_quorum(&self) -> u32 {
        match self.consistency {
            ConsistencyLevel::Strong => self.replication_factor,
            ConsistencyLevel::Quorum => (self.replication_factor / 2) + 1,
            _ => 1,
        }
    }
}

/// ~wService is a distributed service
pub struct ~wService {
    pub name: String,
    pub stateful: bool,
    pub timeout_ms: u64,
    pub sharding_strategy: ShardingStrategy,
    pub partition_key: String,
    pub replication_factor: u32,
    pub consistency: ConsistencyLevel,
    pub nodes: RwLock<HashMap<String, ClusterNode>>,
    pub shards: RwLock<HashMap<u32, ShardInfo>>,
    pub router: RwLock<ShardRouter>,
    pub replication: ReplicationManager,
    state: RwLock<HashMap<String, Value>>,
    request_count: AtomicU64,
}

impl ~wService {
    pub fn new() -> Self {
        ~wService {
            name: \"~w\".to_string(),
            stateful: ~w,
            timeout_ms: ~w,
            sharding_strategy: ShardingStrategy::~w,
            partition_key: \"~w\".to_string(),
            replication_factor: ~w,
            consistency: ConsistencyLevel::~w,
            nodes: RwLock::new(HashMap::new()),
            shards: RwLock::new(HashMap::new()),
            router: RwLock::new(ShardRouter::new(ShardingStrategy::~w, 16)),
            replication: ReplicationManager::new(~w, ConsistencyLevel::~w),
            state: RwLock::new(HashMap::new()),
            request_count: AtomicU64::new(0),
        }
    }

    pub fn add_node(&self, node: ClusterNode) {
        let node_id = node.node_id.clone();
        self.nodes.write().unwrap().insert(node_id.clone(), node);
        self.router.write().unwrap().hash_ring.add_node(&node_id);
    }

    pub fn remove_node(&self, node_id: &str) {
        self.nodes.write().unwrap().remove(node_id);
        self.router.write().unwrap().hash_ring.remove_node(node_id);
    }

    pub fn get_partition_key(&self, request: &Value) -> Value {
        if let Value::Object(obj) = request {
            if let Some(val) = obj.get(&self.partition_key) {
                return val.clone();
            }
        }
        Value::String(format!(\"{:p}\", request))
    }

    pub fn route_request(&self, request: &Value) -> u32 {
        let key = self.get_partition_key(request);
        self.router.read().unwrap().get_shard(&key)
    }

    pub fn call(&self, request: Value) -> Result<Value, ServiceError> {
        self.request_count.fetch_add(1, Ordering::SeqCst);
        let shard_id = self.route_request(&request);
        self.handle_request(request, shard_id)
    }

    fn handle_request(&self, request: Value, _shard_id: u32) -> Result<Value, ServiceError> {
~w
    }
}

// Initialize cluster nodes
~w

lazy_static::lazy_static! {
    pub static ref ~w_SERVICE: ~wService = ~wService::new();
}
", [StructNameAtom, StructNameAtom, StructNameAtom, StructNameAtom, Name, Stateful, Timeout,
    ShardStrategyStr, PartitionKeyStr, ReplicationFactor, ConsistencyStr,
    ShardStrategyStr, ReplicationFactor, ConsistencyStr,
    HandlerCode, NodesCode, StructNameAtom, StructNameAtom, StructNameAtom]).

%% generate_sharding_rust(+Strategy, -Code)
%  Generate Rust code for a specific sharding strategy.
generate_sharding_rust(hash, "ShardingStrategy::Hash").
generate_sharding_rust(range, "ShardingStrategy::Range").
generate_sharding_rust(consistent_hash, "ShardingStrategy::ConsistentHash").
generate_sharding_rust(geographic, "ShardingStrategy::Geographic").
generate_sharding_rust(_, "ShardingStrategy::Hash").

%% generate_replication_rust(+Factor, -Code)
%  Generate Rust replication configuration code.
generate_replication_rust(Factor, Code) :-
    integer(Factor),
    format(string(Code), "replication_factor: ~w", [Factor]).
generate_replication_rust(_, "replication_factor: 1").

%% generate_cluster_nodes_rust(+Config, -Code)
%  Generate Rust code for cluster node initialization.
generate_cluster_nodes_rust([], "// No initial cluster nodes").
generate_cluster_nodes_rust(Nodes, Code) :-
    Nodes \= [],
    maplist(generate_node_init_rust, Nodes, NodeCodes),
    atomic_list_concat(NodeCodes, '\n', Code).

generate_node_init_rust(node(Id, _Host, _Port), Code) :-
    atom_string(Id, IdStr),
    format(string(Code), "// Node ~w initialization would happen here", [IdStr]).
generate_node_init_rust(_, "// Unknown node format").

%% ============================================
%% SERVICE DISCOVERY (Phase 7)
%% ============================================

%% compile_discovery_service_rust(+Service, -RustCode)
%  Generate Rust code for a service with discovery capabilities.
compile_discovery_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract discovery configuration
    ( member(discovery_backend(Backend), Options) -> true ; Backend = consul ),
    ( member(health_check(HealthConfig), Options) -> true ; HealthConfig = http('/health', 30000) ),
    ( member(discovery_ttl(TTL), Options) -> true ; TTL = 60 ),
    ( member(discovery_tags(Tags), Options) -> true ; Tags = [] ),
    ( member(stateful(true), Options) -> Stateful = "true" ; Stateful = "false" ),
    ( member(timeout(Timeout), Options) -> true ; Timeout = 30000 ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Convert to strings
    backend_to_rust_string(Backend, BackendStr),
    health_config_to_rust_string(HealthConfig, HealthTypeStr, HealthEndpointStr, HealthIntervalStr),
    tags_to_rust_vec(Tags, TagsStr),
    % Generate the discovery service
    format(string(RustCode),
"use std::collections::HashMap;
use std::sync::{Arc, RwLock, atomic::{AtomicBool, Ordering}};
use std::time::{Duration, Instant};
use std::thread;
use serde::{Deserialize, Serialize};

// Phase 7: Service Discovery Support

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum DiscoveryBackend {
    Consul,
    Etcd,
    Dns,
    Kubernetes,
    Zookeeper,
    Eureka,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum HealthStatus {
    Healthy,
    Unhealthy,
    Unknown,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceInstance {
    pub service_id: String,
    pub service_name: String,
    pub host: String,
    pub port: u16,
    pub tags: Vec<String>,
    pub metadata: HashMap<String, String>,
    pub health_status: HealthStatus,
    pub last_heartbeat: Instant,
}

#[derive(Debug, Clone)]
pub struct HealthCheckConfig {
    pub check_type: String,
    pub endpoint: String,
    pub interval: Duration,
    pub timeout: Duration,
}

pub trait ServiceRegistry: Send + Sync {
    fn register(&self, instance: &ServiceInstance) -> Result<(), String>;
    fn deregister(&self, service_id: &str) -> Result<(), String>;
    fn discover(&self, service_name: &str, tags: &[String]) -> Vec<ServiceInstance>;
    fn health_check(&self, service_id: &str) -> HealthStatus;
}

pub struct LocalRegistry {
    instances: RwLock<HashMap<String, ServiceInstance>>,
}

impl LocalRegistry {
    pub fn new() -> Self {
        LocalRegistry {
            instances: RwLock::new(HashMap::new()),
        }
    }
}

impl ServiceRegistry for LocalRegistry {
    fn register(&self, instance: &ServiceInstance) -> Result<(), String> {
        let mut instances = self.instances.write().unwrap();
        instances.insert(instance.service_id.clone(), instance.clone());
        Ok(())
    }

    fn deregister(&self, service_id: &str) -> Result<(), String> {
        let mut instances = self.instances.write().unwrap();
        instances.remove(service_id);
        Ok(())
    }

    fn discover(&self, service_name: &str, tags: &[String]) -> Vec<ServiceInstance> {
        let instances = self.instances.read().unwrap();
        instances.values()
            .filter(|i| i.service_name == service_name)
            .filter(|i| tags.is_empty() || tags.iter().all(|t| i.tags.contains(t)))
            .cloned()
            .collect()
    }

    fn health_check(&self, service_id: &str) -> HealthStatus {
        let instances = self.instances.read().unwrap();
        instances.get(service_id)
            .map(|i| {
                if i.last_heartbeat.elapsed() < Duration::from_secs(120) {
                    HealthStatus::Healthy
                } else {
                    HealthStatus::Unhealthy
                }
            })
            .unwrap_or(HealthStatus::Unknown)
    }
}

pub struct HealthChecker {
    config: HealthCheckConfig,
}

impl HealthChecker {
    pub fn new(config: HealthCheckConfig) -> Self {
        HealthChecker { config }
    }

    pub fn check(&self, _host: &str, _port: u16) -> HealthStatus {
        // Simplified health check - in production would make actual HTTP/TCP checks
        HealthStatus::Healthy
    }
}

/// ~wService - Discoverable Service
/// Backend: ~w
/// TTL: ~w seconds
pub struct ~wService {
    pub name: String,
    pub host: String,
    pub port: u16,
    pub stateful: bool,
    pub timeout_ms: u64,
    pub ttl: u64,
    pub tags: Vec<String>,
    state: RwLock<HashMap<String, serde_json::Value>>,
    running: AtomicBool,
    registry: Arc<dyn ServiceRegistry>,
    health_config: HealthCheckConfig,
    health_checker: HealthChecker,
    instance: RwLock<ServiceInstance>,
}

impl ~wService {
    pub fn new(host: &str, port: u16) -> Self {
        let health_config = HealthCheckConfig {
            check_type: \"~w\".to_string(),
            endpoint: \"~w\".to_string(),
            interval: Duration::from_millis(~w),
            timeout: Duration::from_secs(5),
        };
        let instance = ServiceInstance {
            service_id: format!(\"{}-{}-{}\", \"~w\", host, port),
            service_name: \"~w\".to_string(),
            host: host.to_string(),
            port,
            tags: ~w,
            metadata: HashMap::new(),
            health_status: HealthStatus::Unknown,
            last_heartbeat: Instant::now(),
        };
        ~wService {
            name: \"~w\".to_string(),
            host: host.to_string(),
            port,
            stateful: ~w,
            timeout_ms: ~w,
            ttl: ~w,
            tags: ~w,
            state: RwLock::new(HashMap::new()),
            running: AtomicBool::new(false),
            registry: Arc::new(~w),
            health_config: health_config.clone(),
            health_checker: HealthChecker::new(health_config),
            instance: RwLock::new(instance),
        }
    }

    pub fn register(&self) -> Result<(), String> {
        let instance = self.instance.read().unwrap();
        self.registry.register(&instance)?;
        self.start_heartbeat();
        Ok(())
    }

    pub fn deregister(&self) -> Result<(), String> {
        self.stop_heartbeat();
        let instance = self.instance.read().unwrap();
        self.registry.deregister(&instance.service_id)
    }

    pub fn discover_peers(&self) -> Vec<ServiceInstance> {
        self.registry.discover(&self.name, &self.tags)
    }

    fn start_heartbeat(&self) {
        self.running.store(true, Ordering::SeqCst);
    }

    fn stop_heartbeat(&self) {
        self.running.store(false, Ordering::SeqCst);
    }

    pub fn call(&self, request: serde_json::Value) -> serde_json::Value {
        self.handle_request(request)
    }

    fn handle_request(&self, request: serde_json::Value) -> serde_json::Value {
~w
    }
}

lazy_static::lazy_static! {
    pub static ref ~w_SERVICE: ~wService = ~wService::new(\"localhost\", 8080);
}
", [StructNameAtom, BackendStr, TTL, StructNameAtom,
    StructNameAtom, HealthTypeStr, HealthEndpointStr, HealthIntervalStr,
    Name, Name, TagsStr,
    StructNameAtom, Name, Stateful, Timeout, TTL, TagsStr, BackendStr,
    HandlerCode, Name, StructNameAtom, StructNameAtom]).

%% backend_to_rust_string(+Backend, -String)
%  Convert discovery backend to Rust code string.
backend_to_rust_string(consul, "LocalRegistry::new()").
backend_to_rust_string(etcd, "LocalRegistry::new()").
backend_to_rust_string(dns, "LocalRegistry::new()").
backend_to_rust_string(kubernetes, "LocalRegistry::new()").
backend_to_rust_string(_, "LocalRegistry::new()").

%% health_config_to_rust_string(+Config, -TypeStr, -EndpointStr, -IntervalStr)
%  Extract health check type, endpoint and interval from config.
health_config_to_rust_string(http(Path, Interval), "http", Path, Interval) :- !.
health_config_to_rust_string(http(Path, Interval, _), "http", Path, Interval) :- !.
health_config_to_rust_string(tcp(Port, Interval), "tcp", Port, Interval) :- !.
health_config_to_rust_string(_, "http", "/health", 30000).

%% tags_to_rust_vec(+Tags, -String)
%  Convert Prolog list of tags to Rust vec string.
tags_to_rust_vec([], "vec![]").
tags_to_rust_vec(Tags, Code) :-
    Tags \= [],
    maplist(quote_rust_string, Tags, QuotedTags),
    atomic_list_concat(QuotedTags, ', ', Inner),
    format(string(Code), "vec![~w]", [Inner]).

quote_rust_string(Atom, Quoted) :-
    format(string(Quoted), "\"~w\".to_string()", [Atom]).

%% generate_health_check_rust(+Config, -Code)
%  Generate Rust health check configuration code.
generate_health_check_rust(http(Path, Interval), Code) :-
    format(string(Code), "HealthCheckConfig { check_type: \"http\".to_string(), endpoint: \"~w\".to_string(), interval: Duration::from_millis(~w), timeout: Duration::from_secs(5) }", [Path, Interval]).
generate_health_check_rust(_, "HealthCheckConfig { check_type: \"http\".to_string(), endpoint: \"/health\".to_string(), interval: Duration::from_secs(30), timeout: Duration::from_secs(5) }").

%% generate_service_registry_rust(+Backend, -Code)
%  Generate Rust service registry initialization code.
generate_service_registry_rust(consul, "LocalRegistry::new()").
generate_service_registry_rust(_, "LocalRegistry::new()").

%% ============================================
%% SERVICE TRACING (Phase 8)
%% ============================================

%% compile_traced_service_rust(+Service, -RustCode)
%  Generate Rust code for a service with distributed tracing.
compile_traced_service_rust(service(Name, Options, HandlerSpec), RustCode) :-
    % Extract tracing configuration
    ( member(trace_exporter(Exporter), Options) -> true ; Exporter = otlp ),
    ( member(trace_sampling(SamplingRate), Options) -> true ; SamplingRate = 1.0 ),
    ( member(trace_service_name(ServiceName), Options) -> true ; ServiceName = Name ),
    ( member(trace_propagation(Propagation), Options) -> true ; Propagation = w3c ),
    ( member(trace_attributes(Attributes), Options) -> true ; Attributes = [] ),
    ( member(stateful(true), Options) -> Stateful = "true" ; Stateful = "false" ),
    ( member(timeout(Timeout), Options) -> true ; Timeout = 30000 ),
    % Generate handler code
    generate_service_handler_rust(HandlerSpec, HandlerCode),
    % Format the struct name
    atom_codes(Name, [First|Rest]),
    ( First >= 0'a, First =< 0'z ->
        Upper is First - 32,
        StructName = [Upper|Rest]
    ;
        StructName = [First|Rest]
    ),
    atom_codes(StructNameAtom, StructName),
    % Convert to strings
    exporter_to_rust_string(Exporter, ExporterStr),
    propagation_to_rust_string(Propagation, PropagationStr),
    attributes_to_rust_map(Attributes, AttrsStr),
    atom_string(ServiceName, ServiceNameStr),
    % Generate the traced service
    format(string(RustCode),
"use std::collections::HashMap;
use std::sync::{Arc, RwLock, Mutex};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use rand::Rng;

// Phase 8: Service Tracing Support (OpenTelemetry-compatible)

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum TraceExporter {
    Otlp,
    Jaeger,
    Zipkin,
    Datadog,
    Console,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PropagationFormat {
    W3c,
    B3,
    B3Multi,
    Jaeger,
    XRay,
    Datadog,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum SpanKind {
    Internal,
    Server,
    Client,
    Producer,
    Consumer,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum SpanStatus {
    Unset,
    Ok,
    Error,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpanContext {
    pub trace_id: String,
    pub span_id: String,
    pub trace_flags: u8,
    pub trace_state: String,
}

impl SpanContext {
    pub fn new() -> Self {
        SpanContext {
            trace_id: format!(\"{}{}\", Uuid::new_v4().to_string().replace(\"-\", \"\"),
                             &Uuid::new_v4().to_string().replace(\"-\", \"\")[..8]),
            span_id: Uuid::new_v4().to_string().replace(\"-\", \"\")[..16].to_string(),
            trace_flags: 1,
            trace_state: String::new(),
        }
    }

    pub fn to_traceparent(&self) -> String {
        format!(\"00-{}-{}-{:02x}\", self.trace_id, self.span_id, self.trace_flags)
    }

    pub fn from_traceparent(header: &str) -> Option<Self> {
        let parts: Vec<&str> = header.split('-').collect();
        if parts.len() >= 4 {
            Some(SpanContext {
                trace_id: parts[1].to_string(),
                span_id: parts[2].to_string(),
                trace_flags: u8::from_str_radix(parts[3], 16).unwrap_or(1),
                trace_state: String::new(),
            })
        } else {
            None
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpanEvent {
    pub name: String,
    pub timestamp_ns: u128,
    pub attributes: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Span {
    pub name: String,
    pub context: SpanContext,
    pub parent_context: Option<SpanContext>,
    pub kind: SpanKind,
    pub status: SpanStatus,
    pub start_time_ns: u128,
    pub end_time_ns: u128,
    pub attributes: HashMap<String, serde_json::Value>,
    pub events: Vec<SpanEvent>,
}

impl Span {
    pub fn new(name: &str, kind: SpanKind, parent: Option<SpanContext>) -> Self {
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        Span {
            name: name.to_string(),
            context: SpanContext::new(),
            parent_context: parent,
            kind,
            status: SpanStatus::Unset,
            start_time_ns: now,
            end_time_ns: 0,
            attributes: HashMap::new(),
            events: Vec::new(),
        }
    }

    pub fn set_attribute(&mut self, key: &str, value: serde_json::Value) {
        self.attributes.insert(key.to_string(), value);
    }

    pub fn add_event(&mut self, name: &str, attrs: HashMap<String, serde_json::Value>) {
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        self.events.push(SpanEvent {
            name: name.to_string(),
            timestamp_ns: now,
            attributes: attrs,
        });
    }

    pub fn set_status(&mut self, status: SpanStatus, description: Option<&str>) {
        self.status = status;
        if let Some(desc) = description {
            self.attributes.insert(\"status.description\".to_string(),
                                   serde_json::Value::String(desc.to_string()));
        }
    }

    pub fn end(&mut self) {
        self.end_time_ns = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
    }
}

pub trait SpanExporter: Send + Sync {
    fn export(&self, spans: &[Span]) -> Result<(), String>;
}

pub struct ConsoleExporter;

impl SpanExporter for ConsoleExporter {
    fn export(&self, spans: &[Span]) -> Result<(), String> {
        for span in spans {
            println!(\"[TRACE] {:?}\", serde_json::to_string(span).unwrap_or_default());
        }
        Ok(())
    }
}

pub struct Tracer {
    service_name: String,
    sampling_rate: f64,
    exporter: Arc<dyn SpanExporter>,
    propagation: PropagationFormat,
    spans: Mutex<Vec<Span>>,
}

impl Tracer {
    pub fn new(service_name: &str, sampling_rate: f64, exporter: Arc<dyn SpanExporter>, propagation: PropagationFormat) -> Self {
        Tracer {
            service_name: service_name.to_string(),
            sampling_rate,
            exporter,
            propagation,
            spans: Mutex::new(Vec::new()),
        }
    }

    pub fn should_sample(&self) -> bool {
        rand::thread_rng().gen::<f64>() < self.sampling_rate
    }

    pub fn start_span(&self, name: &str, kind: SpanKind, parent: Option<SpanContext>) -> Option<Span> {
        if !self.should_sample() {
            return None;
        }
        let mut span = Span::new(name, kind, parent);
        span.set_attribute(\"service.name\", serde_json::Value::String(self.service_name.clone()));
        Some(span)
    }

    pub fn end_span(&self, mut span: Span) {
        span.end();
        if span.status == SpanStatus::Unset {
            span.status = SpanStatus::Ok;
        }
        let mut spans = self.spans.lock().unwrap();
        spans.push(span);
    }

    pub fn extract_context(&self, headers: &HashMap<String, String>) -> Option<SpanContext> {
        match self.propagation {
            PropagationFormat::W3c => {
                headers.get(\"traceparent\").and_then(|h| SpanContext::from_traceparent(h))
            }
            PropagationFormat::B3 | PropagationFormat::B3Multi => {
                let trace_id = headers.get(\"X-B3-TraceId\")?;
                let span_id = headers.get(\"X-B3-SpanId\")?;
                Some(SpanContext {
                    trace_id: trace_id.clone(),
                    span_id: span_id.clone(),
                    trace_flags: 1,
                    trace_state: String::new(),
                })
            }
            _ => None,
        }
    }

    pub fn inject_context(&self, span: &Span, headers: &mut HashMap<String, String>) {
        match self.propagation {
            PropagationFormat::W3c => {
                headers.insert(\"traceparent\".to_string(), span.context.to_traceparent());
            }
            PropagationFormat::B3 | PropagationFormat::B3Multi => {
                headers.insert(\"X-B3-TraceId\".to_string(), span.context.trace_id.clone());
                headers.insert(\"X-B3-SpanId\".to_string(), span.context.span_id.clone());
                headers.insert(\"X-B3-Sampled\".to_string(), \"1\".to_string());
            }
            _ => {}
        }
    }

    pub fn flush(&self) -> Result<(), String> {
        let mut spans = self.spans.lock().unwrap();
        if !spans.is_empty() {
            let result = self.exporter.export(&spans);
            spans.clear();
            result
        } else {
            Ok(())
        }
    }
}

/// ~wService - Traced Service
/// Service Name: ~w
/// Exporter: ~w
/// Sampling Rate: ~w
/// Propagation: ~w
pub struct ~wService {
    pub name: String,
    pub stateful: bool,
    pub timeout_ms: u64,
    state: RwLock<HashMap<String, serde_json::Value>>,
    tracer: Arc<Tracer>,
    default_attributes: HashMap<String, serde_json::Value>,
}

impl ~wService {
    pub fn new() -> Self {
        let exporter: Arc<dyn SpanExporter> = ~w;
        ~wService {
            name: \"~w\".to_string(),
            stateful: ~w,
            timeout_ms: ~w,
            state: RwLock::new(HashMap::new()),
            tracer: Arc::new(Tracer::new(
                \"~w\",
                ~w,
                exporter,
                PropagationFormat::~w,
            )),
            default_attributes: ~w,
        }
    }

    pub fn call(&self, request: serde_json::Value, headers: Option<HashMap<String, String>>) -> serde_json::Value {
        let headers = headers.unwrap_or_default();
        let parent_ctx = self.tracer.extract_context(&headers);

        if let Some(mut span) = self.tracer.start_span(
            &format!(\"{}.call\", self.name),
            SpanKind::Server,
            parent_ctx,
        ) {
            for (k, v) in &self.default_attributes {
                span.set_attribute(k, v.clone());
            }
            span.set_attribute(\"request.type\", serde_json::Value::String(\"json\".to_string()));

            let result = self.handle_request(request);

            span.set_attribute(\"response.type\", serde_json::Value::String(\"json\".to_string()));
            self.tracer.end_span(span);

            result
        } else {
            self.handle_request(request)
        }
    }

    pub fn flush_traces(&self) -> Result<(), String> {
        self.tracer.flush()
    }

    fn handle_request(&self, request: serde_json::Value) -> serde_json::Value {
~w
    }
}

lazy_static::lazy_static! {
    pub static ref ~w_SERVICE: ~wService = ~wService::new();
}
", [StructNameAtom, ServiceNameStr, ExporterStr, SamplingRate, PropagationStr,
    StructNameAtom,
    StructNameAtom, ExporterStr, StructNameAtom,
    Name, Stateful, Timeout,
    ServiceNameStr, SamplingRate, PropagationStr, AttrsStr,
    HandlerCode, Name, StructNameAtom, StructNameAtom]).

%% exporter_to_rust_string(+Exporter, -String)
%  Convert trace exporter to Rust code string.
exporter_to_rust_string(otlp, "Arc::new(ConsoleExporter)").
exporter_to_rust_string(jaeger, "Arc::new(ConsoleExporter)").
exporter_to_rust_string(zipkin, "Arc::new(ConsoleExporter)").
exporter_to_rust_string(console, "Arc::new(ConsoleExporter)").
exporter_to_rust_string(none, "Arc::new(ConsoleExporter)").
exporter_to_rust_string(_, "Arc::new(ConsoleExporter)").

%% propagation_to_rust_string(+Propagation, -String)
%  Convert propagation format to Rust enum string.
propagation_to_rust_string(w3c, "W3c").
propagation_to_rust_string(b3, "B3").
propagation_to_rust_string(b3_multi, "B3Multi").
propagation_to_rust_string(jaeger, "Jaeger").
propagation_to_rust_string(xray, "XRay").
propagation_to_rust_string(datadog, "Datadog").
propagation_to_rust_string(_, "W3c").

%% attributes_to_rust_map(+Attributes, -String)
%  Convert attribute list to Rust HashMap string.
attributes_to_rust_map([], "HashMap::new()").
attributes_to_rust_map(Attrs, Code) :-
    Attrs \= [],
    maplist(attr_to_rust, Attrs, AttrStrs),
    atomic_list_concat(AttrStrs, ', ', Inner),
    format(string(Code), "vec![~w].into_iter().collect()", [Inner]).

attr_to_rust(Key=Value, Code) :-
    format(string(Code), "(\"~w\".to_string(), serde_json::Value::String(\"~w\".to_string()))", [Key, Value]).
attr_to_rust(Key-Value, Code) :-
    format(string(Code), "(\"~w\".to_string(), serde_json::Value::String(\"~w\".to_string()))", [Key, Value]).

%% generate_tracer_rust(+Config, -Code)
%  Generate Rust tracer initialization code.
generate_tracer_rust(config(ServiceName, SamplingRate, Exporter), Code) :-
    exporter_to_rust_string(Exporter, ExporterStr),
    format(string(Code), "Tracer::new(\"~w\", ~w, ~w, PropagationFormat::W3c)", [ServiceName, SamplingRate, ExporterStr]).

%% generate_span_context_rust(+Context, -Code)
%  Generate Rust span context code.
generate_span_context_rust(context(TraceId, SpanId), Code) :-
    format(string(Code), "SpanContext { trace_id: \"~w\".to_string(), span_id: \"~w\".to_string(), trace_flags: 1, trace_state: String::new() }", [TraceId, SpanId]).
generate_span_context_rust(_, "SpanContext::new()").

%% ============================================
%% PUBLIC API
%% ============================================ 

compile_predicate_to_rust(PredIndicator, Options, RustCode) :- 
    (   PredIndicator = Module:Name/Arity
    ->  Pred = Name, GoalModule = Module
    ;   PredIndicator = Name/Arity, GoalModule = user, Pred = Name
    ),
    format('=== Compiling ~w/~w to Rust (Module: ~w) ===~n', [Pred, Arity, GoalModule]),

    (   option(json_input(true), Options)
    ->  format('  Mode: JSON input~n'),
        compile_json_input_to_rust(Pred, Arity, Options, RustCode)
    ;   option(json_output(true), Options)
    ->  format('  Mode: JSON output~n'),
        compile_json_output_to_rust(Pred, Arity, Options, RustCode)
    ;   option(db_backend(Backend), Options),
        Backend \= none
    ->  format('  Mode: Database Backend (~w)~n', [Backend]),
        compile_db_backend_to_rust(Pred, Arity, Backend, Options, RustCode)
    ;   functor(SemHead, Pred, Arity),
        GoalModule:clause(SemHead, SemBody),
        is_semantic_predicate(SemBody)
    ->  format('  Mode: Semantic Runtime~n'),
        compile_semantic_mode(Pred, Arity, SemHead, SemBody, RustCode)
    ;   option(aggregation(AggOp), Options, none),
        AggOp \= none
    ->  option(field_delimiter(FieldDelim), Options, colon),
        option(include_main(IncludeMain), Options, true),
        compile_aggregation_to_rust(Pred, Arity, AggOp, FieldDelim, IncludeMain, RustCode)
    ;   compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode)
    ).

is_semantic_predicate(Body) :-
    %% Use copy_term to avoid binding variables in Body
    copy_term(Body, BodyCopy),
    (   sub_term(Sub, BodyCopy), nonvar(Sub), functor(Sub, crawler_run, 2)
    ;   sub_term(Sub, BodyCopy), nonvar(Sub), functor(Sub, graph_search, 5)
    ;   sub_term(Sub, BodyCopy), nonvar(Sub), functor(Sub, graph_search, 4)
    ).

compile_semantic_mode(Pred, _Arity, Head, Body, RustCode) :-
    % Generate main.rs content
    generate_semantic_main(Pred, Head, Body, RustCode).

generate_semantic_main(_Pred, _Head, Body, RustCode) :-
    % Simple translation for now
    translate_semantic_body(Body, BodyCode),
    format(string(RustCode), '
mod importer;
mod crawler;
mod searcher;
mod llm;
mod embedding;

use importer::PtImporter;
use crawler::PtCrawler;
use searcher::PtSearcher;
use embedding::EmbeddingProvider;
use llm::LLMProvider;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    // Initialize Runtime
    let embedding = EmbeddingProvider::new("models/model.safetensors", "models/tokenizer.json")?;
    let importer = PtImporter::new("data.redb")?;
    let crawler = PtCrawler::new(importer, embedding.clone());
    let searcher = PtSearcher::new("data.redb", embedding)?;
    // let llm = LLMProvider::new("gemini-2.5-flash");

    ~s

    Ok(())
}
', [BodyCode]).

translate_semantic_body((A, B), Code) :- !,
    translate_semantic_body(A, C1),
    translate_semantic_body(B, C2),
    format(string(Code), "~s\n    ~s", [C1, C2]).

translate_semantic_body(crawler_run(Seeds, Depth), Code) :-
    % Convert seeds to Rust vec
    (   is_list(Seeds) -> maplist(atom_string, Seeds, SeedStrs), maplist(rust_quote, SeedStrs, QuotedSeeds), atomic_list_concat(QuotedSeeds, ', ', SeedList)
    ;   format(string(SeedList), '"~w"', [Seeds]) % Single seed
    ),
    format(string(Code), 'crawler.crawl(&vec![~s], ~w)?;', [SeedList, Depth]).

translate_semantic_body(graph_search(Query, TopK, Hops, Results), Code) :-
    translate_semantic_body(graph_search(Query, TopK, Hops, [mode(vector)], Results), Code).

translate_semantic_body(graph_search(Query, TopK, Hops, Mode, _Results), Code) :-
    % Results variable binding not supported in this simple mode yet
    % Just printing results
    (   Mode = [mode(M)] -> atom_string(M, ModeStr) ; ModeStr = "vector" ),
    format(string(Code), 'let results = searcher.graph_search("~w", ~w, ~w, "~w")?;\n    println!("{}", serde_json::to_string_pretty(&results)?);', [Query, TopK, Hops, ModeStr]).

translate_semantic_body(suggest_bookmarks(Query, _Suggestions), Code) :-
    format(string(Code), 'let output = searcher.suggest_bookmarks("~w", 5)?;\n    println!("{}", output);', [Query]).

translate_semantic_body(semantic_search(Query, TopK, _Results), Code) :-
    format(string(Code), 'let results = searcher.text_search("~w", ~w)?;\n    println!("{}", serde_json::to_string_pretty(&results)?);', [Query, TopK]).

translate_semantic_body(upsert_object(Id, Type, Data), Code) :-
    % Simple translation assuming Data is a string literal or variable that can be stringified
    (   string(Data) -> format(string(DataStr), '"~s"', [Data])
    ;   atom(Data) -> format(string(DataStr), '"~w"', [Data])
    ;   format(string(DataStr), '"~w"', [Data]) % Fallback
    ),
    format(string(Code), 'importer.upsert_object("~w", "~w", &serde_json::from_str(~s)?)?;', [Id, Type, DataStr]).

translate_semantic_body(true, "").

rust_quote(S, Q) :- format(string(Q), "\"~s\"", [S]).

% Helper for sub_term if not available
:- if(\+ current_predicate(sub_term/2)).
sub_term(T, T).
sub_term(Sub, Term) :-
    compound(Term),
    arg(_, Term, Arg),
    sub_term(Sub, Arg).
:- endif.
% Try native clause body lowering first
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(foreign_lowering(ForeignLowering), Options, false),
    ForeignLowering == true,
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses \= [],
    rust_foreign_lowering_spec(Pred, Arity, Clauses, ForeignSpec),
    !,
    wam_target:compile_predicate_to_wam(user:Pred/Arity, Options, WamCode),
    wam_rust_target:compile_wam_predicate_to_rust(
        Pred/Arity,
        WamCode,
        [foreign_lowering(ForeignSpec)|Options],
        RustCode
    ).
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(include_main(IncludeMain), Options, true),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses = [SingleHead-SingleBody],
    classify_aggregate(SingleBody, AggInfo),
    compile_aggregate_rule_to_rust(Pred, Arity, SingleHead, AggInfo, IncludeMain, RustCode),
    !.
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(include_main(IncludeMain), Options, true),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses = [SingleHead-SingleBody],
    compile_rust_foreign_multistage_join_stream_wrapper(Pred, Arity, SingleHead, SingleBody, IncludeMain, RustCode),
    !.
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(include_main(IncludeMain), Options, true),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses = [SingleHead-SingleBody],
    compile_rust_foreign_join_stream_wrapper(Pred, Arity, SingleHead, SingleBody, IncludeMain, RustCode),
    !.
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(include_main(IncludeMain), Options, true),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses = [SingleHead-SingleBody],
    compile_rust_foreign_stream_wrapper(Pred, Arity, SingleHead, SingleBody, IncludeMain, RustCode),
    !.
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(include_main(IncludeMain), Options, true),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses \= [],
    native_rust_clause_body(Pred/Arity, Clauses, FuncBody),
    !,
    atom_string(Pred, PredStr),
    Arity1 is Arity - 1,
    build_rust_arg_list(Arity1, ArgList),
    %% Infer return type: if any clause has arithmetic output, use i64
    infer_rust_native_return_type(Clauses, RetType),
    format(string(FuncCode),
'fn ~w(~w) -> ~w {
~w
}', [PredStr, ArgList, RetType, FuncBody]),
    (   IncludeMain
    ->  format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Native Clause Lowering

~w

fn main() {
    // Example usage
    println!("{}", ~w(0));
}
', [FuncCode, PredStr])
    ;   RustCode = FuncCode
    ).
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    option(field_delimiter(FieldDelim), Options, colon),
    option(include_main(IncludeMain), Options, true),
    option(unique(Unique), Options, true),

    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),

    (   Clauses = [] -> fail
    ;   maplist(is_fact_clause, Clauses) ->
        compile_facts_to_rust(Pred, Arity, Clauses, FieldDelim, RustCode)
    ;   is_general_recursive_pattern_rust(Pred, Arity, Clauses) ->
        format('Type: general_recursion_arity_~w~n', [Arity]),
        (   rust_computed_increment_pattern(Pred, Clauses, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven)
        ->  compile_general_recursive_accumulation_to_rust(Pred, Arity, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, RustCode)
        %% Check for per-path visited pattern and branch code generation
        ;   rust_clauses_to_ppv_pairs(Clauses, PPVPairs),
            is_per_path_visited_pattern(Pred, Arity, PPVPairs, VisitedPos)
        ->  format('  Per-path visited pattern detected (visited at position ~w)~n', [VisitedPos]),
            compile_general_recursive_to_rust(Pred, Arity, Clauses, RustCode)
        ;   compile_general_recursive_to_rust_no_visited(Pred, Arity, Clauses, RustCode)
        )
    ;   Clauses = [SingleHead-SingleBody], SingleBody \= true ->
        compile_single_rule_to_rust(Pred, Arity, SingleHead, SingleBody, FieldDelim, Unique, IncludeMain, RustCode)
    ;   fail
    ).

%% WAM fallback tier: when all native lowering tiers fail, compile
%% via WAM and generate Rust wrapper. Controlled by wam_fallback option
%% (default: true). Set wam_fallback(false) to disable and see how far
%% native lowering can go.
%%
%% To exclude WAM fallback globally:
%%   :- set_prolog_flag(rust_wam_fallback, false).
%% Or per-call:
%%   compile_predicate_to_rust(Pred/Arity, [wam_fallback(false)], Code).
compile_predicate_to_rust_normal(Pred, Arity, Options, RustCode) :-
    % Check if WAM fallback is enabled
    option(wam_fallback(WamFallback), Options, default),
    (   WamFallback == false -> fail  % explicitly disabled
    ;   WamFallback == default,
        catch(current_prolog_flag(rust_wam_fallback, false), _, fail)
    ->  fail  % disabled via Prolog flag
    ;   true  % enabled (default)
    ),
    % All native tiers failed — fall back to WAM compilation
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses \= [],
    format(user_error, 'WAM fallback: ~w/~w resists native lowering, using WAM compilation~n', [Pred, Arity]),
    (   PredIndicator = user:Pred/Arity,
        wam_target:compile_predicate_to_wam(PredIndicator, Options, WamCode)
    ->  wam_rust_target:compile_wam_predicate_to_rust(Pred/Arity, WamCode, Options, RustCode)
    ;   fail
    ).

rust_foreign_lowering_spec(Pred, Arity, Clauses, ForeignSpec) :-
    rust_recursive_kernel(Pred, Arity, Clauses, Kernel),
    rust_recursive_kernel_spec(Kernel, ForeignSpec).

rust_recursive_kernel(Pred, Arity, Clauses, Kernel) :-
    rust_recursive_kernel_detector(KernelKind, Detector),
    call(Detector, Pred, Arity, Clauses, Kernel),
    Kernel = recursive_kernel(KernelKind, _, _).

rust_recursive_kernel_detector(category_ancestor, rust_recursive_kernel_category_ancestor).
rust_recursive_kernel_detector(countdown_sum2, rust_recursive_kernel_countdown_sum).
rust_recursive_kernel_detector(list_suffix2, rust_recursive_kernel_list_suffix).
rust_recursive_kernel_detector(list_suffixes2, rust_recursive_kernel_list_suffixes).
rust_recursive_kernel_detector(transitive_closure2, rust_recursive_kernel_transitive_closure).
rust_recursive_kernel_detector(transitive_distance3, rust_recursive_kernel_transitive_distance).
rust_recursive_kernel_detector(transitive_parent_distance4, rust_recursive_kernel_transitive_parent_distance).
rust_recursive_kernel_detector(transitive_step_parent_distance5, rust_recursive_kernel_transitive_step_parent_distance).
rust_recursive_kernel_detector(weighted_shortest_path3, rust_recursive_kernel_weighted_shortest_path).
rust_recursive_kernel_detector(astar_shortest_path4, rust_recursive_kernel_astar_shortest_path).

rust_recursive_kernel_spec(
        recursive_kernel(KernelKind, PredIndicator, KernelConfig),
        foreign_predicate(PredIndicator, SetupOps, RewriteTargets)) :-
    rust_recursive_kernel_setup_ops(KernelKind, PredIndicator, KernelConfig, SetupOps),
    rust_recursive_kernel_rewrite_targets(KernelKind, PredIndicator, KernelConfig, RewriteTargets).

rust_recursive_kernel_setup_ops(KernelKind, PredIndicator, KernelConfig,
        [ register_foreign_native_kind(PredIndicator, NativeKind),
          register_foreign_result_layout(PredIndicator, ResultLayout),
          register_foreign_result_mode(PredIndicator, ResultMode)
        |ConfigOps]) :-
    rust_recursive_kernel_native_kind(KernelKind, NativeKind),
    rust_recursive_kernel_result_layout(KernelKind, ResultLayout),
    rust_recursive_kernel_result_mode(KernelKind, ResultMode),
    rust_recursive_kernel_config_ops(KernelKind, PredIndicator, KernelConfig, ConfigOps).

rust_recursive_kernel_native_kind(category_ancestor, category_ancestor).
rust_recursive_kernel_native_kind(countdown_sum2, countdown_sum2).
rust_recursive_kernel_native_kind(list_suffix2, list_suffix2).
rust_recursive_kernel_native_kind(list_suffixes2, list_suffixes2).
rust_recursive_kernel_native_kind(transitive_closure2, transitive_closure2).
rust_recursive_kernel_native_kind(transitive_distance3, transitive_distance3).
rust_recursive_kernel_native_kind(transitive_parent_distance4, transitive_parent_distance4).
rust_recursive_kernel_native_kind(transitive_step_parent_distance5, transitive_step_parent_distance5).
rust_recursive_kernel_native_kind(weighted_shortest_path3, weighted_shortest_path3).
rust_recursive_kernel_native_kind(astar_shortest_path4, astar_shortest_path4).

rust_recursive_kernel_result_layout(category_ancestor, tuple(1)).
rust_recursive_kernel_result_layout(countdown_sum2, tuple(1)).
rust_recursive_kernel_result_layout(list_suffix2, tuple(1)).
rust_recursive_kernel_result_layout(list_suffixes2, tuple(1)).
rust_recursive_kernel_result_layout(transitive_closure2, tuple(1)).
rust_recursive_kernel_result_layout(transitive_distance3, tuple(2)).
rust_recursive_kernel_result_layout(transitive_parent_distance4, tuple(3)).
rust_recursive_kernel_result_layout(transitive_step_parent_distance5, tuple(4)).
rust_recursive_kernel_result_layout(weighted_shortest_path3, tuple(2)).
rust_recursive_kernel_result_layout(astar_shortest_path4, tuple(2)).

rust_recursive_kernel_result_mode(category_ancestor, stream).
rust_recursive_kernel_result_mode(countdown_sum2, deterministic).
rust_recursive_kernel_result_mode(list_suffix2, stream).
rust_recursive_kernel_result_mode(list_suffixes2, deterministic_collection).
rust_recursive_kernel_result_mode(transitive_closure2, stream).
rust_recursive_kernel_result_mode(transitive_distance3, stream).
rust_recursive_kernel_result_mode(transitive_parent_distance4, stream).
rust_recursive_kernel_result_mode(transitive_step_parent_distance5, stream).
rust_recursive_kernel_result_mode(weighted_shortest_path3, stream).
rust_recursive_kernel_result_mode(astar_shortest_path4, stream).

rust_recursive_kernel_config_ops(category_ancestor, category_ancestor/4,
        [max_depth(MaxDepth)],
        [register_foreign_usize_config(category_ancestor/4, max_depth, MaxDepth)]).
rust_recursive_kernel_config_ops(countdown_sum2, _PredIndicator, [], []).
rust_recursive_kernel_config_ops(list_suffix2, _PredIndicator, [], []).
rust_recursive_kernel_config_ops(list_suffixes2, _PredIndicator, [], []).
rust_recursive_kernel_config_ops(transitive_closure2, PredIndicator,
        KernelConfig, ConfigOps) :-
    rust_recursive_kernel_binary_edge_config_ops(PredIndicator, KernelConfig, ConfigOps).
rust_recursive_kernel_config_ops(transitive_distance3, PredIndicator,
        KernelConfig, ConfigOps) :-
    rust_recursive_kernel_binary_edge_config_ops(PredIndicator, KernelConfig, ConfigOps).
rust_recursive_kernel_config_ops(transitive_parent_distance4, PredIndicator,
        KernelConfig, ConfigOps) :-
    rust_recursive_kernel_binary_edge_config_ops(PredIndicator, KernelConfig, ConfigOps).
rust_recursive_kernel_config_ops(transitive_step_parent_distance5, PredIndicator,
        KernelConfig, ConfigOps) :-
    rust_recursive_kernel_binary_edge_config_ops(PredIndicator, KernelConfig, ConfigOps).
rust_recursive_kernel_config_ops(weighted_shortest_path3, PredIndicator,
        [weight_pred(WeightPred/3), fact_triples(FactTriples)],
        [ register_foreign_string_config(PredIndicator, weight_pred, WeightPred/3),
          register_indexed_weighted_edge(WeightPred/3, FactTriples)
        ]).
rust_recursive_kernel_config_ops(astar_shortest_path4, PredIndicator,
        [weight_pred(WeightPred/3), fact_triples(FactTriples),
         direct_dist_pred(DirectPred/3), direct_triples(DirectTriples),
         dimensionality(Dim)],
        [ register_foreign_string_config(PredIndicator, weight_pred, WeightPred/3),
          register_indexed_weighted_edge(WeightPred/3, FactTriples),
          register_foreign_string_config(PredIndicator, direct_dist_pred, DirectPred/3),
          register_indexed_weighted_edge(DirectPred/3, DirectTriples),
          register_foreign_usize_config(PredIndicator, dimensionality, Dim)
        ]).

rust_recursive_kernel_binary_edge_config_ops(PredIndicator,
        [edge_pred(EdgePred/2), fact_pairs(FactPairs)],
        [ register_foreign_string_config(PredIndicator, edge_pred, EdgePred/2),
          register_indexed_atom_fact2(EdgePred/2, FactPairs)
        ]).

rust_recursive_kernel_rewrite_targets(_KernelKind, PredIndicator, _KernelConfig, [PredIndicator]).

rust_recursive_kernel_category_ancestor(Pred, Arity, Clauses,
        recursive_kernel(category_ancestor, category_ancestor/4, [max_depth(MaxDepth)])) :-
    rust_foreign_lowerable_category_ancestor(Pred, Arity, Clauses, MaxDepth).

rust_recursive_kernel_countdown_sum(Pred, Arity, Clauses,
        recursive_kernel(countdown_sum2, Pred/Arity, [])) :-
    rust_foreign_lowerable_countdown_sum(Pred, Arity, Clauses).

rust_recursive_kernel_list_suffix(Pred, Arity, Clauses,
        recursive_kernel(list_suffix2, Pred/Arity, [])) :-
    rust_foreign_lowerable_list_suffix(Pred, Arity, Clauses).

rust_recursive_kernel_list_suffixes(Pred, Arity, Clauses,
        recursive_kernel(list_suffixes2, Pred/Arity, [])) :-
    rust_foreign_lowerable_list_suffixes(Pred, Arity, Clauses).

rust_recursive_kernel_transitive_closure(Pred, Arity, Clauses,
        recursive_kernel(transitive_closure2, Pred/Arity,
            [edge_pred(EdgePred/2), fact_pairs(FactPairs)])) :-
    rust_foreign_lowerable_transitive_closure(Pred, Arity, Clauses, EdgePred/2, FactPairs).

rust_recursive_kernel_transitive_distance(Pred, Arity, Clauses,
        recursive_kernel(transitive_distance3, Pred/Arity,
            [edge_pred(EdgePred/2), fact_pairs(FactPairs)])) :-
    rust_foreign_lowerable_transitive_distance(Pred, Arity, Clauses, EdgePred/2, FactPairs).

rust_recursive_kernel_transitive_parent_distance(Pred, Arity, Clauses,
        recursive_kernel(transitive_parent_distance4, Pred/Arity,
            [edge_pred(EdgePred/2), fact_pairs(FactPairs)])) :-
    rust_foreign_lowerable_transitive_parent_distance(Pred, Arity, Clauses, EdgePred/2, FactPairs).

rust_recursive_kernel_transitive_step_parent_distance(Pred, Arity, Clauses,
        recursive_kernel(transitive_step_parent_distance5, Pred/Arity,
            [edge_pred(EdgePred/2), fact_pairs(FactPairs)])) :-
    rust_foreign_lowerable_transitive_step_parent_distance(Pred, Arity, Clauses, EdgePred/2, FactPairs).
rust_recursive_kernel_weighted_shortest_path(Pred, Arity, Clauses,
        recursive_kernel(weighted_shortest_path3, Pred/Arity,
            [weight_pred(WeightPred/3), fact_triples(FactTriples)])) :-
    rust_foreign_lowerable_weighted_shortest_path(Pred, Arity, Clauses, WeightPred/3, FactTriples).

rust_recursive_kernel_astar_shortest_path(Pred, Arity, Clauses,
        recursive_kernel(astar_shortest_path4, Pred/Arity,
            [weight_pred(WeightPred/3), fact_triples(FactTriples),
             direct_dist_pred(DirectPred/3), direct_triples(DirectTriples),
             dimensionality(Dim)])) :-
    rust_foreign_lowerable_astar_shortest_path(Pred, Arity, Clauses,
        WeightPred/3, FactTriples, DirectPred/3, DirectTriples, Dim).

rust_foreign_lowerable_category_ancestor(category_ancestor, 4, Clauses, MaxDepth) :-
    member(_-BaseBody, Clauses),
    member(_-RecBody, Clauses),
    BaseBody \= true,
    RecBody \= true,
    sub_term(\+ member(_, _), BaseBody),
    sub_term(\+ member(_, _), RecBody),
    sub_term((_ is _ + 1), RecBody),
    current_predicate(user:max_depth/1),
    user:max_depth(MaxDepth),
    integer(MaxDepth),
    MaxDepth > 0.

rust_foreign_lowerable_countdown_sum(Pred, 2, Clauses) :-
    member(BaseHead-true, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, 0, 0],
    RecHead =.. [Pred, N, Sum],
    RecBody = (GtGoal, (StepGoal, (RecGoal, SumGoal))),
    GtGoal =.. [>, N, 0],
    StepGoal =.. [is, PrevN, StepExpr],
    (   StepExpr =.. [-, N, 1]
    ;   StepExpr =.. [+, N, -1]
    ),
    RecGoal =.. [Pred, PrevN, PrevSum],
    SumGoal =.. [is, Sum, SumExpr],
    SumExpr =.. [+, PrevSum, N].

rust_foreign_lowerable_list_suffix(Pred, 2, Clauses) :-
    member(BaseHead-true, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, BaseList, BaseList],
    var(BaseList),
    RecHead =.. [Pred, InputList, Suffix],
    InputList = [_|Tail],
    RecBody =.. [Pred, Tail, Suffix].

rust_foreign_lowerable_list_suffixes(Pred, 2, Clauses) :-
    member(BaseHead-true, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, [], [[]]],
    RecHead =.. [Pred, [Head|Tail], [[Head|Tail]|Rest]],
    RecBody =.. [Pred, Tail, Rest].

rust_foreign_lowerable_transitive_closure(Pred, 2, Clauses, EdgePred/2, FactPairs) :-
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, BaseStart, BaseTarget],
    RecHead =.. [Pred, RecStart, RecTarget],
    RecBody = (EdgeGoal, RecGoal),
    BaseBody =.. [EdgePred, BaseArg1, BaseArg2],
    EdgeGoal =.. [EdgePred, EdgeArg1, EdgeArg2],
    RecGoal =.. [Pred, RecMid, RecGoalTarget],
    RecGoalTarget == RecTarget,
    (   BaseArg1 == BaseStart,
        BaseArg2 == BaseTarget,
        EdgeArg1 == RecStart,
        EdgeArg2 == RecMid,
        PairMode = forward
    ;   BaseArg1 == BaseTarget,
        BaseArg2 == BaseStart,
        EdgeArg1 == RecMid,
        EdgeArg2 == RecStart,
        PairMode = reverse
    ),
    findall(PairLeft-PairRight,
        ( functor(EdgeHead, EdgePred, 2),
          user:clause(EdgeHead, true),
          EdgeHead =.. [EdgePred, Left, Right],
          atom(Left),
          atom(Right),
          rust_foreign_edge_pair(PairMode, Left, Right, PairLeft-PairRight)
        ),
        FactPairs),
    FactPairs \= [].

rust_foreign_lowerable_transitive_distance(Pred, 3, Clauses, EdgePred/2, FactPairs) :-
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, BaseStart, BaseTarget, 1],
    RecHead =.. [Pred, RecStart, RecTarget, RecDepth],
    BaseBody =.. [EdgePred, BaseStart, BaseTarget],
    RecBody = (EdgeGoal, (RecGoal, IsGoal)),
    EdgeGoal =.. [EdgePred, RecStart, RecMid],
    RecGoal =.. [Pred, RecMid, RecTarget, PrevDepth],
    IsGoal =.. [is, RecDepth, Expr],
    Expr =.. [+, PrevDepth, 1],
    findall(Left-Right,
        ( functor(EdgeHead, EdgePred, 2),
          user:clause(EdgeHead, true),
          EdgeHead =.. [EdgePred, Left, Right],
          atom(Left),
          atom(Right)
        ),
        FactPairs),
    FactPairs \= [].

rust_foreign_lowerable_transitive_parent_distance(Pred, 4, Clauses, EdgePred/2, FactPairs) :-
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, BaseStart, BaseTarget, BaseStart, 1],
    RecHead =.. [Pred, RecStart, RecTarget, RecParent, RecDepth],
    BaseBody =.. [EdgePred, BaseStart, BaseTarget],
    RecBody = (EdgeGoal, (RecGoal, IsGoal)),
    EdgeGoal =.. [EdgePred, RecStart, RecMid],
    RecGoal =.. [Pred, RecMid, RecTarget, RecParent, PrevDepth],
    IsGoal =.. [is, RecDepth, Expr],
    Expr =.. [+, PrevDepth, 1],
    findall(Left-Right,
        ( functor(EdgeHead, EdgePred, 2),
          user:clause(EdgeHead, true),
          EdgeHead =.. [EdgePred, Left, Right],
          atom(Left),
          atom(Right)
        ),
        FactPairs),
    FactPairs \= [].

rust_foreign_lowerable_transitive_step_parent_distance(Pred, 5, Clauses, EdgePred/2, FactPairs) :-
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead =.. [Pred, BaseStart, BaseTarget, BaseTarget, BaseStart, 1],
    RecHead =.. [Pred, RecStart, RecTarget, RecStep, RecParent, RecDepth],
    BaseBody =.. [EdgePred, BaseStart, BaseTarget],
    RecBody = (EdgeGoal, (RecGoal, IsGoal)),
    EdgeGoal =.. [EdgePred, RecStart, RecMid],
    RecStep == RecMid,
    RecGoal =.. [Pred, RecMid, RecTarget, _InnerStep, RecParent, PrevDepth],
    IsGoal =.. [is, RecDepth, Expr],
    Expr =.. [+, PrevDepth, 1],
    findall(Left-Right,
        ( functor(EdgeHead, EdgePred, 2),
          user:clause(EdgeHead, true),
          EdgeHead =.. [EdgePred, Left, Right],
          atom(Left),
          atom(Right)
        ),
        FactPairs),
    FactPairs \= [].

%% rust_foreign_lowerable_weighted_shortest_path(+Pred, +Arity, +Clauses, -WeightPred, -FactTriples)
%
%  Recognize the weighted shortest path pattern:
%
%    Base case:  Pred(X, Y, W) :- WeightPred(X, Y, W).
%    Recursive:  Pred(X, Y, Cost) :- WeightPred(X, Z, W),
%                    \+ member(Z, Visited),    % (optional cycle check)
%                    Pred(Z, Y, RestCost),
%                    Cost is W + RestCost.
%
%  Also recognizes the simpler form without visited tracking:
%    Pred(X, Y, Cost) :- WeightPred(X, Z, W), Pred(Z, Y, RC), Cost is W + RC.
%
rust_foreign_lowerable_weighted_shortest_path(Pred, 3, Clauses, WeightPred/3, FactTriples) :-
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead \== RecHead,
    % Base case: Pred(X, Y, W) :- WeightPred(X, Y, W).
    BaseHead =.. [Pred, BaseStart, BaseTarget, BaseWeight],
    BaseBody =.. [WeightPred, BaseStart, BaseTarget, BaseWeight],
    % Recursive case: Pred(X, Y, Cost) :- WeightPred(X, Z, W), Pred(Z, Y, RC), Cost is W + RC.
    RecHead =.. [Pred, RecStart, RecTarget, RecCost],
    % Accept both direct conjunction and conjunction with negation/visited
    extract_weighted_rec_body(Pred, WeightPred, RecStart, RecTarget, RecCost, RecBody),
    % Extract all weighted edge facts
    findall(Left-Right-Weight,
        ( functor(WHead, WeightPred, 3),
          user:clause(WHead, true),
          WHead =.. [WeightPred, Left, Right, Weight],
          atom(Left),
          atom(Right),
          number(Weight)
        ),
        FactTriples),
    FactTriples \= [].

%% extract_weighted_rec_body(+Pred, +WeightPred, +Start, +Target, +Cost, +Body)
%  Match the recursive body, accepting optional visited-list filtering.
%
%  Form 1 (simple): WeightPred(X, Z, W), Pred(Z, Y, RC), Cost is W + RC
%  Form 2 (visited): WeightPred(X, Z, W), \+ member(Z, Vis), Pred(Z, Y, RC), Cost is W + RC
extract_weighted_rec_body(Pred, WeightPred, Start, Target, Cost, Body) :-
    % Simple form: (WeightGoal, (RecGoal, IsGoal))
    Body = (WeightGoal, (RecGoal, IsGoal)),
    WeightGoal =.. [WeightPred, Start, Mid, W],
    RecGoal =.. [Pred, Mid, Target, RestCost],
    IsGoal =.. [is, Cost, PlusExpr],
    PlusExpr =.. [+, W, RestCost],
    !.
extract_weighted_rec_body(Pred, WeightPred, Start, Target, Cost, Body) :-
    % Visited form: (WeightGoal, (\+ member(...), (RecGoal, IsGoal)))
    Body = (WeightGoal, (NegGoal, (RecGoal, IsGoal))),
    WeightGoal =.. [WeightPred, Start, Mid, W],
    NegGoal = (\+ _),  % accept any negation (cycle check)
    RecGoal =.. [Pred, Mid, Target, RestCost],
    IsGoal =.. [is, Cost, PlusExpr],
    PlusExpr =.. [+, W, RestCost],
    !.
extract_weighted_rec_body(Pred, WeightPred, Start, _Target, _Cost, Body) :-
    % 4-arity visited form: Pred(X, Y, Visited, Cost) recursion
    Body = (WeightGoal, Rest),
    WeightGoal =.. [WeightPred, Start, _Mid, _W],
    Rest \= (_,_),
    functor(Rest, Pred, _),
    !,
    fail.  % Don't match — this needs the 4-arity kernel instead

%% rust_foreign_lowerable_astar_shortest_path(+Pred, +Arity, +Clauses,
%%     -WeightPred, -FactTriples, -DirectPred, -DirectTriples, -Dim)
%
%  Recognize the A* weighted shortest path pattern (arity 4):
%
%    Base:  Pred(X, Y, _Visited, _Dim, W) :- WeightPred(X, Y, W).
%    Rec:   Pred(X, Y, Visited, Dim, Cost) :-
%               WeightPred(X, Z, W), \+ member(Z, Visited),
%               Pred(Z, Y, [Z|Visited], Dim, RC), Cost is W + RC.
%
%  Also detects direct_semantic_dist/3 facts for the heuristic oracle,
%  and extracts the Dim parameter (default 5).
%
rust_foreign_lowerable_astar_shortest_path(Pred, 4, Clauses,
        WeightPred/3, FactTriples, DirectPred/3, DirectTriples, Dim) :-
    % Must have a weighted path core (reuse the 3-arity pattern check)
    % The 4-arity version adds Dim as the 4th arg
    member(BaseHead-BaseBody, Clauses),
    member(RecHead-RecBody, Clauses),
    BaseHead \== RecHead,
    % Base case: Pred(X, Y, _Visited, _Dim, W) :- WeightPred(X, Y, W)
    BaseHead =.. [Pred, _, _, _, BaseWeight],
    BaseBody =.. [WeightPred, _, _, BaseWeight],
    % Recursive case - extract WeightPred from body
    RecHead =.. [Pred, _, _, _, _],
    RecBody = (WeightGoal, _Rest),
    WeightGoal =.. [WeightPred, _, _, _],
    % Extract weighted edge facts
    findall(Left-Right-Weight,
        ( functor(WHead, WeightPred, 3),
          user:clause(WHead, true),
          WHead =.. [WeightPred, Left, Right, Weight],
          atom(Left), atom(Right), number(Weight)
        ),
        FactTriples),
    FactTriples \= [],
    % Find direct distance predicate (look for direct_semantic_dist/3)
    (   current_predicate(user:direct_semantic_dist/3)
    ->  DirectPred = direct_semantic_dist,
        findall(L-R-D,
            ( user:direct_semantic_dist(L, R, D),
              atom(L), atom(R), number(D)
            ),
            DirectTriples)
    ;   DirectPred = none,
        DirectTriples = []
    ),
    % Default dimensionality
    Dim = 5.

rust_foreign_edge_pair(forward, Left, Right, Left-Right).
rust_foreign_edge_pair(reverse, Left, Right, Right-Left).

rust_foreign_stream_wrapper_plan(Pred, 3, Head, Body,
        foreign_wrapper_plan(KernelSpec, JoinPreds, GoalArgs, HeadResult, GoalInfo)) :-
    Head =.. [Pred, HeadStart, HeadOutput, HeadResult],
    classify_aggregate_goal(Body, GoalInfo),
    get_dict(relations, GoalInfo, [RelGoal|JoinGoals]),
    get_dict(other, GoalInfo, []),
    rust_foreign_kernel_spec(RelGoal, KernelSpec),
    rust_foreign_wrapper_output_arg(RelGoal, JoinGoals, GoalOutput),
    RelGoal =.. [_InnerPred, GoalStart, _GoalTarget, GoalCost],
    HeadStart == GoalStart,
    HeadOutput == GoalOutput,
    GoalArgs = [GoalStart, GoalOutput, GoalCost],
    rust_join_goals_to_preds(JoinGoals, JoinPreds).
rust_foreign_stream_wrapper_plan(Pred, 4, Head, Body,
        foreign_wrapper_plan(KernelSpec, JoinPreds, GoalArgs, HeadResult, GoalInfo)) :-
    Head =.. [Pred, HeadStart, HeadOutput, HeadDim, HeadResult],
    classify_aggregate_goal(Body, GoalInfo),
    get_dict(relations, GoalInfo, [RelGoal|JoinGoals]),
    get_dict(other, GoalInfo, []),
    rust_foreign_kernel_spec(RelGoal, KernelSpec),
    rust_foreign_wrapper_output_arg(RelGoal, JoinGoals, GoalOutput),
    RelGoal =.. [_InnerPred, GoalStart, _GoalTarget, GoalDim, GoalCost],
    HeadStart == GoalStart,
    HeadOutput == GoalOutput,
    HeadDim == GoalDim,
    GoalArgs = [GoalStart, GoalOutput, GoalDim, GoalCost],
    rust_join_goals_to_preds(JoinGoals, JoinPreds).

rust_foreign_aggregate_wrapper_plan(_Pred, 3, _Head, AggInfo,
        foreign_aggregate_plan(KernelSpec, JoinPreds, GoalArgs, Expr, Type, GroupTerm, GoalInfo)) :-
    get_dict(type, AggInfo, Type),
    get_dict(op, AggInfo, min),
    get_dict(expr, AggInfo, Expr),
    get_dict(group, AggInfo, GroupTerm),
    get_dict(goal_info, AggInfo, GoalInfo),
    get_dict(relations, GoalInfo, [RelGoal|JoinGoals]),
    rust_foreign_kernel_spec(RelGoal, KernelSpec),
    rust_foreign_wrapper_output_arg(RelGoal, JoinGoals, GoalOutput),
    RelGoal =.. [_InnerPred, GoalStart, _GoalTarget, GoalCost],
    GoalArgs = [GoalStart, GoalOutput, GoalCost],
    rust_join_goals_to_preds(JoinGoals, JoinPreds).
rust_foreign_aggregate_wrapper_plan(_Pred, 4, _Head, AggInfo,
        foreign_aggregate_plan(KernelSpec, JoinPreds, GoalArgs, Expr, Type, GroupTerm, GoalInfo)) :-
    get_dict(type, AggInfo, Type),
    get_dict(op, AggInfo, min),
    get_dict(expr, AggInfo, Expr),
    get_dict(group, AggInfo, GroupTerm),
    get_dict(goal_info, AggInfo, GoalInfo),
    get_dict(relations, GoalInfo, [RelGoal|JoinGoals]),
    rust_foreign_kernel_spec(RelGoal, KernelSpec),
    rust_foreign_wrapper_output_arg(RelGoal, JoinGoals, GoalOutput),
    RelGoal =.. [_InnerPred, GoalStart, _GoalTarget, GoalDim, GoalCost],
    GoalArgs = [GoalStart, GoalOutput, GoalDim, GoalCost],
    rust_join_goals_to_preds(JoinGoals, JoinPreds).

rust_foreign_kernel_spec(RelGoal, weighted_kernel(InnerPred, WeightPred/3, FactTriples)) :-
    RelGoal =.. [InnerPred, _GoalStart, _GoalTarget, _GoalCost],
    functor(InnerHead, InnerPred, 3),
    findall(InnerHead-InnerBody, user:clause(InnerHead, InnerBody), Clauses),
    Clauses \= [],
    rust_foreign_lowerable_weighted_shortest_path(InnerPred, 3, Clauses, WeightPred/3, FactTriples).
rust_foreign_kernel_spec(RelGoal,
        astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim)) :-
    RelGoal =.. [InnerPred, _GoalStart, _GoalTarget, _GoalDim, _GoalCost],
    functor(InnerHead, InnerPred, 4),
    findall(InnerHead-InnerBody, user:clause(InnerHead, InnerBody), Clauses),
    Clauses \= [],
    rust_foreign_lowerable_astar_shortest_path(InnerPred, 4, Clauses,
        WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim).

rust_render_weighted_kernel(weighted_kernel(InnerPred, WeightPred/3, FactTriples),
        InnerPredStr, WeightPredKey, TriplesLiteral) :-
    atom_string(InnerPred, InnerPredStr),
    format(string(WeightPredKey), '~w/3', [WeightPred]),
    rust_weighted_fact_triples_literal(FactTriples, TriplesLiteral).

rust_render_astar_kernel(
        astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim),
        InnerPredStr, WeightPredKey, WeightTriplesLiteral, DirectPredKey, DirectTriplesLiteral, DefaultDim) :-
    atom_string(InnerPred, InnerPredStr),
    format(string(WeightPredKey), '~w/3', [WeightPred]),
    format(string(DirectPredKey), '~w/3', [DirectPred]),
    rust_weighted_fact_triples_literal(FactTriples, WeightTriplesLiteral),
    rust_weighted_fact_triples_literal(DirectTriples, DirectTriplesLiteral).

rust_foreign_wrapper_output_arg(RelGoal, [], OutputArg) :-
    arg(2, RelGoal, OutputArg).
rust_foreign_wrapper_output_arg(_RelGoal, JoinGoals, OutputArg) :-
    last(JoinGoals, LastJoinGoal),
    arg(2, LastJoinGoal, OutputArg).

rust_join_goals_to_preds([], []).
rust_join_goals_to_preds([JoinGoal|Rest], [JoinPred/2|PredRest]) :-
    JoinGoal =.. [JoinPred, JoinLeft, JoinRight],
    atom(JoinPred),
    var(JoinLeft),
    var(JoinRight),
    rust_binary_atom_fact_pairs(JoinPred/2, _),
    rust_join_goals_to_preds(Rest, PredRest).

rust_render_join_pred(JoinPred/2, JoinPredKey, JoinPairsLiteral) :-
    rust_binary_atom_fact_pairs(JoinPred/2, JoinPairs),
    format(string(JoinPredKey), '~w/2', [JoinPred]),
    rust_atom_fact_pairs_literal(JoinPairs, JoinPairsLiteral).

rust_render_join_preds([JoinPred1/2, JoinPred2/2],
        JoinPredKey1, JoinPairsLiteral1, JoinPredKey2, JoinPairsLiteral2) :-
    rust_render_join_pred(JoinPred1/2, JoinPredKey1, JoinPairsLiteral1),
    rust_render_join_pred(JoinPred2/2, JoinPredKey2, JoinPairsLiteral2).

rust_render_join_specs([], []).
rust_render_join_specs([JoinPred/2|Rest], [join_spec(JoinPredKey, JoinPairsLiteral)|SpecRest]) :-
    rust_render_join_pred(JoinPred/2, JoinPredKey, JoinPairsLiteral),
    rust_render_join_specs(Rest, SpecRest).

rust_foreign_join_registration_code([], "").
rust_foreign_join_registration_code([join_spec(JoinPredKey, JoinPairsLiteral)|Rest], Code) :-
    rust_foreign_join_registration_code(Rest, RestCode),
    format(string(Code),
'    vm.register_indexed_atom_fact2_pairs("~w", &~w);
~w', [JoinPredKey, JoinPairsLiteral, RestCode]).

rust_indent_more(Indent, MoreIndent) :-
    format(string(MoreIndent), '~w    ', [Indent]).

rust_foreign_stage_output_var([], "target").
rust_foreign_stage_output_var(JoinSpecs, OutputVar) :-
    length(JoinSpecs, Depth),
    Depth > 0,
    format(string(OutputVar), 'joined_value_~w', [Depth]).

rust_foreign_stage_chain_code(JoinSpecs, InputLookupExpr, Indent, TerminalCode, Code) :-
    rust_foreign_stage_chain_code_(JoinSpecs, InputLookupExpr, Indent, 1, TerminalCode, Code).

rust_foreign_stage_chain_code_([], _InputLookupExpr, _Indent, _Depth, TerminalCode, TerminalCode).
rust_foreign_stage_chain_code_([join_spec(JoinPredKey, _)|Rest], InputLookupExpr, Indent,
        Depth, TerminalCode, Code) :-
    rust_indent_more(Indent, InnerIndent),
    format(string(JoinedValuesVar), 'joined_values_~w', [Depth]),
    format(string(JoinedValueVar), 'joined_value_~w', [Depth]),
    NextDepth is Depth + 1,
    rust_foreign_stage_chain_code_(Rest, JoinedValueVar, InnerIndent, NextDepth, TerminalCode, InnerCode),
    format(string(Code),
'~wlet ~w = match vm.indexed_atom_fact2.get("~w").and_then(|table| table.get(~w)) {
~w    Some(values) => values.clone(),
~w    None => Vec::new(),
~w};
~wfor ~w in ~w.iter() {
~w~w}
', [Indent, JoinedValuesVar, JoinPredKey, InputLookupExpr,
      Indent, Indent, Indent,
      Indent, JoinedValueVar, JoinedValuesVar,
      InnerCode, Indent]).

rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr) :-
    format(string(FilterExpr), '~w.as_ref().map(|want| want.as_str() == ~w.as_str()).unwrap_or(true)',
        [FilterVar, OutputVar]).

rust_foreign_stream_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr),
    format(string(Code),
'~w~wlet output_value = ~w;
~wif (~w)
~w    && (~w)
~w    && (result_filter.as_ref().map(|want| (output_value - *want).abs() < 1e-9).unwrap_or(true)) {
~w    packed_results.push(Value::Str("__tuple__".to_string(), vec![
~w        Value::Atom(~w.clone()),
~w        Value::Float(output_value),
~w    ]));
~w}
', [SetupCode, Indent, ValueExpr,
      Indent, FilterExpr,
      Indent, FilterCond,
      Indent,
      Indent,
      Indent, OutputVar,
      Indent,
      Indent,
      Indent]).

rust_foreign_stream_with_start_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr),
    format(string(Code),
'~w~wlet output_value = ~w;
~wif (~w)
~w    && (~w)
~w    && (result_filter.as_ref().map(|want| (output_value - *want).abs() < 1e-9).unwrap_or(true)) {
~w    packed_results.push(Value::Str("__tuple__".to_string(), vec![
~w        Value::Atom(start.clone()),
~w        Value::Atom(~w.clone()),
~w        Value::Float(output_value),
~w    ]));
~w}
', [SetupCode, Indent, ValueExpr,
      Indent, FilterExpr,
      Indent, FilterCond,
      Indent,
      Indent,
      Indent,
      Indent, OutputVar,
      Indent,
      Indent,
      Indent]).

rust_foreign_stream_with_start_dim_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr),
    format(string(Code),
'~w~wlet output_value = ~w;
~wif (~w)
~w    && (~w)
~w    && (result_filter.as_ref().map(|want| (output_value - *want).abs() < 1e-9).unwrap_or(true)) {
~w    packed_results.push(Value::Str("__tuple__".to_string(), vec![
~w        Value::Atom(start.clone()),
~w        Value::Atom(~w.clone()),
~w        a3.clone(),
~w        Value::Float(output_value),
~w    ]));
~w}
', [SetupCode, Indent, ValueExpr,
      Indent, FilterExpr,
      Indent, FilterCond,
      Indent,
      Indent,
      Indent,
      Indent, OutputVar,
      Indent,
      Indent,
      Indent,
      Indent]).

rust_foreign_scalar_min_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr),
    format(string(Code),
'~w~wif (~w)
~w    && (~w) {
~w    let agg_value = ~w;
~w    best = Some(match best {
~w        Some(current) => current.min(agg_value),
~w        None => agg_value,
~w    });
~w}
', [SetupCode,
      Indent, FilterExpr,
      Indent, FilterCond,
      Indent, ValueExpr,
      Indent,
      Indent,
      Indent,
      Indent,
      Indent]).

rust_foreign_grouped_min_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_wrapper_filter_expr(FilterVar, OutputVar, FilterExpr),
    format(string(Code),
'~w~wif (~w)
~w    && (~w) {
~w    let agg_value = ~w;
~w    grouped.entry(~w.clone())
~w        .and_modify(|current| *current = current.min(agg_value))
~w        .or_insert(agg_value);
~w}
', [SetupCode,
      Indent, FilterExpr,
      Indent, FilterCond,
      Indent, ValueExpr,
      Indent, OutputVar,
      Indent,
      Indent,
      Indent]).

rust_foreign_terminal_code(stream, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_stream_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).
rust_foreign_terminal_code(stream_with_start, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_stream_with_start_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).
rust_foreign_terminal_code(stream_with_start_dim, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_stream_with_start_dim_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).
rust_foreign_terminal_code(scalar_min, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_scalar_min_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).
rust_foreign_terminal_code(grouped_min, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_grouped_min_terminal_code(Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).

rust_foreign_wrapper_traversal_code([], FilterVar, OutputVar, _InputLookupExpr, Indent,
        TerminalMode, SetupCode, ValueExpr, FilterCond, Code) :-
    rust_foreign_terminal_code(TerminalMode, Indent, FilterVar, OutputVar, SetupCode, ValueExpr, FilterCond, Code).
rust_foreign_wrapper_traversal_code(JoinPreds, FilterVar, _OutputVar, InputLookupExpr, Indent,
        TerminalMode, SetupCode, ValueExpr, FilterCond, Code) :-
    JoinPreds \= [],
    rust_render_join_specs(JoinPreds, JoinSpecs),
    rust_foreign_stage_output_var(JoinSpecs, JoinOutputVar),
    rust_foreign_terminal_code(TerminalMode, "            ", FilterVar, JoinOutputVar,
        SetupCode, ValueExpr, FilterCond, TerminalCode),
    rust_foreign_stage_chain_code(JoinSpecs, InputLookupExpr, Indent, TerminalCode, Code).

rust_foreign_wrapper_stage_traversal_code(JoinPreds, FilterVar, OutputVar, InputLookupExpr, Indent,
        TerminalMode, StagePlan, Code) :-
    rust_foreign_wrapper_render_stage_plan(StagePlan, SetupCode, ValueExpr, FilterCond),
    rust_foreign_wrapper_traversal_code(JoinPreds, FilterVar, OutputVar, InputLookupExpr, Indent,
        TerminalMode, SetupCode, ValueExpr, FilterCond, Code).

compile_rust_foreign_stream_wrapper_from_plan(Pred, 3,
        foreign_wrapper_plan(
            weighted_kernel(InnerPred, WeightPred/3, FactTriples),
            JoinPreds,
            [GoalStart, GoalOutput, GoalCost],
            HeadResult,
            GoalInfo),
        RustCode) :-
    GoalArgs = [GoalStart, GoalOutput, GoalCost],
    rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, HeadResult, StagePlan),
    ( JoinPreds == []
    -> TargetFilterCode =
'    let target_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
       A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
       TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
       rust_foreign_wrapper_stage_traversal_code([], "target_filter", "target", "&target", "        ",
           stream_with_start, StagePlan, TraversalCode)
    ; JoinPreds \= [],
       TargetFilterCode =
'    let join_filter = match &a2 {
        Value::Atom(label) => Some(label.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
       A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
       TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
       rust_render_join_specs(JoinPreds, JoinSpecs),
       rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
       rust_foreign_wrapper_stage_traversal_code(JoinPreds, "join_filter", "target", "&target", "        ",
           stream_with_start, StagePlan, TraversalCode)
    ; fail
    ),
    atom_string(Pred, PredStr),
    atom_string(InnerPred, InnerPredStr),
    format(string(PredKey), '~w/3', [Pred]),
    format(string(WeightPredKey), '~w/3', [WeightPred]),
    rust_weighted_fact_triples_literal(FactTriples, TriplesLiteral),
    ( JoinPreds == []
    -> JoinRegistrationCode = ""
    ; true
    ),
    format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value) -> bool {
    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_result_layout("~w", "tuple:3");
    vm.register_foreign_result_mode("~w", "stream");
    vm.register_foreign_native_kind("~w/3", "weighted_shortest_path3");
    vm.register_foreign_result_layout("~w/3", "tuple:2");
    vm.register_foreign_result_mode("~w/3", "stream");
    vm.register_foreign_string_config("~w/3", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
~w
~w

    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let result_filter = match &a3 {
        Value::Float(value) => Some(*value),
        Value::Integer(value) => Some(*value as f64),
        Value::Unbound(_) => None,
        _ => return false,
    };
    let temp_target = "__wrapper_target".to_string();
    let temp_cost = "__wrapper_cost".to_string();

    let mut packed_results: Vec<Value> = Vec::new();
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start.clone()));

        if !vm.execute_foreign_predicate("~w", 3) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);
    vm.finish_foreign_results("~w", vec![a1.clone(), a2.clone(), a3.clone()], packed_results)
}', [PredStr, PredKey, PredKey, InnerPredStr, InnerPredStr, InnerPredStr,
      InnerPredStr, WeightPredKey, WeightPredKey, TriplesLiteral,
      JoinRegistrationCode, TargetFilterCode, TriplesLiteral, A2RegCode, InnerPredStr, TargetReadCode,
      TraversalCode, PredKey]).

compile_rust_foreign_stream_wrapper_from_plan(Pred, 4,
        foreign_wrapper_plan(
            astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim),
            JoinPreds,
            [GoalStart, GoalOutput, GoalDim, GoalCost],
            HeadResult,
            GoalInfo),
        RustCode) :-
    GoalArgs = [GoalStart, GoalOutput, GoalDim, GoalCost],
    rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, HeadResult, StagePlan),
    ( JoinPreds == []
    -> TargetFilterCode =
'    let target_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
       A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
       TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
       rust_foreign_wrapper_stage_traversal_code([], "target_filter", "target", "&target", "        ",
           stream_with_start_dim, StagePlan, TraversalCode)
    ; JoinPreds \= [],
       TargetFilterCode =
'    let join_filter = match &a2 {
        Value::Atom(label) => Some(label.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
       A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
       TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
       rust_render_join_specs(JoinPreds, JoinSpecs),
       rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
       rust_foreign_wrapper_stage_traversal_code(JoinPreds, "join_filter", "target", "&target", "        ",
           stream_with_start_dim, StagePlan, TraversalCode)
    ; fail
    ),
    rust_render_astar_kernel(
        astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim),
        InnerPredStr, WeightPredKey, WeightTriplesLiteral, DirectPredKey, DirectTriplesLiteral, DefaultDim),
    atom_string(Pred, PredStr),
    format(string(PredKey), '~w/4', [Pred]),
    ( JoinPreds == []
    -> JoinRegistrationCode = ""
    ; true
    ),
    format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value, a4: Value) -> bool {
    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_result_layout("~w", "tuple:4");
    vm.register_foreign_result_mode("~w", "stream");
    vm.register_foreign_native_kind("~w/4", "astar_shortest_path4");
    vm.register_foreign_result_layout("~w/4", "tuple:2");
    vm.register_foreign_result_mode("~w/4", "stream");
    vm.register_foreign_string_config("~w/4", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_string_config("~w/4", "direct_dist_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_usize_config("~w/4", "dimensionality", ~w);
~w
~w

    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let result_filter = match &a4 {
        Value::Float(value) => Some(*value),
        Value::Integer(value) => Some(*value as f64),
        Value::Unbound(_) => None,
        _ => return false,
    };
    let temp_target = "__wrapper_target".to_string();
    let temp_cost = "__wrapper_cost".to_string();

    let dim_value = match &a3 {
        Value::Integer(d) => *d as f64,
        Value::Float(d) => *d,
        _ => ~w_f64,
    };

    let mut packed_results: Vec<Value> = Vec::new();
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start.clone()));

        if !vm.execute_foreign_predicate("~w", 4) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);
    vm.finish_foreign_results("~w", vec![a1.clone(), a2.clone(), a3.clone(), a4.clone()], packed_results)
}', [PredStr, PredKey, PredKey, InnerPredStr, InnerPredStr, InnerPredStr,
      InnerPredStr, WeightPredKey, WeightPredKey, WeightTriplesLiteral,
      InnerPredStr, DirectPredKey, DirectPredKey, DirectTriplesLiteral,
      InnerPredStr, DefaultDim, JoinRegistrationCode, TargetFilterCode, WeightTriplesLiteral,
      DefaultDim, A2RegCode, InnerPredStr, TargetReadCode, TraversalCode, PredKey]).

compile_rust_foreign_multistage_join_stream_wrapper(Pred, 3, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 3, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, JoinPreds, _, _, _),
    length(JoinPreds, Len),
    Len >= 2,
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 3, Plan, RustCode).
compile_rust_foreign_multistage_join_stream_wrapper(Pred, 4, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 4, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, JoinPreds, _, _, _),
    length(JoinPreds, Len),
    Len >= 2,
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 4, Plan, RustCode).

compile_rust_foreign_join_stream_wrapper(Pred, 3, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 3, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, JoinPreds, _, _, _),
    JoinPreds = [_],
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 3, Plan, RustCode).
compile_rust_foreign_join_stream_wrapper(Pred, 4, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 4, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, JoinPreds, _, _, _),
    JoinPreds = [_],
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 4, Plan, RustCode).

compile_rust_foreign_stream_wrapper(Pred, 3, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 3, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, [], _, _, _),
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 3, Plan, RustCode).
compile_rust_foreign_stream_wrapper(Pred, 4, Head, Body, _IncludeMain, RustCode) :-
    rust_foreign_stream_wrapper_plan(Pred, 4, Head, Body, Plan),
    Plan = foreign_wrapper_plan(_, [], _, _, _),
    compile_rust_foreign_stream_wrapper_from_plan(Pred, 4, Plan, RustCode).

compile_aggregate_rule_to_rust(Pred, _Arity, _Head, AggInfo, IncludeMain, RustCode) :-
    get_dict(goal, AggInfo, Goal),
    get_dict(goal_info, AggInfo, GoalInfo),
    compile_rust_weighted_min_aggregate_wrapper(Pred, Goal, GoalInfo, AggInfo, IncludeMain, RustCode),
    !.
compile_aggregate_rule_to_rust(Pred, _Arity, _Head, AggInfo, IncludeMain, RustCode) :-
    get_dict(goal, AggInfo, Goal),
    get_dict(goal_info, AggInfo, GoalInfo),
    get_dict(relations, GoalInfo, [RelGoal|_]),
    RelGoal =.. [InnerPred|GoalArgs],
    length(GoalArgs, InnerArity),
    findall(FactArgs,
        (   functor(FactHead, InnerPred, InnerArity),
            user:clause(FactHead, true),
            FactHead =.. [_|FactArgs]
        ),
        FactRows),
    get_dict(type, AggInfo, Type),
    get_dict(op, AggInfo, Op),
    get_dict(expr, AggInfo, Expr),
    get_dict(group, AggInfo, GroupTerm),
    aggregate_value_index(Op, Expr, GoalArgs, ValueIndex),
    rust_filter_fact_rows(GoalArgs, GoalInfo, FactRows, FilteredFactRows),
    (   FactRows \= [],
        Type == all
    ->  compile_rust_scalar_aggregate(Pred, Op, ValueIndex, FilteredFactRows, IncludeMain, RustCode)
    ;   FactRows \= []
    ->  compile_rust_grouped_aggregate(Pred, Op, GoalArgs, GroupTerm, ValueIndex, FilteredFactRows, IncludeMain, RustCode)
    ;   Type == all
    ->  compile_rust_recursive_aggregate(Pred, Goal, InnerPred, InnerArity, GoalArgs, Op, ValueIndex, IncludeMain, RustCode)
    ;   Type == group
    ->  compile_rust_grouped_recursive_aggregate(Pred, Goal, InnerPred, InnerArity, GoalArgs, GroupTerm, Op, ValueIndex, IncludeMain, RustCode)
    ;   fail
    ).

compile_rust_weighted_min_aggregate_wrapper(Pred, _Goal, _GoalInfo, AggInfo, _IncludeMain, RustCode) :-
    rust_foreign_aggregate_wrapper_plan(Pred, 3, _Head, AggInfo, Plan),
    compile_rust_foreign_min_aggregate_wrapper_from_plan(Pred, 3, Plan, RustCode).
compile_rust_weighted_min_aggregate_wrapper(Pred, _Goal, _GoalInfo, AggInfo, _IncludeMain, RustCode) :-
    rust_foreign_aggregate_wrapper_plan(Pred, 4, _Head, AggInfo, Plan),
    compile_rust_foreign_min_aggregate_wrapper_from_plan(Pred, 4, Plan, RustCode).

compile_rust_foreign_min_aggregate_wrapper_from_plan(Pred, 3,
        foreign_aggregate_plan(
            weighted_kernel(InnerPred, WeightPred/3, FactTriples),
            JoinPreds,
            [GoalStart, GoalOutput, GoalCost],
            Expr,
            Type,
            GroupTerm,
            GoalInfo),
        RustCode) :-
    atom_string(Pred, PredStr),
    format(string(PredKey), '~w/3', [Pred]),
    rust_render_weighted_kernel(
        weighted_kernel(InnerPred, WeightPred/3, FactTriples),
        InnerPredStr, WeightPredKey, TriplesLiteral),
    ( Type == group
    -> parse_group_term_rust(GroupTerm, [GroupVar]),
       GroupVar == GoalOutput,
       GoalArgs = [GoalStart, GoalOutput, GoalCost],
       rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, Expr, StagePlan),
       ( JoinPreds == []
       -> FilterCode =
'    let output_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
          A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
          TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
          JoinRegistrationCode = "",
          rust_foreign_wrapper_stage_traversal_code([], "output_filter", "target", "&target", "        ",
              grouped_min, StagePlan, TraversalCode)
       ; rust_render_join_specs(JoinPreds, JoinSpecs),
         rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
         FilterCode =
'    let output_filter = match &a2 {
        Value::Atom(group) => Some(group.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
         A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
         TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
         rust_foreign_wrapper_stage_traversal_code(JoinPreds, "output_filter", "target", "&target", "        ",
             grouped_min, StagePlan, TraversalCode)
       ),
       format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value) -> bool {
    use std::collections::BTreeMap;

    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_result_layout("~w", "tuple:2");
    vm.register_foreign_result_mode("~w", "stream");
    vm.register_foreign_native_kind("~w/3", "weighted_shortest_path3");
    vm.register_foreign_result_layout("~w/3", "tuple:2");
    vm.register_foreign_result_mode("~w/3", "stream");
    vm.register_foreign_string_config("~w/3", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
~w
~w
    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let temp_target = "__agg_target".to_string();
    let temp_cost = "__agg_cost".to_string();

    let mut grouped: BTreeMap<String, f64> = BTreeMap::new();
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start));

        if !vm.execute_foreign_predicate("~w", 3) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);

    if grouped.is_empty() {
        return false;
    }

    let packed_results: Vec<Value> = grouped.into_iter().map(|(group_key, cost)| {
        Value::Str("__tuple__".to_string(), vec![
            Value::Atom(group_key),
            Value::Float(cost),
        ])
    }).collect();
    vm.finish_foreign_results("~w", vec![a2.clone(), a3.clone()], packed_results)
}', [PredStr, PredKey, PredKey, InnerPredStr, InnerPredStr, InnerPredStr,
      InnerPredStr, WeightPredKey, WeightPredKey, TriplesLiteral,
      JoinRegistrationCode, FilterCode, TriplesLiteral, A2RegCode, InnerPredStr, TargetReadCode,
      TraversalCode, PredKey])
    ; Type == all,
      GoalArgs = [GoalStart, GoalOutput, GoalCost],
      rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, Expr, StagePlan),
      ( JoinPreds == []
      -> FilterCode =
'    let target_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
         A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
         TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
         JoinRegistrationCode = "",
         rust_foreign_wrapper_stage_traversal_code([], "target_filter", "target", "&target", "        ",
             scalar_min, StagePlan, TraversalCode)
      ; rust_render_join_specs(JoinPreds, JoinSpecs),
         rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
        FilterCode =
'    let target_filter = match &a2 {
        Value::Unbound(_) => None,
        Value::Atom(group) => Some(group.clone()),
        _ => return false,
    };',
        A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", Value::Unbound(temp_cost.clone()));',
        TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
        rust_foreign_wrapper_stage_traversal_code(JoinPreds, "target_filter", "target", "&target", "        ",
            scalar_min, StagePlan, TraversalCode)
      ),
      format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value) -> bool {
    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_native_kind("~w/3", "weighted_shortest_path3");
    vm.register_foreign_result_layout("~w/3", "tuple:2");
    vm.register_foreign_result_mode("~w/3", "stream");
    vm.register_foreign_string_config("~w/3", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
~w
~w
    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let temp_target = "__agg_target".to_string();
    let temp_cost = "__agg_cost".to_string();

    let mut best: Option<f64> = None;
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start));

        if !vm.execute_foreign_predicate("~w", 3) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);

    match best {
        Some(cost) => vm.unify(&a3, &Value::Float(cost)),
        None => false,
    }
}', [PredStr, InnerPredStr, InnerPredStr, InnerPredStr, InnerPredStr,
      WeightPredKey, WeightPredKey, TriplesLiteral,
      JoinRegistrationCode, FilterCode, TriplesLiteral, A2RegCode, InnerPredStr, TargetReadCode,
      TraversalCode])
    ).

compile_rust_foreign_min_aggregate_wrapper_from_plan(Pred, 4,
        foreign_aggregate_plan(
            astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim),
            JoinPreds,
            [GoalStart, GoalOutput, GoalDim, GoalCost],
            Expr,
            Type,
            GroupTerm,
            GoalInfo),
        RustCode) :-
    atom_string(Pred, PredStr),
    format(string(PredKey), '~w/4', [Pred]),
    rust_render_astar_kernel(
        astar_kernel(InnerPred, WeightPred/3, FactTriples, DirectPred/3, DirectTriples, DefaultDim),
        InnerPredStr, WeightPredKey, WeightTriplesLiteral, DirectPredKey, DirectTriplesLiteral, DefaultDim),
    ( Type == group
    -> parse_group_term_rust(GroupTerm, [GroupVar]),
       GroupVar == GoalOutput,
       GoalArgs = [GoalStart, GoalOutput, GoalDim, GoalCost],
       rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, Expr, StagePlan),
       ( JoinPreds == []
       -> FilterCode =
'    let output_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
          A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
          TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
          JoinRegistrationCode = "",
          rust_foreign_wrapper_stage_traversal_code([], "output_filter", "target", "&target", "        ",
              grouped_min, StagePlan, TraversalCode)
       ; rust_render_join_specs(JoinPreds, JoinSpecs),
         rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
         FilterCode =
'    let output_filter = match &a2 {
        Value::Atom(group) => Some(group.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
         A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
         TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
         rust_foreign_wrapper_stage_traversal_code(JoinPreds, "output_filter", "target", "&target", "        ",
             grouped_min, StagePlan, TraversalCode)
       ),
       format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value, a4: Value) -> bool {
    use std::collections::BTreeMap;

    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_result_layout("~w", "tuple:2");
    vm.register_foreign_result_mode("~w", "stream");
    vm.register_foreign_native_kind("~w/4", "astar_shortest_path4");
    vm.register_foreign_result_layout("~w/4", "tuple:2");
    vm.register_foreign_result_mode("~w/4", "stream");
    vm.register_foreign_string_config("~w/4", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_string_config("~w/4", "direct_dist_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_usize_config("~w/4", "dimensionality", ~w);
~w
~w
    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let temp_target = "__agg_target".to_string();
    let temp_cost = "__agg_cost".to_string();

    let dim_value = match &a3 {
        Value::Integer(d) => *d as f64,
        Value::Float(d) => *d,
        _ => ~w_f64,
    };

    let mut grouped: BTreeMap<String, f64> = BTreeMap::new();
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start));

        if !vm.execute_foreign_predicate("~w", 4) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);

    if grouped.is_empty() {
        return false;
    }

    let packed_results: Vec<Value> = grouped.into_iter().map(|(group_key, cost)| {
        Value::Str("__tuple__".to_string(), vec![
            Value::Atom(group_key),
            Value::Float(cost),
        ])
    }).collect();
    vm.finish_foreign_results("~w", vec![a2.clone(), a4.clone()], packed_results)
}', [PredStr, PredKey, PredKey, InnerPredStr, InnerPredStr, InnerPredStr,
      InnerPredStr, WeightPredKey, WeightPredKey, WeightTriplesLiteral,
      InnerPredStr, DirectPredKey, DirectPredKey, DirectTriplesLiteral,
      InnerPredStr, DefaultDim, JoinRegistrationCode, FilterCode, WeightTriplesLiteral,
      DefaultDim, A2RegCode, InnerPredStr, TargetReadCode, TraversalCode, PredKey])
    ; Type == all,
      GoalArgs = [GoalStart, GoalOutput, GoalDim, GoalCost],
      rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, Expr, StagePlan),
      ( JoinPreds == []
      -> FilterCode =
'    let target_filter = match &a2 {
        Value::Atom(target) => Some(target.clone()),
        Value::Unbound(_) => None,
        _ => return false,
    };',
         A2RegCode =
'    let target_arg = match &a2 {
        Value::Unbound(_) => Value::Unbound(temp_target.clone()),
        _ => a2.clone(),
    };

    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", target_arg);
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
         TargetReadCode =
'        let target = match &a2 {
            Value::Atom(target) => target.clone(),
            Value::Unbound(_) => match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Atom(target)) => target,
                _ => break,
            },
            _ => break,
        };',
         JoinRegistrationCode = "",
         rust_foreign_wrapper_stage_traversal_code([], "target_filter", "target", "&target", "        ",
             scalar_min, StagePlan, TraversalCode)
      ; rust_render_join_specs(JoinPreds, JoinSpecs),
        rust_foreign_join_registration_code(JoinSpecs, JoinRegistrationCode),
        FilterCode =
'    let target_filter = match &a2 {
        Value::Unbound(_) => None,
        Value::Atom(group) => Some(group.clone()),
        _ => return false,
    };',
        A2RegCode =
'    vm.set_reg("A1", a1.clone());
    vm.set_reg("A2", Value::Unbound(temp_target.clone()));
    vm.set_reg("A3", a3.clone());
    vm.set_reg("A4", Value::Unbound(temp_cost.clone()));',
        TargetReadCode =
'        let target = match vm.bindings.get(&temp_target).cloned().map(|v| vm.deref_var(&v)) {
            Some(Value::Atom(target)) => target,
            _ => break,
        };',
        rust_foreign_wrapper_stage_traversal_code(JoinPreds, "target_filter", "target", "&target", "        ",
            scalar_min, StagePlan, TraversalCode)
      ),
      format(string(RustCode),
'pub fn ~w(vm: &mut WamState, a1: Value, a2: Value, a3: Value, a4: Value) -> bool {
    vm.reset_query();
    vm.code = Vec::new();
    vm.labels = HashMap::new();
    vm.pc = 1;
    vm.register_foreign_native_kind("~w/4", "astar_shortest_path4");
    vm.register_foreign_result_layout("~w/4", "tuple:2");
    vm.register_foreign_result_mode("~w/4", "stream");
    vm.register_foreign_string_config("~w/4", "weight_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_string_config("~w/4", "direct_dist_pred", "~w");
    vm.register_indexed_weighted_edge_triples("~w", &~w);
    vm.register_foreign_usize_config("~w/4", "dimensionality", ~w);
~w
~w
    let start_candidates: Vec<String> = match &a1 {
        Value::Atom(start) => vec![start.clone()],
        Value::Unbound(_) => {
            let mut starts: Vec<String> = Vec::new();
            for (source, _, _) in &~w {
                if !starts.iter().any(|item| item.as_str() == *source) {
                    starts.push((*source).to_string());
                }
            }
            starts
        }
        _ => return false,
    };

    let temp_target = "__agg_target".to_string();
    let temp_cost = "__agg_cost".to_string();

    let dim_value = match &a3 {
        Value::Integer(d) => *d as f64,
        Value::Float(d) => *d,
        _ => ~w_f64,
    };

    let mut best: Option<f64> = None;
    for start in start_candidates {
        vm.bindings.remove(&temp_target);
        vm.bindings.remove(&temp_cost);
~w
        vm.set_reg("A1", Value::Atom(start));

        if !vm.execute_foreign_predicate("~w", 4) {
            continue;
        }

        loop {
~w
            let cost = match vm.bindings.get(&temp_cost).cloned().map(|v| vm.deref_var(&v)) {
                Some(Value::Float(cost)) => cost,
                _ => break,
            };
~w
            if !vm.backtrack() {
                break;
            }
        }
    }

    vm.bindings.remove(&temp_target);
    vm.bindings.remove(&temp_cost);

    match best {
        Some(cost) => vm.unify(&a4, &Value::Float(cost)),
        None => false,
    }
}', [PredStr, InnerPredStr, InnerPredStr, InnerPredStr, InnerPredStr,
      WeightPredKey, WeightPredKey, WeightTriplesLiteral,
      InnerPredStr, DirectPredKey, DirectPredKey, DirectTriplesLiteral,
      InnerPredStr, DefaultDim, JoinRegistrationCode, FilterCode, WeightTriplesLiteral,
      DefaultDim, A2RegCode, InnerPredStr, TargetReadCode, TraversalCode])
    ).

rust_foreign_wrapper_stage_plan(GoalInfo, GoalArgs, Expr,
        wrapper_stage_plan(ComputeStage, FilterStages)) :-
    get_dict(other, GoalInfo, []),
    rust_foreign_wrapper_compute_stage(Expr, GoalInfo, GoalArgs, ComputeStage),
    get_dict(constraints, GoalInfo, Constraints),
    findall(filter_stage(Part),
        ( member(Constraint, Constraints),
          rust_foreign_wrapper_constraint_expr(Constraint, GoalArgs, Expr, Part)
        ),
        FilterStages).

rust_foreign_wrapper_render_stage_plan(wrapper_stage_plan(ComputeStage, FilterStages),
        SetupCode, ValueExpr, FilterCond) :-
    rust_foreign_wrapper_render_compute_stage(ComputeStage, SetupCode, ValueExpr),
    findall(Part, member(filter_stage(Part), FilterStages), Parts),
    rust_combine_pipeline_conditions(Parts, FilterCond).

rust_foreign_wrapper_compute_stage(Expr, GoalInfo, GoalArgs, passthrough_stage("cost")) :-
    last(GoalArgs, CostArg),
    Expr == CostArg,
    get_dict(other, GoalInfo, []).
rust_foreign_wrapper_compute_stage(Expr, GoalInfo, GoalArgs, compute_stage("agg_value", RustExpr)) :-
    get_dict(other, GoalInfo, []),
    get_dict(arithmetic, GoalInfo, Arithmetic),
    member(Arithmetic0, Arithmetic),
    strip_module(Arithmetic0, _, ArithmeticGoal),
    ArithmeticGoal = (Expr is ArithmeticExpr),
    rust_foreign_wrapper_numeric_expr(ArithmeticExpr, GoalArgs, Expr, RustExpr).

rust_foreign_wrapper_render_compute_stage(passthrough_stage(ValueExpr), "", ValueExpr).
rust_foreign_wrapper_render_compute_stage(compute_stage(ValueExpr, RustExpr), SetupCode, ValueExpr) :-
    format(string(SetupCode), '            let ~w = ~w;~n', [ValueExpr, RustExpr]).

rust_foreign_wrapper_numeric_expr(Expr, _GoalArgs, _AggExpr, RustExpr) :-
    number(Expr),
    !,
    format(string(RustExpr), '~w_f64', [Expr]).
rust_foreign_wrapper_numeric_expr(Expr, GoalArgs, _AggExpr, "cost") :-
    var(Expr),
    last(GoalArgs, CostArg),
    Expr == CostArg,
    !.
rust_foreign_wrapper_numeric_expr(Expr, GoalArgs, _AggExpr, "dim_value") :-
    var(Expr),
    GoalArgs = [_StartArg, _TargetArg, DimArg, _CostArg],
    Expr == DimArg,
    !.
rust_foreign_wrapper_numeric_expr(Expr, GoalArgs, AggExpr, RustExpr) :-
    compound(Expr),
    Expr =.. [Op, Left, Right],
    member(Op-Sym, [(+)-'+', (-)-'-', (*)-'*', (/)-'/']),
    rust_foreign_wrapper_numeric_expr(Left, GoalArgs, AggExpr, LeftExpr),
    rust_foreign_wrapper_numeric_expr(Right, GoalArgs, AggExpr, RightExpr),
    format(string(RustExpr), '(~w ~w ~w)', [LeftExpr, Sym, RightExpr]).

rust_foreign_wrapper_constraint_expr(Constraint0, GoalArgs, AggExpr, Cond) :-
    strip_module(Constraint0, _, Constraint),
    Constraint =.. [Op, Left0, Right0],
    rust_foreign_wrapper_constraint_operand(Left0, GoalArgs, AggExpr, LeftType, LeftExpr),
    rust_foreign_wrapper_constraint_operand(Right0, GoalArgs, AggExpr, RightType, RightExpr),
    rust_foreign_wrapper_constraint_operator(Op, LeftType, RightType, OpExpr),
    format(string(Cond), '~w ~w ~w', [LeftExpr, OpExpr, RightExpr]).

rust_foreign_wrapper_constraint_operand(Operand, GoalArgs, AggExpr, number, "agg_value") :-
    var(Operand),
    Operand == AggExpr,
    \+ (last(GoalArgs, CostArg), Operand == CostArg),
    !.
rust_foreign_wrapper_constraint_operand(Operand, GoalArgs, _AggExpr, number, "cost") :-
    var(Operand),
    last(GoalArgs, CostArg),
    Operand == CostArg,
    !.
rust_foreign_wrapper_constraint_operand(Operand, GoalArgs, _AggExpr, number, "dim_value") :-
    var(Operand),
    GoalArgs = [_StartArg, _TargetArg, DimArg, _CostArg],
    Operand == DimArg,
    !.
rust_foreign_wrapper_constraint_operand(Operand, GoalArgs, _AggExpr, string, "target.as_str()") :-
    var(Operand),
    GoalArgs = [_StartArg, TargetArg|_],
    Operand == TargetArg,
    !.
rust_foreign_wrapper_constraint_operand(Operand, _GoalArgs, _AggExpr, number, RustExpr) :-
    number(Operand),
    !,
    format(string(RustExpr), '~w_f64', [Operand]).
rust_foreign_wrapper_constraint_operand(Operand, _GoalArgs, _AggExpr, string, RustExpr) :-
    atom(Operand),
    !,
    format(string(RustExpr), '"~w"', [Operand]).

rust_foreign_wrapper_constraint_operator(Op, number, number, Sym) :-
    member(Op-Sym, [(>)-'>', (<)-'<', (>=)-'>=', (=<)-'<=', (=:=)-'==', (=\\=)-'!=', (==)-'==', (\\==)-'!=']),
    !.
rust_foreign_wrapper_constraint_operator(Op, string, string, Sym) :-
    member(Op-Sym, [(==)-'==', (\\==)-'!=']),
    !.

rust_weighted_fact_triples_literal(Triples, Literal) :-
    maplist(rust_weighted_fact_triple_literal, Triples, TripleLiterals),
    atomic_list_concat(TripleLiterals, ', ', Joined),
    format(string(Literal), '[~w]', [Joined]).

rust_atom_fact_pairs_literal(Pairs, Literal) :-
    maplist(rust_atom_fact_pair_literal, Pairs, PairLiterals),
    atomic_list_concat(PairLiterals, ', ', Joined),
    format(string(Literal), '[~w]', [Joined]).

rust_binary_atom_fact_pairs(Pred/2, Pairs) :-
    findall(Left-Right,
        ( functor(JoinHead, Pred, 2),
          user:clause(JoinHead, true),
          JoinHead =.. [Pred, Left, Right],
          atom(Left),
          atom(Right)
        ),
        Pairs),
    Pairs \= [].

rust_atom_fact_pair_literal(Left-Right, Literal) :-
    rust_literal(Left, LeftLiteral),
    rust_literal(Right, RightLiteral),
    format(string(Literal), '(~w, ~w)', [LeftLiteral, RightLiteral]).

rust_weighted_fact_triple_literal(Left-Right-Weight, Literal) :-
    rust_literal(Left, LeftLiteral),
    rust_literal(Right, RightLiteral),
    format(string(Literal), '(~w, ~w, ~w)', [LeftLiteral, RightLiteral, Weight]).

rust_filter_fact_rows(_GoalArgs, GoalInfo, FactRows, FilteredRows) :-
    include(rust_fact_row_matches(GoalInfo), FactRows, FilteredRows).

rust_fact_row_matches(GoalInfo, FactArgs) :-
    get_dict(relations, GoalInfo, [RelGoal|_]),
    RelGoal =.. [_|GoalArgs],
    rust_match_goal_args(GoalArgs, FactArgs, [], Bindings),
    get_dict(constraints, GoalInfo, Constraints),
    maplist(rust_constraint_holds(Bindings), Constraints).

rust_match_goal_args([], [], Bindings, Bindings).
rust_match_goal_args([GoalArg|GoalRest], [FactArg|FactRest], BindingsIn, BindingsOut) :-
    rust_match_goal_arg(GoalArg, FactArg, BindingsIn, BindingsMid),
    rust_match_goal_args(GoalRest, FactRest, BindingsMid, BindingsOut).

rust_match_goal_arg(GoalArg, FactArg, BindingsIn, BindingsOut) :-
    (   var(GoalArg)
    ->  (   member(BoundVar-BoundVal, BindingsIn),
            BoundVar == GoalArg
        ->  BoundVal = FactArg,
            BindingsOut = BindingsIn
        ;   BindingsOut = [GoalArg-FactArg|BindingsIn]
        )
    ;   GoalArg = FactArg,
        BindingsOut = BindingsIn
    ).

rust_constraint_holds(Bindings, Constraint0) :-
    strip_module(Constraint0, _, Constraint),
    Constraint =.. [Op, Left0, Right0],
    rust_constraint_operand(Bindings, Left0, Left),
    rust_constraint_operand(Bindings, Right0, Right),
    rust_apply_constraint(Op, Left, Right).

rust_constraint_operand(Bindings, Operand0, Operand) :-
    (   var(Operand0)
    ->  member(BoundVar-Operand, Bindings),
        BoundVar == Operand0
    ;   Operand = Operand0
    ).

rust_apply_constraint(>, Left, Right) :- Left > Right.
rust_apply_constraint(<, Left, Right) :- Left < Right.
rust_apply_constraint(>=, Left, Right) :- Left >= Right.
rust_apply_constraint(=<, Left, Right) :- Left =< Right.
rust_apply_constraint(=:=, Left, Right) :- Left =:= Right.
rust_apply_constraint(=\=, Left, Right) :- Left =\= Right.
rust_apply_constraint(==, Left, Right) :- Left == Right.
rust_apply_constraint(\==, Left, Right) :- Left \== Right.

aggregate_value_index(count, _Expr, _Args, -1) :- !.
aggregate_value_index(Op, Expr, Args, Index) :-
    member(Op, [sum, avg, min, max, set, bag]),
    nth0(Index, Args, Arg),
    Arg == Expr,
    !.

compile_rust_scalar_aggregate(Pred, Op, ValueIndex, FactRows, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    rust_scalar_return_type(Op, ReturnType),
    rust_scalar_seed(Op, SeedExpr),
    rust_scalar_update(Op, UpdateExpr),
    rust_scalar_finish(Op, FinishExpr),
    rust_scalar_rows(Op, ValueIndex, FactRows, RowsExpr),
    format(string(FuncCode),
'use std::collections::{HashMap, HashSet};

fn ~w() -> ~w {
    let rows = ~w;
    let mut agg = ~w;
    for value in rows.iter() {
        ~w
    }
    ~w
}', [PredStr, ReturnType, RowsExpr, SeedExpr, UpdateExpr, FinishExpr]),
    (   IncludeMain
    ->  format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - aggregate_all lowering

~w

fn main() {
    let result = ~w();
    println!("{:?}", result);
}
', [FuncCode, PredStr])
    ;   RustCode = FuncCode
    ).

compile_rust_grouped_aggregate(Pred, Op, GoalArgs, GroupTerm, ValueIndex, FactRows, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    parse_group_term_rust(GroupTerm, GroupVars),
    GroupVars = [GroupVar],
    nth0(GroupIndex, GoalArgs, GroupVar),
    rust_group_rows(Op, GroupIndex, ValueIndex, FactRows, RowsExpr),
    rust_group_update(Op, UpdateExpr),
    rust_group_value_type(Op, ValueType),
    rust_group_seed(Op, SeedExpr),
    rust_group_finish(Op, FinishExpr),
    format(string(FuncCode),
'use std::collections::HashMap;

fn ~w() -> HashMap<String, ~w> {
    let rows = ~w;
    let mut groups: HashMap<String, ~w> = HashMap::new();
    for (key, value) in rows.into_iter() {
        let entry = groups.entry(key).or_insert(~w);
        ~w
    }
    ~w
}', [PredStr, ValueType, RowsExpr, ValueType, SeedExpr, UpdateExpr, FinishExpr]),
    (   IncludeMain
    ->  format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - aggregate_all lowering

~w

fn main() {
    let result = ~w();
    println!("{:?}", result);
}
', [FuncCode, PredStr])
    ;   RustCode = FuncCode
    ).

rust_scalar_return_type(count, 'usize').
rust_scalar_return_type(sum, 'f64').
rust_scalar_return_type(avg, 'f64').
rust_scalar_return_type(min, 'f64').
rust_scalar_return_type(max, 'f64').
rust_scalar_return_type(set, 'Vec<String>').
rust_scalar_return_type(bag, 'Vec<String>').

rust_scalar_seed(count, '0usize').
rust_scalar_seed(sum, '0.0_f64').
rust_scalar_seed(avg, '(0.0_f64, 0usize)').
rust_scalar_seed(min, 'f64::INFINITY').
rust_scalar_seed(max, 'f64::NEG_INFINITY').
rust_scalar_seed(set, 'HashSet::new()').
rust_scalar_seed(bag, 'Vec::new()').

rust_scalar_update(count, 'agg += 1;').
rust_scalar_update(sum, 'agg += *value;').
rust_scalar_update(avg, 'agg.0 += *value; agg.1 += 1;').
rust_scalar_update(min, 'agg = agg.min(*value);').
rust_scalar_update(max, 'agg = agg.max(*value);').
rust_scalar_update(set, 'agg.insert(value.clone());').
rust_scalar_update(bag, 'agg.push(value.clone());').

rust_scalar_finish(count, 'agg').
rust_scalar_finish(sum, 'agg').
rust_scalar_finish(avg, 'if agg.1 == 0 { 0.0 } else { agg.0 / (agg.1 as f64) }').
rust_scalar_finish(min, 'agg').
rust_scalar_finish(max, 'agg').
rust_scalar_finish(set, 'agg.into_iter().collect()').
rust_scalar_finish(bag, 'agg').

rust_group_value_type(count, 'usize').
rust_group_value_type(sum, 'f64').
rust_group_value_type(avg, '(f64, usize)').
rust_group_value_type(min, 'f64').
rust_group_value_type(max, 'f64').

rust_group_seed(count, '0usize').
rust_group_seed(sum, '0.0_f64').
rust_group_seed(avg, '(0.0_f64, 0usize)').
rust_group_seed(min, 'f64::INFINITY').
rust_group_seed(max, 'f64::NEG_INFINITY').

rust_group_update(count, '*entry += 1;').
rust_group_update(sum, '*entry += value;').
rust_group_update(avg, 'entry.0 += value; entry.1 += 1;').
rust_group_update(min, '*entry = (*entry).min(value);').
rust_group_update(max, '*entry = (*entry).max(value);').

rust_group_finish(avg,
'groups.into_iter()
        .map(|(k, (sum, count))| (k, if count == 0 { 0.0 } else { sum / (count as f64) }))
        .collect()').
rust_group_finish(_Op, 'groups').

rust_scalar_rows(count, _ValueIndex, FactRows, RowsExpr) :-
    length(FactRows, Count),
    format(string(RowsExpr), 'vec![(); ~w]', [Count]).
rust_scalar_rows(set, ValueIndex, FactRows, RowsExpr) :-
    maplist(rust_value_at_string(ValueIndex), FactRows, Values),
    atomic_list_concat(Values, ', ', Joined),
    format(string(RowsExpr), 'vec![~w]', [Joined]).
rust_scalar_rows(bag, ValueIndex, FactRows, RowsExpr) :-
    maplist(rust_value_at_string(ValueIndex), FactRows, Values),
    atomic_list_concat(Values, ', ', Joined),
    format(string(RowsExpr), 'vec![~w]', [Joined]).
rust_scalar_rows(_Op, ValueIndex, FactRows, RowsExpr) :-
    maplist(rust_value_at_float(ValueIndex), FactRows, Values),
    atomic_list_concat(Values, ', ', Joined),
    format(string(RowsExpr), 'vec![~w]', [Joined]).

rust_group_rows(count, GroupIndex, _ValueIndex, FactRows, RowsExpr) :-
    maplist(rust_group_count_pair(GroupIndex), FactRows, Pairs),
    atomic_list_concat(Pairs, ', ', Joined),
    format(string(RowsExpr), 'vec![~w]', [Joined]).
rust_group_rows(_Op, GroupIndex, ValueIndex, FactRows, RowsExpr) :-
    ValueIndex >= 0,
    maplist(rust_group_value_pair(GroupIndex, ValueIndex), FactRows, Pairs),
    atomic_list_concat(Pairs, ', ', Joined),
    format(string(RowsExpr), 'vec![~w]', [Joined]).

rust_group_count_pair(GroupIndex, FactArgs, PairExpr) :-
    nth0(GroupIndex, FactArgs, GroupVal),
    rust_term_string(GroupVal, GroupExpr),
    format(string(PairExpr), '(~w, 1usize)', [GroupExpr]).

rust_group_value_pair(GroupIndex, ValueIndex, FactArgs, PairExpr) :-
    nth0(GroupIndex, FactArgs, GroupVal),
    nth0(ValueIndex, FactArgs, Value),
    rust_term_string(GroupVal, GroupExpr),
    rust_term_float(Value, ValueExpr),
    format(string(PairExpr), '(~w, ~w)', [GroupExpr, ValueExpr]).

parse_group_term_rust(Var, [Var]) :-
    var(Var),
    !.
parse_group_term_rust(Term, Vars) :-
    term_variables(Term, Vars).

rust_value_at_float(Index, FactArgs, Expr) :-
    nth0(Index, FactArgs, Value),
    rust_term_float(Value, Expr).

rust_value_at_string(Index, FactArgs, Expr) :-
    nth0(Index, FactArgs, Value),
    rust_term_string(Value, Expr).

rust_term_float(Value, Expr) :-
    number(Value),
    !,
    format(string(Expr), '~w_f64', [Value]).
rust_term_float(Value, Expr) :-
    atom(Value),
    !,
    format(string(Expr), '"~w".parse::<f64>().unwrap()', [Value]).

rust_term_string(Value, Expr) :-
    atom(Value),
    !,
    format(string(Expr), '"~w".to_string()', [Value]).
rust_term_string(Value, Expr) :-
    number(Value),
    !,
    format(string(Expr), '"~w".to_string()', [Value]).

compile_rust_recursive_aggregate(Pred, Goal, InnerPred, InnerArity, GoalArgs, Op, ValueIndex, IncludeMain, RustCode) :-
    functor(InnerHead, InnerPred, InnerArity),
    findall(InnerHead-InnerBody, user:clause(InnerHead, InnerBody), Clauses),
    Clauses \= [],
    term_variables(Goal, GoalVars),
    GoalVars = [InputVar|_],
    nth0(0, GoalArgs, InputVar),
    (   rust_computed_increment_pattern(InnerPred, Clauses, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven)
    ->  compile_rust_recursive_accumulation_aggregate(Pred, InnerPred, InnerArity, Op, ValueIndex, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, IncludeMain, RustCode)
    ;   is_general_recursive_pattern_rust(InnerPred, InnerArity, Clauses)
    ->  compile_rust_recursive_tc_aggregate(Pred, InnerPred, InnerArity, Op, ValueIndex, Clauses, IncludeMain, RustCode)
    ).

compile_rust_grouped_recursive_aggregate(Pred, _Goal, InnerPred, InnerArity, GoalArgs, GroupTerm, Op, ValueIndex, IncludeMain, RustCode) :-
    functor(InnerHead, InnerPred, InnerArity),
    findall(InnerHead-InnerBody, user:clause(InnerHead, InnerBody), Clauses),
    Clauses \= [],
    parse_group_term_rust(GroupTerm, GroupVars),
    GroupVars = [GroupVar],
    nth0(GroupArgIndex, GoalArgs, GroupVar),
    GroupArgIndex > 0,
    (   rust_computed_increment_pattern(InnerPred, Clauses, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven)
    ->  compile_rust_grouped_recursive_accumulation_aggregate(Pred, InnerPred, InnerArity, GroupArgIndex, Op, ValueIndex, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, IncludeMain, RustCode)
    ;   is_general_recursive_pattern_rust(InnerPred, InnerArity, Clauses)
    ->  compile_rust_grouped_recursive_tc_aggregate(Pred, InnerPred, InnerArity, GroupArgIndex, Op, ValueIndex, Clauses, IncludeMain, RustCode)
    ).

compile_rust_recursive_tc_aggregate(Pred, InnerPred, InnerArity, Op, ValueIndex, Clauses, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    atom_string(InnerPred, InnerPredStr),
    rust_declared_table_mode(InnerPred/InnerArity, TableMode),
    partition(is_rec_clause_rust(InnerPred), Clauses, RecClauses, BaseClauses),
    extract_tc_pattern_rust(BaseClauses, RecClauses, _StepRel, BaseConstStr, IncrStr, FactBlock),
    rust_recursive_aggregate_return_type(Op, ReturnType),
    rust_recursive_aggregate_seed(Op, SeedExpr),
    rust_recursive_aggregate_update_from_tuple(Op, ValueIndex, UpdateExpr),
    rust_recursive_aggregate_finish(Op, FinishExpr),
    (   TableMode == min
    ->  format(string(SupportCode),
'use std::collections::{HashMap, VecDeque};

fn ~w_min(start: &str, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {
    let mut best: HashMap<String, i32> = HashMap::new();
    let mut queue: VecDeque<(String, i32)> = VecDeque::new();
    if let Some(neighbors) = adj.get(start) {
        for nb in neighbors {
            queue.push_back((nb.clone(), ~w));
        }
    }
    while let Some((node, depth)) = queue.pop_front() {
        if let Some(existing) = best.get(&node) {
            if depth >= *existing {
                continue;
            }
        }
        best.insert(node.clone(), depth);
        if let Some(neighbors) = adj.get(&node) {
            for nb in neighbors {
                queue.push_back((nb.clone(), depth + ~w));
            }
        }
    }
    let mut results: Vec<(String, i32)> = best.into_iter().collect();
    results.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.cmp(&b.1)));
    results
}', [InnerPredStr, BaseConstStr, IncrStr]),
        format(string(WorkerCall), '~w_min(arg1, &adj)', [InnerPredStr])
    ;   format(string(SupportCode),
'use std::collections::{HashMap, HashSet};

fn ~w_worker(arg1: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {
    if visited.contains(arg1) {
        return Vec::new();
    }
    let mut new_visited = visited.clone();
    new_visited.insert(arg1.to_string());
    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {
        for nb in neighbors {
            if !new_visited.contains(nb.as_str()) {
                results.push((nb.clone(), ~w));
                for (ancestor, h) in ~w_worker(nb, &new_visited, adj) {
                    results.push((ancestor, h + ~w));
                }
            }
        }
    }
    results
}', [InnerPredStr, BaseConstStr, InnerPredStr, IncrStr]),
        format(string(WorkerCall), '{ let visited = HashSet::new(); ~w_worker(arg1, &visited, &adj) }', [InnerPredStr])
    ),
    format(string(FuncCode),
'// aggregate_all over recursive predicate
~w

fn ~w(arg1: &str) -> ~w {
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w
    let inner_results = ~w;
    let rows = inner_results.iter();
    let mut agg = ~w;
    for row in rows {
        ~w
    }
    ~w
}', [SupportCode, PredStr, ReturnType, FactBlock, WorkerCall, SeedExpr, UpdateExpr, FinishExpr]),
    rust_wrap_function_with_main(PredStr, FuncCode, IncludeMain, RustCode).

compile_rust_grouped_recursive_tc_aggregate(Pred, InnerPred, InnerArity, GroupArgIndex, Op, ValueIndex, Clauses, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    atom_string(InnerPred, InnerPredStr),
    rust_declared_table_mode(InnerPred/InnerArity, TableMode),
    partition(is_rec_clause_rust(InnerPred), Clauses, RecClauses, BaseClauses),
    extract_tc_pattern_rust(BaseClauses, RecClauses, _StepRel, BaseConstStr, IncrStr, FactBlock),
    rust_grouped_recursive_aggregate_return_type(Op, ReturnType),
    rust_grouped_recursive_aggregate_seed(Op, SeedExpr),
    rust_recursive_group_key_expr(GroupArgIndex, KeyExpr),
    rust_recursive_group_update_from_tuple(Op, ValueIndex, UpdateExpr),
    rust_grouped_recursive_aggregate_finish(Op, FinishExpr),
    (   TableMode == min
    ->  format(string(SupportCode),
'use std::collections::{HashMap, VecDeque};

fn ~w_min(start: &str, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {
    let mut best: HashMap<String, i32> = HashMap::new();
    let mut queue: VecDeque<(String, i32)> = VecDeque::new();
    if let Some(neighbors) = adj.get(start) {
        for nb in neighbors {
            queue.push_back((nb.clone(), ~w));
        }
    }
    while let Some((node, depth)) = queue.pop_front() {
        if let Some(existing) = best.get(&node) {
            if depth >= *existing {
                continue;
            }
        }
        best.insert(node.clone(), depth);
        if let Some(neighbors) = adj.get(&node) {
            for nb in neighbors {
                queue.push_back((nb.clone(), depth + ~w));
            }
        }
    }
    let mut results: Vec<(String, i32)> = best.into_iter().collect();
    results.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.cmp(&b.1)));
    results
}', [InnerPredStr, BaseConstStr, IncrStr]),
        format(string(WorkerCall), '~w_min(arg1, &adj)', [InnerPredStr])
    ;   format(string(SupportCode),
'use std::collections::{HashMap, HashSet};

fn ~w_worker(arg1: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {
    if visited.contains(arg1) {
        return Vec::new();
    }
    let mut new_visited = visited.clone();
    new_visited.insert(arg1.to_string());
    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {
        for nb in neighbors {
            if !new_visited.contains(nb.as_str()) {
                results.push((nb.clone(), ~w));
                for (ancestor, h) in ~w_worker(nb, &new_visited, adj) {
                    results.push((ancestor, h + ~w));
                }
            }
        }
    }
    results
}', [InnerPredStr, BaseConstStr, InnerPredStr, IncrStr]),
        format(string(WorkerCall), '{ let visited = HashSet::new(); ~w_worker(arg1, &visited, &adj) }', [InnerPredStr])
    ),
    format(string(FuncCode),
'// aggregate_all grouped over recursive predicate
~w

fn ~w(arg1: &str) -> HashMap<String, ~w> {
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w
    let inner_results = ~w;
    let mut groups: HashMap<String, ~w> = HashMap::new();
    for row in inner_results.iter() {
        let key = ~w;
        let entry = groups.entry(key).or_insert(~w);
        ~w
    }
    ~w
}', [SupportCode, PredStr, ReturnType, FactBlock, WorkerCall, ReturnType, KeyExpr, SeedExpr, UpdateExpr, FinishExpr]),
    rust_wrap_function_with_main(PredStr, FuncCode, IncludeMain, RustCode).

compile_rust_recursive_accumulation_aggregate(Pred, InnerPred, InnerArity, Op, ValueIndex, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    atom_string(InnerPred, InnerPredStr),
    rust_declared_table_mode(InnerPred/InnerArity, TableMode),
    (   (PositiveStepGuardProven == true ; rust_positive_step_metadata(InnerPred/InnerArity, InnerArity))
    ->  PositiveStepProven = true
    ;   PositiveStepProven = false
    ),
    rust_accumulation_numeric_type(BaseExpr, RecExpr, AccType),
    rust_accumulation_expr(BaseExpr, [AuxValue-'*step_cost'], AccType, BaseExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-acc, AuxValue-'*step_cost'], AccType, RecExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-cost, AuxValue-'*step_cost'], AccType, MinRecExprCode),
    functor(StepHead, StepRel, 2),
    findall(StepLine,
        (   user:clause(StepHead, true),
            StepHead =.. [_, K, V],
            format(string(StepLine), '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());', [K, V])
        ),
        StepLines),
    atomic_list_concat(StepLines, '\n', StepBlock),
    functor(AuxHead, AuxRel, 2),
    findall(AuxLine,
        (   user:clause(AuxHead, true),
            AuxHead =.. [_, K, V],
            rust_numeric_literal(AccType, V, AuxLiteral),
            format(string(AuxLine), '    aux.insert("~w".to_string(), ~w);', [K, AuxLiteral])
        ),
        AuxLines),
    atomic_list_concat(AuxLines, '\n', AuxBlock),
    rust_recursive_aggregate_return_type(Op, ReturnType),
    rust_recursive_aggregate_seed(Op, SeedExpr),
    rust_recursive_aggregate_update_from_tuple(Op, ValueIndex, UpdateExpr),
    rust_recursive_aggregate_finish(Op, FinishExpr),
    (   TableMode == min,
        PositiveStepProven == true
    ->  format(string(SupportCode),
'use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap};

#[derive(Clone, Debug)]
struct State {
    cost: ~w,
    node: String,
}
impl PartialEq for State {
    fn eq(&self, other: &Self) -> bool { self.node == other.node && self.cost == other.cost }
}
impl Eq for State {}
impl Ord for State {
    fn cmp(&self, other: &Self) -> Ordering {
        other.cost.partial_cmp(&self.cost).unwrap_or(Ordering::Equal).then_with(|| self.node.cmp(&other.node))
    }
}
impl PartialOrd for State {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> { Some(self.cmp(other)) }
}

fn ~w_min(start: &str, adj: &HashMap<String, Vec<String>>, aux: &HashMap<String, ~w>) -> Vec<(String, ~w)> {
    let mut best: HashMap<String, ~w> = HashMap::new();
    let mut heap: BinaryHeap<State> = BinaryHeap::new();
    if let (Some(neighbors), Some(step_cost)) = (adj.get(start), aux.get(start)) {
        for nb in neighbors {
            heap.push(State { cost: ~w, node: nb.clone() });
        }
    }
    while let Some(State { cost, node }) = heap.pop() {
        if let Some(existing) = best.get(&node) {
            if cost >= *existing {
                continue;
            }
        }
        best.insert(node.clone(), cost);
        if let (Some(neighbors), Some(step_cost)) = (adj.get(&node), aux.get(&node)) {
            for nb in neighbors {
                heap.push(State { cost: ~w, node: nb.clone() });
            }
        }
    }
    let mut results: Vec<(String, ~w)> = best.into_iter().collect();
    results.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.partial_cmp(&b.1).unwrap_or(Ordering::Equal)));
    results
}', [AccType, InnerPredStr, AccType, AccType, AccType, BaseExprCode, MinRecExprCode, AccType]),
        format(string(WorkerCall), '~w_min(arg1, &adj, &aux)', [InnerPredStr])
    ;   format(string(SupportCode),
'use std::collections::{HashMap, HashSet};

fn ~w_worker(current: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>, aux: &HashMap<String, ~w>) -> Vec<(String, ~w)> {
    if visited.contains(current) { return Vec::new(); }
    let mut new_visited = visited.clone();
    new_visited.insert(current.to_string());
    let mut results = Vec::new();
    if let (Some(neighbors), Some(step_cost)) = (adj.get(current), aux.get(current)) {
        for nb in neighbors {
            if !new_visited.contains(nb.as_str()) {
                results.push((nb.clone(), ~w));
                for (ancestor, acc) in ~w_worker(nb, &new_visited, adj, aux) {
                    results.push((ancestor, ~w));
                }
            }
        }
    }
    results
}', [InnerPredStr, AccType, AccType, BaseExprCode, InnerPredStr, RecExprCode]),
        format(string(WorkerCall), '{ let visited = HashSet::new(); ~w_worker(arg1, &visited, &adj, &aux) }', [InnerPredStr])
    ),
    format(string(FuncCode),
'// aggregate_all over recursive accumulation predicate
~w

fn ~w(arg1: &str) -> ~w {
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w
    let mut aux: HashMap<String, ~w> = HashMap::new();
~w
    let inner_results = ~w;
    let rows = inner_results.iter();
    let mut agg = ~w;
    for row in rows {
        ~w
    }
    ~w
}', [SupportCode, PredStr, ReturnType, StepBlock, AccType, AuxBlock, WorkerCall, SeedExpr, UpdateExpr, FinishExpr]),
    rust_wrap_function_with_main(PredStr, FuncCode, IncludeMain, RustCode).

compile_rust_grouped_recursive_accumulation_aggregate(Pred, InnerPred, InnerArity, GroupArgIndex, Op, ValueIndex, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, IncludeMain, RustCode) :-
    atom_string(Pred, PredStr),
    atom_string(InnerPred, InnerPredStr),
    rust_declared_table_mode(InnerPred/InnerArity, TableMode),
    (   (PositiveStepGuardProven == true ; rust_positive_step_metadata(InnerPred/InnerArity, InnerArity))
    ->  PositiveStepProven = true
    ;   PositiveStepProven = false
    ),
    rust_accumulation_numeric_type(BaseExpr, RecExpr, AccType),
    rust_accumulation_expr(BaseExpr, [AuxValue-'*step_cost'], AccType, BaseExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-acc, AuxValue-'*step_cost'], AccType, RecExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-cost, AuxValue-'*step_cost'], AccType, MinRecExprCode),
    functor(StepHead, StepRel, 2),
    findall(StepLine,
        (   user:clause(StepHead, true),
            StepHead =.. [_, K, V],
            format(string(StepLine), '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());', [K, V])
        ),
        StepLines),
    atomic_list_concat(StepLines, '\n', StepBlock),
    functor(AuxHead, AuxRel, 2),
    findall(AuxLine,
        (   user:clause(AuxHead, true),
            AuxHead =.. [_, K, V],
            rust_numeric_literal(AccType, V, AuxLiteral),
            format(string(AuxLine), '    aux.insert("~w".to_string(), ~w);', [K, AuxLiteral])
        ),
        AuxLines),
    atomic_list_concat(AuxLines, '\n', AuxBlock),
    rust_grouped_recursive_aggregate_return_type(Op, ReturnType),
    rust_grouped_recursive_aggregate_seed(Op, SeedExpr),
    rust_recursive_group_key_expr(GroupArgIndex, KeyExpr),
    rust_recursive_group_update_from_tuple(Op, ValueIndex, UpdateExpr),
    rust_grouped_recursive_aggregate_finish(Op, FinishExpr),
    (   TableMode == min,
        PositiveStepProven == true
    ->  format(string(SupportCode),
'use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap};

#[derive(Clone, Debug)]
struct State {
    cost: ~w,
    node: String,
}
impl PartialEq for State {
    fn eq(&self, other: &Self) -> bool { self.node == other.node && self.cost == other.cost }
}
impl Eq for State {}
impl Ord for State {
    fn cmp(&self, other: &Self) -> Ordering {
        other.cost.partial_cmp(&self.cost).unwrap_or(Ordering::Equal).then_with(|| self.node.cmp(&other.node))
    }
}
impl PartialOrd for State {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> { Some(self.cmp(other)) }
}

fn ~w_min(start: &str, adj: &HashMap<String, Vec<String>>, aux: &HashMap<String, ~w>) -> Vec<(String, ~w)> {
    let mut best: HashMap<String, ~w> = HashMap::new();
    let mut heap: BinaryHeap<State> = BinaryHeap::new();
    if let (Some(neighbors), Some(step_cost)) = (adj.get(start), aux.get(start)) {
        for nb in neighbors {
            heap.push(State { cost: ~w, node: nb.clone() });
        }
    }
    while let Some(State { cost, node }) = heap.pop() {
        if let Some(existing) = best.get(&node) {
            if cost >= *existing {
                continue;
            }
        }
        best.insert(node.clone(), cost);
        if let (Some(neighbors), Some(step_cost)) = (adj.get(&node), aux.get(&node)) {
            for nb in neighbors {
                heap.push(State { cost: ~w, node: nb.clone() });
            }
        }
    }
    let mut results: Vec<(String, ~w)> = best.into_iter().collect();
    results.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.partial_cmp(&b.1).unwrap_or(Ordering::Equal)));
    results
}', [AccType, InnerPredStr, AccType, AccType, AccType, BaseExprCode, MinRecExprCode, AccType]),
        format(string(WorkerCall), '~w_min(arg1, &adj, &aux)', [InnerPredStr])
    ;   format(string(SupportCode),
'use std::collections::{HashMap, HashSet};

fn ~w_worker(current: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>, aux: &HashMap<String, ~w>) -> Vec<(String, ~w)> {
    if visited.contains(current) { return Vec::new(); }
    let mut new_visited = visited.clone();
    new_visited.insert(current.to_string());
    let mut results = Vec::new();
    if let (Some(neighbors), Some(step_cost)) = (adj.get(current), aux.get(current)) {
        for nb in neighbors {
            if !new_visited.contains(nb.as_str()) {
                results.push((nb.clone(), ~w));
                for (ancestor, acc) in ~w_worker(nb, &new_visited, adj, aux) {
                    results.push((ancestor, ~w));
                }
            }
        }
    }
    results
}', [InnerPredStr, AccType, AccType, BaseExprCode, InnerPredStr, RecExprCode]),
        format(string(WorkerCall), '{ let visited = HashSet::new(); ~w_worker(arg1, &visited, &adj, &aux) }', [InnerPredStr])
    ),
    format(string(FuncCode),
'// aggregate_all grouped over recursive accumulation predicate
~w

fn ~w(arg1: &str) -> HashMap<String, ~w> {
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w
    let mut aux: HashMap<String, ~w> = HashMap::new();
~w
    let inner_results = ~w;
    let mut groups: HashMap<String, ~w> = HashMap::new();
    for row in inner_results.iter() {
        let key = ~w;
        let entry = groups.entry(key).or_insert(~w);
        ~w
    }
    ~w
}', [SupportCode, PredStr, ReturnType, StepBlock, AccType, AuxBlock, WorkerCall, ReturnType, KeyExpr, SeedExpr, UpdateExpr, FinishExpr]),
    rust_wrap_function_with_main(PredStr, FuncCode, IncludeMain, RustCode).

extract_tc_pattern_rust(BaseClauses, RecClauses, StepRel, BaseConstStr, IncrStr, FactBlock) :-
    BaseClauses = [_-BaseBody|_],
    extract_goals_list_rust(BaseBody, BaseGoals),
    (   BaseGoals = [StepGoal|_],
        StepGoal =.. [StepRel|_]
    ->  true
    ;   StepRel = step
    ),
    (   BaseClauses = [BH-_|_],
        BH =.. [_|BArgs],
        length(BArgs, 3),
        nth1(3, BArgs, BaseConst),
        number(BaseConst)
    ->  format(string(BaseConstStr), "~w", [BaseConst])
    ;   BaseConstStr = "1"
    ),
    (   RecClauses = [_-RecBody|_],
        extract_goals_list_rust(RecBody, RecGoals),
        member((_ is ArithExpr), RecGoals),
        ArithExpr = (_ + Incr),
        number(Incr)
    ->  format(string(IncrStr), "~w", [Incr])
    ;   IncrStr = "1"
    ),
    functor(StepHead, StepRel, 2),
    findall(FactLine,
        (   user:clause(StepHead, true),
            StepHead =.. [_, K, V],
            format(string(FactLine), '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());', [K, V])
        ),
        FactLines),
    atomic_list_concat(FactLines, '\n', FactBlock).

rust_recursive_aggregate_return_type(count, 'usize').
rust_recursive_aggregate_return_type(sum, 'f64').
rust_recursive_aggregate_return_type(avg, 'f64').
rust_recursive_aggregate_return_type(min, 'f64').
rust_recursive_aggregate_return_type(max, 'f64').

rust_recursive_aggregate_seed(count, '0usize').
rust_recursive_aggregate_seed(sum, '0.0_f64').
rust_recursive_aggregate_seed(avg, '(0.0_f64, 0usize)').
rust_recursive_aggregate_seed(min, 'f64::INFINITY').
rust_recursive_aggregate_seed(max, 'f64::NEG_INFINITY').

rust_recursive_aggregate_update_from_tuple(count, _ValueIndex, 'agg += 1;').
rust_recursive_aggregate_update_from_tuple(sum, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), 'agg += (~w as f64);', [ValueExpr]).
rust_recursive_aggregate_update_from_tuple(avg, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), 'agg.0 += (~w as f64); agg.1 += 1;', [ValueExpr]).
rust_recursive_aggregate_update_from_tuple(min, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), 'agg = agg.min((~w as f64));', [ValueExpr]).
rust_recursive_aggregate_update_from_tuple(max, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), 'agg = agg.max((~w as f64));', [ValueExpr]).

rust_recursive_tuple_value_expr(0, 'row.0').
rust_recursive_tuple_value_expr(1, 'row.0').
rust_recursive_tuple_value_expr(2, 'row.1').

rust_recursive_aggregate_finish(count, 'agg').
rust_recursive_aggregate_finish(sum, 'agg').
rust_recursive_aggregate_finish(avg, 'if agg.1 == 0 { 0.0 } else { agg.0 / (agg.1 as f64) }').
rust_recursive_aggregate_finish(min, 'agg').
rust_recursive_aggregate_finish(max, 'agg').

rust_grouped_recursive_aggregate_return_type(count, 'usize').
rust_grouped_recursive_aggregate_return_type(sum, 'f64').
rust_grouped_recursive_aggregate_return_type(avg, '(f64, usize)').
rust_grouped_recursive_aggregate_return_type(min, 'f64').
rust_grouped_recursive_aggregate_return_type(max, 'f64').

rust_grouped_recursive_aggregate_seed(count, '0usize').
rust_grouped_recursive_aggregate_seed(sum, '0.0_f64').
rust_grouped_recursive_aggregate_seed(avg, '(0.0_f64, 0usize)').
rust_grouped_recursive_aggregate_seed(min, 'f64::INFINITY').
rust_grouped_recursive_aggregate_seed(max, 'f64::NEG_INFINITY').

rust_recursive_group_key_expr(1, 'row.0.clone()') :- !.
rust_recursive_group_key_expr(2, 'row.1.to_string()') :- !.

rust_recursive_group_update_from_tuple(count, _ValueIndex, '*entry += 1;').
rust_recursive_group_update_from_tuple(sum, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), '*entry += (~w as f64);', [ValueExpr]).
rust_recursive_group_update_from_tuple(avg, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), 'entry.0 += (~w as f64); entry.1 += 1;', [ValueExpr]).
rust_recursive_group_update_from_tuple(min, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), '*entry = (*entry).min((~w as f64));', [ValueExpr]).
rust_recursive_group_update_from_tuple(max, ValueIndex, UpdateExpr) :-
    rust_recursive_tuple_value_expr(ValueIndex, ValueExpr),
    format(string(UpdateExpr), '*entry = (*entry).max((~w as f64));', [ValueExpr]).

rust_grouped_recursive_aggregate_finish(avg,
'groups.into_iter()
        .map(|(k, (sum, count))| (k, if count == 0 { 0.0 } else { sum / (count as f64) }))
        .collect()').
rust_grouped_recursive_aggregate_finish(_Op, 'groups').

rust_wrap_function_with_main(PredStr, FuncCode, IncludeMain, RustCode) :-
    (   IncludeMain
    ->  format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - aggregate_all lowering

~w

fn main() {
    let result = ~w("test");
    println!("{:?}", result);
}
', [FuncCode, PredStr])
    ;   RustCode = FuncCode
    ).

% ============================================================================
% GENERAL (NON-TAIL) RECURSION — Arity 2-3
% ============================================================================
%%
%% Handles transitive closure with counter patterns.
%% Generates recursive Rust function with HashSet<String> visited parameter.

rust_declared_table_mode(Pred/Arity, Mode) :-
    clause(user:'table'(TableSpec), true),
    compound(TableSpec),
    functor(TableSpec, Pred, Arity),
    parse_table_spec(TableSpec, Modes),
    nth1(Arity, Modes, Mode),
    !.
rust_declared_table_mode(_, all).

rust_positive_step_metadata(Pred/Arity, Position) :-
    get_constraints(Pred/Arity, Constraints),
    member(positive_step(Position), Constraints).

is_general_recursive_pattern_rust(Pred, Arity, Clauses) :-
    Arity >= 2,
    member(_-Body, Clauses),
    contains_call_to_rust(Body, Pred),
    % Not all clauses are recursive (must have base case)
    member(_-BaseBody, Clauses),
    \+ contains_call_to_rust(BaseBody, Pred).

contains_call_to_rust(Goal, Pred) :-
    Goal =.. [Pred|_], !.
contains_call_to_rust((A, _), Pred) :-
    contains_call_to_rust(A, Pred), !.
contains_call_to_rust((_, B), Pred) :-
    contains_call_to_rust(B, Pred).

%% rust_clauses_to_ppv_pairs(+Clauses, -Pairs)
%  Convert Head-Body pairs to (Head, Body) pairs for is_per_path_visited_pattern.
rust_clauses_to_ppv_pairs([], []).
rust_clauses_to_ppv_pairs([Head-Body|Rest], [(Head, Body)|RestPairs]) :-
    rust_clauses_to_ppv_pairs(Rest, RestPairs).

%% compile_general_recursive_to_rust_no_visited(+Pred, +Arity, +Clauses, -RustCode)
%  Plain recursive Rust function without HashSet<String> visited parameter.
compile_general_recursive_to_rust_no_visited(Pred, Arity, Clauses, RustCode) :-
    atom_string(Pred, PredStr),
    rust_declared_table_mode(Pred/Arity, TableMode),
    % Partition clauses
    partition(is_rec_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    % Extract step relation from base case
    (   BaseClauses = [_BaseHead-BaseBody|_]
    ->  extract_goals_list_rust(BaseBody, BaseGoals),
        (   BaseGoals = [StepGoal|_],
            StepGoal =.. [StepRel|_],
            atom_string(StepRel, StepRelStr)
        ->  true
        ;   StepRelStr = "step"
        ),
        (   BaseClauses = [BH-_|_],
            BH =.. [_|BArgs],
            length(BArgs, 3),
            nth1(3, BArgs, BaseConst),
            number(BaseConst)
        ->  format(string(BaseConstStr), "~w", [BaseConst])
        ;   BaseConstStr = "1"
        )
    ;   StepRelStr = "step",
        BaseConstStr = "1"
    ),
    % Extract arithmetic increment from recursive case
    (   RecClauses = [_RH-RecBody|_]
    ->  extract_goals_list_rust(RecBody, RecGoals),
        (   member((_ is ArithExpr), RecGoals),
            ArithExpr = (_ + Incr),
            number(Incr)
        ->  format(string(IncrStr), "~w", [Incr])
        ;   IncrStr = "1"
        )
    ;   IncrStr = "1"
    ),
    % Collect step relation facts for embedding
    atom_string(StepRelAtom, StepRelStr),
    functor(StepHead, StepRelAtom, 2),
    findall(A-B, (user:clause(StepHead, true), StepHead =.. [_,A,B]), StepFacts),
    % Build fact initializer lines
    findall(FactLine,
        (   member(K-V, StepFacts),
            format(string(FactLine),
                '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());',
                [K, V])
        ),
        FactLines),
    atomic_list_concat(FactLines, '\n', FactBlock),
    (   Arity =:= 3,
        TableMode == min
    ->  load_rust_template('path_aware_transitive_closure_min', Template),
        render_template(Template, [
            pred=PredStr,
            step_rel=StepRelStr,
            base_const=BaseConstStr,
            recursive_increment=IncrStr,
            step_block=FactBlock
        ], RustCode)
    ;   Arity =:= 3
    ->  format(string(RustCode),
'// Transitive closure with counter: ~w/3 (no visited pattern)
// Step relation: ~w/2
use std::collections::HashMap;

fn ~w_worker(arg1: &str, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {{
    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {{
        for nb in neighbors {{
            results.push((nb.clone(), ~s));
            for (ancestor, h) in ~w_worker(nb, adj) {{
                results.push((ancestor, h + ~s));
            }}
        }}
    }}
    results
}}

fn main() {{
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w

    let results = ~w_worker("test", &adj);
    for (ancestor, hops) in &results {{
        println!("{{}}\\t{{}}", ancestor, hops);
    }}
}}
', [PredStr, StepRelStr,
    PredStr, BaseConstStr, PredStr, IncrStr,
    FactBlock, PredStr])
    ;   % Arity 2 — simpler, no counter
        format(string(RustCode),
'// Transitive closure: ~w/2 (no visited pattern)
use std::collections::HashMap;

fn ~w_worker(arg1: &str, adj: &HashMap<String, Vec<String>>) -> Vec<String> {{
    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {{
        for nb in neighbors {{
            results.push(nb.clone());
            results.extend(~w_worker(nb, adj));
        }}
    }}
    results
}}

fn main() {{
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w

    let results = ~w_worker("test", &adj);
    for r in &results {{
        println!("{{}}", r);
    }}
}}
', [PredStr, PredStr, PredStr, FactBlock, PredStr])
    ).

compile_general_recursive_to_rust(Pred, Arity, Clauses, RustCode) :-
    atom_string(Pred, PredStr),
    rust_declared_table_mode(Pred/Arity, TableMode),
    % Partition clauses
    partition(is_rec_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    % Extract step relation from base case
    (   BaseClauses = [_BaseHead-BaseBody|_]
    ->  extract_goals_list_rust(BaseBody, BaseGoals),
        (   BaseGoals = [StepGoal|_],
            StepGoal =.. [StepRel|_],
            atom_string(StepRel, StepRelStr)
        ->  true
        ;   StepRelStr = "step"
        ),
        % Get base case constant (3rd arg)
        (   BaseClauses = [BH-_|_],
            BH =.. [_|BArgs],
            length(BArgs, 3),
            nth1(3, BArgs, BaseConst),
            number(BaseConst)
        ->  format(string(BaseConstStr), "~w", [BaseConst])
        ;   BaseConstStr = "1"
        )
    ;   StepRelStr = "step",
        BaseConstStr = "1"
    ),
    % Extract arithmetic increment from recursive case
    (   RecClauses = [_RH-RecBody|_]
    ->  extract_goals_list_rust(RecBody, RecGoals),
        (   member((_ is ArithExpr), RecGoals),
            ArithExpr = (_ + Incr),
            number(Incr)
        ->  format(string(IncrStr), "~w", [Incr])
        ;   IncrStr = "1"
        )
    ;   IncrStr = "1"
    ),
    % Collect step relation facts for embedding
    atom_string(StepRelAtom, StepRelStr),
    functor(StepHead, StepRelAtom, 2),
    findall(A-B, (user:clause(StepHead, true), StepHead =.. [_,A,B]), StepFacts),
    % Build fact initializer lines
    findall(FactLine,
        (   member(K-V, StepFacts),
            format(string(FactLine),
                '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());',
                [K, V])
        ),
        FactLines),
    atomic_list_concat(FactLines, '\n', FactBlock),
    (   Arity =:= 3,
        TableMode == min
    ->  load_rust_template('path_aware_transitive_closure_min', Template),
        render_template(Template, [
            pred=PredStr,
            step_rel=StepRelStr,
            base_const=BaseConstStr,
            recursive_increment=IncrStr,
            step_block=FactBlock
        ], RustCode)
    ;   Arity =:= 3
    ->  format(string(RustCode),
'// Transitive closure with counter: ~w/3
// Step relation: ~w/2
use std::collections::{{HashMap, HashSet}};

fn ~w_worker(arg1: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>) -> Vec<(String, i32)> {{
    if visited.contains(arg1) {{
        return Vec::new();
    }}
    let mut new_visited = visited.clone();
    new_visited.insert(arg1.to_string());

    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {{
        for nb in neighbors {{
            if !new_visited.contains(nb.as_str()) {{
                results.push((nb.clone(), ~s));
                for (ancestor, h) in ~w_worker(nb, &new_visited, adj) {{
                    results.push((ancestor, h + ~s));
                }}
            }}
        }}
    }}
    results
}}

fn main() {{
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w

    let visited = HashSet::new();
    let results = ~w_worker("test", &visited, &adj);
    for (ancestor, hops) in &results {{
        println!("{{}}\\t{{}}", ancestor, hops);
    }}
}}
', [PredStr, StepRelStr,
    PredStr, BaseConstStr, PredStr, IncrStr,
    FactBlock, PredStr])
    ;   % Arity 2 — simpler, no counter
        format(string(RustCode),
'// Transitive closure: ~w/2
use std::collections::{{HashMap, HashSet}};

fn ~w_worker(arg1: &str, visited: &HashSet<String>, adj: &HashMap<String, Vec<String>>) -> Vec<String> {{
    if visited.contains(arg1) {{
        return Vec::new();
    }}
    let mut new_visited = visited.clone();
    new_visited.insert(arg1.to_string());

    let mut results = Vec::new();
    if let Some(neighbors) = adj.get(arg1) {{
        for nb in neighbors {{
            if !new_visited.contains(nb.as_str()) {{
                results.push(nb.clone());
                results.extend(~w_worker(nb, &new_visited, adj));
            }}
        }}
    }}
    results
}}

fn main() {{
    let mut adj: HashMap<String, Vec<String>> = HashMap::new();
~w

    let visited = HashSet::new();
    let results = ~w_worker("test", &visited, &adj);
    for r in &results {{
        println!("{{}}", r);
    }}
}}
', [PredStr, PredStr, PredStr, FactBlock, PredStr])
    ).

is_rec_clause_rust(Pred, _Head-Body) :-
    contains_call_to_rust(Body, Pred).

extract_goals_list_rust((A, B), [A|Rest]) :- !,
    extract_goals_list_rust(B, Rest).
extract_goals_list_rust(Goal, [Goal]).

rust_computed_increment_pattern(Pred, Clauses, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepProven) :-
    partition(is_rec_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    BaseClauses = [BaseHead-BaseBody|_],
    RecClauses = [_RecHead-RecBody|_],
    BaseHead =.. [Pred, From, To, Acc],
    var(From),
    var(To),
    var(Acc),
    extract_goals_list_rust(BaseBody, BaseGoals),
    select(BaseArith, BaseGoals, BaseTerms0),
    rust_extract_positive_step_guard(BaseTerms0, AuxValue, BaseTerms, BasePositiveStep),
    BaseTerms = [BaseGoalA, BaseGoalB],
    rust_edge_aux_terms(From, To, AuxValue, BaseGoalA, BaseGoalB, EdgeGoal, AuxGoal),
    EdgeGoal =.. [StepRel, From, To],
    AuxGoal =.. [AuxRel, From, AuxValue],
    BaseArith = (Acc is BaseExpr),
    term_variables(BaseExpr, BaseVars),
    subset_vars(BaseVars, [AuxValue]),
    extract_goals_list_rust(RecBody, RecGoals),
    select(RecArith, RecGoals, RecTermsWithGuard),
    rust_extract_positive_step_guard(RecTermsWithGuard, AuxValue, RecTerms0, RecPositiveStep),
    select(RecAuxGoal, RecTerms0, RecTerms1),
    select(RecEdgeGoal, RecTerms1, [RecCall]),
    RecEdgeGoal =.. [StepRel, From, Mid],
    RecAuxGoal =.. [AuxRel, From, AuxValue],
    RecCall =.. [Pred, Mid, To, PrevAcc],
    RecArith = (Acc is RecExpr),
    term_variables(RecExpr, RecVars),
    member_var_eq(PrevAcc, RecVars),
    subset_vars(RecVars, [PrevAcc, AuxValue]),
    (   (BasePositiveStep == true ; RecPositiveStep == true)
    ->  PositiveStepProven = true
    ;   PositiveStepProven = false
    ).

rust_extract_positive_step_guard(Terms, AuxValue, RemainingTerms, true) :-
    select(Guard0, Terms, RemainingTerms),
    rust_positive_step_guard(Guard0, AuxValue),
    !.
rust_extract_positive_step_guard(Terms, _AuxValue, Terms, false).

rust_positive_step_guard(Goal0, AuxValue) :-
    strip_module(Goal0, _, Goal),
    (   Goal =.. [>, AuxValue, Value],
        number(Value),
        Value >= 0
    ;   Goal =.. [<, Value, AuxValue],
        number(Value),
        Value >= 0
    ;   Goal =.. [>=, AuxValue, Value],
        number(Value),
        Value > 0
    ;   Goal =.. [=<, Value, AuxValue],
        number(Value),
        Value > 0
    ).

rust_edge_aux_terms(From, To, AuxValue, GoalA, GoalB, EdgeGoal, AuxGoal) :-
    (   rust_binary_relation_term(From, To, GoalA),
        rust_aux_relation_term(From, AuxValue, GoalB)
    ->  EdgeGoal = GoalA,
        AuxGoal = GoalB
    ;   rust_binary_relation_term(From, To, GoalB),
        rust_aux_relation_term(From, AuxValue, GoalA)
    ->  EdgeGoal = GoalB,
        AuxGoal = GoalA
    ).

rust_binary_relation_term(Left, Right, Goal0) :-
    strip_module(Goal0, _, Goal),
    functor(Goal, _, 2),
    arg(1, Goal, Left),
    arg(2, Goal, Right).

rust_aux_relation_term(Key, Value, Goal0) :-
    strip_module(Goal0, _, Goal),
    functor(Goal, _, 2),
    arg(1, Goal, Key),
    arg(2, Goal, Value).

compile_general_recursive_accumulation_to_rust(Pred, Arity, StepRel, AuxRel, AuxValue, PrevAcc, BaseExpr, RecExpr, PositiveStepGuardProven, RustCode) :-
    Arity =:= 3,
    atom_string(Pred, PredStr),
    atom_string(StepRel, StepRelStr),
    atom_string(AuxRel, AuxRelStr),
    rust_declared_table_mode(Pred/Arity, TableMode),
    (   (PositiveStepGuardProven == true ; rust_positive_step_metadata(Pred/Arity, Arity))
    ->  PositiveStepProven = true
    ;   PositiveStepProven = false
    ),
    rust_accumulation_numeric_type(BaseExpr, RecExpr, AccType),
    rust_accumulation_expr(BaseExpr, [AuxValue-'*step_cost'], AccType, BaseExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-acc, AuxValue-'*step_cost'], AccType, RecExprCode),
    rust_accumulation_expr(RecExpr, [PrevAcc-cost, AuxValue-'*step_cost'], AccType, MinRecExprCode),
    functor(StepHead, StepRel, 2),
    findall(A-B, (user:clause(StepHead, true), StepHead =.. [_, A, B]), StepFacts),
    findall(StepLine,
        (   member(K-V, StepFacts),
            format(string(StepLine),
                '    adj.entry("~w".to_string()).or_insert_with(Vec::new).push("~w".to_string());',
                [K, V])
        ),
        StepLines),
    atomic_list_concat(StepLines, '\n', StepBlock),
    functor(AuxHead, AuxRel, 2),
    findall(AuxLine,
        (   user:clause(AuxHead, true),
            AuxHead =.. [_, K, V],
            rust_numeric_literal(AccType, V, AuxLiteral),
            format(string(AuxLine),
                '    aux.insert("~w".to_string(), ~w);',
                [K, AuxLiteral])
        ),
        AuxLines),
    atomic_list_concat(AuxLines, '\n', AuxBlock),
    (   TableMode == min,
        PositiveStepProven == true
    ->  load_rust_template('path_aware_accumulation_min', Template)
    ;   load_rust_template('path_aware_accumulation', Template)
    ),
    render_template(Template, [
        pred=PredStr,
        step_rel=StepRelStr,
        aux_rel=AuxRelStr,
        acc_type=AccType,
        step_block=StepBlock,
        aux_block=AuxBlock,
        base_expr=BaseExprCode,
        recursive_expr=RecExprCode,
        min_recursive_expr=MinRecExprCode
    ], RustCode).

member_var_eq(Var, [Candidate|_]) :-
    Var == Candidate, !.
member_var_eq(Var, [_|Rest]) :-
    member_var_eq(Var, Rest).

subset_vars([], _).
subset_vars([Var|Rest], Allowed) :-
    member_var_eq(Var, Allowed),
    subset_vars(Rest, Allowed).

rust_accumulation_numeric_type(BaseExpr, RecExpr, "f64") :-
    (   rust_expr_requires_float(BaseExpr)
    ;   rust_expr_requires_float(RecExpr)
    ),
    !.
rust_accumulation_numeric_type(_, _, "i64").

rust_expr_requires_float(Expr) :-
    number(Expr),
    \+ integer(Expr),
    !.
rust_expr_requires_float(Expr) :-
    compound(Expr),
    (   Expr = (_ / _)
    ;   Expr = (_ ** _)
    ;   Expr =.. [log, _]
    ;   Expr =.. [ln, _]
    ),
    !.
rust_expr_requires_float(Expr) :-
    compound(Expr),
    Expr =.. [_|Args],
    member(Arg, Args),
    rust_expr_requires_float(Arg),
    !.

rust_numeric_literal("f64", Number, Literal) :-
    number(Number),
    !,
    (   integer(Number)
    ->  format(string(Literal), '~w.0', [Number])
    ;   format(string(Literal), '~w', [Number])
    ).
rust_numeric_literal("i64", Number, Literal) :-
    format(string(Literal), '~w', [Number]).

rust_accumulation_expr(Expr, VarBindings, _Type, RustExpr) :-
    var(Expr),
    !,
    lookup_var(Expr, VarBindings, RustExpr).
rust_accumulation_expr(Number, _, Type, RustExpr) :-
    number(Number),
    !,
    rust_numeric_literal(Type, Number, RustExpr).
rust_accumulation_expr(-Expr, VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Expr, VarBindings, Type, Inner),
    format(string(RustExpr), '(-~w)', [Inner]).
rust_accumulation_expr(Left ** Right, VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Left, VarBindings, Type, LeftExpr),
    rust_accumulation_expr(Right, VarBindings, Type, RightExpr),
    format(string(RustExpr), '(~w).powf(~w)', [LeftExpr, RightExpr]).
rust_accumulation_expr(log(Expr), VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Expr, VarBindings, Type, Inner),
    format(string(RustExpr), '(~w).ln()', [Inner]).
rust_accumulation_expr(ln(Expr), VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Expr, VarBindings, Type, Inner),
    format(string(RustExpr), '(~w).ln()', [Inner]).
rust_accumulation_expr(min(Left, Right), VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Left, VarBindings, Type, LeftExpr),
    rust_accumulation_expr(Right, VarBindings, Type, RightExpr),
    format(string(RustExpr), '(~w).min(~w)', [LeftExpr, RightExpr]).
rust_accumulation_expr(max(Left, Right), VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Left, VarBindings, Type, LeftExpr),
    rust_accumulation_expr(Right, VarBindings, Type, RightExpr),
    format(string(RustExpr), '(~w).max(~w)', [LeftExpr, RightExpr]).
rust_accumulation_expr(abs(Expr), VarBindings, Type, RustExpr) :-
    !,
    rust_accumulation_expr(Expr, VarBindings, Type, Inner),
    format(string(RustExpr), '(~w).abs()', [Inner]).
rust_accumulation_expr(Expr, VarBindings, Type, RustExpr) :-
    compound(Expr),
    Expr =.. [Op, Left, Right],
    expr_op(Op, StdOp),
    !,
    rust_accumulation_expr(Left, VarBindings, Type, LeftExpr),
    rust_accumulation_expr(Right, VarBindings, Type, RightExpr),
    rust_op(StdOp, RustOp),
    format(string(RustExpr), '(~w ~w ~w)', [LeftExpr, RustOp, RightExpr]).
rust_accumulation_expr(Atom, _, _, RustExpr) :-
    atom(Atom),
    rust_literal(Atom, RustExpr).

load_rust_template(Name, Template) :-
    format(string(RelPath), 'templates/targets/rust/~w.mustache', [Name]),
    format(string(VfsPath), '/user/templates/targets/rust/~w.mustache', [Name]),
    (   exists_file(RelPath)
    ->  read_file_to_string(RelPath, Template, [])
    ;   exists_file(VfsPath)
    ->  read_file_to_string(VfsPath, Template, [])
    ;   format(user_error, 'Rust template not found: ~w (tried ~w)~n', [RelPath, VfsPath]),
        fail
    ).

% ============================================================================
% NATIVE CLAUSE BODY LOWERING
% ============================================================================

%% build_rust_arg_list(+N, -ArgList)
build_rust_arg_list(0, "") :- !.
build_rust_arg_list(N, ArgList) :-
    findall(ArgDecl, (
        between(1, N, I),
        format(string(ArgDecl), 'arg~w: i64', [I])
    ), ArgDecls),
    atomic_list_concat(ArgDecls, ', ', ArgList).

%% infer_rust_native_return_type(+Clauses, -Type)
%%   If any clause outputs an arithmetic expression or variable, use i64.
%%   If all outputs are atoms (constants), use &'static str.
infer_rust_native_return_type(Clauses, Type) :-
    (   member(_Head-Body, Clauses),
        clause_has_arithmetic_output(Body)
    ->  Type = 'i64'
    ;   Type = '&\'static str'
    ).

clause_has_arithmetic_output(Body) :-
    clause_body_analysis:normalize_goals(Body, Goals),
    member(Goal, Goals),
    (   Goal = (_ is _)
    ;   Goal = (_ -> Then ; _), clause_has_arithmetic_output(Then)
    ;   Goal = (_ -> _ ; Else), clause_has_arithmetic_output(Else)
    ),
    !.

%% native_rust_clause_body(+PredSpec, +Clauses, -Code)

% Single clause
native_rust_clause_body(PredSpec, [Head-Body], Code) :-
    native_rust_clause(PredSpec, Head, Body, Condition, ClauseCode),
    !,
    (   Condition == "true"
    ->  Code = ClauseCode
    ;   format(string(Code),
'    if ~w {
~w
    } else {
        panic!("No matching clause for ~w")
    }', [Condition, ClauseCode, PredSpec])
    ).

% Multi-clause
native_rust_clause_body(PredSpec, Clauses, Code) :-
    Clauses = [_|[_|_]],
    maplist(native_rust_clause_pair(PredSpec), Clauses, Branches),
    Branches \= [],
    branches_to_rust_if_chain(Branches, IfChain),
    format(string(Code),
'~w else {
        panic!("No matching clause for ~w")
    }', [IfChain, PredSpec]).

native_rust_clause_pair(PredSpec, Head-Body, branch(Condition, ClauseCode)) :-
    native_rust_clause(PredSpec, Head, Body, Condition, ClauseCode),
    !.

%% native_rust_clause(+PredSpec, +Head, +Body, -Condition, -Code)
native_rust_clause(_PredSpec, Head, Body, Condition, Code) :-
    Head =.. [_Pred|HeadArgs],
    length(HeadArgs, Arity),
    build_head_varmap(HeadArgs, 1, VarMap),
    (   Arity > 1
    ->  append(_InputHeadArgs, [OutputHeadArg], HeadArgs),
        rust_head_conditions(HeadArgs, 1, Arity, HeadConditions)
    ;   OutputHeadArg = _,
        rust_head_conditions(HeadArgs, 1, Arity, HeadConditions)
    ),
    normalize_goals(Body, Goals),
    (   Goals == []
    ->  rust_resolve_value(VarMap, OutputHeadArg, OutputExpr),
        format(string(Code), '        ~w', [OutputExpr]),
        GoalConditions = []
    ;   (   Arity > 1, nonvar(OutputHeadArg)
        ->  clause_guard_output_split(Goals, VarMap, GuardGoals, OutputGoals),
            maplist(rust_guard_condition(VarMap), GuardGoals, GoalConditions),
            (   OutputGoals == []
            ->  rust_literal(OutputHeadArg, OutputLit),
                format(string(Code), '        ~w', [OutputLit])
            ;   rust_output_goals(OutputGoals, VarMap, Code)
            )
        ;   native_rust_goal_sequence(Goals, VarMap, GoalConditions, Code)
        )
    ),
    append(HeadConditions, GoalConditions, AllConditions),
    combine_rust_conditions(AllConditions, Condition).

%% rust_head_conditions(+HeadArgs, +Index, +Arity, -Conditions)
%  Skip the last arg (output) when generating conditions.
rust_head_conditions([], _, _, []).
rust_head_conditions([_], _, Arity, []) :- Arity > 1, !.  % Skip last (output) arg
rust_head_conditions([HeadArg|Rest], Index, Arity, Conditions) :-
    (   var(HeadArg)
    ->  Conditions = RestConditions
    ;   format(string(ArgName), 'arg~w', [Index]),
        rust_literal(HeadArg, Literal),
        format(string(Cond), '~w == ~w', [ArgName, Literal]),
        Conditions = [Cond|RestConditions]
    ),
    NextIndex is Index + 1,
    rust_head_conditions(Rest, NextIndex, Arity, RestConditions).

%% native_rust_goal_sequence(+Goals, +VarMap, -Conditions, -Code)
%  Uses classify_goal_sequence for advanced pattern detection.
%  Falls back to clause_guard_output_split if classification fails.
native_rust_goal_sequence(Goals, VarMap, Conditions, Code) :-
    classify_goal_sequence(Goals, VarMap, ClassifiedGoals),
    ClassifiedGoals \= [],
    rust_render_classified_goals(ClassifiedGoals, VarMap, Conditions, Lines),
    Lines \= [],
    atomic_list_concat(Lines, '\n', Code),
    !.
native_rust_goal_sequence(Goals, VarMap, Conditions, Code) :-
    clause_guard_output_split(Goals, VarMap, GuardGoals, OutputGoals),
    maplist(rust_guard_condition(VarMap), GuardGoals, Conditions),
    rust_output_goals(OutputGoals, VarMap, Code).

%% rust_render_classified_goals(+ClassifiedGoals, +VarMap, -Conditions, -Lines)
rust_render_classified_goals([], _VarMap, [], []).
rust_render_classified_goals([Classified], VarMap, Conds, Lines) :-
    !,
    rust_render_classified_last(Classified, VarMap, Conds, Lines).
%% Guarded tail: output followed by guard(s)
rust_render_classified_goals([output(Goal, _, _)|Rest], VarMap, [], Lines) :-
    Rest = [guard(_, _)|_],
    !,
    rust_output_goal(Goal, VarMap, AssignLine, VarMap1),
    rust_collect_trailing_guards(Rest, VarMap1, GuardGoals, _Remaining),
    maplist(rust_guard_condition(VarMap1), GuardGoals, GuardConds),
    atomic_list_concat(GuardConds, ' && ', GuardExpr),
    (   goal_output_var(Goal, OutVar), lookup_var(OutVar, VarMap1, OutName)
    ->  true
    ;   OutName = "_"
    ),
    format(string(IfLine), '        if ~w {', [GuardExpr]),
    format(string(RetLine), '            return ~w;', [OutName]),
    CloseLine = '        }',
    Lines = [AssignLine, IfLine, RetLine, CloseLine].
rust_render_classified_goals([Classified|Rest], VarMap, Conds, Lines) :-
    rust_render_classified_mid(Classified, VarMap, MidConds, MidLines, VarMap1),
    rust_render_classified_goals(Rest, VarMap1, RestConds, RestLines),
    append(MidConds, RestConds, Conds),
    append(MidLines, RestLines, Lines).

%% rust_render_classified_mid(+Classified, +VarMap, -Conds, -Lines, -VarMapOut)
rust_render_classified_mid(guard(Goal, _), VarMap, [Cond], [], VarMap) :-
    rust_guard_condition(VarMap, Goal, Cond).
rust_render_classified_mid(output(Goal, _, _), VarMap0, [], [Line], VarMapOut) :-
    rust_output_goal(Goal, VarMap0, Line, VarMapOut).
rust_render_classified_mid(output_ite(If, Then, Else, _SharedVars), VarMap0, [], Lines, VarMap0) :-
    rust_guard_condition(VarMap0, If, Cond),
    rust_branch_value(Then, VarMap0, ThenExpr),
    rust_branch_value(Else, VarMap0, ElseExpr),
    format(string(IfLine), '        if ~w {', [Cond]),
    format(string(ThenLine), '            return ~w;', [ThenExpr]),
    ElseLine = '        } else {',
    format(string(ElseRetLine), '            return ~w;', [ElseExpr]),
    CloseLine = '        }',
    Lines = [IfLine, ThenLine, ElseLine, ElseRetLine, CloseLine].
rust_render_classified_mid(passthrough(Goal), VarMap0, [], [Line], VarMapOut) :-
    rust_output_goal(Goal, VarMap0, Line, VarMapOut).
rust_render_classified_mid(_, VarMap, [], [], VarMap).

%% rust_render_classified_last(+Classified, +VarMap, -Conds, -Lines)
rust_render_classified_last(guard(Goal, _), VarMap, [Cond], []) :-
    rust_guard_condition(VarMap, Goal, Cond).
rust_render_classified_last(output(Goal, _, _), VarMap, [], Lines) :-
    rust_render_output_goal_last(Goal, VarMap, Lines).
rust_render_classified_last(output_ite(If, Then, Else, _), VarMap, [], Lines) :-
    rust_guard_condition(VarMap, If, Cond),
    rust_branch_value(Then, VarMap, ThenExpr),
    rust_branch_value(Else, VarMap, ElseExpr),
    format(string(IfLine), '        if ~w {', [Cond]),
    format(string(ThenLine), '            return ~w;', [ThenExpr]),
    ElseLine = '        } else {',
    format(string(ElseRetLine), '            return ~w;', [ElseExpr]),
    CloseLine = '        }',
    Lines = [IfLine, ThenLine, ElseLine, ElseRetLine, CloseLine].
rust_render_classified_last(output_disj(Alternatives, _SharedVars), VarMap, [], Lines) :-
    rust_disj_if_chain(Alternatives, VarMap, Lines).
rust_render_classified_last(passthrough(Goal), VarMap, [], Lines) :-
    rust_render_output_goal_last(Goal, VarMap, Lines).
rust_render_classified_last(_, _, [], []).

%% rust_render_output_goal_last(+Goal, +VarMap, -Lines)
%  3-arg wrapper used by classified goal renderers.
rust_render_output_goal_last(Goal, VarMap, [Line]) :-
    rust_output_goal(Goal, VarMap, AssignLine, VarMapOut),
    (   goal_output_var(Goal, OutVar), lookup_var(OutVar, VarMapOut, OutName)
    ->  format(string(Line), '~w\n        return ~w;', [AssignLine, OutName])
    ;   Line = AssignLine
    ).
rust_render_output_goal_last(Goal, VarMap, [Line]) :-
    rust_branch_value(Goal, VarMap, Expr),
    format(string(Line), '        return ~w;', [Expr]).

%% rust_collect_trailing_guards(+ClassifiedGoals, +VarMap, -GuardGoals, -Remaining)
rust_collect_trailing_guards([guard(Goal, _)|Rest], VarMap, [Goal|Guards], Remaining) :-
    !, rust_collect_trailing_guards(Rest, VarMap, Guards, Remaining).
rust_collect_trailing_guards(Remaining, _, [], Remaining).

%% rust_disj_if_chain(+Alternatives, +VarMap, -Lines)
rust_disj_if_chain([], _, []).
rust_disj_if_chain([Alt], VarMap, [ElseLine, RetLine, CloseLine]) :-
    !,
    rust_branch_value(Alt, VarMap, ValExpr),
    ElseLine = '        } else {',
    format(string(RetLine), '            return ~w;', [ValExpr]),
    CloseLine = '        }'.
rust_disj_if_chain([Alt|Rest], VarMap, Lines) :-
    normalize_goals(Alt, Goals),
    clause_guard_output_split(Goals, VarMap, Guards, _Outputs),
    (   Guards \= []
    ->  maplist(rust_guard_condition(VarMap), Guards, CondStrs),
        atomic_list_concat(CondStrs, ' && ', CondExpr)
    ;   CondExpr = "true"
    ),
    rust_branch_value(Alt, VarMap, ValExpr),
    format(string(IfLine), '        if ~w {', [CondExpr]),
    format(string(RetLine), '            return ~w;', [ValExpr]),
    rust_disj_elif_chain(Rest, VarMap, RestLines),
    append([IfLine, RetLine], RestLines, Lines).

%% rust_disj_elif_chain(+Alternatives, +VarMap, -Lines)
rust_disj_elif_chain([], _, []).
rust_disj_elif_chain([Alt], VarMap, [ElseLine, RetLine, CloseLine]) :-
    !,
    rust_branch_value(Alt, VarMap, ValExpr),
    ElseLine = '        } else {',
    format(string(RetLine), '            return ~w;', [ValExpr]),
    CloseLine = '        }'.
rust_disj_elif_chain([Alt|Rest], VarMap, [ElifLine, RetLine|RestLines]) :-
    normalize_goals(Alt, Goals),
    clause_guard_output_split(Goals, VarMap, Guards, _Outputs),
    (   Guards \= []
    ->  maplist(rust_guard_condition(VarMap), Guards, CondStrs),
        atomic_list_concat(CondStrs, ' && ', CondExpr)
    ;   CondExpr = "true"
    ),
    rust_branch_value(Alt, VarMap, ValExpr),
    format(string(ElifLine), '        } else if ~w {', [CondExpr]),
    format(string(RetLine), '            return ~w;', [ValExpr]),
    rust_disj_elif_chain(Rest, VarMap, RestLines).

%% rust_guard_condition(+VarMap, +Goal, -Condition)
rust_guard_condition(VarMap, _Module:Goal, Condition) :-
    !, rust_guard_condition(VarMap, Goal, Condition).
rust_guard_condition(VarMap, Goal, Condition) :-
    compound(Goal),
    Goal =.. [Op, Left, Right],
    expr_op(Op, StdOp),
    !,
    rust_expr(Left, VarMap, RsLeft),
    rust_expr(Right, VarMap, RsRight),
    rust_op(StdOp, RsOp),
    format(string(Condition), '~w ~w ~w', [RsLeft, RsOp, RsRight]).
rust_guard_condition(VarMap, integer(X), Condition) :-
    !, rust_expr(X, VarMap, RsX),
    format(string(Condition), '~w.is_integer()', [RsX]).
rust_guard_condition(VarMap, float(X), Condition) :-
    !, rust_expr(X, VarMap, RsX),
    format(string(Condition), '~w.is_float()', [RsX]).

%% rust_output_goals(+Goals, +VarMap, -Code)
rust_output_goals([], _VarMap, '        panic!("no output")') :- !.
rust_output_goals(Goals, VarMap, Code) :-
    rust_output_goals_acc(Goals, VarMap, Lines, _VarMapOut),
    atomic_list_concat(Lines, '\n', Code).

rust_output_goals_acc([], VarMap, [], VarMap).
rust_output_goals_acc([Goal], VarMap, Lines, VarMapOut) :-
    !, rust_output_goal_last(Goal, VarMap, Lines, VarMapOut).
rust_output_goals_acc([Goal|Rest], VarMap0, [Line|RestLines], VarMapOut) :-
    rust_output_goal(Goal, VarMap0, Line, VarMap1),
    rust_output_goals_acc(Rest, VarMap1, RestLines, VarMapOut).

%% rust_output_goal_last — produce a return expression (Rust implicit return)
rust_output_goal_last(_Module:Goal, VarMap, Lines, VarMapOut) :-
    !, rust_output_goal_last(Goal, VarMap, Lines, VarMapOut).
rust_output_goal_last(Goal, VarMap0, Lines, VarMapOut) :-
    if_then_else_goal(Goal, IfGoal, ThenGoal, ElseGoal),
    !,
    rust_if_then_else_output(IfGoal, ThenGoal, ElseGoal, VarMap0, Lines, VarMapOut).
rust_output_goal_last(=(Var, Expr), VarMap, [Line], VarMap) :-
    var(Var), !,
    rust_expr(Expr, VarMap, RsExpr),
    format(string(Line), '        ~w', [RsExpr]).
rust_output_goal_last(is(Var, Expr), VarMap, [Line], VarMap) :-
    var(Var), !,
    rust_expr(Expr, VarMap, RsExpr),
    format(string(Line), '        ~w', [RsExpr]).
rust_output_goal_last(Goal, VarMap0, [AssignLine, ReturnLine], VarMapOut) :-
    rust_output_goal(Goal, VarMap0, AssignLine, VarMapOut),
    (   goal_output_var(Goal, OutVar),
        lookup_var(OutVar, VarMapOut, OutName)
    ->  format(string(ReturnLine), '        ~w', [OutName])
    ;   ReturnLine = '        panic!("no output")'
    ).

%% rust_output_goal — produce a let binding
rust_output_goal(_Module:Goal, VarMap0, Line, VarMapOut) :-
    !, rust_output_goal(Goal, VarMap0, Line, VarMapOut).
rust_output_goal(=(Var, Expr), VarMap0, Line, VarMapOut) :-
    var(Var), !,
    ensure_var(VarMap0, Var, VarName, VarMapOut),
    rust_expr(Expr, VarMap0, RsExpr),
    format(string(Line), '        let ~w = ~w;', [VarName, RsExpr]).
rust_output_goal(is(Var, Expr), VarMap0, Line, VarMapOut) :-
    var(Var), !,
    ensure_var(VarMap0, Var, VarName, VarMapOut),
    rust_expr(Expr, VarMap0, RsExpr),
    format(string(Line), '        let ~w = ~w;', [VarName, RsExpr]).

%% rust_if_then_else_output — generate if/else for output
rust_if_then_else_output(IfGoal, ThenGoal, ElseGoal, VarMap0, Lines, VarMapOut) :-
    flatten_rust_if_elif_branches(IfGoal, ThenGoal, ElseGoal, Branches, DefaultGoal),
    rust_if_elif_return_lines(Branches, DefaultGoal, VarMap0, Lines),
    VarMapOut = VarMap0.

flatten_rust_if_elif_branches(If, Then, Else, [branch(If, Then)|RestBranches], Default) :-
    if_then_else_goal(Else, If2, Then2, Else2),
    !,
    flatten_rust_if_elif_branches(If2, Then2, Else2, RestBranches, Default).
flatten_rust_if_elif_branches(If, Then, Else, [branch(If, Then)], Else).

rust_if_elif_return_lines([branch(If, Then)|Rest], DefaultGoal, VarMap, [IfLine, RetLine|RestLines]) :-
    rust_guard_condition(VarMap, If, IfCond),
    rust_branch_value(Then, VarMap, ThenVal),
    format(string(IfLine), '        if ~w {', [IfCond]),
    format(string(RetLine), '            ~w', [ThenVal]),
    rust_elif_return_lines(Rest, DefaultGoal, VarMap, RestLines).

rust_elif_return_lines([], DefaultGoal, VarMap, [CloseElseLine, RetLine, CloseLine]) :-
    !,
    CloseElseLine = '        } else {',
    rust_branch_value(DefaultGoal, VarMap, DefVal),
    format(string(RetLine), '            ~w', [DefVal]),
    CloseLine = '        }'.
rust_elif_return_lines([branch(If, Then)|Rest], DefaultGoal, VarMap, [CloseElifLine, RetLine|RestLines]) :-
    rust_guard_condition(VarMap, If, IfCond),
    rust_branch_value(Then, VarMap, ThenVal),
    format(string(CloseElifLine), '        } else if ~w {', [IfCond]),
    format(string(RetLine), '            ~w', [ThenVal]),
    rust_elif_return_lines(Rest, DefaultGoal, VarMap, RestLines).

%% rust_branch_value — extract result value from a branch
rust_branch_value(_Module:Goal, VarMap, Value) :-
    !, rust_branch_value(Goal, VarMap, Value).
rust_branch_value(Goal, VarMap, Value) :-
    if_then_else_goal(Goal, If, Then, Else),
    !,
    rust_guard_condition(VarMap, If, Cond),
    rust_branch_value(Then, VarMap, ThenVal),
    rust_branch_value(Else, VarMap, ElseVal),
    format(string(Value), 'if ~w { ~w } else { ~w }', [Cond, ThenVal, ElseVal]).
rust_branch_value((A, B), VarMap, Value) :-
    !,
    normalize_goals((A, B), Goals),
    last(Goals, LastGoal),
    rust_branch_value(LastGoal, VarMap, Value).
rust_branch_value(=(_, Expr), VarMap, Value) :-
    !, rust_expr(Expr, VarMap, Value).
rust_branch_value(is(_, Expr), VarMap, Value) :-
    !, rust_expr(Expr, VarMap, Value).
rust_branch_value(Goal, VarMap, Value) :-
    rust_expr(Goal, VarMap, Value).

% ============================================================================
% MULTIFILE HOOKS — Register Rust renderers for shared compile_expression
% ============================================================================

clause_body_analysis:render_output_goal(rust, Goal, VarMap, Line, VarName, VarMapOut) :-
    rust_output_goal(Goal, VarMap, Line, VarMapOut),
    (   goal_output_var(Goal, OutVar), lookup_var(OutVar, VarMapOut, VarName)
    ->  true
    ;   VarName = "_"
    ).

clause_body_analysis:render_guard_condition(rust, Goal, VarMap, CondStr) :-
    rust_guard_condition(VarMap, Goal, CondStr).

clause_body_analysis:render_branch_value(rust, Branch, VarMap, ExprStr) :-
    rust_branch_value(Branch, VarMap, ExprStr).

clause_body_analysis:render_ite_block(rust, Cond, ThenLines, ElseLines, Indent, _ReturnVars, Lines) :-
    format(string(IfLine), '~wif ~w {', [Indent, Cond]),
    rust_indent_lines(ThenLines, Indent, IndentedThen),
    format(string(CloseThen), '~w}', [Indent]),
    (   ElseLines \= []
    ->  format(string(ElseLine), '~w} else {', [Indent]),
        rust_indent_lines(ElseLines, Indent, IndentedElse),
        format(string(CloseElse), '~w}', [Indent]),
        append([IfLine|IndentedThen], [ElseLine|IndentedElse], PreClose),
        append(PreClose, [CloseElse], Lines)
    ;   append([IfLine|IndentedThen], [CloseThen], Lines)
    ).

rust_indent_lines([], _, []).
rust_indent_lines([Line|Rest], Indent, [Indented|RestIndented]) :-
    format(string(Indented), '~w    ~w', [Indent, Line]),
    rust_indent_lines(Rest, Indent, RestIndented).

%% rust_expr — convert Prolog expression to Rust syntax
rust_expr(Var, VarMap, RsExpr) :-
    var(Var), !,
    (   lookup_var(Var, VarMap, Name)
    ->  RsExpr = Name
    ;   term_string(Var, RsExpr)
    ).
rust_expr(Expr, VarMap, RsExpr) :-
    compound(Expr),
    Expr =.. [Op, Left, Right],
    expr_op(Op, StdOp),
    !,
    rust_expr(Left, VarMap, RsLeft),
    rust_expr(Right, VarMap, RsRight),
    rust_op(StdOp, RsOp),
    format(string(RsExpr), '(~w ~w ~w)', [RsLeft, RsOp, RsRight]).
rust_expr(-Expr, VarMap, RsExpr) :-
    !,
    rust_expr(Expr, VarMap, Inner),
    format(string(RsExpr), '(-~w)', [Inner]).
rust_expr(abs(Expr), VarMap, RsExpr) :-
    !,
    rust_expr(Expr, VarMap, Inner),
    format(string(RsExpr), '~w.abs()', [Inner]).
rust_expr(Atom, _VarMap, RsExpr) :-
    atom(Atom), !,
    rust_literal(Atom, RsExpr).
rust_expr(Number, _VarMap, RsExpr) :-
    number(Number), !,
    format(string(RsExpr), '~w', [Number]).
rust_expr(String, _VarMap, RsExpr) :-
    string(String), !,
    format(string(RsExpr), '"~w"', [String]).

%% rust_literal — convert Prolog value to Rust literal
rust_literal(Value, 'None') :- var(Value), !.
rust_literal(true, 'true') :- !.
rust_literal(false, 'false') :- !.
rust_literal([], 'vec![]') :- !.
rust_literal(Value, RsLiteral) :-
    number(Value), !,
    format(string(RsLiteral), '~w', [Value]).
rust_literal(Value, RsLiteral) :-
    atom(Value), !,
    format(string(RsLiteral), '"~w"', [Value]).
rust_literal(Value, RsLiteral) :-
    string(Value), !,
    format(string(RsLiteral), '"~w"', [Value]).
rust_literal(Value, RsLiteral) :-
    term_string(Value, RsLiteral).

%% rust_resolve_value — resolve variable or constant to Rust expression
rust_resolve_value(VarMap, Var, RsExpr) :-
    var(Var), !,
    lookup_var(Var, VarMap, RsExpr).
rust_resolve_value(_VarMap, Value, RsExpr) :-
    rust_literal(Value, RsExpr).

%% rust_op — map standard operator to Rust syntax
rust_op('>', '>').
rust_op('<', '<').
rust_op('>=', '>=').
rust_op('<=', '<=').
rust_op('==', '==').
rust_op('!=', '!=').
rust_op('+', '+').
rust_op('-', '-').
rust_op('*', '*').
rust_op('/', '/').
rust_op('%', '%').
rust_op('&&', '&&').
rust_op('||', '||').

%% combine_rust_conditions — join conditions with &&
combine_rust_conditions([], "true") :- !.
combine_rust_conditions([Condition], Condition) :- !.
combine_rust_conditions(Conditions, Combined) :-
    atomic_list_concat(Conditions, ' && ', Combined).

%% branches_to_rust_if_chain — build Rust if/else if chain
branches_to_rust_if_chain([branch(Condition, ClauseCode)], Code) :-
    !,
    format(string(Code), '    if ~w {\n~w\n    }', [Condition, ClauseCode]).
branches_to_rust_if_chain([branch(Condition, ClauseCode)|Rest], Code) :-
    branches_to_rust_elif_chain(Rest, RestCode),
    format(string(Code), '    if ~w {\n~w\n    } ~w', [Condition, ClauseCode, RestCode]).

branches_to_rust_elif_chain([branch(Condition, ClauseCode)], Code) :-
    !,
    format(string(Code), 'else if ~w {\n~w\n    }', [Condition, ClauseCode]).
branches_to_rust_elif_chain([branch(Condition, ClauseCode)|Rest], Code) :-
    branches_to_rust_elif_chain(Rest, RestCode),
    format(string(Code), 'else if ~w {\n~w\n    } ~w', [Condition, ClauseCode, RestCode]).

is_fact_clause(_-true).

%% ============================================ 
%% COMPILATION MODES
%% ============================================ 

%% compile_facts_to_rust(+Pred, +Arity, -RustCode)
%  PUBLIC API: Export Prolog facts as a standalone Rust program.
%  Generates a Rust program with struct and Vec of facts.
%
%  Example:
%    ?- compile_facts_to_rust(parent, 2, Code).
%    Generates a Rust program with facts as a Vec of structs.
%
compile_facts_to_rust(Pred, Arity, RustCode) :-
    % Get the predicate name
    atom_string(Pred, PredStr),
    upcase_atom(Pred, PredUp),
    atom_string(PredUp, PredUpStr),
    
    % Collect all facts
    functor(Head, Pred, Arity),
    findall(Args, (user:clause(Head, true), Head =.. [_|Args]), AllFacts),
    
    % Generate field names
    findall(Field, (
        between(1, Arity, N),
        format(string(Field), 'arg~w: String', [N])
    ), Fields),
    atomic_list_concat(Fields, ',\n    ', FieldDefs),
    
    % Format facts as Rust struct literals
    findall(Entry, (
        member(Args, AllFacts),
        format_rust_struct_entry(Args, PredUpStr, Entry)
    ), Entries),
    atomic_list_concat(Entries, ',\n        ', EntriesCode),
    
    % Generate print fields
    generate_rust_print_fields(Arity, PrintFields),
    
    % Generate Rust program
    format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Fact Export
// Predicate: ~w/~w

/// Represents a ~w/~w fact
#[derive(Debug, Clone, PartialEq, Eq)]
struct ~w {
    ~w,
}

/// Get all facts
fn get_all_~w() -> Vec<~w> {
    vec![
        ~w,
    ]
}

/// Stream facts using iterator
fn stream_~w() -> impl Iterator<Item = ~w> {
    get_all_~w().into_iter()
}

/// Check if a fact exists
fn contains_~w(target: &~w) -> bool {
    get_all_~w().iter().any(|f| f == target)
}

fn main() {
    for fact in stream_~w() {
        println!("{}", vec![~w].join(":"));
    }
}
', [PredStr, Arity, PredStr, Arity, PredUpStr, FieldDefs,
    PredStr, PredUpStr, EntriesCode,
    PredStr, PredUpStr, PredStr,
    PredStr, PredUpStr, PredStr,
    PredStr, PrintFields]).

%% format_rust_struct_entry(+Args, +StructName, -Entry)
format_rust_struct_entry(Args, StructName, Entry) :-
    findall(FieldVal, (
        nth1(N, Args, Arg),
        atom_string(Arg, ArgStr),
        format(string(FieldVal), 'arg~w: "~w".to_string()', [N, ArgStr])
    ), FieldVals),
    atomic_list_concat(FieldVals, ', ', FieldsStr),
    format(string(Entry), '~w { ~w }', [StructName, FieldsStr]).

%% generate_rust_print_fields(+Arity, -Code) 
generate_rust_print_fields(Arity, Code) :-
    findall(Field, (
        between(1, Arity, N),
        format(string(Field), 'fact.arg~w.clone()', [N])
    ), Fields),
    atomic_list_concat(Fields, ', ', Code).

%% compile_facts_to_rust/5 - internal version (takes Clauses)
compile_facts_to_rust(_Pred, _Arity, Clauses, FieldDelim, RustCode) :-
    map_field_delimiter(FieldDelim, DelimChar),
    
    findall(Entry, 
        (   member(Fact-true, Clauses),
            Fact =.. [_|Args],
            maplist(atom_string, Args, ArgStrs),
            atomic_list_concat(ArgStrs, DelimChar, Key),
            format(string(Entry), '    facts.insert("~s".to_string());', [Key])
        ),
        Entries),
    atomic_list_concat(Entries, '\n', EntriesCode),

    format(string(RustCode), 'use std::collections::HashSet;

fn main() {
    let mut facts = HashSet::new();~s

    for fact in facts {
        println!("{}", fact);
    }
}
', [EntriesCode]).

%% ============================================
%% DATABASE INTEGRATION (sled)
%% ============================================

%% compile_db_backend_to_rust(+Pred, +Arity, +Backend, +Options, -RustCode)
%  Compile predicate to Rust with embedded database support.
%  Backend: sled (pure Rust embedded database)
%
%  Options:
%    db_file(Path)           - Database file path (default: 'data.db')
%    db_tree(Name)           - Tree name (default: predicate name)
%    db_key_field(Field)     - Single field as primary key
%    db_key_strategy(S)      - Complex key generation
%    db_key_delimiter(Char)  - Composite key separator (default: ':')
%    db_mode(Mode)           - read | write | analyze
%    json_input(true)        - Enable JSONL input for write mode
%
compile_db_backend_to_rust(Pred, Arity, sled, Options, RustCode) :-
    % Extract options
    option(db_file(DbFile), Options, 'data.db'),
    option(db_tree(DbTree), Options, Pred),
    option(db_mode(Mode), Options, read),
    option(db_key_delimiter(KeyDelim), Options, ':'),
    option(unique(Unique), Options, true),

    % Get key strategy
    (   option(db_key_field(KeyField), Options)
    ->  KeyStrategy = field(KeyField)
    ;   option(db_key_strategy(KeyStrategy), Options)
    ->  true
    ;   KeyStrategy = auto
    ),

    format('  Database: sled, File: ~w, Tree: ~w, Mode: ~w~n', [DbFile, DbTree, Mode]),

    % Generate based on mode
    (   Mode = write
    ->  compile_db_write_mode_rust(Pred, Arity, DbFile, DbTree, KeyStrategy, KeyDelim, Options, RustCode)
    ;   Mode = analyze
    ->  compile_db_analyze_mode_rust(Pred, Arity, DbFile, DbTree, Options, RustCode)
    ;   % Default: read mode
        compile_db_read_mode_rust(Pred, Arity, DbFile, DbTree, KeyStrategy, KeyDelim, Unique, Options, RustCode)
    ).

compile_db_backend_to_rust(Pred, Arity, rocksdb, Options, RustCode) :-
    % RocksDB support (similar pattern, different crate)
    compile_db_backend_to_rust(Pred, Arity, sled, Options, RustCode).

%% compile_db_read_mode_rust(+Pred, +Arity, +DbFile, +DbTree, +KeyStrategy, +KeyDelim, +Unique, +Options, -RustCode)
%  Generate Rust code for reading from database.
compile_db_read_mode_rust(Pred, Arity, DbFile, DbTree, KeyStrategy, KeyDelim, Unique, Options, RustCode) :-
    atom_string(DbTree, TreeStr),

    % Get predicate clauses to check for constraints
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),

    % Check for indexed fields
    (   get_rust_index_fields(Pred, Arity, IndexedFields)
    ->  true
    ;   IndexedFields = []
    ),

    % Determine optimization type
    (   Clauses = [_SingleHead-SingleBody], SingleBody \= true,
        extract_db_constraints_rust(SingleBody, Constraints),
        Constraints \= [],
        can_use_rust_optimization(KeyStrategy, Constraints, IndexedFields, OptType, OptDetails)
    ->  format('  Optimization: ~w~n', [OptType]),
        generate_optimized_db_read_rust(OptType, OptDetails, DbFile, TreeStr, KeyDelim, Options, RustCode)
    ;   % Full scan
        generate_full_scan_read_rust(DbFile, TreeStr, KeyDelim, Unique, Options, RustCode)
    ).

%% generate_full_scan_read_rust(+DbFile, +TreeStr, +KeyDelim, +Unique, +Options, -RustCode)
%  Generate code for full database scan.
generate_full_scan_read_rust(DbFile, TreeStr, _KeyDelim, Unique, Options, RustCode) :-
    % Check for observability options
    (   option(progress(interval(ProgressInterval)), Options)
    ->  ProgressCode = format("
        if count % ~w == 0 {
            eprintln!(\"Read {} records...\", count);
        }", [ProgressInterval])
    ;   ProgressCode = ""
    ),

    (   option(metrics_file(MetricsFile), Options)
    ->  MetricsSetup = "    let start_time = std::time::Instant::now();",
        format(string(MetricsEnd), '
    let elapsed = start_time.elapsed();
    let metrics = serde_json::json!({
        "total_records": count,
        "duration_secs": elapsed.as_secs_f64(),
        "records_per_sec": count as f64 / elapsed.as_secs_f64()
    });
    std::fs::write("~w", metrics.to_string()).ok();', [MetricsFile])
    ;   MetricsSetup = "", MetricsEnd = ""
    ),

    (   Unique = true
    ->  UniqueSetup = "    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();",
        UniqueCheck = "
            let key_str = String::from_utf8_lossy(&key).to_string();
            if seen.contains(&key_str) { continue; }
            seen.insert(key_str);"
    ;   UniqueSetup = "", UniqueCheck = ""
    ),

    format(string(RustCode), '
use sled;
use serde_json;
use std::io::Write;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let tree = db.open_tree("~w")?;
~s
~s
    let mut count: u64 = 0;

    for result in tree.iter() {
        let (key, value) = result?;~s
        count += 1;~s

        // Parse and output record
        if let Ok(record) = serde_json::from_slice::<serde_json::Value>(&value) {
            println!("{}", record);
        }
    }
~s
    Ok(())
}
', [DbFile, TreeStr, MetricsSetup, UniqueSetup, UniqueCheck, ProgressCode, MetricsEnd]).

%% generate_optimized_db_read_rust(+OptType, +OptDetails, +DbFile, +TreeStr, +KeyDelim, +Options, -RustCode)
%  Generate optimized database read code.
generate_optimized_db_read_rust(direct_lookup, key(Key), DbFile, TreeStr, _KeyDelim, _Options, RustCode) :-
    format(string(RustCode), '
use sled;
use serde_json;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let tree = db.open_tree("~w")?;

    // Direct lookup - O(log n)
    let key = "~w";
    if let Some(value) = tree.get(key)? {
        if let Ok(record) = serde_json::from_slice::<serde_json::Value>(&value) {
            println!("{}", record);
        }
    }

    Ok(())
}
', [DbFile, TreeStr, Key]).

generate_optimized_db_read_rust(prefix_scan, prefix(Prefix), DbFile, TreeStr, _KeyDelim, _Options, RustCode) :-
    format(string(RustCode), '
use sled;
use serde_json;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let tree = db.open_tree("~w")?;

    // Prefix scan - O(k log n) where k is matching records
    let prefix = "~w";
    for result in tree.scan_prefix(prefix) {
        let (_key, value) = result?;
        if let Ok(record) = serde_json::from_slice::<serde_json::Value>(&value) {
            println!("{}", record);
        }
    }

    Ok(())
}
', [DbFile, TreeStr, Prefix]).

generate_optimized_db_read_rust(index_scan, index(Field, Value), DbFile, TreeStr, _KeyDelim, _Options, RustCode) :-
    format(string(IndexTree), "index_~w_~w", [TreeStr, Field]),
    format(string(RustCode), '
use sled;
use serde_json;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let main_tree = db.open_tree("~w")?;
    let index_tree = db.open_tree("~w")?;

    // Secondary index scan - O(k log n)
    let search_prefix = format!("{}:", "~w");
    for result in index_tree.scan_prefix(search_prefix.as_bytes()) {
        let (index_key, _) = result?;

        // Extract primary key from index key (format: value:primary_key)
        let key_str = String::from_utf8_lossy(&index_key);
        if let Some(primary_key) = key_str.strip_prefix(&search_prefix) {
            // Fetch from main tree
            if let Some(value) = main_tree.get(primary_key)? {
                if let Ok(record) = serde_json::from_slice::<serde_json::Value>(&value) {
                    println!("{}", record);
                }
            }
        }
    }

    Ok(())
}
', [DbFile, TreeStr, IndexTree, Value]).

%% compile_db_write_mode_rust(+Pred, +Arity, +DbFile, +DbTree, +KeyStrategy, +KeyDelim, +Options, -RustCode)
%  Generate Rust code for writing to database.
compile_db_write_mode_rust(_Pred, _Arity, DbFile, DbTree, KeyStrategy, KeyDelim, Options, RustCode) :-
    atom_string(DbTree, TreeStr),

    % Check for indexed fields from index_analyzer module
    (   catch(get_rust_index_fields(DbTree, _, IndexedFields), _, fail)
    ->  true
    ;   IndexedFields = []
    ),

    % Generate key extraction code
    generate_rust_key_extraction(KeyStrategy, KeyDelim, KeyExtractionCode),

    % Generate index update code
    (   IndexedFields = []
    ->  IndexUpdateCode = ""
    ;   generate_rust_index_updates(TreeStr, IndexedFields, IndexUpdateCode)
    ),

    % Check for observability options
    (   option(progress(interval(ProgressInterval)), Options)
    ->  format(string(ProgressCode), '
            if count % ~w == 0 {
                eprintln!("Written {} records...", count);
            }', [ProgressInterval])
    ;   ProgressCode = ""
    ),

    (   option(error_file(ErrorFile), Options)
    ->  format(string(ErrorSetup), '    let error_file = std::fs::File::create("~w")?;
    let mut error_writer = std::io::BufWriter::new(error_file);', [ErrorFile]),
        ErrorHandling = '
                let error_entry = serde_json::json!({
                    "timestamp": chrono::Utc::now().to_rfc3339(),
                    "error": e.to_string(),
                    "line": line.clone()
                });
                writeln!(error_writer, "{}", error_entry).ok();
                error_count += 1;'
    ;   ErrorSetup = "", ErrorHandling = ""
    ),

    (   option(error_threshold(count(MaxErrors)), Options)
    ->  format(string(ErrorThreshold), '
            if error_count >= ~w {
                eprintln!("Error threshold reached: {} errors", error_count);
                break;
            }', [MaxErrors])
    ;   ErrorThreshold = ""
    ),

    (   option(metrics_file(MetricsFile), Options)
    ->  MetricsSetup = "    let start_time = std::time::Instant::now();",
        format(string(MetricsEnd), '
    let elapsed = start_time.elapsed();
    let metrics = serde_json::json!({
        "total_records": count,
        "error_records": error_count,
        "duration_secs": elapsed.as_secs_f64(),
        "records_per_sec": count as f64 / elapsed.as_secs_f64()
    });
    std::fs::write("~w", metrics.to_string()).ok();', [MetricsFile])
    ;   MetricsSetup = "", MetricsEnd = ""
    ),

    format(string(RustCode), '
use sled;
use serde_json::{self, Value};
use std::io::{self, BufRead, Write};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let tree = db.open_tree("~w")?;
~s
~s
    let mut count: u64 = 0;
    let mut error_count: u64 = 0;

    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => continue,
        };

        match serde_json::from_str::<Value>(&line) {
            Ok(record) => {
                // Generate key
~s

                // Store record
                let value = serde_json::to_vec(&record)?;
                tree.insert(key.as_bytes(), value)?;
~s
                count += 1;~s~s
            }
            Err(e) => {~s~s
            }
        }
    }

    // Flush to disk
    db.flush()?;
    eprintln!("Completed: {} records written", count);
~s
    Ok(())
}
', [DbFile, TreeStr, ErrorSetup, MetricsSetup, KeyExtractionCode, IndexUpdateCode, ProgressCode, ErrorThreshold, ErrorHandling, ErrorThreshold, MetricsEnd]).

%% generate_rust_key_extraction(+KeyStrategy, +KeyDelim, -Code)
%  Generate Rust code for key extraction based on strategy.
generate_rust_key_extraction(auto, _KeyDelim, Code) :-
    Code = '                let key = format!("{}", count);'.

generate_rust_key_extraction(field(FieldName), _KeyDelim, Code) :-
    format(string(Code), '                let key = record.get("~w")
                    .and_then(|v| v.as_str())
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| format!("{}", count));', [FieldName]).

generate_rust_key_extraction(composite(Fields), KeyDelim, Code) :-
    length(Fields, _N),
    findall(Part, (
        member(field(F), Fields),
        format(string(Part), 'record.get("~w").and_then(|v| v.as_str()).unwrap_or("")', [F])
    ), Parts),
    atomic_list_concat(Parts, ', ', PartsStr),
    format(string(Code), '                let parts: Vec<&str> = vec![~w];
                let key = parts.join("~w");', [PartsStr, KeyDelim]).

generate_rust_key_extraction(hash(field(FieldName)), _KeyDelim, Code) :-
    format(string(Code), '                use std::collections::hash_map::DefaultHasher;
                use std::hash::{Hash, Hasher};
                let field_val = record.get("~w")
                    .and_then(|v| v.as_str())
                    .unwrap_or("");
                let mut hasher = DefaultHasher::new();
                field_val.hash(&mut hasher);
                let key = format!("{:x}", hasher.finish());', [FieldName]).

generate_rust_key_extraction(hash(field(FieldName), sha256), _KeyDelim, Code) :-
    format(string(Code), '                use sha2::{Sha256, Digest};
                let field_val = record.get("~w")
                    .and_then(|v| v.as_str())
                    .unwrap_or("");
                let hash = Sha256::digest(field_val.as_bytes());
                let key = format!("{:x}", hash);', [FieldName]).

generate_rust_key_extraction(uuid, _KeyDelim, Code) :-
    Code = '                let key = uuid::Uuid::new_v4().to_string();'.

generate_rust_key_extraction(literal(Lit), _KeyDelim, Code) :-
    format(string(Code), '                let key = "~w".to_string();', [Lit]).

%% generate_rust_index_updates(+TreeStr, +IndexedFields, -Code)
%  Generate Rust code for updating secondary indexes.
generate_rust_index_updates(TreeStr, IndexedFields, Code) :-
    findall(IndexCode, (
        member(Field, IndexedFields),
        format(string(IndexTree), "index_~w_~w", [TreeStr, Field]),
        format(string(IndexCode), '
                // Update secondary index: ~w
                if let Some(field_val) = record.get("~w").and_then(|v| v.as_str()) {
                    let index_key = format!("{}:{}", field_val, key);
                    let index_tree = db.open_tree("~w")?;
                    index_tree.insert(index_key.as_bytes(), b"")?;
                }', [Field, Field, IndexTree])
    ), IndexCodes),
    atomic_list_concat(IndexCodes, '\n', Code).

%% compile_db_analyze_mode_rust(+Pred, +Arity, +DbFile, +DbTree, +Options, -RustCode)
%  Generate Rust code for collecting database statistics.
compile_db_analyze_mode_rust(_Pred, _Arity, DbFile, DbTree, _Options, RustCode) :-
    atom_string(DbTree, TreeStr),
    format(string(RustCode), '
use sled;
use serde_json;
use std::collections::HashMap;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let db = sled::open("~w")?;
    let tree = db.open_tree("~w")?;

    let mut count: u64 = 0;
    let mut key_lengths: Vec<usize> = Vec::new();
    let mut value_lengths: Vec<usize> = Vec::new();
    let mut field_counts: HashMap<String, u64> = HashMap::new();
    let mut field_cardinality: HashMap<String, std::collections::HashSet<String>> = HashMap::new();

    for result in tree.iter() {
        let (key, value) = result?;
        count += 1;
        key_lengths.push(key.len());
        value_lengths.push(value.len());

        // Analyze record structure
        if let Ok(record) = serde_json::from_slice::<serde_json::Value>(&value) {
            if let Some(obj) = record.as_object() {
                for (field, val) in obj {
                    *field_counts.entry(field.clone()).or_insert(0) += 1;

                    let val_str = match val {
                        serde_json::Value::String(s) => s.clone(),
                        serde_json::Value::Number(n) => n.to_string(),
                        serde_json::Value::Bool(b) => b.to_string(),
                        _ => format!("{}", val)
                    };
                    field_cardinality.entry(field.clone())
                        .or_insert_with(std::collections::HashSet::new)
                        .insert(val_str);
                }
            }
        }
    }

    // Calculate statistics
    let avg_key_len = key_lengths.iter().sum::<usize>() as f64 / count.max(1) as f64;
    let avg_value_len = value_lengths.iter().sum::<usize>() as f64 / count.max(1) as f64;

    // Build cardinality map
    let cardinality: HashMap<String, u64> = field_cardinality.iter()
        .map(|(k, v)| (k.clone(), v.len() as u64))
        .collect();

    // Calculate selectivity (cardinality / count)
    let selectivity: HashMap<String, f64> = cardinality.iter()
        .map(|(k, v)| (k.clone(), *v as f64 / count.max(1) as f64))
        .collect();

    let stats = serde_json::json!({
        "tree": "~w",
        "record_count": count,
        "avg_key_length": avg_key_len,
        "avg_value_length": avg_value_len,
        "field_counts": field_counts,
        "field_cardinality": cardinality,
        "field_selectivity": selectivity
    });

    println!("{}", serde_json::to_string_pretty(&stats)?);

    Ok(())
}
', [DbFile, TreeStr, TreeStr]).

%% extract_db_constraints_rust(+Body, -Constraints)
%  Extract database-pushable constraints from predicate body.
extract_db_constraints_rust(true, []) :- !.
extract_db_constraints_rust((A, B), Constraints) :- !,
    extract_db_constraints_rust(A, C1),
    extract_db_constraints_rust(B, C2),
    append(C1, C2, Constraints).
extract_db_constraints_rust(A = B, [eq(A, B)]) :-
    (atom(A) ; atom(B)), !.
extract_db_constraints_rust(A \= B, [neq(A, B)]) :-
    (atom(A) ; atom(B)), !.
extract_db_constraints_rust(A > B, [gt(A, B)]) :- !.
extract_db_constraints_rust(A < B, [lt(A, B)]) :- !.
extract_db_constraints_rust(A >= B, [gte(A, B)]) :- !.
extract_db_constraints_rust(A =< B, [lte(A, B)]) :- !.
extract_db_constraints_rust(_, []).

%% can_use_rust_optimization(+KeyStrategy, +Constraints, +IndexedFields, -OptType, -OptDetails)
%  Determine if an optimization can be applied.
can_use_rust_optimization(field(KeyField), Constraints, _, direct_lookup, key(Value)) :-
    member(eq(KeyField, Value), Constraints),
    atom(Value), !.

can_use_rust_optimization(composite([field(FirstField)|_]), Constraints, _, prefix_scan, prefix(Value)) :-
    member(eq(FirstField, Value), Constraints),
    atom(Value), !.

can_use_rust_optimization(_, Constraints, IndexedFields, index_scan, index(Field, Value)) :-
    IndexedFields \= [],
    member(Field, IndexedFields),
    member(eq(Field, Value), Constraints),
    atom(Value), !.

%% get_rust_index_fields(+Pred, +Arity, -IndexedFields)
%  Get indexed fields for a predicate (from index_analyzer or declarations).
get_rust_index_fields(Pred, Arity, IndexedFields) :-
    (   catch(
            findall(Field, index_analyzer:has_index(Pred/Arity, Field), IndexedFields),
            _,
            IndexedFields = []
        )
    ->  true
    ;   IndexedFields = []
    ).

%% ============================================
%% TAIL RECURSION OPTIMIZATION
%% ============================================

%% compile_tail_recursion_rust(+Pred/Arity, +Options, -RustCode)
%  Compile tail recursive predicates to Rust for loops.
%  Pattern: sum([], Acc, Acc). sum([H|T], Acc, S) :- Acc1 is Acc + H, sum(T, Acc1, S).
%  Generates O(1) stack space code.
%
compile_tail_recursion_rust(Pred/Arity, _Options, RustCode) :-
    atom_string(Pred, PredStr),
    
    % Detect step operation from predicate clauses
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    detect_rust_step_op(Clauses, Pred, StepOp),
    step_op_to_rust(StepOp, RustStepCode),
    
    (   Arity =:= 3 ->
        format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Tail Recursion Optimization
// Predicate: ~w/~w
// O(1) stack space via for loop

use std::io::{self, BufRead};

/// ~w computes result using accumulator pattern
fn ~w(items: &[i32], acc: i32) -> i32 {
    let mut result = acc;
    for &item in items {
        ~w;
    }
    result
}

fn main() {
    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            let items: Vec<i32> = line
                .split('','')
                .filter_map(|s| s.trim().parse().ok())
                .collect();
            println!("{}", ~w(&items, 0));
        }
    }
}
', [PredStr, Arity, PredStr, PredStr, RustStepCode, PredStr])
    ;   Arity =:= 2 ->
        format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Tail Recursion Optimization
// Predicate: ~w/~w

use std::io::{self, BufRead};

fn ~w(items: &[i32]) -> i32 {
    let mut acc = 0;
    for &item in items {
        ~w;
    }
    acc
}

fn main() {
    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            let items: Vec<i32> = line
                .split('','')
                .filter_map(|s| s.trim().parse().ok())
                .collect();
            println!("{}", ~w(&items));
        }
    }
}
', [PredStr, Arity, PredStr, RustStepCode, PredStr])
    ;   format(string(RustCode), '// Tail recursion for arity ~w not supported', [Arity])
    ).

%% detect_rust_step_op(+Clauses, +Pred, -StepOp)
detect_rust_step_op(Clauses, Pred, StepOp) :-
    member(_Head-Body, Clauses),
    Body \= true,
    contains_pred_rust(Body, Pred),
    extract_arith_rust(Body, StepOp),
    !.
detect_rust_step_op(_, _, add_element).

%% contains_pred_rust(+Body, +Pred)
contains_pred_rust(Body, Pred) :-
    Body =.. [Pred|_], !.
contains_pred_rust((A, _), Pred) :- contains_pred_rust(A, Pred), !.
contains_pred_rust((_, B), Pred) :- contains_pred_rust(B, Pred), !.

%% extract_arith_rust(+Body, -StepOp)
extract_arith_rust((_ is _ + B), add_element) :- var(B), !.
extract_arith_rust((_ is _ + 1), add_1) :- !.
extract_arith_rust((_ is _ * B), mult_element) :- var(B), !.
extract_arith_rust((A, _), Op) :- extract_arith_rust(A, Op), !.
extract_arith_rust((_, B), Op) :- extract_arith_rust(B, Op), !.
extract_arith_rust(_, add_1).

%% step_op_to_rust(+StepOp, -RustCode)
%  Non-multifile version (used by legacy tail recursion path)
step_op_to_rust(add_element, "result += item").
step_op_to_rust(add_1, "result += 1").
step_op_to_rust(mult_element, "result *= item").
step_op_to_rust(sub_element, "result -= item").
step_op_to_rust(arithmetic(Expr), RustExpr) :- tail_expr_to_rust(Expr, RustExpr).
step_op_to_rust(unknown, 'acc + 1').

%% can_compile_tail_recursion_rust(+Pred/Arity)
can_compile_tail_recursion_rust(Pred/Arity) :-
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    partition(is_recursive_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    RecClauses \= [],
    BaseClauses \= [].

%% is_recursive_clause_rust(+Pred, +Clause)
is_recursive_clause_rust(Pred, _Head-Body) :-
    Body \= true,
    contains_pred_rust(Body, Pred).

%% ============================================
%% LINEAR RECURSION WITH MEMOIZATION
%% ============================================

%% compile_linear_recursion_rust(+Pred/Arity, +Options, -RustCode)
%  Compile linear recursive predicates to Rust with memoization (HashMap).
%
compile_linear_recursion_rust(Pred/Arity, _Options, RustCode) :-
    atom_string(Pred, PredStr),
    upcase_atom(Pred, PredUp),
    atom_string(PredUp, PredUpStr),
    
    (   Arity =:= 2 ->
        format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Linear Recursion with Memoization
// Predicate: ~w/~w
// Uses HashMap-based memoization for O(n) performance

use std::collections::HashMap;
use std::io::{self, BufRead};

thread_local! {
    static ~w_MEMO: std::cell::RefCell<HashMap<i32, i32>> = std::cell::RefCell::new(HashMap::new());
}

/// ~w computes result with memoization
fn ~w(n: i32) -> i32 {
    // Check memo
    if let Some(&result) = ~w_MEMO.with(|m| m.borrow().get(&n).copied()) {
        return result;
    }
    
    // Base cases
    if n <= 0 {
        return 0;
    }
    if n == 1 {
        return 1;
    }
    
    // Recursive case with memoization
    let result = ~w(n - 1) + n;
    ~w_MEMO.with(|m| m.borrow_mut().insert(n, result));
    result
}

fn main() {
    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            if let Ok(n) = line.trim().parse::<i32>() {
                println!("{}", ~w(n));
            }
        }
    }
}
', [PredStr, Arity, PredUpStr, PredUpStr, PredStr, PredUpStr, PredStr, PredUpStr, PredStr])
    ;   format(string(RustCode), '// Linear recursion for arity ~w not supported', [Arity])
    ).

%% can_compile_linear_recursion_rust(+Pred/Arity)
can_compile_linear_recursion_rust(Pred/Arity) :-
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    partition(is_recursive_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    RecClauses \= [],
    BaseClauses \= [],
    forall(member(_-Body, RecClauses), count_recursive_calls_rust(Body, Pred, 1)).

%% count_recursive_calls_rust(+Body, +Pred, ?Count)
count_recursive_calls_rust(Body, Pred, Count) :-
    count_recursive_calls_rust_(Body, Pred, 0, Count).

count_recursive_calls_rust_(Goal, Pred, Acc, Count) :-
    Goal =.. [Pred|_], !,
    Count is Acc + 1.
count_recursive_calls_rust_((A, B), Pred, Acc, Count) :- !,
    count_recursive_calls_rust_(A, Pred, Acc, Acc1),
    count_recursive_calls_rust_(B, Pred, Acc1, Count).
count_recursive_calls_rust_(_, _, Acc, Acc).

%% ============================================
%% MUTUAL RECURSION
%% ============================================

%% compile_mutual_recursion_rust(+Predicates, +Options, -RustCode)
%  Compile mutually recursive predicates to Rust.
%  Example: is_even/1 and is_odd/1
%
compile_mutual_recursion_rust(Predicates, _Options, RustCode) :-
    % Extract predicate names for group name
    findall(PredStr, (
        member(Pred/_Arity, Predicates),
        atom_string(Pred, PredStr)
    ), PredStrs),
    atomic_list_concat(PredStrs, '_', GroupName),
    
    % Generate functions for each predicate
    findall(FuncCode, (
        member(Pred/Arity, Predicates),
        generate_mutual_function_rust(Pred, Arity, Predicates, GroupName, FuncCode)
    ), FuncCodes),
    atomic_list_concat(FuncCodes, '\n\n', FunctionsCode),
    
    format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Mutual Recursion
// Group: ~w

use std::collections::HashMap;
use std::cell::RefCell;
use std::env;

thread_local! {
    static ~w_MEMO: RefCell<HashMap<String, bool>> = RefCell::new(HashMap::new());
}

~w

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() >= 3 {
        if let Ok(n) = args[2].parse::<i32>() {
            match args[1].as_str() {
~w            _ => eprintln!("Unknown function"),
            }
        }
    }
}
', [GroupName, GroupName, FunctionsCode, generate_rust_match_arms(Predicates)]).

%% generate_mutual_function_rust(+Pred, +Arity, +AllPredicates, +GroupName, -Code)
generate_mutual_function_rust(Pred, Arity, AllPredicates, GroupName, Code) :-
    atom_string(Pred, PredStr),
    
    % Get clauses for this predicate
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    
    % Separate base and recursive cases
    partition(is_mutual_recursive_clause_rust(AllPredicates), Clauses, RecClauses, BaseClauses),
    
    % Generate base case code
    generate_mutual_base_cases_rust(BaseClauses, GroupName, BaseCaseCode),
    
    % Generate recursive case code  
    generate_mutual_recursive_cases_rust(RecClauses, AllPredicates, GroupName, RecCaseCode),
    
    format(string(Code),
'/// ~w is part of mutual recursion group
fn ~w(n: i32) -> bool {
    // Check memo
    let key = format!("~w:{}", n);
    if let Some(&result) = ~w_MEMO.with(|m| m.borrow().get(&key).copied()) {
        return result;
    }
    
~w
~w
    
    // No match
    false
}', [PredStr, PredStr, PredStr, GroupName, BaseCaseCode, RecCaseCode]).

%% is_mutual_recursive_clause_rust(+AllPredicates, +Clause)
is_mutual_recursive_clause_rust(AllPredicates, _Head-Body) :-
    Body \= true,
    member(Pred/Arity, AllPredicates),
    functor(Goal, Pred, Arity),
    body_contains_goal_rust(Body, Goal).

%% body_contains_goal_rust(+Body, +Goal)
body_contains_goal_rust((A, B), Goal) :- !,
    (   body_contains_goal_rust(A, Goal)
    ;   body_contains_goal_rust(B, Goal)
    ).
body_contains_goal_rust(Body, Goal) :-
    compound(Body),
    functor(Body, F, A),
    functor(Goal, F, A).

%% generate_mutual_base_cases_rust(+BaseClauses, +GroupName, -Code)
generate_mutual_base_cases_rust([], _, "    // No base cases").
generate_mutual_base_cases_rust(BaseClauses, GroupName, Code) :-
    BaseClauses \= [],
    findall(CaseCode, (
        member(Head-true, BaseClauses),
        Head =.. [_|[Value]],
        format(string(CaseCode), '    if n == ~w {\n        ~w_MEMO.with(|m| m.borrow_mut().insert(key.clone(), true));\n        return true;\n    }', [Value, GroupName])
    ), CaseCodes),
    atomic_list_concat(CaseCodes, '\n', Code).

%% generate_mutual_recursive_cases_rust(+RecClauses, +AllPredicates, +GroupName, -Code)
generate_mutual_recursive_cases_rust([], _, _, "    // No recursive cases").
generate_mutual_recursive_cases_rust([_Head-Body|_], AllPredicates, GroupName, Code) :-
    % Extract the called predicate from the body
    find_mutual_call_rust(Body, AllPredicates, CalledPred),
    atom_string(CalledPred, CalledPredStr),
    format(string(Code),
'    // Recursive case
    if n > 0 {
        let result = ~w(n - 1);
        ~w_MEMO.with(|m| m.borrow_mut().insert(key, result));
        return result;
    }', [CalledPredStr, GroupName]).

%% find_mutual_call_rust(+Body, +AllPredicates, -CalledPred)
find_mutual_call_rust((A, B), AllPredicates, CalledPred) :- !,
    (   find_mutual_call_rust(A, AllPredicates, CalledPred)
    ;   find_mutual_call_rust(B, AllPredicates, CalledPred)
    ).
find_mutual_call_rust(Goal, AllPredicates, CalledPred) :-
    Goal =.. [Pred|_],
    member(Pred/_Arity, AllPredicates),
    CalledPred = Pred.

%% generate_rust_match_arms(+Predicates)
generate_rust_match_arms(Predicates) :-
    findall(CaseCode, (
        member(Pred/_Arity, Predicates),
        atom_string(Pred, PredStr),
        format(string(CaseCode), '                "~w" => println!("{}", ~w(n)),', [PredStr, PredStr])
    ), CaseCodes),
    atomic_list_concat(CaseCodes, '\n', _Cases).

compile_single_rule_to_rust(_Pred, _Arity, Head, Body, FieldDelim, Unique, IncludeMain, RustCode) :-
    Head =.. [_|HeadArgs],
    
    extract_predicates(Body, Predicates),
    extract_constraints(Body, Constraints),
    extract_match_constraints(Body, MatchConstraints), 
    extract_key_generation(Body, Keys),
    extract_bindings(Body, Bindings),
    
    (   (Predicates = [BodyPred]; Predicates = []) ->
        (   Predicates = [BodyPred]
        ->  BodyPred =.. [_BodyName|BodyArgs]
        ;   BodyArgs = HeadArgs
        ),
        length(BodyArgs, NumFields),
        
        build_source_map(BodyArgs, SourceMap), 
        
        map_field_delimiter(FieldDelim, DelimChar),

        generate_rust_keys(Keys, SourceMap, KeyCode, KeyMap),
        generate_rust_bindings(Bindings, SourceMap, BindingMap, BindingCode),

        findall(OutputPart, 
            (
                member(Arg, HeadArgs),
                (   var(Arg), member((Var, Idx), SourceMap), Arg == Var ->
                    format(string(OutputPart), "parts[~w]", [Idx])
                ;   var(Arg), member((Var, RustVar), KeyMap), Arg == Var ->
                    format(string(OutputPart), "~w", [RustVar])
                ;   var(Arg), member((Var, BindVar), BindingMap), Arg == Var ->
                    format(string(OutputPart), "~w", [BindVar])
                ;   atom(Arg) ->
                    format(string(OutputPart), '"~w"', [Arg])
                ;   OutputPart = "\"unknown\""
                )
            ),
            OutputParts),
        build_rust_concat(OutputParts, DelimChar, OutputExpr),

        generate_rust_constraints(Constraints, SourceMap, BindingMap, ConstraintChecks),
        
        generate_rust_match_constraints(MatchConstraints, SourceMap, RegexInit, RegexChecks, NeedsRegex),

        (   Unique = true ->
            UniqueDecl = "    let mut seen = HashSet::new();",
            UniqueCheck = "            if seen.insert(result.clone()) {\n                println!(\"{}\", result);\n            }"
        ;   UniqueDecl = "",
            UniqueCheck = "            println!(\"{}\", result);"
        ),
        
        format(string(ScriptBody), '    let stdin = io::stdin();
~s
~s
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            let parts: Vec<&str> = line.split("~s").collect();
            if parts.len() == ~w {
~s
~s
~s
~s
                let result = ~s;
~s
            }
        }
    }
', [UniqueDecl, RegexInit, DelimChar, NumFields, RegexChecks, ConstraintChecks, KeyCode, BindingCode, OutputExpr, UniqueCheck]),

        (   IncludeMain ->
            (   NeedsRegex = true -> UseRegex = "use regex::Regex;\n" ; UseRegex = "" ),
            format(string(RustCode), 'use std::io::{self, BufRead};
use std::collections::HashSet;
~s
fn main() {
~s}
', [UseRegex, ScriptBody])
        ;   RustCode = ScriptBody
        )
    ;   RustCode = "// TODO: Multi-predicate not supported"
    ).

%% ============================================ 
%% AGGREGATION COMPILATION
%% ============================================ 

compile_aggregation_to_rust(_Pred, _Arity, AggOp, _FieldDelim, IncludeMain, RustCode) :-
    generate_aggregation_logic(AggOp, Logic),
    
    (   IncludeMain ->
        format(string(RustCode), 'use std::io::{self, BufRead};

fn main() {
~s}
', [Logic])
    ;   RustCode = Logic
    ).

%% ============================================ 
%% JSON INPUT COMPILATION
%% ============================================ 

compile_json_input_to_rust(Pred, Arity, Options, RustCode) :-
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),

    (   Clauses = [SingleHead-SingleBody] ->
        % Optimize goals (Codd Phase)
        (   optimizer:optimize_clause(SingleHead, SingleBody, Options, OptimizedBody)
        ->  format('  Optimized body: ~w~n', [OptimizedBody])
        ;   OptimizedBody = SingleBody
        ),

        extract_json_operations(OptimizedBody, JsonOps),
        option(field_delimiter(FieldDelim), Options, colon),
        map_field_delimiter(FieldDelim, DelimChar),
        option(unique(Unique), Options, true),
        option(json_schema(SchemaName), Options, none), 

        generate_json_input_logic(JsonOps, SingleHead, SchemaName, DelimChar, Unique, ScriptBody),
        
        format(string(RustCode), 'use std::io::{self, BufRead};
use std::collections::HashSet;
use serde::Deserialize;
use serde_json::{self, Value};

fn main() {
~s
}
', [ScriptBody])
    ;   fail
    ).

%% ============================================ 
%% JSON OUTPUT COMPILATION
%% ============================================ 

compile_json_output_to_rust(Pred, Arity, Options, RustCode) :-
    atom_string(Pred, PredStr),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    
    (   Clauses = [SingleHead-_] ->
        option(field_delimiter(FieldDelim), Options, colon),
        map_field_delimiter(FieldDelim, DelimChar),
        
        generate_json_output_struct(PredStr, SingleHead, StructDef),
        generate_json_output_logic(SingleHead, DelimChar, ScriptBody),
        
        format(string(RustCode), 'use std::io::{self, BufRead};
use serde::Serialize;
use serde_json::{self, Value};

~s

fn main() {
    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        if let Ok(l) = line {
            let parts: Vec<&str> = l.split("~s").collect();
            if parts.len() == ~w {
~s
            }
        }
    }
}
', [StructDef, DelimChar, Arity, ScriptBody])
    ;   fail
    ).

%% ============================================ 
%% LOGIC GENERATION HELPERS
%% ============================================ 

generate_aggregation_logic(count, "let c = io::stdin().lock().lines().count(); println!(\"{}\", c);").
generate_aggregation_logic(sum, "let s: f64 = io::stdin().lock().lines().filter_map(|l| l.ok()?.trim().parse().ok()).sum(); println!(\"{}\", s);").
generate_aggregation_logic(avg, "let (c, s) = io::stdin().lock().lines().filter_map(|l| l.ok()?.trim().parse::<f64>().ok()).fold((0, 0.0), |(c, s), n| (c + 1, s + n)); if c > 0 { println!(\"{}\", s / c as f64); }").
generate_aggregation_logic(min, "if let Some(m) = io::stdin().lock().lines().filter_map(|l| l.ok()?.trim().parse::<f64>().ok()).min_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal)) { println!(\"{}\", m); }").
generate_aggregation_logic(max, "if let Some(m) = io::stdin().lock().lines().filter_map(|l| l.ok()?.trim().parse::<f64>().ok()).max_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal)) { println!(\"{}\", m); }").

% Statistical aggregations (ported from Go target)
generate_aggregation_logic(stddev, "
    let values: Vec<f64> = io::stdin().lock().lines()
        .filter_map(|l| l.ok()?.trim().parse().ok())
        .collect();
    if values.len() > 1 {
        let n = values.len() as f64;
        let mean = values.iter().sum::<f64>() / n;
        let variance = values.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / (n - 1.0);
        println!(\"{}\", variance.sqrt());
    } else {
        println!(\"0\");
    }
").
generate_aggregation_logic(median, "
    let mut values: Vec<f64> = io::stdin().lock().lines()
        .filter_map(|l| l.ok()?.trim().parse().ok())
        .collect();
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    if !values.is_empty() {
        let mid = values.len() / 2;
        let median = if values.len() % 2 == 0 {
            (values[mid - 1] + values[mid]) / 2.0
        } else {
            values[mid]
        };
        println!(\"{}\", median);
    }
").
generate_aggregation_logic(percentile(P), Code) :-
    format(string(Code), "
    let mut values: Vec<f64> = io::stdin().lock().lines()
        .filter_map(|l| l.ok()?.trim().parse().ok())
        .collect();
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    if !values.is_empty() {
        let p = ~w as f64 / 100.0;
        let idx = (p * (values.len() - 1) as f64).round() as usize;
        println!(\"{}\", values[idx.min(values.len() - 1)]);
    }
", [P]).

% Collection aggregations
generate_aggregation_logic(collect_list, "
    let values: Vec<String> = io::stdin().lock().lines()
        .filter_map(|l| l.ok())
        .map(|l| l.trim().to_string())
        .collect();
    println!(\"[{}]\", values.iter().map(|s| format!(\"\\\"{}\\\"\", s)).collect::<Vec<_>>().join(\",\"));
").
generate_aggregation_logic(collect_set, "
    use std::collections::HashSet;
    let values: HashSet<String> = io::stdin().lock().lines()
        .filter_map(|l| l.ok())
        .map(|l| l.trim().to_string())
        .collect();
    let mut sorted: Vec<_> = values.into_iter().collect();
    sorted.sort();
    println!(\"[{}]\", sorted.iter().map(|s| format!(\"\\\"{}\\\"\", s)).collect::<Vec<_>>().join(\",\"));
").

%% ============================================
%% OBSERVABILITY FEATURES (ported from Go target)
%% ============================================

%% generate_rust_observability(+Options, -Imports, -Setup, -OnRecord, -OnError, -Finalize)
%  Generate observability code for progress reporting, error logging, and metrics
generate_rust_observability(Options, Imports, Setup, OnRecord, OnError, Finalize) :-
    % Progress reporting
    (   option(progress(ProgressOpt), Options)
    ->  (   ProgressOpt = interval(N) -> Interval = N
        ;   ProgressOpt = true -> Interval = 1000
        ;   Interval = 1000
        ),
        ProgressImport = "use std::sync::atomic::{AtomicU64, Ordering};",
        format(string(ProgressSetup), '
    let record_count = AtomicU64::new(0);', []),
        format(string(ProgressOnRecord), '
        let count = record_count.fetch_add(1, Ordering::SeqCst) + 1;
        if count % ~w == 0 {
            eprintln!("Processed {} records", count);
        }', [Interval])
    ;   ProgressImport = "",
        ProgressSetup = "",
        ProgressOnRecord = ""
    ),

    % Error file logging
    (   option(error_file(ErrorFile), Options)
    ->  ErrorImport = "use std::fs::OpenOptions;\nuse std::io::Write;",
        format(string(ErrorSetup), '
    let mut error_file = OpenOptions::new()
        .create(true)
        .append(true)
        .open("~w")
        .expect("Failed to open error file");', [ErrorFile]),
        ErrorOnError = '
        if let Err(ref e) = result {
            writeln!(error_file, "{{\\"timestamp\\": \\"{:?}\\", \\"error\\": \\"{}\\", \\"line\\": \\"{}\\"}}",
                std::time::SystemTime::now(), e, line.escape_default()).ok();
        }'
    ;   ErrorImport = "",
        ErrorSetup = "",
        ErrorOnError = ""
    ),

    % Error threshold
    (   option(error_threshold(count(Threshold)), Options)
    ->  ThresholdImport = "use std::sync::atomic::{AtomicU64, Ordering};",
        ThresholdSetup = '
    let error_count = AtomicU64::new(0);',
        format(string(ThresholdOnError), '
        let err_count = error_count.fetch_add(1, Ordering::SeqCst) + 1;
        if err_count > ~w {
            eprintln!("FATAL: Error threshold exceeded ({} errors)", err_count);
            std::process::exit(1);
        }', [Threshold])
    ;   ThresholdImport = "",
        ThresholdSetup = "",
        ThresholdOnError = ""
    ),

    % Metrics file
    (   option(metrics_file(MetricsFile), Options)
    ->  MetricsImport = "use std::time::Instant;",
        MetricsSetup = '
    let start_time = Instant::now();
    let mut total_records: u64 = 0;
    let mut error_records: u64 = 0;',
        MetricsOnRecord = '
        total_records += 1;',
        MetricsOnError = '
        error_records += 1;',
        format(string(MetricsFinalize), '
    let elapsed = start_time.elapsed();
    let metrics = format!("{{\\"total_records\\": {}, \\"error_records\\": {}, \\"duration_secs\\": {:.3}, \\"records_per_sec\\": {:.2}}}",
        total_records, error_records, elapsed.as_secs_f64(),
        if elapsed.as_secs_f64() > 0.0 { total_records as f64 / elapsed.as_secs_f64() } else { 0.0 });
    std::fs::write("~w", metrics).expect("Failed to write metrics");
    eprintln!("Metrics: {}", metrics);', [MetricsFile])
    ;   MetricsImport = "",
        MetricsSetup = "",
        MetricsOnRecord = "",
        MetricsOnError = "",
        MetricsFinalize = ""
    ),

    % Combine all imports
    atomic_list_concat([ProgressImport, ErrorImport, ThresholdImport, MetricsImport], '\n', ImportsRaw),
    % Remove duplicate atomic import if present
    (   sub_string(ImportsRaw, _, _, _, "AtomicU64")
    ->  Imports = "use std::sync::atomic::{AtomicU64, Ordering};\nuse std::time::Instant;\nuse std::fs::OpenOptions;\nuse std::io::Write;"
    ;   Imports = ImportsRaw
    ),

    % Combine setup code
    atomic_list_concat([ProgressSetup, ErrorSetup, ThresholdSetup, MetricsSetup], '', Setup),

    % Combine on-record code
    atomic_list_concat([ProgressOnRecord, MetricsOnRecord], '', OnRecord),

    % Combine on-error code
    atomic_list_concat([ErrorOnError, ThresholdOnError, MetricsOnError], '', OnError),

    % Finalize code
    Finalize = MetricsFinalize.

%% rust_observability_wrapper(+InnerCode, +Options, -WrappedCode)
%  Wrap code with observability if options are present
rust_observability_wrapper(InnerCode, Options, WrappedCode) :-
    (   (option(progress(_), Options) ; option(error_file(_), Options) ;
         option(error_threshold(_), Options) ; option(metrics_file(_), Options))
    ->  generate_rust_observability(Options, Imports, Setup, OnRecord, _OnError, Finalize),
        format(string(WrappedCode), '~s
~s
fn main() {
~s
    // Processing loop with observability
    for line in std::io::stdin().lock().lines() {
        if let Ok(l) = line {
~s
~s
        }
    }
~s
}', [Imports, "", Setup, InnerCode, OnRecord, Finalize])
    ;   WrappedCode = InnerCode
    ).

%% ============================================
%% WINDOW FUNCTIONS (ported from Go target)
%% ============================================

%% has_rust_window_function(+Op)
%  Check if an aggregation operation is a window function
has_rust_window_function(Op) :-
    (   compound(Op), functor(Op, row_number, _) -> true
    ;   compound(Op), functor(Op, rank, _) -> true
    ;   compound(Op), functor(Op, dense_rank, _) -> true
    ;   compound(Op), functor(Op, lag, _) -> true
    ;   compound(Op), functor(Op, lead, _) -> true
    ;   compound(Op), functor(Op, first_value, _) -> true
    ;   compound(Op), functor(Op, last_value, _) -> true
    ;   is_list(Op), member(Sub, Op), has_rust_window_function(Sub) -> true
    ), !.

%% parse_rust_window_spec(+Ops, +FieldMappings, -SortField, -ResultVar, -WindowType)
%  Parse window function specification from aggregation operations
parse_rust_window_spec(Ops, _, SortField, RankVar, row_number) :-
    member(row_number(SortField, RankVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, RankVar, rank) :-
    member(rank(SortField, RankVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, RankVar, dense_rank) :-
    member(dense_rank(SortField, RankVar), Ops), !.

% LAG window function variants
parse_rust_window_spec(Ops, _, SortField, ResultVar, lag(ValueField, Offset, Default)) :-
    member(lag(SortField, ValueField, Offset, Default, ResultVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, ResultVar, lag(ValueField, Offset)) :-
    member(lag(SortField, ValueField, Offset, ResultVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, ResultVar, lag(ValueField)) :-
    member(lag(SortField, ValueField, ResultVar), Ops), !.

% LEAD window function variants
parse_rust_window_spec(Ops, _, SortField, ResultVar, lead(ValueField, Offset, Default)) :-
    member(lead(SortField, ValueField, Offset, Default, ResultVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, ResultVar, lead(ValueField, Offset)) :-
    member(lead(SortField, ValueField, Offset, ResultVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, ResultVar, lead(ValueField)) :-
    member(lead(SortField, ValueField, ResultVar), Ops), !.

% FIRST_VALUE and LAST_VALUE
parse_rust_window_spec(Ops, _, SortField, ResultVar, first_value(ValueField)) :-
    member(first_value(SortField, ValueField, ResultVar), Ops), !.
parse_rust_window_spec(Ops, _, SortField, ResultVar, last_value(ValueField)) :-
    member(last_value(SortField, ValueField, ResultVar), Ops), !.

%% generate_rust_lag_lead_code(+WindowType, +ValueField, +Offset, +Default, +FieldMappings, -RustCode)
%  Generate Rust code snippet for LAG/LEAD window functions
generate_rust_lag_lead_code(lag, ValueField, Offset, Default, _FieldMappings, RustCode) :-
    (   Default = null -> DefaultVal = "None"
    ;   number(Default) -> format(atom(DefaultVal), 'Some(serde_json::json!(~w))', [Default])
    ;   format(atom(DefaultVal), 'Some(serde_json::json!("~w"))', [Default])
    ),
    format(string(RustCode), '
        // LAG: Access previous row value
        for i in 0..rows.len() {
            let lag_value = if i >= ~w {
                rows[i - ~w].get("~w").cloned()
            } else {
                ~w
            };
            if let Some(ref mut row) = rows.get_mut(i) {
                if let Some(obj) = row.as_object_mut() {
                    obj.insert("lag_~w".to_string(), lag_value.unwrap_or(serde_json::Value::Null));
                }
            }
        }', [Offset, Offset, ValueField, DefaultVal, ValueField]).

generate_rust_lag_lead_code(lead, ValueField, Offset, Default, _FieldMappings, RustCode) :-
    (   Default = null -> DefaultVal = "None"
    ;   number(Default) -> format(atom(DefaultVal), 'Some(serde_json::json!(~w))', [Default])
    ;   format(atom(DefaultVal), 'Some(serde_json::json!("~w"))', [Default])
    ),
    format(string(RustCode), '
        // LEAD: Access next row value
        let len = rows.len();
        for i in 0..len {
            let lead_value = if i + ~w < len {
                rows[i + ~w].get("~w").cloned()
            } else {
                ~w
            };
            if let Some(ref mut row) = rows.get_mut(i) {
                if let Some(obj) = row.as_object_mut() {
                    obj.insert("lead_~w".to_string(), lead_value.unwrap_or(serde_json::Value::Null));
                }
            }
        }', [Offset, Offset, ValueField, DefaultVal, ValueField]).

generate_rust_lag_lead_code(first_value, ValueField, _Offset, _Default, _FieldMappings, RustCode) :-
    format(string(RustCode), '
        // FIRST_VALUE: Get first row value in window
        let first_value = rows.first()
            .and_then(|r| r.get("~w"))
            .cloned()
            .unwrap_or(serde_json::Value::Null);
        for row in rows.iter_mut() {
            if let Some(obj) = row.as_object_mut() {
                obj.insert("first_~w".to_string(), first_value.clone());
            }
        }', [ValueField, ValueField]).

generate_rust_lag_lead_code(last_value, ValueField, _Offset, _Default, _FieldMappings, RustCode) :-
    format(string(RustCode), '
        // LAST_VALUE: Get last row value in window
        let last_value = rows.last()
            .and_then(|r| r.get("~w"))
            .cloned()
            .unwrap_or(serde_json::Value::Null);
        for row in rows.iter_mut() {
            if let Some(obj) = row.as_object_mut() {
                obj.insert("last_~w".to_string(), last_value.clone());
            }
        }', [ValueField, ValueField]).

%% generate_rust_window_jsonl(+WindowType, +GroupField, +SortField, +ValueField, +Offset, +Default, +FieldMappings, -RustCode)
%  Generate complete JSONL processing code for window functions
generate_rust_window_jsonl(WindowType, GroupField, SortField, ValueField, Offset, Default, FieldMappings, RustCode) :-
    find_rust_field_for_var(GroupField, FieldMappings, GroupFieldName),
    find_rust_field_for_var(SortField, FieldMappings, SortFieldName),
    find_rust_field_for_var(ValueField, FieldMappings, ValueFieldName),
    generate_rust_lag_lead_code(WindowType, ValueFieldName, Offset, Default, FieldMappings, WindowCode),

    format(string(RustCode), '
use std::io::{self, BufRead};
use std::collections::HashMap;
use serde_json::Value;

fn main() {
    let mut groups: HashMap<String, Vec<Value>> = HashMap::new();

    // Read and group records
    for line in io::stdin().lock().lines() {
        if let Ok(l) = line {
            if let Ok(data) = serde_json::from_str::<Value>(&l) {
                let group_key = data.get("~w")
                    .map(|v| v.to_string())
                    .unwrap_or_default();
                groups.entry(group_key).or_default().push(data);
            }
        }
    }

    // Process each group
    for (_, mut rows) in groups {
        // Sort by ~w
        rows.sort_by(|a, b| {
            let va = a.get("~w").and_then(|v| v.as_f64()).unwrap_or(0.0);
            let vb = b.get("~w").and_then(|v| v.as_f64()).unwrap_or(0.0);
            va.partial_cmp(&vb).unwrap_or(std::cmp::Ordering::Equal)
        });

~w

        // Output results
        for row in rows {
            println!("{}", serde_json::to_string(&row).unwrap_or_default());
        }
    }
}', [GroupFieldName, SortFieldName, SortFieldName, WindowCode]).

%% find_rust_field_for_var(+Var, +FieldMappings, -FieldName)
%  Find the JSON field name for a Prolog variable
find_rust_field_for_var(Var, FieldMappings, FieldName) :-
    (   member(json_field(FieldName, Var), FieldMappings)
    ->  true
    ;   member(field(FieldName, Var), FieldMappings)
    ->  true
    ;   atom(Var)
    ->  FieldName = Var
    ;   format(atom(FieldName), '~w', [Var])
    ).

generate_json_input_logic(JsonOps, Head, SchemaName, DelimChar, Unique, ScriptBody) :-
    Head =.. [_|HeadArgs],
    findall(ExtractLine, (
        nth1(Pos, HeadArgs, Arg),
        format(atom(ValVar), 'val_~w', [Pos]),
        (   member(json_field(JsonField, Arg), JsonOps) ->
            ( SchemaName \= none -> get_field_type(SchemaName, JsonField, Type) ; Type = any ),
            rust_json_extract_code(ValVar, JsonField, Type, ExtractLine)
        ;   member(json_path(Path, Arg), JsonOps) ->
            ( SchemaName \= none -> last(Path, LF), get_field_type(SchemaName, LF, Type) ; Type = any ),
            rust_json_path_extract_code(ValVar, Path, Type, ExtractLine)
        ;   format(string(ExtractLine), 'let ~w = Value::Null;', [ValVar])
        )
    ), ExtractLines),
    atomic_list_concat(ExtractLines, '\n', ExtractCode),
    findall(OutputPart, (nth1(Pos, HeadArgs, _), format(atom(OutputPart), 'val_~w', [Pos])), OutputParts),
    build_rust_concat(OutputParts, DelimChar, OutputExpr),
    ( Unique = true -> UniqueDecl = "let mut seen = HashSet::new();", UniqueCheck = "if seen.insert(result.clone()) { println!(\"{}\", result); }" ; UniqueDecl = "", UniqueCheck = "println!(\"{}\", result);" ),
    format(string(ScriptBody), '~s
    for line in io::stdin().lock().lines() {
        if let Ok(l) = line {
            let json_data: Value = match serde_json::from_str(&l) { Ok(d) => d, Err(_) => continue };
~s
            let result = ~s;
            ~s
        }
    }', [UniqueDecl, ExtractCode, OutputExpr, UniqueCheck]).

rust_json_extract_code(Var, Field, Type, Code) :-
    atom_string(Field, FieldStr),
    (   Type = any -> format(string(Code), 'let ~w = json_data.get(\"~s\").cloned().unwrap_or(Value::Null);', [Var, FieldStr])
    ;   format_type_for_json(Type, RustType),
        format(string(Code), 'let ~w: ~s = match json_data.get(\"~s\") {
                Some(v) => match serde_json::from_value(v.clone()) { Ok(val) => val, Err(_) => continue },
                None => continue,
            };', [Var, RustType, FieldStr])
    ).
ust_json_path_extract_code(Var, Path, Type, Code) :-
    atomic_list_concat(Path, '/', PathStr),
    (   Type = any -> format(string(Code), 'let ~w = json_data.pointer(\"/~s\").cloned().unwrap_or(Value::Null);', [Var, PathStr])
    ;   format_type_for_json(Type, RustType),
        format(string(Code), 'let ~w: ~s = match json_data.pointer(\"/~s\") {
                Some(v) => match serde_json::from_value(v.clone()) { Ok(val) => val, Err(_) => continue },
                None => continue,
            };', [Var, RustType, PathStr])
    ).

generate_json_output_struct(PredName, Head, StructDef) :-
    Head =.. [_|HeadArgs],
    findall(FieldName, (nth1(Idx, HeadArgs, Arg), (var(Arg) -> format(atom(FieldName), 'field_~w', [Idx]) ; atom_string(Arg, FieldName))), FieldNames),
    findall(FieldLine, (
        nth1(Idx, HeadArgs, Arg), nth1(Idx, FieldNames, FieldName),
        ( var(Arg) -> Type = string ; Type = string ),
        format_type_for_json(Type, RustType),
        format(string(FieldLine), '    #[serde(rename = "~w")]\n    pub ~w: ~s,', [FieldName, FieldName, RustType])
    ), FieldLines),
    atomic_list_concat(FieldLines, '\n', FieldsStr),
    format(string(StructDef), '#[derive(Serialize)]
struct ~w {
~s
}', [PredName, FieldsStr]).

generate_json_output_logic(Head, _DelimChar, ScriptBody) :-
    Head =.. [PredName|HeadArgs],
    findall(FieldName, (nth1(Idx, HeadArgs, Arg), (var(Arg) -> format(atom(FieldName), 'field_~w', [Idx]) ; atom_string(Arg, FieldName))), FieldNames),
    findall(AssignLine, (nth1(Idx, FieldNames, FieldName), PartIdx is Idx-1, format(string(AssignLine), '        ~w: parts[~w].to_string(),', [FieldName, PartIdx])), AssignLines),
    atomic_list_concat(AssignLines, '\n', AssignCode),
    format(string(ScriptBody), 'let record = ~w {
~s
};
if let Ok(json_str) = serde_json::to_string(&record) {
    println!("{}", json_str);
}', [PredName, AssignCode]).
%% ============================================ 
%% HELPERS
%% ============================================ 

build_source_map(BodyArgs, Map) :- build_source_map_(BodyArgs, 0, Map).
build_source_map_([], _, []).
build_source_map_([Arg|Rest], Idx, [(Arg, Idx)|Map]) :- NextIdx is Idx + 1, build_source_map_(Rest, NextIdx, Map).

build_rust_concat([Single], _, Format) :- !, format(string(Format), "String::from(~s)", [Single]).
build_rust_concat(Parts, Delim, Format) :-
    atomic_list_concat(Parts, ', ', Args),
    maplist(rust_format_placeholder, Parts, Placeholders),
    atomic_list_concat(Placeholders, Delim, FmtStr),
    format(string(Format), "format!(\"~s\", ~s)", [FmtStr, Args]).

rust_format_placeholder(_, "{}").

extract_predicates(true, []) :- !.
extract_predicates((A, B), Ps) :- !, extract_predicates(A, P1), extract_predicates(B, P2), append(P1, P2, Ps).
extract_predicates(Goal, []) :- member(Goal, [(_>_), (_<_), (_>=_), (_=<_), (_=:=_), (_=\=_), (_ is _), match(_, _), json_field(_, _), json_path(_, _), json_record(_), json_get(_, _), generate_key(_, _)]), !.
extract_predicates(Goal, []) :- functor(Goal, Name, Arity), rs_binding(Name/Arity, _, _, _, _), !.
extract_predicates(Goal, [Goal]).

extract_constraints(true, []) :- !.
extract_constraints((A, B), Cs) :- !, extract_constraints(A, C1), extract_constraints(B, C2), append(C1, C2, Cs).
extract_constraints(Goal, [Goal]) :- member(Goal, [(_>_), (_<_), (_>=_), (_=<_), (_=:=_), (_=\=_)]), !.
extract_constraints(_, []).

extract_match_constraints(true, []) :- !.
extract_match_constraints((A, B), Ms) :- !, extract_match_constraints(A, M1), extract_match_constraints(B, M2), append(M1, M2, Ms).
extract_match_constraints(match(Var, Pattern), [match(Var, Pattern)]) :- !.
extract_match_constraints(_, []).

extract_bindings(true, []) :- !.
extract_bindings((A, B), Bs) :- !, extract_bindings(A, B1), extract_bindings(B, B2), append(B1, B2, Bs).
extract_bindings(Goal, [Goal]) :-
    functor(Goal, Name, Arity),
    rs_binding(Name/Arity, _, _, _, _), !.
extract_bindings(_, []).

generate_rust_bindings(Goals, SourceMap, BindingMap, Code) :-
    generate_rust_bindings_rec(Goals, SourceMap, [], BindingMap, Code).

generate_rust_bindings_rec([], _, Map, Map, "").
generate_rust_bindings_rec([Goal|Rest], SourceMap, MapIn, MapOut, Code) :-
    Goal =.. [Pred|Args],
    functor(Goal, Pred, Arity),
    binding(rust, Pred/Arity, TargetName, InputTypes, _, _),
    
    length(InputTypes, NumInputs),
    length(Inputs, NumInputs),
    append(Inputs, Outputs, Args),
    
    maplist(term_to_rust_expr(SourceMap, MapIn), Inputs, InputExprs),
    
    findall(VarName-Var, (member(Var, Outputs), gensym('val_', Atom), atom_string(Atom, VarName)), OutPairs),
    
    (   sub_string(TargetName, 0, 1, _, ".")
    ->  InputExprs = [Obj|RestInputs],
        atomic_list_concat(RestInputs, ", ", ArgStr),
        (   sub_string(TargetName, _, 2, 0, "()")
        ->  sub_string(TargetName, 0, _, 2, MethodName),
            format(string(CallExpr), "~s~w()", [Obj, MethodName])
        ;   format(string(CallExpr), "~s~w(~s)", [Obj, TargetName, ArgStr])
        )
    ;   atomic_list_concat(InputExprs, ", ", ArgStr),
        format(string(CallExpr), "~w(~s)", [TargetName, ArgStr])
    ),
    
    (   OutPairs = [VarName-Var]
    ->  format(string(Line), "                let ~s = ~s;\n", [VarName, CallExpr]),
        NewBindings = [(Var, VarName)]
    ;   OutPairs = []
    ->  format(string(Line), "                ~s;\n", [CallExpr]),
        NewBindings = []
    ;   fail % Tuple todo
    ),
    
    append(NewBindings, MapIn, MapNext),
    generate_rust_bindings_rec(Rest, SourceMap, MapNext, MapOut, RestCode),
    string_concat(Line, RestCode, Code).

term_to_rust_expr(SourceMap, _, Var, Code) :-
    var(Var), member((V, I), SourceMap), Var == V, !,
    format(string(Code), "parts[~w].trim()", [I]). % Default string
term_to_rust_expr(_, BindingMap, Var, Code) :-
    var(Var), member((V, Name), BindingMap), Var == V, !,
    Code = Name.
term_to_rust_expr(_, _, Val, Code) :-
    number(Val), !, format(string(Code), "~w", [Val]).
term_to_rust_expr(_, _, Val, Code) :-
    string(Val), !, format(string(Code), "\"~s\"", [Val]).
term_to_rust_expr(_, _, Val, Code) :-
    atom(Val), !, format(string(Code), "\"~w\"", [Val]).


extract_json_operations(true, []) :- !.
extract_json_operations((A, B), Ops) :- !, extract_json_operations(A, O1), extract_json_operations(B, O2), append(O1, O2, Ops).
extract_json_operations(json_field(F, V), [json_field(F, V)]) :- !.
extract_json_operations(json_path(P, V), [json_path(P, V)]) :- !.
extract_json_operations(json_record(Fs), Ops) :- !, maplist(field_to_json_op, Fs, Ops).
extract_json_operations(json_get(P, V), [json_path(P, V)]) :- !.
extract_json_operations(_, []).

extract_key_generation(true, []) :- !.
extract_key_generation((A, B), Keys) :- !, extract_key_generation(A, K1), extract_key_generation(B, K2), append(K1, K2, Keys).
extract_key_generation(generate_key(S, V), [generate_key(S, V)]) :- !.
extract_key_generation(_, []).

generate_rust_keys([], _, "", []).
generate_rust_keys(Keys, SourceMap, Code, KeyMap) :-
    generate_rust_keys_(Keys, SourceMap, [], CodeList, [], KeyMap),
    atomic_list_concat(CodeList, '\n', Code).

generate_rust_keys_([], _, CodeAcc, CodeList, MapAcc, MapAcc) :-
    reverse(CodeAcc, CodeList).
generate_rust_keys_([generate_key(Strategy, Var)|Rest], SourceMap, CodeAcc, CodeResult, MapAcc, MapResult) :-
    gensym('key_', KeyVar),
    compile_rust_key_expr(Strategy, SourceMap, MapAcc, Expr),
    format(string(Line), "                let ~w = ~s;", [KeyVar, Expr]),
    generate_rust_keys_(Rest, SourceMap, [Line|CodeAcc], CodeResult, [(Var, KeyVar)|MapAcc], MapResult).

compile_rust_key_expr(Var, SourceMap, _, Code) :- % Implicit field or key
    var(Var), member((V, I), SourceMap), Var == V, !,
    format(string(Code), "parts[~w]", [I]).
compile_rust_key_expr(Var, _, KeyMap, Code) :- % Generated key
    var(Var), member((V, K), KeyMap), Var == V, !,
    format(string(Code), "~w", [K]).
compile_rust_key_expr(field(Var), SourceMap, _, Code) :-
    var(Var), member((V, I), SourceMap), Var == V, !,
    format(string(Code), "parts[~w]", [I]).
compile_rust_key_expr(literal(Text), _, _, Code) :-
    format(string(Code), "\"~w\"", [Text]).
compile_rust_key_expr(composite(List), SourceMap, KeyMap, Code) :-
    compile_rust_key_expr_list(List, SourceMap, KeyMap, Parts),
    atomic_list_concat(Parts, ", ", Args),
    length(Parts, N),
    length(Slots, N), maplist(=("{}"), Slots), atomic_list_concat(Slots, "", Fmt),
    format(string(Code), "format!(\"~s\", ~s)", [Fmt, Args]).
compile_rust_key_expr(hash(Expr), SourceMap, KeyMap, Code) :-
    compile_rust_key_expr(Expr, SourceMap, KeyMap, Inner),
    format(string(Code), "{ use sha2::{Sha256, Digest}; let mut hasher = Sha256::new(); hasher.update(~s.as_bytes()); hex::encode(hasher.finalize()) }", [Inner]).
compile_rust_key_expr(uuid(), _, _, "uuid::Uuid::new_v4().to_string()").
compile_rust_key_expr(Var, _, _, "\"UNKNOWN_VAR\"") :-
    var(Var),
    format('WARNING: Key variable ~w not found in source map or key map~n', [Var]).

compile_rust_key_expr_list([], _, _, []).
compile_rust_key_expr_list([H|T], SourceMap, KeyMap, [HC|TC]) :-
    compile_rust_key_expr(H, SourceMap, KeyMap, HC),
    compile_rust_key_expr_list(T, SourceMap, KeyMap, TC).

field_to_json_op(Field-Var, json_field(Field, Var)).

generate_rust_constraints([], _, _, "").
generate_rust_constraints(Constraints, SourceMap, BindingMap, Code) :-
    findall(Check, (member(C, Constraints), constraint_to_rust(C, SourceMap, BindingMap, Check)), Checks),
    atomic_list_concat(Checks, '\n', Code).

constraint_to_rust(Comparison, SourceMap, BindingMap, Code) :-
    Comparison =.. [Op, L, R], map_rust_op(Op, RO), 
    term_to_rust_numeric(L, SourceMap, BindingMap, LC), 
    term_to_rust_numeric(R, SourceMap, BindingMap, RC),
    format(string(Code), "if !(~s ~s ~s) { continue; }", [LC, RO, RC]).

map_rust_op(>, ">"). map_rust_op(<, "<"). map_rust_op(>=, ">="). map_rust_op(=<, "<="). map_rust_op(=:=, "=="). map_rust_op(=\=, "!=").

term_to_rust_numeric(Var, SourceMap, _, Code) :- var(Var), member((V, I), SourceMap), Var == V, !, format(string(Code), "parts[~w].trim().parse::<f64>().unwrap_or(0.0)", [I]).
term_to_rust_numeric(Var, _, BindingMap, Code) :- var(Var), member((V, Name), BindingMap), Var == V, !, format(string(Code), "~w as f64", [Name]).
term_to_rust_numeric(Num, _, _, Num) :- number(Num).

generate_rust_match_constraints([], _, "", "", false).
generate_rust_match_constraints(Matches, SourceMap, InitCode, CheckCode, true) :-
    findall((Init, Check), (
        member(match(Var, Pattern), Matches),
        var(Var), member((V, Idx), SourceMap), Var == V,
        gensym('re_', ReVar),
        format(string(Init), 'let ~w = Regex::new(\"~w\").unwrap();', [ReVar, Pattern]),
        format(string(Check), 'if !~w.is_match(parts[~w]) { continue; }', [ReVar, Idx])
    ), Pairs),
    findall(I, member((I,_), Pairs), Inits), findall(C, member((_,C), Pairs), Checks),
    atomic_list_concat(Inits, '\n', InitCode), atomic_list_concat(Checks, '\n', CheckCode).

map_field_delimiter(colon, ':'). map_field_delimiter(tab, '\t'). map_field_delimiter(comma, ','). map_field_delimiter(pipe, '|'). map_field_delimiter(C, C).

format_type_for_json(string, "String").
format_type_for_json(integer, "i64").
format_type_for_json(float, "f64").
format_type_for_json(boolean, "bool").
format_type_for_json(array, "Vec<Value>").
format_type_for_json(object, "serde_json::Map<String, Value>").
format_type_for_json(any, "Value").

%% ============================================ 
%% PROJECT GENERATION
%% ============================================ 

write_rust_program(Code, Path) :- open(Path, write, S), write(S, Code), close(S), format('Rust program written to: ~w~n', [Path]).

write_rust_project(RustCode, ProjectDir) :- 
    make_directory_path(ProjectDir),
    directory_file_path(ProjectDir, 'src', SrcDir), make_directory_path(SrcDir),
    directory_file_path(SrcDir, 'main.rs', MainPath), write_rust_program(RustCode, MainPath),
    write_runtime_files(SrcDir),
    detect_dependencies(RustCode, Deps),
    directory_file_path(ProjectDir, 'Cargo.toml', CargoPath),
    file_base_name(ProjectDir, ProjectName),
    generate_cargo_toml(ProjectName, Deps, CargoContent),
    open(CargoPath, write, S), write(S, CargoContent), close(S),
    format('Rust project created at: ~w~n', [ProjectDir]).

write_runtime_files(SrcDir) :-
    RuntimeFiles = ['importer.rs', 'crawler.rs', 'searcher.rs', 'llm.rs', 'embedding.rs'],
    % Assuming runtime dir is relative to this source file or cwd
    % We'll try a fixed path relative to CWD for now
    RuntimeDir = 'src/unifyweaver/targets/rust_runtime',
    
    forall(member(File, RuntimeFiles), (
        directory_file_path(RuntimeDir, File, SourcePath),
        directory_file_path(SrcDir, File, DestPath),
        (   exists_file(SourcePath)
        ->  copy_file(SourcePath, DestPath),
            format('Copied runtime file: ~w~n', [File])
        ;   format('WARNING: Runtime file not found: ~w~n', [SourcePath])
        )
    )).

detect_dependencies(Code, Deps) :-
    findall(Dep, 
        (   sub_string(Code, _, _, _, 'use regex::'), Dep = regex
        ;   sub_string(Code, _, _, _, 'use serde::'), Dep = serde
        ;   sub_string(Code, _, _, _, 'use serde_json'), Dep = serde_json
        ;   sub_string(Code, _, _, _, 'use sha2::'), Dep = sha2
        ;   sub_string(Code, _, _, _, 'hex::encode'), Dep = hex
        ;   sub_string(Code, _, _, _, 'uuid::Uuid'), Dep = uuid
        ;   sub_string(Code, _, _, _, 'mod importer;'), Dep = redb
        ;   sub_string(Code, _, _, _, 'mod crawler;'), Dep = quick_xml
        ;   sub_string(Code, _, _, _, 'mod llm;'), Dep = serde_json % llm uses serde_json
        ;   sub_string(Code, _, _, _, 'mod embedding;'), Dep = candle
        ),
        DepsList),
    sort(DepsList, Deps).
generate_cargo_toml(Name, Deps, Content) :-
    format(string(Header), '[package]\nname = "~w"\nversion = "0.1.0"\nedition = "2021"\n\n[dependencies]\n', [Name]),
    maplist(dep_to_toml, Deps, DepLines),
    atomic_list_concat(DepLines, '\n', DepBlock),
    string_concat(Header, DepBlock, Content).

dep_to_toml(regex, "regex = \"1\"").
dep_to_toml(serde, "serde = { version = \"1.0\", features = [\"derive\"] }").
dep_to_toml(serde_json, "serde_json = \"1.0\"").
dep_to_toml(sha2, "sha2 = \"0.10\"").
dep_to_toml(hex, "hex = \"0.4\"").
dep_to_toml(uuid, "uuid = { version = \"1.4\", features = [\"v4\"] }").
dep_to_toml(redb, "redb = \"1.4.0\"").
dep_to_toml(quick_xml, "quick-xml = \"0.38\"").
dep_to_toml(candle, "candle-core = \"0.9\"\ncandle-nn = \"0.9\"\ncandle-transformers = \"0.9\"\ntokenizers = \"0.22\"\nanyhow = \"1.0\"").

% ============================================================================
% Pipeline Generator Mode for Rust
% ============================================================================
%
% This section implements pipeline chaining with support for generator mode
% (fixpoint iteration) for Rust targets. Similar to Python, PowerShell, and
% C# pipeline implementations.
%
% Usage:
%   compile_rust_pipeline([derive/1, transform/1], [
%       pipeline_name(fixpoint_pipe),
%       pipeline_mode(generator),
%       output_format(jsonl)
%   ], RustCode).

%% compile_rust_pipeline(+Predicates, +Options, -RustCode)
%  Compile a list of predicates into a Rust pipeline.
%  Options:
%    pipeline_name(Name) - Name for the pipeline function (default: 'pipeline')
%    pipeline_mode(Mode) - 'sequential' (default) or 'generator' (fixpoint)
%    output_format(Format) - 'jsonl' (default) or 'json'
%    panic_fallback(input) - have main call a safe wrapper that returns the
%      original input if generated stage execution panics
%
compile_rust_pipeline(Predicates, Options, RustCode) :-
    option(pipeline_name(PipelineName), Options, pipeline),
    option(pipeline_mode(PipelineMode), Options, sequential),
    option(output_format(OutputFormat), Options, jsonl),
    option(panic_fallback(PanicFallback), Options, none),

    % Generate header based on mode
    rust_pipeline_header(PipelineMode, Header),

    % Generate helper functions based on mode
    rust_pipeline_helpers(PipelineMode, Helpers),

    % Extract stage names
    extract_rust_stage_names(Predicates, StageNames),

    % Generate stage functions
    generate_rust_stage_functions(Predicates, StageFunctions),

    % Generate the pipeline connector (mode-aware)
    generate_rust_pipeline_connector(StageNames, PipelineName, PipelineMode, ConnectorCode),

    % Optionally generate a panic-catching entrypoint for outer fallback use.
    generate_rust_pipeline_panic_fallback(PipelineName, PanicFallback, FallbackCode, MainPipelineName),

    % Generate main execution block
    generate_rust_main_block(MainPipelineName, OutputFormat, MainBlock),

    % Combine all parts
    format(string(RustCode),
"~w

~w

~w
~w
~w

~w
", [Header, Helpers, StageFunctions, ConnectorCode, FallbackCode, MainBlock]).

%% rust_pipeline_header(+Mode, -Header)
%  Generate mode-aware header with use statements
rust_pipeline_header(generator, Header) :-
    !,
    format(string(Header),
"// Generated by UnifyWeaver Rust Pipeline Generator Mode
// Fixpoint evaluation for recursive pipeline stages
use std::collections::{HashMap, HashSet};
use std::io::{self, BufRead, Write};
use serde_json::{Value, Map};", []).

rust_pipeline_header(_, Header) :-
    format(string(Header),
"// Generated by UnifyWeaver Rust Pipeline (sequential mode)
use std::collections::HashMap;
use std::io::{self, BufRead, Write};
use serde_json::{Value, Map};", []).

%% rust_pipeline_helpers(+Mode, -Helpers)
%  Generate mode-aware helper functions
rust_pipeline_helpers(generator, Helpers) :-
    !,
    format(string(Helpers),
"/// Generates a unique key for record deduplication.
fn record_key(record: &HashMap<String, Value>) -> String {
    let mut keys: Vec<&String> = record.keys().collect();
    keys.sort();
    keys.iter()
        .map(|k| format!(\"{}={}\", k, record.get(*k).unwrap_or(&Value::Null)))
        .collect::<Vec<_>>()
        .join(\";\")
}

/// Read JSONL records from stdin.
fn read_jsonl_stream() -> Vec<HashMap<String, Value>> {
    let stdin = io::stdin();
    let mut records = Vec::new();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            if !line.trim().is_empty() {
                if let Ok(value) = serde_json::from_str::<HashMap<String, Value>>(&line) {
                    records.push(value);
                }
            }
        }
    }
    records
}

/// Write JSONL records to stdout.
fn write_jsonl_stream(records: &[HashMap<String, Value>]) {
    let stdout = io::stdout();
    let mut handle = stdout.lock();
    for record in records {
        if let Ok(json) = serde_json::to_string(record) {
            writeln!(handle, \"{}\", json).ok();
        }
    }
}

fn value_to_f64(value: Option<&Value>) -> f64 {
    match value {
        Some(Value::Number(n)) => n.as_f64().unwrap_or(0.0),
        Some(Value::String(s)) => s.parse::<f64>().unwrap_or(0.0),
        Some(Value::Bool(b)) => if *b { 1.0 } else { 0.0 },
        _ => 0.0,
    }
}", []).

rust_pipeline_helpers(_, Helpers) :-
    format(string(Helpers),
"/// Read JSONL records from stdin.
fn read_jsonl_stream() -> Vec<HashMap<String, Value>> {
    let stdin = io::stdin();
    let mut records = Vec::new();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            if !line.trim().is_empty() {
                if let Ok(value) = serde_json::from_str::<HashMap<String, Value>>(&line) {
                    records.push(value);
                }
            }
        }
    }
    records
}

/// Write JSONL records to stdout.
fn write_jsonl_stream(records: &[HashMap<String, Value>]) {
    let stdout = io::stdout();
    let mut handle = stdout.lock();
    for record in records {
        if let Ok(json) = serde_json::to_string(record) {
            writeln!(handle, \"{}\", json).ok();
        }
    }
}", []).

%% extract_rust_stage_names(+Predicates, -Names)
%  Extract stage names from predicate indicators
extract_rust_stage_names([], []).
extract_rust_stage_names([Pred|Rest], [Name|RestNames]) :-
    extract_rust_pred_name(Pred, Name),
    extract_rust_stage_names(Rest, RestNames).
extract_rust_stage_names([Pred/_Arity|Rest], [Pred|RestNames]) :-
    !,
    extract_rust_stage_names(Rest, RestNames).
extract_rust_stage_names([_|Rest], RestNames) :-
    extract_rust_stage_names(Rest, RestNames).

extract_rust_pred_name(_Target:Name/_Arity, NameStr) :-
    !,
    atom_string(Name, NameStr).
extract_rust_pred_name(Name/_Arity, NameStr) :-
    atom_string(Name, NameStr).

%% generate_rust_stage_functions(+Predicates, -Code)
%  Generate pipeline stage implementations when a predicate matches a
%  supported lowering shape, otherwise emit an explicit unsupported-stage
%  failure so generated pipelines do not silently pass data through.
generate_rust_stage_functions([], "").
generate_rust_stage_functions([PredIndicator|Rest], Code) :-
    generate_rust_stage_function(PredIndicator, StageCode),
    generate_rust_stage_functions(Rest, RestCode),
    format(string(Code), "~w~w", [StageCode, RestCode]).

generate_rust_stage_function(PredIndicator, StageCode) :-
    extract_rust_pred_name(PredIndicator, Name),
    (   rust_pipeline_stage_code(PredIndicator, Name, StageCode)
    ->  true
    ;   format(string(StageCode),
"/// Stage: ~w
fn stage_~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    let _ = input;
    panic!(\"unsupported Rust pipeline stage: ~w\");
}

", [Name, Name, Name])
    ).

rust_pipeline_stage_code(PredIndicator, Name, StageCode) :-
    pred_indicator_parts(PredIndicator, Pred, Arity),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    (   Clauses = [Head-Body],
        normalize_goals(Body, Goals),
        append(BeforeAgg, [AggGoal|AfterAgg], Goals),
        classify_aggregate(AggGoal, AggInfo),
        BeforeAgg = [TriggerGoal],
        include(rust_pipeline_builtin_goal, AfterAgg, HavingFilters),
        exclude(rust_pipeline_builtin_goal, AfterAgg, UnsupportedAfterAgg),
        UnsupportedAfterAgg == [],
        rust_pipeline_correlated_aggregate_stage(Name, Head, TriggerGoal, AggInfo, HavingFilters, StageCode)
    ;   Arity =:= 3,
        is_general_recursive_pattern_rust(Pred, Arity, Clauses),
        \+ rust_computed_increment_pattern(Pred, Clauses, _, _, _, _, _, _, _),
        rust_pipeline_recursive_tc_stage(Name, Pred, Clauses, StageCode)
    ;   rust_pipeline_join_stage(Name, Head, Clauses, StageCode)
    ).

rust_pipeline_recursive_tc_stage(Name, Pred, Clauses, StageCode) :-
    partition(is_rec_clause_rust(Pred), Clauses, RecClauses, BaseClauses),
    BaseClauses = [BaseHead-BaseBody|_],
    RecClauses = [_RecHead-RecBody|_],
    BaseHead =.. [HeadPred, _, _, BaseConst],
    number(BaseConst),
    extract_goals_list_rust(BaseBody, BaseGoals),
    BaseGoals = [BaseStepGoal|_],
    BaseStepGoal =.. [StepRel, _, _],
    extract_goals_list_rust(RecBody, RecGoals),
    member(_Hops is (_Prev + Incr), RecGoals),
    number(Incr),
    (   member(BoundGoal, RecGoals),
        strip_module(BoundGoal, _, PlainBoundGoal),
        functor(PlainBoundGoal, BoundRel, 1),
        BoundRel \= Pred,
        BoundRel \= StepRel,
        member(Constraint0, RecGoals),
        strip_module(Constraint0, _, Constraint),
        Constraint =.. [Op, Left, Right],
        member(Op, [=<, <, >=, >]),
        term_variables(PlainBoundGoal, [BoundVar]),
        (   Left == BoundVar
        ;   Right == BoundVar
        )
    ->  atom_string(BoundRel, BoundRelStr),
        format(string(BoundSetup),
"    let mut recursion_bound: Option<f64> = None;
    for bound_fact in &input {
        if matches!(bound_fact.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") {
            recursion_bound = Some(value_to_f64(bound_fact.get(\"arg0\")));
            break;
        }
    }
", [BoundRelStr]),
        rust_pipeline_tc_bound_condition(Op, Left, Right, BoundVar, 'next_depth', BoundCond)
    ;   BoundSetup = "",
        BoundCond = "true"
    ),
    atom_string(HeadPred, HeadPredStr),
    atom_string(StepRel, StepRelStr),
    rust_numeric_literal("f64", BaseConst, BaseConstStr),
    rust_numeric_literal("f64", Incr, IncrStr),
    format(string(StageCode),
"/// Stage: ~w
fn stage_~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    let mut results: Vec<HashMap<String, Value>> = Vec::new();
~w    for edge in &input {
        if !matches!(edge.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") {
            continue;
        }
        let mut base_record = HashMap::new();
        base_record.insert(\"relation\".to_string(), Value::String(\"~w\".to_string()));
        base_record.insert(\"arg0\".to_string(), edge.get(\"arg0\").cloned().unwrap_or(Value::Null));
        base_record.insert(\"arg1\".to_string(), edge.get(\"arg1\").cloned().unwrap_or(Value::Null));
        if let Some(n) = serde_json::Number::from_f64(~w) {
            base_record.insert(\"arg2\".to_string(), Value::Number(n));
        } else {
            base_record.insert(\"arg2\".to_string(), Value::Null);
        }
        results.push(base_record);

        for prev in &input {
            if !matches!(prev.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") {
                continue;
            }
            if edge.get(\"arg1\") != prev.get(\"arg0\") {
                continue;
            }
            let next_depth = value_to_f64(prev.get(\"arg2\")) + ~w;
            if ~w {
                let mut record = HashMap::new();
                record.insert(\"relation\".to_string(), Value::String(\"~w\".to_string()));
                record.insert(\"arg0\".to_string(), edge.get(\"arg0\").cloned().unwrap_or(Value::Null));
                record.insert(\"arg1\".to_string(), prev.get(\"arg1\").cloned().unwrap_or(Value::Null));
                if let Some(n) = serde_json::Number::from_f64(next_depth) {
                    record.insert(\"arg2\".to_string(), Value::Number(n));
                } else {
                    record.insert(\"arg2\".to_string(), Value::Null);
                }
                results.push(record);
            }
        }
    }
    results
}

", [Name, Name, BoundSetup, StepRelStr, HeadPredStr, BaseConstStr, HeadPredStr, IncrStr, BoundCond, HeadPredStr]).

rust_pipeline_tc_bound_condition(Op, Left, Right, BoundVar, DepthExpr, Cond) :-
    rust_pipeline_tc_bound_operand(Left, BoundVar, DepthExpr, LeftExpr),
    rust_pipeline_tc_bound_operand(Right, BoundVar, DepthExpr, RightExpr),
    member(Op-RustOp, [(=<)-"<=", (<)-"<", (>=)-">=", (>)-">"]),
    format(string(Cond), "recursion_bound.map(|bound| ~w ~w ~w).unwrap_or(true)", [LeftExpr, RustOp, RightExpr]).

rust_pipeline_tc_bound_operand(Term, BoundVar, _DepthExpr, "bound") :-
    var(Term),
    Term == BoundVar,
    !.
rust_pipeline_tc_bound_operand(Term, _BoundVar, DepthExpr, DepthExpr) :-
    var(Term),
    !.
rust_pipeline_tc_bound_operand(Term, _BoundVar, _DepthExpr, Expr) :-
    number(Term),
    !,
    rust_numeric_literal("f64", Term, Expr).

rust_pipeline_join_stage(Name, _Head, Clauses, StageCode) :-
    findall(ClauseCode,
        ( member(ClauseHead-Body, Clauses),
          ClauseHead =.. [HeadPred|HeadArgs],
          normalize_goals(Body, Goals),
          rust_pipeline_clause_block(Goals, HeadPred, HeadArgs, ClauseCode)
        ),
        ClauseBlocks),
    ClauseBlocks \= [],
    atomic_list_concat(ClauseBlocks, "", ClauseBody),
    format(string(StageCode),
"/// Stage: ~w
fn stage_~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    let mut results: Vec<HashMap<String, Value>> = Vec::new();
~w    results
}

", [Name, Name, ClauseBody]).

rust_pipeline_clause_block(Goals, HeadPred, HeadArgs, ClauseCode) :-
    rust_pipeline_goal_walk(Goals, 0, [], HeadPred, HeadArgs, "    ", ClauseBody, _),
    ClauseBody \= "",
    format(string(ClauseCode), "~w", [ClauseBody]).

rust_pipeline_goal_walk([], Counter, Env, HeadPred, HeadArgs, Indent, Code, Counter) :-
    rust_pipeline_emit_record(HeadPred, HeadArgs, Env, Indent, Code).
rust_pipeline_goal_walk([Goal0|Rest], Counter0, Env0, HeadPred, HeadArgs, Indent, Code, CounterOut) :-
    strip_module(Goal0, _, Goal),
    (   rust_pipeline_builtin_goal(Goal)
    ->  rust_pipeline_builtin_block(Goal, Env0, Indent, Prefix, Env1),
        rust_pipeline_goal_walk(Rest, Counter0, Env1, HeadPred, HeadArgs, Indent, InnerCode, CounterOut),
        rust_pipeline_wrap_prefix(Prefix, InnerCode, Indent, Code)
    ;   Goal =.. [Rel|Args],
        format(string(LoopVar), "f~w", [Counter0]),
        Counter1 is Counter0 + 1,
        rust_pipeline_relation_condition(Args, LoopVar, Env0, Cond),
        rust_pipeline_bind_new_vars(Args, LoopVar, Env0, Indent, BindingsCode, Env1),
        atom_string(Rel, RelStr),
        format(string(LoopHeader),
"~wfor ~w in &input {
~w    if !matches!(~w.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") || !(~w) {
~w        continue;
~w    }
~w",
            [Indent, LoopVar, Indent, LoopVar, RelStr, Cond, Indent, Indent, BindingsCode]),
        format(string(InnerIndent), "~w    ", [Indent]),
        rust_pipeline_goal_walk(Rest, Counter1, Env1, HeadPred, HeadArgs, InnerIndent, InnerCode, CounterOut),
        format(string(Code), "~w~w~w}\n", [LoopHeader, InnerCode, Indent])
    ).

rust_pipeline_relation_condition([], _LoopVar, _Env, "true").
rust_pipeline_relation_condition(Args, LoopVar, Env, Cond) :-
    findall(Part,
        ( nth0(Index, Args, Arg),
          rust_pipeline_relation_arg_condition(Arg, Index, LoopVar, Env, Part)
        ),
        Parts),
    rust_combine_pipeline_conditions(Parts, Cond).

rust_pipeline_relation_arg_condition(Arg, Index, LoopVar, Env, Cond) :-
    var(Arg),
    lookup_var(Arg, Env, Binding),
    Binding = val(Name),
    !,
    format(string(Cond), "~w.get(\"arg~w\").cloned().unwrap_or(Value::Null) == ~w", [LoopVar, Index, Name]).
rust_pipeline_relation_arg_condition(Arg, Index, LoopVar, _Env, Cond) :-
    nonvar(Arg),
    rust_pipeline_value_literal(Arg, Literal),
    format(string(Cond), "~w.get(\"arg~w\").cloned().unwrap_or(Value::Null) == ~w", [LoopVar, Index, Literal]).

rust_pipeline_bind_new_vars(Args, LoopVar, Env0, Indent, Code, EnvOut) :-
    rust_pipeline_bind_new_vars_(Args, 0, LoopVar, Env0, Indent, Code, EnvOut).

rust_pipeline_bind_new_vars_([], _Index, _LoopVar, Env, _Indent, "", Env).
rust_pipeline_bind_new_vars_([Arg|Rest], Index, LoopVar, Env0, Indent, Code, EnvOut) :-
    rust_pipeline_bind_new_var(Arg, Index, LoopVar, Env0, Indent, Code0, Env1),
    NextIndex is Index + 1,
    rust_pipeline_bind_new_vars_(Rest, NextIndex, LoopVar, Env1, Indent, RestCode, EnvOut),
    format(string(Code), "~w~w", [Code0, RestCode]).

rust_pipeline_bind_new_var(Arg, _Index, _LoopVar, Env, _Indent, "", Env) :-
    nonvar(Arg),
    !.
rust_pipeline_bind_new_var(Arg, _Index, _LoopVar, Env, _Indent, "", Env) :-
    lookup_var(Arg, Env, _),
    !.
rust_pipeline_bind_new_var(Arg, Index, LoopVar, Env0, Indent, Code, [Arg-val(Name)|Env0]) :-
    gensym(rv_, NameAtom),
    atom_string(NameAtom, Name),
    format(string(Code), "~w    let ~w = ~w.get(\"arg~w\").cloned().unwrap_or(Value::Null);\n", [Indent, Name, LoopVar, Index]).

rust_pipeline_builtin_block(is(Var, Expr), Env0, Indent, Prefix, [Var-num(Name)|Env0]) :-
    var(Var),
    !,
    gensym(rn_, NameAtom),
    atom_string(NameAtom, Name),
    rust_pipeline_numeric_expr(Expr, Env0, ExprCode),
    format(string(Prefix), "~wlet ~w = ~w;\n", [Indent, Name, ExprCode]).
rust_pipeline_builtin_block(=(Left, Right), Env, Indent, Prefix, Env) :-
    !,
    rust_pipeline_equality_condition(Left, Right, Env, Cond),
    format(string(Prefix), "~wif ~w {\n", [Indent, Cond]).
rust_pipeline_builtin_block('\\='(Left, Right), Env, Indent, Prefix, Env) :-
    !,
    rust_pipeline_equality_condition(Left, Right, Env, EqCond),
    format(string(Prefix), "~wif !(~w) {\n", [Indent, EqCond]).
rust_pipeline_builtin_block(Goal, Env, Indent, Prefix, Env) :-
    Goal =.. [Op, Left, Right],
    member(Op-RustOp, [(>)-">", (<)-"<", (>=)-">=", (=<)-"<=", (=:=)-"==", (=\\=)-"!="]),
    !,
    rust_pipeline_numeric_expr(Left, Env, LeftExpr),
    rust_pipeline_numeric_expr(Right, Env, RightExpr),
    format(string(Prefix), "~wif ~w ~w ~w {\n", [Indent, LeftExpr, RustOp, RightExpr]).
rust_pipeline_builtin_block(true, Env, _Indent, "", Env) :- !.

rust_pipeline_wrap_prefix("", InnerCode, _Indent, InnerCode).
rust_pipeline_wrap_prefix(Prefix, InnerCode, Indent, Code) :-
    format(string(Code), "~w~w~w}\n", [Prefix, InnerCode, Indent]).

rust_pipeline_equality_condition(Left, Right, Env, Cond) :-
    rust_pipeline_comparable_expr(Left, Env, LeftExpr),
    rust_pipeline_comparable_expr(Right, Env, RightExpr),
    format(string(Cond), "~w == ~w", [LeftExpr, RightExpr]).

rust_pipeline_comparable_expr(Term, Env, Expr) :-
    var(Term),
    lookup_var(Term, Env, Binding),
    (   Binding = val(Name)
    ->  Expr = Name
    ;   Binding = num(Name)
    ->  Expr = Name
    ),
    !.
rust_pipeline_comparable_expr(Term, _Env, Expr) :-
    number(Term),
    !,
    rust_numeric_literal("f64", Term, Expr).
rust_pipeline_comparable_expr(Term, _Env, Expr) :-
    rust_pipeline_value_literal(Term, Expr).

rust_pipeline_numeric_expr(Expr, Env, RustExpr) :-
    var(Expr),
    lookup_var(Expr, Env, Binding),
    !,
    (   Binding = num(Name)
    ->  RustExpr = Name
    ;   Binding = val(Name)
    ->  format(string(RustExpr), "value_to_f64(Some(&~w))", [Name])
    ).
rust_pipeline_numeric_expr(Expr, _Env, RustExpr) :-
    number(Expr),
    !,
    rust_numeric_literal("f64", Expr, RustExpr).
rust_pipeline_numeric_expr(-Expr, Env, RustExpr) :-
    !,
    rust_pipeline_numeric_expr(Expr, Env, Inner),
    format(string(RustExpr), "(-~w)", [Inner]).
rust_pipeline_numeric_expr(Left ** Right, Env, RustExpr) :-
    !,
    rust_pipeline_numeric_expr(Left, Env, LeftExpr),
    rust_pipeline_numeric_expr(Right, Env, RightExpr),
    format(string(RustExpr), "(~w).powf(~w)", [LeftExpr, RightExpr]).
rust_pipeline_numeric_expr(Expr, Env, RustExpr) :-
    compound(Expr),
    Expr =.. [Op, Left, Right],
    member(Op-RustOp, [(+)-"+", (-)-"-", (*)-"*", (/)-"/"]),
    !,
    rust_pipeline_numeric_expr(Left, Env, LeftExpr),
    rust_pipeline_numeric_expr(Right, Env, RightExpr),
    format(string(RustExpr), "(~w ~w ~w)", [LeftExpr, RustOp, RightExpr]).

rust_pipeline_emit_record(HeadPred, HeadArgs, Env, Indent, Code) :-
    atom_string(HeadPred, HeadPredStr),
    rust_pipeline_head_bindings(HeadArgs, Env, Indent, BindingsCode),
    format(string(Code),
"~wlet mut record = HashMap::new();
~wrecord.insert(\"relation\".to_string(), Value::String(\"~w\".to_string()));
~w
~wresults.push(record);
", [Indent, Indent, HeadPredStr, BindingsCode, Indent]).

rust_pipeline_head_bindings(Args, Env, Indent, Code) :-
    rust_pipeline_head_bindings_(0, Args, Env, Indent, Code).

rust_pipeline_head_bindings_(Index, [], _Env, _Indent, "") :-
    integer(Index).
rust_pipeline_head_bindings_(Index, [Arg|Rest], Env, Indent, Code) :-
    rust_pipeline_head_binding(Index, Arg, Env, Indent, Line),
    NextIndex is Index + 1,
    rust_pipeline_head_bindings_(NextIndex, Rest, Env, Indent, RestCode),
    format(string(Code), "~w~w", [Line, RestCode]).

rust_pipeline_head_binding(Index, Arg, Env, Indent, Line) :-
    var(Arg),
    lookup_var(Arg, Env, Binding),
    !,
    (   Binding = val(Name)
    ->  format(string(Line), "~wrecord.insert(\"arg~w\".to_string(), ~w.clone());\n", [Indent, Index, Name])
    ;   Binding = num(Name)
    ->  format(string(Line),
"~wif let Some(n) = serde_json::Number::from_f64(~w) {
~w    record.insert(\"arg~w\".to_string(), Value::Number(n));
~w} else {
~w    record.insert(\"arg~w\".to_string(), Value::Null);
~w}
", [Indent, Name, Indent, Index, Indent, Indent, Index, Indent])
    ).
rust_pipeline_head_binding(Index, Arg, _Env, Indent, Line) :-
    atom(Arg),
    !,
    format(string(Line), "~wrecord.insert(\"arg~w\".to_string(), Value::String(\"~w\".to_string()));\n", [Indent, Index, Arg]).
rust_pipeline_head_binding(Index, Arg, _Env, Indent, Line) :-
    number(Arg),
    !,
    rust_numeric_literal("f64", Arg, Literal),
    format(string(Line),
"~wif let Some(n) = serde_json::Number::from_f64(~w) {
~w    record.insert(\"arg~w\".to_string(), Value::Number(n));
~w} else {
~w    record.insert(\"arg~w\".to_string(), Value::Null);
~w}
", [Indent, Literal, Indent, Index, Indent, Indent, Index, Indent]).

rust_pipeline_value_literal(Atom, Expr) :-
    atom(Atom),
    !,
    format(string(Expr), "Value::String(\"~w\".to_string())", [Atom]).
rust_pipeline_value_literal(Number, Expr) :-
    number(Number),
    rust_numeric_literal("f64", Number, Literal),
    format(string(Expr), "Value::Number(serde_json::Number::from_f64(~w).unwrap())", [Literal]).

pred_indicator_parts(_Target:Pred/Arity, Pred, Arity) :- !.
pred_indicator_parts(Pred/Arity, Pred, Arity).

rust_pipeline_builtin_goal(Goal0) :-
    strip_module(Goal0, _, Goal),
    nonvar(Goal),
    Goal =.. [Functor|_],
    member(Functor, [is, '=', '>', '<', '>=', '=<', '=:=', '=\\=', '==', '\\=', not, '\\+']).

rust_pipeline_correlated_aggregate_stage(Name, Head, TriggerGoal, AggInfo, HavingFilters, StageCode) :-
    Head =.. [HeadPred|HeadArgs],
    TriggerGoal =.. [TriggerPred|TriggerArgs],
    get_dict(type, AggInfo, all),
    get_dict(op, AggInfo, Op),
    get_dict(expr, AggInfo, Expr),
    get_dict(result, AggInfo, ResultVar),
    get_dict(goal_info, AggInfo, GoalInfo),
    GoalInfo.relations = [RelGoal],
    GoalInfo.other = [],
    RelGoal =.. [InnerPred|InnerArgs],
    rust_build_correlation_conditions(TriggerArgs, InnerArgs, CorrelationCond),
    rust_build_aggregate_filter_conditions(GoalInfo, InnerArgs, FilterCond0),
    rust_combine_pipeline_conditions([CorrelationCond, FilterCond0], FilterCond),
    rust_pipeline_aggregate_value_index(Op, Expr, InnerArgs, ValueIdx),
    rust_pipeline_agg_compute(Op, ValueIdx, AggSetup, AggLoop, AggGuard),
    rust_pipeline_agg_finish(Op, FinishExpr),
    rust_pipeline_having_condition(HavingFilters, ResultVar, HavingCond),
    rust_pipeline_output_bindings(HeadArgs, ResultVar, TriggerArgs, OutputBindings),
    atom_string(HeadPred, HeadPredStr),
    atom_string(TriggerPred, TriggerPredStr),
    atom_string(InnerPred, InnerPredStr),
    format(string(StageCode),
"/// Stage: ~w
fn stage_~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    let mut results: Vec<HashMap<String, Value>> = Vec::new();
    for fact in &input {
        if !matches!(fact.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") {
            continue;
        }
~w
        for f in &input {
            if matches!(f.get(\"relation\"), Some(Value::String(rel)) if rel == \"~w\") && (~w) {
~w
            }
        }
        if ~w {
            let agg = ~w;
            if ~w {
                let mut record = HashMap::new();
                record.insert(\"relation\".to_string(), Value::String(\"~w\".to_string()));
~w
                results.push(record);
            }
        }
    }
    results
}

", [Name, Name, TriggerPredStr, AggSetup, InnerPredStr, FilterCond, AggLoop, AggGuard, FinishExpr, HavingCond, HeadPredStr, OutputBindings]).

rust_pipeline_aggregate_value_index(count, _Expr, _Args, -1) :- !.
rust_pipeline_aggregate_value_index(Op, Expr, Args, Index) :-
    member(Op, [sum, avg, min, max]),
    nth0(Index, Args, Arg),
    Arg == Expr,
    !.

rust_pipeline_agg_compute(count, _ValueIdx, "        let mut agg_count: usize = 0;\n", "                agg_count += 1;\n", "agg_count > 0") :- !.
rust_pipeline_agg_compute(sum, ValueIdx, "        let mut values: Vec<f64> = Vec::new();\n", Loop, "!values.is_empty()") :-
    format(string(Loop), "                values.push(value_to_f64(f.get(\"arg~w\")));\n", [ValueIdx]).
rust_pipeline_agg_compute(avg, ValueIdx, "        let mut values: Vec<f64> = Vec::new();\n", Loop, "!values.is_empty()") :-
    format(string(Loop), "                values.push(value_to_f64(f.get(\"arg~w\")));\n", [ValueIdx]).
rust_pipeline_agg_compute(min, ValueIdx, "        let mut values: Vec<f64> = Vec::new();\n", Loop, "!values.is_empty()") :-
    format(string(Loop), "                values.push(value_to_f64(f.get(\"arg~w\")));\n", [ValueIdx]).
rust_pipeline_agg_compute(max, ValueIdx, "        let mut values: Vec<f64> = Vec::new();\n", Loop, "!values.is_empty()") :-
    format(string(Loop), "                values.push(value_to_f64(f.get(\"arg~w\")));\n", [ValueIdx]).

rust_pipeline_agg_finish(count, "agg_count as f64") :- !.
rust_pipeline_agg_finish(sum, "values.iter().copied().sum::<f64>()") :- !.
rust_pipeline_agg_finish(avg, "values.iter().copied().sum::<f64>() / (values.len() as f64)") :- !.
rust_pipeline_agg_finish(min, "values.iter().copied().fold(f64::INFINITY, f64::min)") :- !.
rust_pipeline_agg_finish(max, "values.iter().copied().fold(f64::NEG_INFINITY, f64::max)") :- !.

rust_pipeline_having_condition([], _ResultVar, "true") :- !.
rust_pipeline_having_condition([Constraint0], ResultVar, Cond) :-
    strip_module(Constraint0, _, Constraint),
    Constraint =.. [Op, Left0, Right0],
    rust_pipeline_having_operand(Left0, ResultVar, Left),
    rust_pipeline_having_operand(Right0, ResultVar, Right),
    member(Op-GoOp, [(>)-">", (<)-"<", (>=)-">=", (=<)-"<=", (=:=)-"==", (=\\=)-"!=", (==)-"=="]),
    format(string(Cond), "~w ~w ~w", [Left, GoOp, Right]).

rust_pipeline_having_operand(Operand0, ResultVar, "agg") :-
    var(Operand0),
    Operand0 == ResultVar,
    !.
rust_pipeline_having_operand(Operand, _ResultVar, Expr) :-
    number(Operand),
    !,
    format(string(Expr), "~w", [Operand]).

rust_build_correlation_conditions(TriggerArgs, InnerArgs, Condition) :-
    findall(Part,
        rust_correlation_condition(TriggerArgs, InnerArgs, Part),
        Parts),
    rust_combine_pipeline_conditions(Parts, Condition).

rust_correlation_condition(TriggerArgs, InnerArgs, Cond) :-
    nth0(TriggerIndex, TriggerArgs, TriggerArg),
    var(TriggerArg),
    nth0(InnerIndex, InnerArgs, InnerArg),
    var(InnerArg),
    TriggerArg == InnerArg,
    format(string(Cond), "f.get(\"arg~w\") == fact.get(\"arg~w\")", [InnerIndex, TriggerIndex]).

rust_build_aggregate_filter_conditions(GoalInfo, Args, Condition) :-
    get_dict(constraints, GoalInfo, Constraints),
    findall(Part,
        ( member(Constraint, Constraints),
          rust_aggregate_constraint_condition(Constraint, Args, Part)
        ),
        Parts),
    rust_combine_pipeline_conditions(Parts, Condition).

rust_aggregate_constraint_condition(Constraint0, Args, Cond) :-
    strip_module(Constraint0, _, Constraint),
    Constraint =.. [Op, Left, Right],
    member(Op-GoOp, [(>)-">", (<)-"<", (>=)-">=", (=<)-"<=", (=:=)-"==", (=\\=)-"!="]),
    rust_aggregate_operand(Left, Args, LeftExpr),
    rust_aggregate_operand(Right, Args, RightExpr),
    format(string(Cond), "~w ~w ~w", [LeftExpr, GoOp, RightExpr]).

rust_aggregate_operand(Term, Args, Expr) :-
    var(Term),
    !,
    nth0(Index, Args, Arg),
    Arg == Term,
    format(string(Expr), "value_to_f64(f.get(\"arg~w\"))", [Index]).
rust_aggregate_operand(Term, _Args, Expr) :-
    number(Term),
    !,
    format(string(Expr), "~w", [Term]).

rust_combine_pipeline_conditions(Parts0, Condition) :-
    exclude(=("true"), Parts0, Parts),
    (   Parts == []
    ->  Condition = "true"
    ;   atomic_list_concat(Parts, " && ", Condition)
    ).

rust_pipeline_output_bindings(HeadArgs, ResultVar, TriggerArgs, BindingsCode) :-
    findall(Line,
        ( nth0(Index, HeadArgs, Arg),
          rust_pipeline_output_binding(Index, Arg, ResultVar, TriggerArgs, Line)
        ),
        Lines),
    atomic_list_concat(Lines, "", BindingsCode).

rust_pipeline_output_binding(Index, Arg, ResultVar, _TriggerArgs, Line) :-
    var(Arg),
    Arg == ResultVar,
    !,
    format(string(Line),
"                if let Some(n) = serde_json::Number::from_f64(agg) {
                    record.insert(\"arg~w\".to_string(), Value::Number(n));
                } else {
                    record.insert(\"arg~w\".to_string(), Value::Null);
                }
", [Index, Index]).
rust_pipeline_output_binding(Index, Arg, _ResultVar, TriggerArgs, Line) :-
    var(Arg),
    nth0(TriggerIndex, TriggerArgs, TriggerArg),
    TriggerArg == Arg,
    !,
    format(string(Line), "                record.insert(\"arg~w\".to_string(), fact.get(\"arg~w\").cloned().unwrap_or(Value::Null));\n", [Index, TriggerIndex]).
rust_pipeline_output_binding(Index, Arg, _ResultVar, _TriggerArgs, Line) :-
    atom(Arg),
    !,
    format(string(Line), "                record.insert(\"arg~w\".to_string(), Value::String(\"~w\".to_string()));\n", [Index, Arg]).
rust_pipeline_output_binding(Index, Arg, _ResultVar, _TriggerArgs, Line) :-
    number(Arg),
    !,
    format(string(Line),
"                if let Some(n) = serde_json::Number::from_f64(~w_f64) {
                    record.insert(\"arg~w\".to_string(), Value::Number(n));
                } else {
                    record.insert(\"arg~w\".to_string(), Value::Null);
                }
", [Arg, Index, Index]).

%% generate_rust_pipeline_connector(+StageNames, +PipelineName, +Mode, -Code)
%  Generate the pipeline connector function (mode-aware)
generate_rust_pipeline_connector(StageNames, PipelineName, sequential, Code) :-
    !,
    generate_rust_sequential_chain(StageNames, ChainCode),
    atom_string(PipelineName, PipelineNameStr),
    format(string(Code),
"/// Sequential pipeline connector: ~w
fn ~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    // Sequential mode - chain stages directly
~w
}", [PipelineNameStr, PipelineNameStr, ChainCode]).

generate_rust_pipeline_connector(StageNames, PipelineName, generator, Code) :-
    generate_rust_fixpoint_chain(StageNames, ChainCode),
    atom_string(PipelineName, PipelineNameStr),
    format(string(Code),
"/// Fixpoint pipeline connector: ~w
/// Iterates until no new records are produced.
fn ~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    // Generator mode - fixpoint iteration
    let mut total: HashSet<String> = HashSet::new();
    let mut results: Vec<HashMap<String, Value>> = Vec::new();

    // Initialize with input records
    let mut working_set: Vec<HashMap<String, Value>> = Vec::new();
    for record in input {
        let key = record_key(&record);
        if !total.contains(&key) {
            total.insert(key);
            working_set.push(record.clone());
            results.push(record);
        }
    }

    // Fixpoint iteration
    let mut changed = true;
    while changed {
        changed = false;
        let current = working_set.clone();

        // Apply pipeline stages
~w

        // Check for new records
        for record in new_records {
            let key = record_key(&record);
            if !total.contains(&key) {
                total.insert(key);
                working_set.push(record.clone());
                results.push(record);
                changed = true;
            }
        }
    }

    results
}", [PipelineNameStr, PipelineNameStr, ChainCode]).

%% generate_rust_sequential_chain(+Names, -Code)
%  Generate sequential stage chaining code
generate_rust_sequential_chain([], Code) :-
    format(string(Code), "    input", []).
generate_rust_sequential_chain([Name], Code) :-
    !,
    format(string(Code), "    stage_~w(input)", [Name]).
generate_rust_sequential_chain(Names, Code) :-
    Names \= [],
    generate_rust_chain_expr(Names, "input", ChainExpr),
    format(string(Code), "    ~w", [ChainExpr]).

generate_rust_chain_expr([], Current, Current).
generate_rust_chain_expr([Name|Rest], Current, Expr) :-
    format(string(NextExpr), "stage_~w(~w)", [Name, Current]),
    generate_rust_chain_expr(Rest, NextExpr, Expr).

%% generate_rust_fixpoint_chain(+Names, -Code)
%  Generate fixpoint stage application code
generate_rust_fixpoint_chain([], Code) :-
    format(string(Code), "        let new_records = current;", []).
generate_rust_fixpoint_chain(Names, Code) :-
    Names \= [],
    generate_rust_fixpoint_stages(Names, StageCode),
    format(string(Code), "~w", [StageCode]).

generate_rust_fixpoint_stages(Names, Code) :-
    findall(StageCall,
        ( member(Stage, Names),
          format(string(StageCall),
"        new_records.extend(stage_~w(current.clone()));
", [Stage])
        ),
        StageCalls),
    atomic_list_concat(StageCalls, "", StageCallsCode),
    format(string(Code),
"        let mut new_records: Vec<HashMap<String, Value>> = Vec::new();
~w", [StageCallsCode]).

%% generate_rust_pipeline_panic_fallback(+PipelineName, +FallbackMode, -Code, -MainPipelineName)
%  Generate an optional safe entrypoint around a standard Rust pipeline.
generate_rust_pipeline_panic_fallback(PipelineName, input, Code, SafePipelineName) :-
    !,
    atom_string(PipelineName, PipelineNameStr),
    format(string(SafePipelineNameStr), 'safe_~w', [PipelineNameStr]),
    atom_string(SafePipelineName, SafePipelineNameStr),
    format(string(Code),
"
/// Panic-catching entrypoint for outer fallback.
fn ~w(input: Vec<HashMap<String, Value>>) -> Vec<HashMap<String, Value>> {
    let fallback = input.clone();
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| ~w(input))) {
        Ok(output) => output,
        Err(_) => fallback,
    }
}
", [SafePipelineNameStr, PipelineNameStr]).
generate_rust_pipeline_panic_fallback(PipelineName, _FallbackMode, "", PipelineName).

%% generate_rust_main_block(+PipelineName, +Format, -Code)
%  Generate main execution block
generate_rust_main_block(PipelineName, jsonl, Code) :-
    atom_string(PipelineName, PipelineNameStr),
    format(string(Code),
"fn main() {
    // Read from stdin, process through pipeline, write to stdout
    let input = read_jsonl_stream();
    let output = ~w(input);
    write_jsonl_stream(&output);
}", [PipelineNameStr]).

generate_rust_main_block(PipelineName, json, Code) :-
    atom_string(PipelineName, PipelineNameStr),
    format(string(Code),
"fn main() {
    // Read JSON array from stdin, process through pipeline, write to stdout
    let mut input_str = String::new();
    io::stdin().read_to_string(&mut input_str).expect(\"Failed to read stdin\");
    let input: Vec<HashMap<String, Value>> = serde_json::from_str(&input_str)
        .expect(\"Failed to parse JSON array\");
    let output = ~w(input);
    println!(\"{}\", serde_json::to_string(&output).unwrap());
}", [PipelineNameStr]).

% ============================================================================
% Unit Tests for Rust Pipeline Generator Mode
% ============================================================================

test_rust_pipeline_generator :-
    format("~n=== Rust Pipeline Generator Mode Unit Tests ===~n~n", []),

    % Test 1: Basic pipeline compilation with generator mode
    format("Test 1: Basic pipeline with generator mode... ", []),
    (   compile_rust_pipeline([transform/1, derive/1], [
            pipeline_name(test_pipeline),
            pipeline_mode(generator),
            output_format(jsonl)
        ], Code1),
        sub_string(Code1, _, _, _, "record_key"),
        sub_string(Code1, _, _, _, "while changed"),
        sub_string(Code1, _, _, _, "test_pipeline")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 2: Sequential mode still works
    format("Test 2: Sequential mode still works... ", []),
    (   compile_rust_pipeline([filter/1, format/1], [
            pipeline_name(seq_pipeline),
            pipeline_mode(sequential),
            output_format(jsonl)
        ], Code2),
        sub_string(Code2, _, _, _, "seq_pipeline"),
        sub_string(Code2, _, _, _, "sequential mode"),
        \+ sub_string(Code2, _, _, _, "while changed")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 3: Generator mode includes record_key function
    format("Test 3: Generator mode has record_key function... ", []),
    (   compile_rust_pipeline([a/1], [pipeline_mode(generator)], Code3),
        sub_string(Code3, _, _, _, "fn record_key"),
        sub_string(Code3, _, _, _, "keys.sort()")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 4: JSONL helpers included
    format("Test 4: JSONL helpers included... ", []),
    (   compile_rust_pipeline([x/1], [pipeline_mode(generator)], Code4),
        sub_string(Code4, _, _, _, "read_jsonl_stream"),
        sub_string(Code4, _, _, _, "write_jsonl_stream")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 5: Fixpoint iteration structure
    format("Test 5: Fixpoint iteration structure... ", []),
    (   compile_rust_pipeline([derive/1, transform/1], [pipeline_mode(generator)], Code5),
        sub_string(Code5, _, _, _, "HashSet<String>"),
        sub_string(Code5, _, _, _, "changed = true"),
        sub_string(Code5, _, _, _, "while changed"),
        sub_string(Code5, _, _, _, "total.contains")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 6: Stage functions generated
    format("Test 6: Stage functions generated... ", []),
    (   compile_rust_pipeline([filter/1, transform/1], [pipeline_mode(generator)], Code6),
        sub_string(Code6, _, _, _, "fn stage_filter"),
        sub_string(Code6, _, _, _, "fn stage_transform")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 7: Pipeline chain code for generator
    format("Test 7: Pipeline chain code for generator mode... ", []),
    (   compile_rust_pipeline([derive/1, transform/1], [pipeline_mode(generator)], Code7),
        sub_string(Code7, _, _, _, "let mut new_records: Vec<HashMap<String, Value>> = Vec::new();"),
        sub_string(Code7, _, _, _, "new_records.extend(stage_derive(current.clone()));"),
        sub_string(Code7, _, _, _, "new_records.extend(stage_transform(current.clone()));")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 8: Default options work
    format("Test 8: Default options work... ", []),
    (   compile_rust_pipeline([a/1, b/1], [], Code8),
        sub_string(Code8, _, _, _, "fn pipeline"),
        sub_string(Code8, _, _, _, "sequential mode")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 9: Main block for JSONL format
    format("Test 9: Main block for JSONL format... ", []),
    (   compile_rust_pipeline([x/1], [
            pipeline_name(jsonl_pipe),
            output_format(jsonl)
        ], Code9),
        sub_string(Code9, _, _, _, "fn main()"),
        sub_string(Code9, _, _, _, "read_jsonl_stream()"),
        sub_string(Code9, _, _, _, "jsonl_pipe")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    % Test 10: Use statements for generator mode
    format("Test 10: Use statements for generator mode... ", []),
    (   compile_rust_pipeline([x/1], [pipeline_mode(generator)], Code10),
        sub_string(Code10, _, _, _, "use std::collections::{HashMap, HashSet}"),
        sub_string(Code10, _, _, _, "use serde_json")
    ->  format("PASS~n", [])
    ;   format("FAIL~n", []), fail
    ),

    format("~n=== All Rust Pipeline Generator Mode Tests Passed ===~n", []).

%% ============================================
%% RUST ENHANCED PIPELINE CHAINING
%% ============================================
%
%  Supports advanced flow patterns:
%    - fan_out(Stages)        : Broadcast to stages (sequential execution)
%    - parallel(Stages)       : Execute stages concurrently (see parallel_mode option)
%    - merge                  : Combine results from fan_out or parallel
%    - route_by(Pred, Routes) : Conditional routing
%    - filter_by(Pred)        : Filter records
%    - Pred/Arity             : Standard stage
%
%  Options:
%    - parallel_mode(Mode)    : How to execute parallel stages
%        - std_thread (default): Use std::thread for parallelism (no extra deps)
%        - rayon               : Use rayon crate for parallel iteration (requires rayon dep)
%
%% compile_rust_enhanced_pipeline(+Stages, +Options, -RustCode)
%  Main entry point for enhanced Rust pipeline with advanced flow patterns.
%  Validates pipeline stages before code generation.
%
compile_rust_enhanced_pipeline(Stages, Options, RustCode) :-
    % Validate pipeline stages
    option(validate(Validate), Options, true),
    option(strict(Strict), Options, false),
    ( Validate == true ->
        validate_pipeline(Stages, [strict(Strict)], result(Errors, Warnings)),
        % Report warnings
        ( Warnings \== [] ->
            format(user_error, 'Rust pipeline warnings:~n', []),
            forall(member(W, Warnings), (
                format_validation_warning(W, Msg),
                format(user_error, '  ~w~n', [Msg])
            ))
        ; true
        ),
        % Fail on errors
        ( Errors \== [] ->
            format(user_error, 'Rust pipeline validation errors:~n', []),
            forall(member(E, Errors), (
                format_validation_error(E, Msg),
                format(user_error, '  ~w~n', [Msg])
            )),
            throw(pipeline_validation_failed(Errors))
        ; true
        )
    ; true
    ),

    option(pipeline_name(PipelineName), Options, enhanced_pipeline),
    option(output_format(OutputFormat), Options, jsonl),
    option(parallel_mode(ParallelMode), Options, std_thread),

    % Generate helpers based on parallel mode
    rust_enhanced_helpers(ParallelMode, Helpers),

    % Generate stage functions
    generate_rust_enhanced_stage_functions(Stages, StageFunctions),

    % Generate the main connector
    generate_rust_enhanced_connector(Stages, PipelineName, ConnectorCode),

    % Generate main function
    generate_rust_enhanced_main(PipelineName, OutputFormat, MainCode),

    % Generate imports based on parallel mode
    rust_enhanced_imports(ParallelMode, Imports),

    format(string(RustCode),
"// Generated by UnifyWeaver Rust Enhanced Pipeline
// Supports fan-out, merge, conditional routing, and filtering
~w

type Record = HashMap<String, Value>;

~w

~w
~w
~w
", [Imports, Helpers, StageFunctions, ConnectorCode, MainCode]).

%% rust_enhanced_imports(+ParallelMode, -Imports)
%  Generate imports based on parallel mode
rust_enhanced_imports(std_thread, Imports) :-
    Imports = "use std::collections::HashMap;
use std::io::{self, BufRead, Write};
use serde_json::Value;".
rust_enhanced_imports(rayon, Imports) :-
    Imports = "use std::collections::HashMap;
use std::io::{self, BufRead, Write};
use serde_json::Value;
use rayon::prelude::*;  // Requires: rayon = \"1.8\" in Cargo.toml".

%% rust_enhanced_helpers(+ParallelMode, -Code)
%  Generate helper functions for enhanced pipeline operations.
%  ParallelMode determines which parallel_records implementation to use.
rust_enhanced_helpers(ParallelMode, Code) :-
    rust_common_helpers(CommonHelpers),
    rust_parallel_helper(ParallelMode, ParallelHelper),
    rust_parallel_helper_ordered(ParallelMode, ParallelHelperOrdered),
    format(string(Code), "~w~n~w~n~w", [CommonHelpers, ParallelHelper, ParallelHelperOrdered]).

%% rust_common_helpers(-Code)
%  Helper functions shared between all parallel modes.
rust_common_helpers(Code) :-
    Code = "// Enhanced Pipeline Helpers

/// Fan-out: Send record to all stages, collect all results.
fn fan_out_records<F>(record: &Record, stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
{
    let mut results = Vec::new();
    for stage in stages {
        for result in stage(&[record.clone()]) {
            results.push(result);
        }
    }
    results
}

/// Merge: Combine multiple record slices into one.
fn merge_streams(streams: &[Vec<Record>]) -> Vec<Record> {
    let mut merged = Vec::new();
    for stream in streams {
        merged.extend(stream.clone());
    }
    merged
}

/// Route: Direct record to appropriate stage based on condition.
fn route_record<F, C>(
    record: &Record,
    condition_fn: C,
    route_map: &HashMap<Value, F>,
    default_fn: Option<&F>,
) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
    C: Fn(&Record) -> Value,
{
    let condition = condition_fn(record);
    if let Some(stage) = route_map.get(&condition) {
        stage(&[record.clone()])
    } else if let Some(default) = default_fn {
        default(&[record.clone()])
    } else {
        vec![record.clone()] // Pass through if no matching route
    }
}

/// Filter: Only yield records that satisfy the predicate.
fn filter_records<F>(records: &[Record], predicate_fn: F) -> Vec<Record>
where
    F: Fn(&Record) -> bool,
{
    records.iter()
        .filter(|record| predicate_fn(record))
        .cloned()
        .collect()
}

/// Tee: Send each record to multiple stages and collect all results.
fn tee_stream<F>(records: &[Record], stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
{
    let mut results = Vec::new();
    for record in records {
        for stage in stages {
            results.extend(stage(&[record.clone()]));
        }
    }
    results
}

/// Read JSONL records from stdin.
fn read_jsonl_stream() -> Vec<Record> {
    let stdin = io::stdin();
    let mut records = Vec::new();
    for line in stdin.lock().lines() {
        if let Ok(line) = line {
            if !line.trim().is_empty() {
                if let Ok(value) = serde_json::from_str::<Record>(&line) {
                    records.push(value);
                }
            }
        }
    }
    records
}

/// Write JSONL records to stdout.
fn write_jsonl_stream(records: &[Record]) {
    let stdout = io::stdout();
    let mut handle = stdout.lock();
    for record in records {
        if let Ok(json) = serde_json::to_string(record) {
            writeln!(handle, \"{}\", json).ok();
        }
    }
}

/// Batch: Collect records into batches of specified size.
fn batch_records(records: &[Record], batch_size: usize) -> Vec<Vec<Record>> {
    records.chunks(batch_size)
        .map(|chunk| chunk.to_vec())
        .collect()
}

/// Unbatch: Flatten batches back to individual records.
fn unbatch_records(batches: &[Vec<Record>]) -> Vec<Record> {
    batches.iter()
        .flat_map(|batch| batch.clone())
        .collect()
}

/// Unique: Keep only the first record for each unique field value.
fn unique_by_field(records: &[Record], field: &str) -> Vec<Record> {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    let mut result = Vec::new();
    for record in records {
        if let Some(key) = record.get(field) {
            let key_str = format!(\"{:?}\", key);
            if !seen.contains(&key_str) {
                seen.insert(key_str);
                result.push(record.clone());
            }
        }
    }
    result
}

/// First: Alias for unique_by_field (keeps first occurrence).
fn first_by_field(records: &[Record], field: &str) -> Vec<Record> {
    unique_by_field(records, field)
}

/// Last: Keep only the last record for each unique field value.
fn last_by_field(records: &[Record], field: &str) -> Vec<Record> {
    use std::collections::HashMap;
    let mut last_seen: HashMap<String, Record> = HashMap::new();
    let mut order = Vec::new();
    for record in records {
        if let Some(key) = record.get(field) {
            let key_str = format!(\"{:?}\", key);
            if !last_seen.contains_key(&key_str) {
                order.push(key_str.clone());
            }
            last_seen.insert(key_str, record.clone());
        }
    }
    order.iter().filter_map(|k| last_seen.get(k).cloned()).collect()
}

/// Aggregation type for group_by operations.
#[derive(Clone)]
enum AggType {
    Count,
    Sum(String),
    Avg(String),
    Min(String),
    Max(String),
    First(String),
    Last(String),
    Collect(String),
}

/// Group by field and apply aggregations.
fn group_by_field(records: &[Record], field: &str, aggregations: &[(&str, AggType)]) -> Vec<Record> {
    use std::collections::HashMap;
    let mut groups: HashMap<String, Vec<Record>> = HashMap::new();
    let mut order = Vec::new();

    for record in records {
        if let Some(key) = record.get(field) {
            let key_str = format!(\"{:?}\", key);
            if !groups.contains_key(&key_str) {
                order.push((key_str.clone(), key.clone()));
            }
            groups.entry(key_str).or_insert_with(Vec::new).push(record.clone());
        }
    }

    let mut result = Vec::new();
    for (key_str, key_val) in order {
        if let Some(group_records) = groups.get(&key_str) {
            let mut result_record = Record::new();
            result_record.insert(field.to_string(), key_val);

            for (name, agg) in aggregations {
                let value: Value = match agg {
                    AggType::Count => Value::from(group_records.len() as i64),
                    AggType::Sum(f) => {
                        let sum: f64 = group_records.iter()
                            .filter_map(|r| r.get(f).and_then(|v| v.as_f64()))
                            .sum();
                        Value::from(sum)
                    }
                    AggType::Avg(f) => {
                        let values: Vec<f64> = group_records.iter()
                            .filter_map(|r| r.get(f).and_then(|v| v.as_f64()))
                            .collect();
                        let avg = if values.is_empty() { 0.0 } else { values.iter().sum::<f64>() / values.len() as f64 };
                        Value::from(avg)
                    }
                    AggType::Min(f) => {
                        group_records.iter()
                            .filter_map(|r| r.get(f).and_then(|v| v.as_f64()))
                            .fold(f64::INFINITY, f64::min)
                            .into()
                    }
                    AggType::Max(f) => {
                        group_records.iter()
                            .filter_map(|r| r.get(f).and_then(|v| v.as_f64()))
                            .fold(f64::NEG_INFINITY, f64::max)
                            .into()
                    }
                    AggType::First(f) => {
                        group_records.first().and_then(|r| r.get(f)).cloned().unwrap_or(Value::Null)
                    }
                    AggType::Last(f) => {
                        group_records.last().and_then(|r| r.get(f)).cloned().unwrap_or(Value::Null)
                    }
                    AggType::Collect(f) => {
                        let values: Vec<Value> = group_records.iter()
                            .filter_map(|r| r.get(f).cloned())
                            .collect();
                        Value::from(values)
                    }
                };
                result_record.insert(name.to_string(), value);
            }
            result.push(result_record);
        }
    }
    result
}

/// Reduce: Apply reducer function sequentially across all records.
fn reduce_records<F>(records: &[Record], reducer: F, initial: Value) -> Vec<Record>
where
    F: Fn(&Record, Value) -> Value,
{
    let mut acc = initial;
    for record in records {
        acc = reducer(record, acc);
    }
    let mut result = Record::new();
    result.insert(\"result\".to_string(), acc);
    vec![result]
}

/// Scan: Like reduce but yields intermediate results.
fn scan_records<F>(records: &[Record], reducer: F, initial: Value) -> Vec<Record>
where
    F: Fn(&Record, Value) -> Value,
{
    let mut result = Vec::new();
    let mut acc = initial;
    for record in records {
        acc = reducer(record, acc);
        let mut r = Record::new();
        r.insert(\"result\".to_string(), acc.clone());
        result.push(r);
    }
    result
}

/// Order by single field with direction.
fn order_by_field(records: &[Record], field: &str, direction: &str) -> Vec<Record> {
    let mut result: Vec<Record> = records.to_vec();
    result.sort_by(|a, b| {
        let va = a.get(field);
        let vb = b.get(field);
        let cmp = compare_values(va, vb);
        if direction == \"desc\" {
            cmp.reverse()
        } else {
            cmp
        }
    });
    result
}

/// Field specification for multi-field ordering.
struct FieldSpec {
    field: String,
    direction: String,
}

/// Order by multiple fields.
fn order_by_fields(records: &[Record], field_specs: &[FieldSpec]) -> Vec<Record> {
    let mut result: Vec<Record> = records.to_vec();
    result.sort_by(|a, b| {
        for spec in field_specs {
            let va = a.get(&spec.field);
            let vb = b.get(&spec.field);
            let cmp = compare_values(va, vb);
            let cmp = if spec.direction == \"desc\" { cmp.reverse() } else { cmp };
            if cmp != std::cmp::Ordering::Equal {
                return cmp;
            }
        }
        std::cmp::Ordering::Equal
    });
    result
}

/// Compare two optional JSON values.
fn compare_values(a: Option<&Value>, b: Option<&Value>) -> std::cmp::Ordering {
    use std::cmp::Ordering;
    match (a, b) {
        (None, None) => Ordering::Equal,
        (None, Some(_)) => Ordering::Greater,  // None sorts to end
        (Some(_), None) => Ordering::Less,
        (Some(va), Some(vb)) => {
            // Compare by type
            match (va, vb) {
                (Value::Number(na), Value::Number(nb)) => {
                    let fa = na.as_f64().unwrap_or(0.0);
                    let fb = nb.as_f64().unwrap_or(0.0);
                    fa.partial_cmp(&fb).unwrap_or(Ordering::Equal)
                }
                (Value::String(sa), Value::String(sb)) => sa.cmp(sb),
                _ => {
                    // Fallback: compare string representations
                    let sa = format!(\"{:?}\", va);
                    let sb = format!(\"{:?}\", vb);
                    sa.cmp(&sb)
                }
            }
        }
    }
}

/// Sort by custom comparator function.
fn sort_by_comparator<F>(records: &[Record], comparator: F) -> Vec<Record>
where
    F: Fn(&Record, &Record) -> std::cmp::Ordering,
{
    let mut result: Vec<Record> = records.to_vec();
    result.sort_by(|a, b| comparator(a, b));
    result
}

// Error Handling Stage Helpers

/// Type alias for stage functions
type StageFunc = fn(&[Record]) -> Result<Vec<Record>, Box<dyn std::error::Error>>;
type ErrorHandlerFunc = fn(&[Record], &dyn std::error::Error) -> Vec<Record>;

/// Try-catch: Execute stage, on error route to handler.
fn try_catch_stage(
    records: &[Record],
    stage: StageFunc,
    handler: ErrorHandlerFunc,
) -> Vec<Record> {
    let mut result = Vec::new();
    for record in records {
        match stage(&[record.clone()]) {
            Ok(results) => result.extend(results),
            Err(e) => {
                let handler_results = handler(&[record.clone()], e.as_ref());
                result.extend(handler_results);
            }
        }
    }
    result
}

/// Retry: Retry stage up to max_retries times on failure.
fn retry_stage(
    records: &[Record],
    stage: StageFunc,
    max_retries: usize,
    delay_ms: u64,
    backoff: &str,
) -> Vec<Record> {
    let mut result = Vec::new();
    for record in records {
        let mut last_error: Option<String> = None;
        for attempt in 0..=max_retries {
            match stage(&[record.clone()]) {
                Ok(results) => {
                    result.extend(results);
                    last_error = None;
                    break;
                }
                Err(e) => {
                    last_error = Some(e.to_string());
                    if attempt < max_retries && delay_ms > 0 {
                        let wait_time = match backoff {
                            \"exponential\" => delay_ms * (1 << attempt),
                            \"linear\" => delay_ms * (attempt as u64 + 1),
                            _ => delay_ms,
                        };
                        std::thread::sleep(std::time::Duration::from_millis(wait_time));
                    }
                }
            }
        }
        // If all retries exhausted, add error record
        if let Some(err) = last_error {
            let mut error_record = Record::new();
            error_record.insert(\"_error\".to_string(), Value::String(err));
            error_record.insert(\"_record\".to_string(), serde_json::to_value(record).unwrap_or(Value::Null));
            error_record.insert(\"_retries\".to_string(), Value::Number(max_retries.into()));
            result.push(error_record);
        }
    }
    result
}

/// On-error: Global error handler wrapping.
fn on_error_stage(records: &[Record], _handler: ErrorHandlerFunc) -> Vec<Record> {
    // In Rust, we pass records through - errors are handled at stage level
    records.to_vec()
}

/// Timeout: Execute stage with time limit.
fn timeout_stage(
    records: &[Record],
    stage: StageFunc,
    timeout_ms: u64,
) -> Vec<Record> {
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    let mut result = Vec::new();
    for record in records {
        let record_clone = record.clone();
        let (tx, rx) = mpsc::channel();

        thread::spawn(move || {
            let stage_result = stage(&[record_clone]);
            let _ = tx.send(stage_result);
        });

        match rx.recv_timeout(Duration::from_millis(timeout_ms)) {
            Ok(Ok(results)) => result.extend(results),
            Ok(Err(_)) | Err(_) => {
                // Timeout or error occurred
                let mut timeout_record = Record::new();
                timeout_record.insert(\"_timeout\".to_string(), Value::Bool(true));
                timeout_record.insert(\"_record\".to_string(), serde_json::to_value(record).unwrap_or(Value::Null));
                timeout_record.insert(\"_limit_ms\".to_string(), Value::Number(timeout_ms.into()));
                result.push(timeout_record);
            }
        }
    }
    result
}

/// Timeout with fallback: Execute stage with time limit, use fallback on timeout.
fn timeout_stage_with_fallback<F>(
    records: &[Record],
    stage: StageFunc,
    timeout_ms: u64,
    fallback: F,
) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
{
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    let mut result = Vec::new();
    for record in records {
        let record_clone = record.clone();
        let (tx, rx) = mpsc::channel();

        thread::spawn(move || {
            let stage_result = stage(&[record_clone]);
            let _ = tx.send(stage_result);
        });

        match rx.recv_timeout(Duration::from_millis(timeout_ms)) {
            Ok(Ok(results)) => result.extend(results),
            Ok(Err(_)) | Err(_) => {
                // Timeout or error occurred, use fallback
                let fallback_results = fallback(&[record.clone()]);
                result.extend(fallback_results);
            }
        }
    }
    result
}

/// Rate limit: Limit throughput to count records per interval.
fn rate_limit_stage(records: &[Record], count: usize, interval_ms: u64) -> Vec<Record> {
    use std::time::{Duration, Instant};
    use std::thread;

    let mut result = Vec::new();
    let interval = Duration::from_millis(interval_ms) / count as u32;
    let mut last_time: Option<Instant> = None;

    for record in records {
        if let Some(last) = last_time {
            let elapsed = last.elapsed();
            if elapsed < interval {
                thread::sleep(interval - elapsed);
            }
        }
        last_time = Some(Instant::now());
        result.push(record.clone());
    }
    result
}

/// Throttle: Add fixed delay between records.
fn throttle_stage(records: &[Record], delay_ms: u64) -> Vec<Record> {
    use std::time::Duration;
    use std::thread;

    let mut result = Vec::new();
    let delay = Duration::from_millis(delay_ms);

    for (i, record) in records.iter().enumerate() {
        if i > 0 {
            thread::sleep(delay);
        }
        result.push(record.clone());
    }
    result
}

/// Buffer: Collect records into batches of specified size.
fn buffer_stage(records: &[Record], size: usize) -> Vec<Vec<Record>> {
    let mut result = Vec::new();
    let mut buffer = Vec::new();

    for record in records {
        buffer.push(record.clone());
        if buffer.len() >= size {
            result.push(buffer);
            buffer = Vec::new();
        }
    }
    if !buffer.is_empty() {
        result.push(buffer);
    }
    result
}

/// Debounce: Emit record only after quiet period.
fn debounce_stage(records: &[Record], delay_ms: u64) -> Vec<Record> {
    use std::time::Duration;
    use std::thread;

    if records.is_empty() {
        return Vec::new();
    }

    let delay = Duration::from_millis(delay_ms);
    let last_record = records.last().unwrap().clone();
    thread::sleep(delay);
    vec![last_record]
}

/// Zip: Run multiple stage functions and combine results.
fn zip_stage<F>(records: &[Record], stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
{
    let mut result = Vec::new();
    for record in records {
        let mut stage_results: Vec<Vec<Record>> = Vec::new();
        let mut max_len = 0;
        for stage in stages {
            let res = stage(&[record.clone()]);
            if res.len() > max_len {
                max_len = res.len();
            }
            stage_results.push(res);
        }
        for i in 0..max_len {
            let mut combined = Record::new();
            for res_list in &stage_results {
                if i < res_list.len() {
                    for (k, v) in &res_list[i] {
                        combined.insert(k.clone(), v.clone());
                    }
                }
            }
            result.push(combined);
        }
    }
    result
}

/// Window: Collect records into non-overlapping windows.
fn window_stage(records: &[Record], size: usize) -> Vec<Vec<Record>> {
    let mut result = Vec::new();
    let mut window = Vec::new();
    for record in records {
        window.push(record.clone());
        if window.len() >= size {
            result.push(window);
            window = Vec::new();
        }
    }
    if !window.is_empty() {
        result.push(window);
    }
    result
}

/// Sliding Window: Create sliding windows of records.
fn sliding_window_stage(records: &[Record], size: usize, step: usize) -> Vec<Vec<Record>> {
    let mut result = Vec::new();
    let mut buffer = Vec::new();
    for record in records {
        buffer.push(record.clone());
        while buffer.len() >= size {
            let window: Vec<Record> = buffer[..size].to_vec();
            result.push(window);
            buffer = buffer[step..].to_vec();
        }
    }
    if !buffer.is_empty() {
        result.push(buffer);
    }
    result
}

/// Sample: Randomly sample n records using reservoir sampling.
fn sample_stage(records: &[Record], n: usize) -> Vec<Record> {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    let mut reservoir = Vec::with_capacity(n);
    for (i, record) in records.iter().enumerate() {
        if i < n {
            reservoir.push(record.clone());
        } else {
            let j = rng.gen_range(0..=i);
            if j < n {
                reservoir[j] = record.clone();
            }
        }
    }
    reservoir
}

/// Take Every: Take every nth record.
fn take_every_stage(records: &[Record], n: usize) -> Vec<Record> {
    records.iter().enumerate()
        .filter(|(i, _)| i % n == 0)
        .map(|(_, r)| r.clone())
        .collect()
}

/// Partition: Split records into matches and non-matches.
fn partition_stage<F>(records: &[Record], pred: F) -> (Vec<Record>, Vec<Record>)
where
    F: Fn(&Record) -> bool,
{
    let mut matches = Vec::new();
    let mut non_matches = Vec::new();
    for record in records {
        if pred(record) {
            matches.push(record.clone());
        } else {
            non_matches.push(record.clone());
        }
    }
    (matches, non_matches)
}

/// Take: Take first n records.
fn take_stage(records: &[Record], n: usize) -> Vec<Record> {
    records.iter().take(n).cloned().collect()
}

/// Skip: Skip first n records.
fn skip_stage(records: &[Record], n: usize) -> Vec<Record> {
    records.iter().skip(n).cloned().collect()
}

/// Take While: Take records while predicate is true.
fn take_while_stage<F>(records: &[Record], pred: F) -> Vec<Record>
where
    F: Fn(&Record) -> bool,
{
    records.iter().take_while(|r| pred(r)).cloned().collect()
}

/// Skip While: Skip records while predicate is true.
fn skip_while_stage<F>(records: &[Record], pred: F) -> Vec<Record>
where
    F: Fn(&Record) -> bool,
{
    records.iter().skip_while(|r| pred(r)).cloned().collect()
}

/// Distinct: Remove all duplicate records (global dedup).
fn distinct_stage(records: &[Record]) -> Vec<Record> {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    let mut result = Vec::new();
    for record in records {
        let key = record_key(record);
        if !seen.contains(&key) {
            seen.insert(key);
            result.push(record.clone());
        }
    }
    result
}

/// Distinct By: Remove duplicates based on a specific field.
fn distinct_by_stage(records: &[Record], field: &str) -> Vec<Record> {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    let mut result = Vec::new();
    for record in records {
        let key = format!(\"{:?}\", record.get(field));
        if !seen.contains(&key) {
            seen.insert(key);
            result.push(record.clone());
        }
    }
    result
}

/// Dedup: Remove consecutive duplicate records.
fn dedup_stage(records: &[Record]) -> Vec<Record> {
    let mut result = Vec::new();
    let mut last_key: Option<String> = None;
    for record in records {
        let key = record_key(record);
        if last_key.as_ref() != Some(&key) {
            last_key = Some(key);
            result.push(record.clone());
        }
    }
    result
}

/// Dedup By: Remove consecutive duplicates based on a specific field.
fn dedup_by_stage(records: &[Record], field: &str) -> Vec<Record> {
    let mut result = Vec::new();
    let mut last_value: Option<String> = None;
    for record in records {
        let value = format!(\"{:?}\", record.get(field));
        if last_value.as_ref() != Some(&value) {
            last_value = Some(value);
            result.push(record.clone());
        }
    }
    result
}

/// Generate a unique key for a record (for dedup comparison).
fn record_key(record: &Record) -> String {
    let mut keys: Vec<&String> = record.keys().collect();
    keys.sort();
    keys.iter()
        .map(|k| format!(\"{}={:?}\", k, record.get(*k)))
        .collect::<Vec<_>>()
        .join(\",\")
}

/// Interleave: Round-robin interleave records from multiple streams.
fn interleave_stage(streams: &[Vec<Record>]) -> Vec<Record> {
    if streams.is_empty() {
        return Vec::new();
    }
    let mut result = Vec::new();
    let max_len = streams.iter().map(|s| s.len()).max().unwrap_or(0);
    for i in 0..max_len {
        for stream in streams {
            if i < stream.len() {
                result.push(stream[i].clone());
            }
        }
    }
    result
}

/// Concat: Concatenate multiple streams sequentially.
fn concat_stage(streams: &[Vec<Record>]) -> Vec<Record> {
    let mut result = Vec::new();
    for stream in streams {
        result.extend(stream.iter().cloned());
    }
    result
}

/// Merge Sorted: Merge multiple pre-sorted streams maintaining sort order.
/// Uses a k-way merge algorithm for efficiency.
fn merge_sorted_stage(streams: &[Vec<Record>], field: &str, ascending: bool) -> Vec<Record> {
    use std::cmp::Ordering;

    if streams.is_empty() {
        return Vec::new();
    }

    // Track current index in each stream
    let mut indices: Vec<usize> = vec![0; streams.len()];
    let mut result = Vec::new();

    loop {
        // Find the stream with the best (smallest/largest) next value
        let mut best_stream: Option<usize> = None;
        let mut best_value: Option<&serde_json::Value> = None;

        for (i, stream) in streams.iter().enumerate() {
            if indices[i] >= stream.len() {
                continue; // This stream is exhausted
            }

            let value = stream[indices[i]].get(field);
            if best_stream.is_none() {
                best_stream = Some(i);
                best_value = value;
                continue;
            }

            // Compare values
            let is_better = match (value, best_value) {
                (Some(serde_json::Value::Number(v)), Some(serde_json::Value::Number(bv))) => {
                    let v_f = v.as_f64().unwrap_or(0.0);
                    let bv_f = bv.as_f64().unwrap_or(0.0);
                    if ascending { v_f < bv_f } else { v_f > bv_f }
                }
                (Some(serde_json::Value::String(v)), Some(serde_json::Value::String(bv))) => {
                    if ascending { v < bv } else { v > bv }
                }
                _ => false,
            };

            if is_better {
                best_stream = Some(i);
                best_value = value;
            }
        }

        match best_stream {
            Some(idx) => {
                result.push(streams[idx][indices[idx]].clone());
                indices[idx] += 1;
            }
            None => break, // All streams exhausted
        }
    }

    result
}

/// Tap: Execute a side effect for each record without modifying the stream.
/// Useful for logging, metrics, debugging, or other observations.
fn tap_stage<F>(records: &[Record], side_effect: F) -> Vec<Record>
where
    F: Fn(&Record),
{
    for record in records {
        // Use catch_unwind to prevent side effect errors from interrupting pipeline
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            side_effect(record);
        }));
    }
    records.to_vec()
}

/// Flatten: Flatten nested collections into individual records.
/// If a record contains an \"__items__\" key with an array, yields each item.
fn flatten_stage(records: &[Record]) -> Vec<Record> {
    let mut result = Vec::new();
    for record in records {
        if let Some(serde_json::Value::Array(items)) = record.get(\"__items__\") {
            for item in items {
                if let serde_json::Value::Object(map) = item {
                    result.push(map.clone());
                }
            }
        } else {
            result.push(record.clone());
        }
    }
    result
}

/// Flatten Field: Flatten a specific field within each record.
/// Expands records where field contains an array into multiple records.
fn flatten_field_stage(records: &[Record], field: &str) -> Vec<Record> {
    let mut result = Vec::new();
    for record in records {
        if let Some(serde_json::Value::Array(items)) = record.get(field) {
            for item in items {
                let mut new_record = record.clone();
                new_record.insert(field.to_string(), item.clone());
                result.push(new_record);
            }
        } else {
            result.push(record.clone());
        }
    }
    result
}

/// Debounce: Emit records only after a silence period.
/// Groups records by time windows and emits the last record in each window.
fn debounce_stage(records: &[Record], ms: u64, timestamp_field: Option<&str>) -> Vec<Record> {
    use std::time::{SystemTime, UNIX_EPOCH};

    if records.is_empty() {
        return Vec::new();
    }

    let mut result = Vec::new();
    let mut buffer: Option<Record> = None;
    let mut last_time: Option<f64> = None;
    let threshold_sec = ms as f64 / 1000.0;

    for record in records {
        let current_time = if let Some(field) = timestamp_field {
            if let Some(ts) = record.get(field) {
                match ts {
                    serde_json::Value::Number(n) => n.as_f64().unwrap_or_else(|| {
                        SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()
                    }),
                    _ => SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64(),
                }
            } else {
                SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()
            }
        } else {
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()
        };

        match last_time {
            None => {
                buffer = Some(record.clone());
                last_time = Some(current_time);
            }
            Some(lt) if current_time - lt < threshold_sec => {
                // Within debounce window, replace buffer
                buffer = Some(record.clone());
                last_time = Some(current_time);
            }
            Some(_) => {
                // Silence period exceeded, emit buffered and start new
                if let Some(buf) = buffer.take() {
                    result.push(buf);
                }
                buffer = Some(record.clone());
                last_time = Some(current_time);
            }
        }
    }

    // Emit final buffered record
    if let Some(buf) = buffer {
        result.push(buf);
    }

    result
}

/// Branch: Conditional routing within pipeline.
/// Records matching condition go through true_fn, others through false_fn.
fn branch_stage<F, T, E>(
    records: &[Record],
    cond_fn: F,
    true_fn: T,
    false_fn: E,
) -> Vec<Record>
where
    F: Fn(&Record) -> bool,
    T: Fn(&[Record]) -> Vec<Record>,
    E: Fn(&[Record]) -> Vec<Record>,
{
    let (true_records, false_records): (Vec<_>, Vec<_>) =
        records.iter().cloned().partition(|r| cond_fn(r));

    let mut result = Vec::new();
    if !true_records.is_empty() {
        result.extend(true_fn(&true_records));
    }
    if !false_records.is_empty() {
        result.extend(false_fn(&false_records));
    }
    result
}

/// Tee: Run side stage on records, discard results, return original records.
/// Like Unix tee - fork to side destination while main stream continues.
fn tee_stage<F>(records: &[Record], side_fn: F) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record>,
{
    // Run side stage (results discarded)
    let _ = side_fn(records);

    // Return original records unchanged
    records.to_vec()
}

// ============================================
// SERVICE INFRASTRUCTURE (Client-Server Phase 1)
// ============================================

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::error::Error;
use std::fmt;

/// ServiceError represents an error from a service call.
#[derive(Debug, Clone)]
pub struct ServiceError {
    pub service: String,
    pub message: String,
}

impl fmt::Display for ServiceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, \"service {}: {}\", self.service, self.message)
    }
}

impl Error for ServiceError {}

/// Service trait for in-process services.
pub trait Service: Send + Sync {
    fn name(&self) -> &str;
    fn call(&self, request: serde_json::Value) -> Result<serde_json::Value, ServiceError>;
}

/// StatefulService provides state management for services.
pub struct StatefulService {
    name: String,
    state: RwLock<HashMap<String, serde_json::Value>>,
}

impl StatefulService {
    pub fn new(name: &str) -> Self {
        StatefulService {
            name: name.to_string(),
            state: RwLock::new(HashMap::new()),
        }
    }

    pub fn state_get(&self, key: &str) -> Option<serde_json::Value> {
        self.state.read().ok()?.get(key).cloned()
    }

    pub fn state_put(&self, key: &str, value: serde_json::Value) {
        if let Ok(mut state) = self.state.write() {
            state.insert(key.to_string(), value);
        }
    }

    pub fn state_modify<F>(&self, key: &str, f: F)
    where
        F: FnOnce(Option<serde_json::Value>) -> serde_json::Value,
    {
        if let Ok(mut state) = self.state.write() {
            let current = state.get(key).cloned();
            state.insert(key.to_string(), f(current));
        }
    }

    pub fn state_delete(&self, key: &str) {
        if let Ok(mut state) = self.state.write() {
            state.remove(key);
        }
    }
}

/// Global service registry (lazy initialized)
lazy_static::lazy_static! {
    static ref SERVICES: RwLock<HashMap<String, Arc<dyn Service>>> = RwLock::new(HashMap::new());
}

/// Register a service in the global registry.
pub fn register_service(name: &str, service: Arc<dyn Service>) {
    if let Ok(mut services) = SERVICES.write() {
        services.insert(name.to_string(), service);
    }
}

/// Get a service from the registry.
pub fn get_service(name: &str) -> Result<Arc<dyn Service>, ServiceError> {
    let services = SERVICES.read().map_err(|_| ServiceError {
        service: name.to_string(),
        message: \"failed to acquire service registry lock\".to_string(),
    })?;
    services.get(name).cloned().ok_or(ServiceError {
        service: name.to_string(),
        message: \"service not found\".to_string(),
    })
}

/// Options for service calls.
#[derive(Default, Clone)]
pub struct CallServiceOptions {
    pub timeout_ms: Option<u64>,
    pub retry: u32,
    pub retry_delay_ms: u64,
    pub fallback: Option<serde_json::Value>,
}

/// Call a service with options.
pub fn call_service_impl(
    service_name: &str,
    request: serde_json::Value,
    options: &CallServiceOptions,
) -> Result<serde_json::Value, ServiceError> {
    let service = get_service(service_name)?;

    let mut last_error = None;
    for attempt in 0..=options.retry {
        match service.call(request.clone()) {
            Ok(result) => return Ok(result),
            Err(e) => {
                last_error = Some(e);
                if attempt < options.retry && options.retry_delay_ms > 0 {
                    std::thread::sleep(std::time::Duration::from_millis(options.retry_delay_ms));
                }
            }
        }
    }

    if let Some(fallback) = &options.fallback {
        return Ok(fallback.clone());
    }

    Err(last_error.unwrap_or(ServiceError {
        service: service_name.to_string(),
        message: \"service call failed\".to_string(),
    }))
}

/// Pipeline stage that calls a service for each record.
fn call_service_stage(
    records: &[Record],
    service_name: &str,
    request_field: &str,
    response_field: &str,
    options: &CallServiceOptions,
) -> Vec<Record> {
    records
        .iter()
        .map(|record| {
            let mut record = record.clone();
            let request = record.get(request_field).cloned().unwrap_or(serde_json::Value::Null);
            match call_service_impl(service_name, request, options) {
                Ok(response) => {
                    record.insert(response_field.to_string(), response);
                }
                Err(e) => {
                    record.insert(\"__error__\".to_string(), serde_json::json!(true));
                    record.insert(\"__type__\".to_string(), serde_json::json!(\"ServiceError\"));
                    record.insert(\"__message__\".to_string(), serde_json::json!(e.message));
                }
            }
            record
        })
        .collect()
}
".

%% rust_parallel_helper(+ParallelMode, -Code)
%  Generate parallel_records helper based on mode.

% std_thread mode: Use std::thread for parallelism (no extra dependencies)
rust_parallel_helper(std_thread, Code) :-
    Code = "
/// Parallel: Execute stages concurrently using std::thread.
/// Each stage receives the same input record.
/// Results are collected after all threads complete.
fn parallel_records<F>(record: &Record, stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record> + Send + Sync,
{
    use std::sync::{Arc, Mutex};
    use std::thread;

    let record = Arc::new(record.clone());
    let results = Arc::new(Mutex::new(Vec::new()));
    let handles: Vec<_> = stages
        .iter()
        .map(|stage| {
            let record_clone = Arc::clone(&record);
            let results_clone = Arc::clone(&results);
            let stage_results = stage(&[(*record_clone).clone()]);
            thread::spawn(move || {
                let mut results = results_clone.lock().unwrap();
                results.extend(stage_results);
            })
        })
        .collect();

    for handle in handles {
        handle.join().ok();
    }

    Arc::try_unwrap(results)
        .unwrap_or_else(|arc| (*arc.lock().unwrap()).clone())
        .into_inner()
        .unwrap_or_default()
}
".

% rayon mode: Use rayon crate for parallel iteration (requires rayon dependency)
rust_parallel_helper(rayon, Code) :-
    Code = "
/// Parallel: Execute stages concurrently using rayon parallel iterators.
/// Each stage receives the same input record.
/// Results are collected after all stages complete.
/// Requires: rayon = \"1.8\" in Cargo.toml
fn parallel_records<F>(record: &Record, stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record> + Send + Sync,
{
    stages
        .par_iter()
        .flat_map(|stage| stage(&[record.clone()]))
        .collect()
}
".

%% rust_parallel_helper_ordered(+ParallelMode, -Code) is det.
%  Generate parallel_records_ordered helper based on mode (preserves stage order).

% std_thread mode: Use std::thread with indexed results
rust_parallel_helper_ordered(std_thread, Code) :-
    Code = "
/// Parallel (Ordered): Execute stages concurrently, preserve input order.
/// Each stage receives the same input record.
/// Results are returned in stage definition order.
fn parallel_records_ordered<F>(record: &Record, stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record> + Send + Sync,
{
    use std::sync::{Arc, Mutex};
    use std::thread;

    let record = Arc::new(record.clone());
    let indexed_results: Arc<Mutex<Vec<Option<Vec<Record>>>>> =
        Arc::new(Mutex::new(vec![None; stages.len()]));

    let handles: Vec<_> = stages
        .iter()
        .enumerate()
        .map(|(idx, stage)| {
            let record_clone = Arc::clone(&record);
            let results_clone = Arc::clone(&indexed_results);
            let stage_results = stage(&[(*record_clone).clone()]);
            thread::spawn(move || {
                let mut results = results_clone.lock().unwrap();
                results[idx] = Some(stage_results);
            })
        })
        .collect();

    for handle in handles {
        handle.join().ok();
    }

    // Flatten results in order
    Arc::try_unwrap(indexed_results)
        .unwrap_or_else(|arc| (*arc.lock().unwrap()).clone())
        .into_inner()
        .unwrap_or_default()
        .into_iter()
        .flatten()
        .flatten()
        .collect()
}
".

% rayon mode: Use rayon with indexed collection
rust_parallel_helper_ordered(rayon, Code) :-
    Code = "
/// Parallel (Ordered): Execute stages concurrently, preserve input order.
/// Each stage receives the same input record.
/// Results are returned in stage definition order.
/// Requires: rayon = \"1.8\" in Cargo.toml
fn parallel_records_ordered<F>(record: &Record, stages: &[F]) -> Vec<Record>
where
    F: Fn(&[Record]) -> Vec<Record> + Send + Sync,
{
    // Execute in parallel but collect with indices
    let indexed_results: Vec<(usize, Vec<Record>)> = stages
        .par_iter()
        .enumerate()
        .map(|(idx, stage)| (idx, stage(&[record.clone()])))
        .collect();

    // Sort by index and flatten
    let mut sorted = indexed_results;
    sorted.sort_by_key(|(idx, _)| *idx);
    sorted.into_iter().flat_map(|(_, results)| results).collect()
}
".

%% generate_rust_enhanced_stage_functions(+Stages, -Code)
%  Generate stub functions for each stage.
generate_rust_enhanced_stage_functions([], "").
generate_rust_enhanced_stage_functions([Stage|Rest], Code) :-
    generate_rust_single_enhanced_stage(Stage, StageCode),
    generate_rust_enhanced_stage_functions(Rest, RestCode),
    (RestCode = "" ->
        Code = StageCode
    ;   format(string(Code), "~w~n~w", [StageCode, RestCode])
    ).

generate_rust_single_enhanced_stage(fan_out(SubStages), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(parallel(SubStages, _Options), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(parallel(SubStages), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(merge, "") :- !.
generate_rust_single_enhanced_stage(route_by(_, Routes), Code) :-
    !,
    findall(Stage, member((_Cond, Stage), Routes), RouteStages),
    generate_rust_enhanced_stage_functions(RouteStages, Code).
generate_rust_single_enhanced_stage(filter_by(_), "") :- !.
generate_rust_single_enhanced_stage(batch(_), "") :- !.
generate_rust_single_enhanced_stage(unbatch, "") :- !.
generate_rust_single_enhanced_stage(unique(_), "") :- !.
generate_rust_single_enhanced_stage(first(_), "") :- !.
generate_rust_single_enhanced_stage(last(_), "") :- !.
generate_rust_single_enhanced_stage(group_by(_, _), "") :- !.
generate_rust_single_enhanced_stage(reduce(_, _), "") :- !.
generate_rust_single_enhanced_stage(reduce(_), "") :- !.
generate_rust_single_enhanced_stage(scan(_, _), "") :- !.
generate_rust_single_enhanced_stage(scan(_), "") :- !.
generate_rust_single_enhanced_stage(order_by(_), "") :- !.
generate_rust_single_enhanced_stage(order_by(_, _), "") :- !.
generate_rust_single_enhanced_stage(sort_by(_), "") :- !.
generate_rust_single_enhanced_stage(try_catch(Stage, Handler), Code) :-
    !,
    generate_rust_single_enhanced_stage(Stage, StageCode),
    generate_rust_single_enhanced_stage(Handler, HandlerCode),
    format(string(Code), "~w~w", [StageCode, HandlerCode]).
generate_rust_single_enhanced_stage(retry(Stage, _), Code) :-
    !,
    generate_rust_single_enhanced_stage(Stage, Code).
generate_rust_single_enhanced_stage(retry(Stage, _, _), Code) :-
    !,
    generate_rust_single_enhanced_stage(Stage, Code).
generate_rust_single_enhanced_stage(on_error(Handler), Code) :-
    !,
    generate_rust_single_enhanced_stage(Handler, Code).
generate_rust_single_enhanced_stage(timeout(Stage, _), Code) :-
    !,
    generate_rust_single_enhanced_stage(Stage, Code).
generate_rust_single_enhanced_stage(timeout(Stage, _, Fallback), Code) :-
    !,
    generate_rust_single_enhanced_stage(Stage, StageCode),
    generate_rust_single_enhanced_stage(Fallback, FallbackCode),
    format(string(Code), "~w~w", [StageCode, FallbackCode]).
generate_rust_single_enhanced_stage(rate_limit(_, _), "") :- !.
generate_rust_single_enhanced_stage(throttle(_), "") :- !.
generate_rust_single_enhanced_stage(buffer(_), "") :- !.
generate_rust_single_enhanced_stage(debounce(_), "") :- !.
generate_rust_single_enhanced_stage(zip(SubStages), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(window(_), "") :- !.
generate_rust_single_enhanced_stage(sliding_window(_, _), "") :- !.
generate_rust_single_enhanced_stage(sample(_), "") :- !.
generate_rust_single_enhanced_stage(take_every(_), "") :- !.
generate_rust_single_enhanced_stage(partition(_), "") :- !.
generate_rust_single_enhanced_stage(take(_), "") :- !.
generate_rust_single_enhanced_stage(skip(_), "") :- !.
generate_rust_single_enhanced_stage(take_while(_), "") :- !.
generate_rust_single_enhanced_stage(skip_while(_), "") :- !.
generate_rust_single_enhanced_stage(distinct, "") :- !.
generate_rust_single_enhanced_stage(distinct_by(_), "") :- !.
generate_rust_single_enhanced_stage(dedup, "") :- !.
generate_rust_single_enhanced_stage(dedup_by(_), "") :- !.
generate_rust_single_enhanced_stage(interleave(SubStages), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(concat(SubStages), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(merge_sorted(SubStages, _Field), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(merge_sorted(SubStages, _Field, _Dir), Code) :-
    !,
    generate_rust_enhanced_stage_functions(SubStages, Code).
generate_rust_single_enhanced_stage(tap(_), "") :- !.
generate_rust_single_enhanced_stage(flatten, "") :- !.
generate_rust_single_enhanced_stage(flatten(_), "") :- !.
generate_rust_single_enhanced_stage(debounce(_), "") :- !.
generate_rust_single_enhanced_stage(debounce(_, _), "") :- !.
generate_rust_single_enhanced_stage(branch(_Cond, TrueStage, FalseStage), Code) :-
    !,
    generate_rust_single_enhanced_stage(TrueStage, TrueCode),
    generate_rust_single_enhanced_stage(FalseStage, FalseCode),
    format(string(Code), "~w~w", [TrueCode, FalseCode]).
generate_rust_single_enhanced_stage(tee(SideStage), Code) :-
    !,
    generate_rust_single_enhanced_stage(SideStage, Code).
generate_rust_single_enhanced_stage(call_service(_, _, _), "") :- !.
generate_rust_single_enhanced_stage(call_service(_, _, _, _), "") :- !.
generate_rust_single_enhanced_stage(Pred/Arity, Code) :-
    !,
    format(string(Code),
"/// Pipeline stage: ~w/~w
fn ~w(input: &[Record]) -> Vec<Record> {
    let _ = input;
    panic!(\"unsupported Rust enhanced pipeline stage: ~w/~w\");
}

", [Pred, Arity, Pred, Pred, Arity]).
generate_rust_single_enhanced_stage(_, "").

%% generate_rust_enhanced_connector(+Stages, +PipelineName, -Code)
%  Generate the main connector that handles enhanced flow patterns.
generate_rust_enhanced_connector(Stages, PipelineName, Code) :-
    generate_rust_enhanced_flow_code(Stages, "input", FlowCode),
    format(string(Code),
"/// ~w is an enhanced pipeline with fan-out, merge, and routing support.
fn ~w(input: &[Record]) -> Vec<Record> {
~w
}

", [PipelineName, PipelineName, FlowCode]).

%% generate_rust_enhanced_flow_code(+Stages, +CurrentVar, -Code)
%  Generate the flow code for enhanced pipeline stages.
generate_rust_enhanced_flow_code([], CurrentVar, Code) :-
    format(string(Code), "    ~w.to_vec()", [CurrentVar]).
generate_rust_enhanced_flow_code([Stage|Rest], CurrentVar, Code) :-
    generate_rust_stage_flow(Stage, CurrentVar, NextVar, StageCode),
    generate_rust_enhanced_flow_code(Rest, NextVar, RestCode),
    format(string(Code), "~w~n~w", [StageCode, RestCode]).

%% generate_rust_stage_flow(+Stage, +InVar, -OutVar, -Code)
%  Generate flow code for a single stage.

% Fan-out stage: broadcast to stages (sequential execution)
generate_rust_stage_flow(fan_out(SubStages), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "fan_out_~w_result", [N]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    format(string(Code),
"    // Fan-out to ~w stages (sequential)
    let ~w: Vec<Record> = ~w.iter()
        .flat_map(|record| fan_out_records(record, &[~w]))
        .collect();", [N, OutVar, InVar, StageListStr]).

% Parallel stage with options: parallel(Stages, Options)
generate_rust_stage_flow(parallel(SubStages, Options), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "parallel_~w_result", [N]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    % Check for ordered option
    (   member(ordered(true), Options)
    ->  FuncName = "parallel_records_ordered",
        format(atom(Comment), "Parallel execution (ordered) of ~w stages", [N])
    ;   FuncName = "parallel_records",
        format(atom(Comment), "Parallel execution of ~w stages (concurrent via threads)", [N])
    ),
    format(string(Code),
"    // ~w
    let ~w: Vec<Record> = ~w.iter()
        .flat_map(|record| ~w(record, &[~w]))
        .collect();", [Comment, OutVar, InVar, FuncName, StageListStr]).

% Parallel stage: concurrent execution using threads (default: unordered)
generate_rust_stage_flow(parallel(SubStages), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "parallel_~w_result", [N]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    format(string(Code),
"    // Parallel execution of ~w stages (concurrent via threads)
    let ~w: Vec<Record> = ~w.iter()
        .flat_map(|record| parallel_records(record, &[~w]))
        .collect();", [N, OutVar, InVar, StageListStr]).

% Merge stage: placeholder, usually follows fan_out or parallel
generate_rust_stage_flow(merge, InVar, OutVar, Code) :-
    !,
    OutVar = InVar,
    Code = "    // Merge: results already combined from fan-out or parallel".

% Conditional routing
generate_rust_stage_flow(route_by(CondPred, Routes), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "routed_result", []),
    format_rust_route_map(Routes, RouteMapStr),
    format(string(Code),
"    // Conditional routing based on ~w
    let mut route_map: HashMap<Value, fn(&[Record]) -> Vec<Record>> = HashMap::new();
~w
    let ~w: Vec<Record> = ~w.iter()
        .flat_map(|record| route_record(record, ~w, &route_map, None))
        .collect();", [CondPred, RouteMapStr, OutVar, InVar, CondPred]).

% Filter stage
generate_rust_stage_flow(filter_by(Pred), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "filtered_result", []),
    format(string(Code),
"    // Filter by ~w
    let ~w = filter_records(&~w, ~w);", [Pred, OutVar, InVar, Pred]).

% Batch stage: collect N records into batches
generate_rust_stage_flow(batch(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "batched_~w_result", [N]),
    format(string(Code),
"    // Batch records into groups of ~w
    let ~w = batch_records(&~w, ~w);", [N, OutVar, InVar, N]).

% Unbatch stage: flatten batches back to individual records
generate_rust_stage_flow(unbatch, InVar, OutVar, Code) :-
    !,
    OutVar = "unbatched_result",
    format(string(Code),
"    // Unbatch: flatten batches to individual records
    let ~w = unbatch_records(&~w);", [OutVar, InVar]).

% Unique stage: deduplicate by field (keep first)
generate_rust_stage_flow(unique(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "unique_~w_result", [Field]),
    format(string(Code),
"    // Unique: keep first record per '~w' value
    let ~w = unique_by_field(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% First stage: alias for unique (keep first occurrence)
generate_rust_stage_flow(first(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "first_~w_result", [Field]),
    format(string(Code),
"    // First: keep first record per '~w' value
    let ~w = first_by_field(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% Last stage: keep last record per field value
generate_rust_stage_flow(last(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "last_~w_result", [Field]),
    format(string(Code),
"    // Last: keep last record per '~w' value
    let ~w = last_by_field(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% Group by stage: group and aggregate
generate_rust_stage_flow(group_by(Field, Agg), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "grouped_~w_result", [Field]),
    format_rust_aggregations(Agg, AggStr),
    format(string(Code),
"    // Group by '~w' with aggregations
    let ~w = group_by_field(&~w, \"~w\", &[~w]);", [Field, OutVar, InVar, Field, AggStr]).

% Reduce stage with initial value
generate_rust_stage_flow(reduce(Pred, Init), InVar, OutVar, Code) :-
    !,
    OutVar = "reduced_result",
    format(string(Code),
"    // Reduce: sequential fold with ~w
    let ~w = reduce_records(&~w, ~w, ~w.into());", [Pred, OutVar, InVar, Pred, Init]).

% Reduce stage without initial value
generate_rust_stage_flow(reduce(Pred), InVar, OutVar, Code) :-
    !,
    OutVar = "reduced_result",
    format(string(Code),
"    // Reduce: sequential fold with ~w
    let ~w = reduce_records(&~w, ~w, Value::Null);", [Pred, OutVar, InVar, Pred]).

% Scan stage with initial value
generate_rust_stage_flow(scan(Pred, Init), InVar, OutVar, Code) :-
    !,
    OutVar = "scanned_result",
    format(string(Code),
"    // Scan: running fold with ~w (emits intermediate values)
    let ~w = scan_records(&~w, ~w, ~w.into());", [Pred, OutVar, InVar, Pred, Init]).

% Scan stage without initial value
generate_rust_stage_flow(scan(Pred), InVar, OutVar, Code) :-
    !,
    OutVar = "scanned_result",
    format(string(Code),
"    // Scan: running fold with ~w (emits intermediate values)
    let ~w = scan_records(&~w, ~w, Value::Null);", [Pred, OutVar, InVar, Pred]).

% Order by single field (ascending by default)
generate_rust_stage_flow(order_by(Field), InVar, OutVar, Code) :-
    atom(Field),
    !,
    format(atom(OutVar), "ordered_~w_result", [Field]),
    format(string(Code),
"    // Order by '~w' ascending
    let ~w = order_by_field(&~w, \"~w\", \"asc\");", [Field, OutVar, InVar, Field]).

% Order by single field with direction
generate_rust_stage_flow(order_by(Field, Dir), InVar, OutVar, Code) :-
    atom(Field),
    !,
    format(atom(OutVar), "ordered_~w_result", [Field]),
    format(string(Code),
"    // Order by '~w' ~w
    let ~w = order_by_field(&~w, \"~w\", \"~w\");", [Field, Dir, OutVar, InVar, Field, Dir]).

% Order by multiple fields with directions
generate_rust_stage_flow(order_by(FieldSpecs), InVar, OutVar, Code) :-
    is_list(FieldSpecs),
    !,
    OutVar = "ordered_multi_result",
    format_rust_field_specs(FieldSpecs, SpecStr),
    format(string(Code),
"    // Order by multiple fields
    let ~w = order_by_fields(&~w, &[~w]);", [OutVar, InVar, SpecStr]).

% Sort by custom comparator
generate_rust_stage_flow(sort_by(ComparePred), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "sorted_~w_result", [ComparePred]),
    format(string(Code),
"    // Sort by custom comparator: ~w
    let ~w = sort_by_comparator(&~w, ~w);", [ComparePred, OutVar, InVar, ComparePred]).

% Try-catch stage: execute stage, on error route to handler
generate_rust_stage_flow(try_catch(Stage, Handler), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Stage, StageName),
    extract_rust_stage_name(Handler, HandlerName),
    OutVar = "try_catch_result",
    format(string(Code),
"    // Try-Catch: ~w with handler ~w
    let ~w = try_catch_stage(&~w, ~w, ~w);", [StageName, HandlerName, OutVar, InVar, StageName, HandlerName]).

% Retry stage: retry N times on failure
generate_rust_stage_flow(retry(Stage, N), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Stage, StageName),
    OutVar = "retry_result",
    format(string(Code),
"    // Retry: ~w up to ~w times
    let ~w = retry_stage(&~w, ~w, ~w, 0, \"none\");", [StageName, N, OutVar, InVar, StageName, N]).

% Retry stage with options
generate_rust_stage_flow(retry(Stage, N, Options), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Stage, StageName),
    OutVar = "retry_result",
    extract_rust_retry_options(Options, DelayMs, Backoff),
    format(string(Code),
"    // Retry: ~w up to ~w times (delay=~wms, backoff=~w)
    let ~w = retry_stage(&~w, ~w, ~w, ~w, \"~w\");", [StageName, N, DelayMs, Backoff, OutVar, InVar, StageName, N, DelayMs, Backoff]).

% On-error stage: global error handler
generate_rust_stage_flow(on_error(Handler), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Handler, HandlerName),
    OutVar = "on_error_result",
    format(string(Code),
"    // On-Error: route errors to ~w
    let ~w = on_error_stage(&~w, ~w);", [HandlerName, OutVar, InVar, HandlerName]).

% Timeout stage: execute with time limit
generate_rust_stage_flow(timeout(Stage, Ms), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Stage, StageName),
    OutVar = "timeout_result",
    format(string(Code),
"    // Timeout: ~w with ~wms limit
    let ~w = timeout_stage(&~w, ~w, ~w);", [StageName, Ms, OutVar, InVar, StageName, Ms]).

% Timeout stage with fallback
generate_rust_stage_flow(timeout(Stage, Ms, Fallback), InVar, OutVar, Code) :-
    !,
    extract_rust_stage_name(Stage, StageName),
    extract_rust_stage_name(Fallback, FallbackName),
    OutVar = "timeout_result",
    format(string(Code),
"    // Timeout: ~w with ~wms limit, fallback to ~w
    let ~w = timeout_stage_with_fallback(&~w, ~w, ~w, ~w);", [StageName, Ms, FallbackName, OutVar, InVar, StageName, Ms, FallbackName]).

% Rate limit stage: limit throughput to N records per time unit
generate_rust_stage_flow(rate_limit(N, Per), InVar, OutVar, Code) :-
    !,
    rust_time_unit_to_ms(Per, IntervalMs),
    OutVar = "rate_limited",
    format(string(Code),
"    // Rate limit: ~w records per ~w
    let ~w = rate_limit_stage(&~w, ~w, ~w);", [N, Per, OutVar, InVar, N, IntervalMs]).

% Throttle stage: add fixed delay between records
generate_rust_stage_flow(throttle(Ms), InVar, OutVar, Code) :-
    !,
    OutVar = "throttled",
    format(string(Code),
"    // Throttle: ~wms delay between records
    let ~w = throttle_stage(&~w, ~w);", [Ms, OutVar, InVar, Ms]).

% Buffer stage: collect records into batches
generate_rust_stage_flow(buffer(N), InVar, OutVar, Code) :-
    !,
    OutVar = "buffered",
    format(string(Code),
"    // Buffer: collect ~w records into batches
    let ~w = buffer_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Debounce stage: emit only if no new record within delay
generate_rust_stage_flow(debounce(Ms), InVar, OutVar, Code) :-
    !,
    OutVar = "debounced",
    format(string(Code),
"    // Debounce: ~wms quiet period
    let ~w = debounce_stage(&~w, ~w);", [Ms, OutVar, InVar, Ms]).

% Zip stage: combine multiple stages record-by-record
generate_rust_stage_flow(zip(Stages), InVar, OutVar, Code) :-
    !,
    OutVar = "zipped",
    extract_rust_stage_names(Stages, Names),
    format_rust_stage_list(Names, StageListStr),
    format(string(Code),
"    // Zip: combine outputs from multiple stages
    let ~w = zip_stage(&~w, &[~w]);", [OutVar, InVar, StageListStr]).

% Window stage: collect records into non-overlapping windows
generate_rust_stage_flow(window(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "windowed_~w", [N]),
    format(string(Code),
"    // Window: collect into batches of ~w
    let ~w = window_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Sliding window stage: create overlapping windows
generate_rust_stage_flow(sliding_window(N, Step), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "sliding_~w_~w", [N, Step]),
    format(string(Code),
"    // Sliding window: size=~w, step=~w
    let ~w = sliding_window_stage(&~w, ~w, ~w);", [N, Step, OutVar, InVar, N, Step]).

% Sample stage: randomly sample n records
generate_rust_stage_flow(sample(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "sampled_~w", [N]),
    format(string(Code),
"    // Sample: reservoir sampling of ~w records
    let ~w = sample_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Take every stage: take every nth record
generate_rust_stage_flow(take_every(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "every_~w", [N]),
    format(string(Code),
"    // Take every: every ~wth record
    let ~w = take_every_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Partition stage: split records by predicate
generate_rust_stage_flow(partition(Pred), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "partitioned_~w", [Pred]),
    format(string(Code),
"    // Partition: split by ~w predicate
    let (~w_matches, ~w_non_matches) = partition_stage(&~w, ~w);
    let ~w = ~w_matches;  // Use matches (non-matches available as ~w_non_matches)", [Pred, OutVar, OutVar, InVar, Pred, OutVar, OutVar, OutVar]).

% Take stage: take first n records
generate_rust_stage_flow(take(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "taken_~w", [N]),
    format(string(Code),
"    // Take: first ~w records
    let ~w = take_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Skip stage: skip first n records
generate_rust_stage_flow(skip(N), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "skipped_~w", [N]),
    format(string(Code),
"    // Skip: first ~w records
    let ~w = skip_stage(&~w, ~w);", [N, OutVar, InVar, N]).

% Take while stage: take while predicate is true
generate_rust_stage_flow(take_while(Pred), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "take_while_~w", [Pred]),
    format(string(Code),
"    // Take while: ~w is true
    let ~w = take_while_stage(&~w, ~w);", [Pred, OutVar, InVar, Pred]).

% Skip while stage: skip while predicate is true
generate_rust_stage_flow(skip_while(Pred), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "skip_while_~w", [Pred]),
    format(string(Code),
"    // Skip while: ~w is true
    let ~w = skip_while_stage(&~w, ~w);", [Pred, OutVar, InVar, Pred]).

% Distinct stage: remove all duplicates (global)
generate_rust_stage_flow(distinct, InVar, OutVar, Code) :-
    !,
    OutVar = "distinct_result",
    format(string(Code),
"    // Distinct: remove all duplicates (global dedup)
    let ~w = distinct_stage(&~w);", [OutVar, InVar]).

% Distinct by field: remove duplicates based on specific field
generate_rust_stage_flow(distinct_by(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "distinct_~w_result", [Field]),
    format(string(Code),
"    // Distinct By: remove duplicates based on '~w' field
    let ~w = distinct_by_stage(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% Dedup stage: remove consecutive duplicates only
generate_rust_stage_flow(dedup, InVar, OutVar, Code) :-
    !,
    OutVar = "dedup_result",
    format(string(Code),
"    // Dedup: remove consecutive duplicates
    let ~w = dedup_stage(&~w);", [OutVar, InVar]).

% Dedup by field: remove consecutive duplicates based on specific field
generate_rust_stage_flow(dedup_by(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "dedup_~w_result", [Field]),
    format(string(Code),
"    // Dedup By: remove consecutive duplicates based on '~w' field
    let ~w = dedup_by_stage(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% Interleave stage: round-robin interleave from multiple stage outputs
generate_rust_stage_flow(interleave(SubStages), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "interleaved_~w_result", [N]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    format(string(Code),
"    // Interleave: round-robin from ~w stage outputs
    let interleave_streams_~w: Vec<Vec<Record>> = vec![~w]
        .iter()
        .map(|stage_fn| stage_fn(&~w))
        .collect();
    let ~w = interleave_stage(&interleave_streams_~w);", [N, N, StageListStr, InVar, OutVar, N]).

% Concat stage: sequential concatenation of multiple stage outputs
generate_rust_stage_flow(concat(SubStages), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "concatenated_~w_result", [N]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    format(string(Code),
"    // Concat: sequential concatenation of ~w stage outputs
    let concat_streams_~w: Vec<Vec<Record>> = vec![~w]
        .iter()
        .map(|stage_fn| stage_fn(&~w))
        .collect();
    let ~w = concat_stage(&concat_streams_~w);", [N, N, StageListStr, InVar, OutVar, N]).

% Merge sorted stage: merge pre-sorted streams maintaining order (ascending)
generate_rust_stage_flow(merge_sorted(SubStages, Field), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "merge_sorted_~w_result", [Field]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    format(string(Code),
"    // Merge Sorted: merge ~w pre-sorted streams by '~w' (ascending)
    let merge_sorted_streams_~w: Vec<Vec<Record>> = vec![~w]
        .iter()
        .map(|stage_fn| stage_fn(&~w))
        .collect();
    let ~w = merge_sorted_stage(&merge_sorted_streams_~w, \"~w\", true);", [N, Field, N, StageListStr, InVar, OutVar, N, Field]).

% Merge sorted stage with direction: merge pre-sorted streams with specified order
generate_rust_stage_flow(merge_sorted(SubStages, Field, Dir), InVar, OutVar, Code) :-
    !,
    length(SubStages, N),
    format(atom(OutVar), "merge_sorted_~w_~w_result", [Field, Dir]),
    extract_rust_stage_names(SubStages, StageNames),
    format_rust_stage_list(StageNames, StageListStr),
    ( Dir = asc -> Ascending = "true" ; Ascending = "false" ),
    format(string(Code),
"    // Merge Sorted: merge ~w pre-sorted streams by '~w' (~w)
    let merge_sorted_streams_~w_~w: Vec<Vec<Record>> = vec![~w]
        .iter()
        .map(|stage_fn| stage_fn(&~w))
        .collect();
    let ~w = merge_sorted_stage(&merge_sorted_streams_~w_~w, \"~w\", ~w);", [N, Field, Dir, N, Dir, StageListStr, InVar, OutVar, N, Dir, Field, Ascending]).

% Tap stage: execute side effect without modifying stream
generate_rust_stage_flow(tap(Pred), InVar, OutVar, Code) :-
    !,
    ( Pred = PredName/_ -> true ; PredName = Pred ),
    format(atom(OutVar), "tapped_~w_result", [PredName]),
    format(string(Code),
"    // Tap: execute ~w for side effects (logging/metrics)
    let ~w = tap_stage(&~w, ~w);", [PredName, OutVar, InVar, PredName]).

% Flatten stage: flatten nested collections
generate_rust_stage_flow(flatten, InVar, OutVar, Code) :-
    !,
    OutVar = "flattened_result",
    format(string(Code),
"    // Flatten: expand nested collections into individual records
    let ~w = flatten_stage(&~w);", [OutVar, InVar]).

% Flatten field stage: flatten a specific field within records
generate_rust_stage_flow(flatten(Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "flattened_~w_result", [Field]),
    format(string(Code),
"    // Flatten Field: expand '~w' field into individual records
    let ~w = flatten_field_stage(&~w, \"~w\");", [Field, OutVar, InVar, Field]).

% Debounce stage: emit only after silence period
generate_rust_stage_flow(debounce(Ms), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "debounced_~w_result", [Ms]),
    format(string(Code),
"    // Debounce: emit after ~wms silence period
    let ~w = debounce_stage(&~w, ~w, None);", [Ms, OutVar, InVar, Ms]).

% Debounce stage with timestamp field
generate_rust_stage_flow(debounce(Ms, Field), InVar, OutVar, Code) :-
    !,
    format(atom(OutVar), "debounced_~w_~w_result", [Ms, Field]),
    format(string(Code),
"    // Debounce: emit after ~wms silence (using '~w' timestamp field)
    let ~w = debounce_stage(&~w, ~w, Some(\"~w\"));", [Ms, Field, OutVar, InVar, Ms, Field]).

% Branch stage: conditional routing
generate_rust_stage_flow(branch(Cond, TrueStage, FalseStage), InVar, OutVar, Code) :-
    !,
    OutVar = "branch_result",
    % Extract condition predicate name
    ( Cond = CondName/_ -> true ; CondName = Cond ),
    % Extract true/false stage names
    ( TrueStage = TrueName/_ -> true ; TrueName = TrueStage ),
    ( FalseStage = FalseName/_ -> true ; FalseName = FalseStage ),
    format(string(Code),
"    // Branch: if ~w then ~w else ~w
    let ~w = branch_stage(
        &~w,
        |r| ~w(r),
        |rs| ~w(rs),
        |rs| ~w(rs),
    );", [CondName, TrueName, FalseName, OutVar, InVar, CondName, TrueName, FalseName]).

% Tee stage: run side stage, discard results, pass through
generate_rust_stage_flow(tee(SideStage), InVar, OutVar, Code) :-
    !,
    OutVar = "tee_result",
    % Extract side stage name
    ( SideStage = SideName/_ -> true ; SideName = SideStage ),
    format(string(Code),
"    // Tee: fork to ~w (results discarded), pass original through
    let ~w = tee_stage(&~w, |rs| ~w(rs));",
    [SideName, OutVar, InVar, SideName]).

% Call service stage (without options)
generate_rust_stage_flow(call_service(ServiceName, RequestExpr, ResponseVar), InVar, OutVar, Code) :-
    !,
    OutVar = "service_result",
    format(string(Code),
"    // Call service: ~w
    let ~w = call_service_stage(&~w, \"~w\", \"~w\", \"~w\", &CallServiceOptions::default());",
    [ServiceName, OutVar, InVar, ServiceName, RequestExpr, ResponseVar]).

% Call service stage (with options)
generate_rust_stage_flow(call_service(ServiceName, RequestExpr, ResponseVar, Options), InVar, OutVar, Code) :-
    !,
    OutVar = "service_result",
    format_rust_options(Options, OptionsStr),
    format(string(Code),
"    // Call service: ~w (with options)
    let ~w = call_service_stage(&~w, \"~w\", \"~w\", \"~w\", &~w);",
    [ServiceName, OutVar, InVar, ServiceName, RequestExpr, ResponseVar, OptionsStr]).

% Standard predicate stage
generate_rust_stage_flow(Pred/Arity, InVar, OutVar, Code) :-
    !,
    atom(Pred),
    format(atom(OutVar), "~w_result", [Pred]),
    format(string(Code),
"    // Stage: ~w/~w
    let ~w = ~w(&~w);", [Pred, Arity, OutVar, Pred, InVar]).

% Fallback for unknown stages
generate_rust_stage_flow(Stage, InVar, InVar, Code) :-
    format(string(Code), "    // Unknown stage type: ~w (pass-through)", [Stage]).

%% format_rust_options(+Options, -RustStruct)
%  Format a list of Prolog options as a Rust struct initializer.
format_rust_options([], "CallServiceOptions::default()").
format_rust_options(Options, RustStruct) :-
    Options \= [],
    format_rust_option_fields(Options, Fields),
    atomic_list_concat(Fields, ', ', FieldsStr),
    format(string(RustStruct), "CallServiceOptions { ~w, ..Default::default() }", [FieldsStr]).

format_rust_option_fields([], []).
format_rust_option_fields([Opt|Rest], [Field|RestFields]) :-
    format_rust_option_field(Opt, Field),
    format_rust_option_fields(Rest, RestFields).

format_rust_option_field(timeout(Ms), Field) :-
    format(string(Field), "timeout_ms: Some(~w)", [Ms]).
format_rust_option_field(retry(N), Field) :-
    format(string(Field), "retry: ~w", [N]).
format_rust_option_field(retry_delay(Ms), Field) :-
    format(string(Field), "retry_delay_ms: ~w", [Ms]).
format_rust_option_field(fallback(Value), Field) :-
    ( atom(Value) ->
        format(string(Field), "fallback: Some(serde_json::json!(\"~w\"))", [Value])
    ; number(Value) ->
        format(string(Field), "fallback: Some(serde_json::json!(~w))", [Value])
    ;
        format(string(Field), "fallback: None", [])
    ).
format_rust_option_field(transport(T), Field) :-
    format(string(Field), "/* transport: ~w */", [T]).
format_rust_option_field(Opt, Field) :-
    % Fallback for unknown options
    format(string(Field), "/* Unknown option: ~w */", [Opt]).

%% extract_rust_stage_name(+Stage, -Name)
%  Extract function name from a single stage specification.
extract_rust_stage_name(Pred/_, Pred) :- atom(Pred), !.
extract_rust_stage_name(Pred, Pred) :- atom(Pred), !.
extract_rust_stage_name(_, unknown_stage).

%% extract_rust_retry_options(+Options, -DelayMs, -Backoff)
%  Extract retry options from options list.
extract_rust_retry_options(Options, DelayMs, Backoff) :-
    ( member(delay(D), Options) -> DelayMs = D ; DelayMs = 0 ),
    ( member(backoff(B), Options) -> Backoff = B ; Backoff = none ).

%% rust_time_unit_to_ms(+Unit, -Ms)
%  Convert time unit to milliseconds for Rust rate limiting.
rust_time_unit_to_ms(second, 1000) :- !.
rust_time_unit_to_ms(minute, 60000) :- !.
rust_time_unit_to_ms(hour, 3600000) :- !.
rust_time_unit_to_ms(ms(X), X) :- !.
rust_time_unit_to_ms(X, X) :- integer(X), !.
rust_time_unit_to_ms(_, 1000).

%% format_rust_stage_list(+Names, -ListStr)
%  Format stage names as Rust function references.
format_rust_stage_list([], "").
format_rust_stage_list([Name], Str) :-
    format(string(Str), "~w", [Name]).
format_rust_stage_list([Name|Rest], Str) :-
    Rest \= [],
    format_rust_stage_list(Rest, RestStr),
    format(string(Str), "~w, ~w", [Name, RestStr]).

%% format_rust_route_map(+Routes, -MapStr)
%  Format routing map for Rust.
format_rust_route_map([], "").
format_rust_route_map([(_Cond, Stage)|[]], Str) :-
    (Stage = StageName/_Arity -> true ; StageName = Stage),
    format(string(Str), "    route_map.insert(Value::Bool(true), ~w);", [StageName]).
format_rust_route_map([(Cond, Stage)|Rest], Str) :-
    Rest \= [],
    (Stage = StageName/_Arity -> true ; StageName = Stage),
    format_rust_route_map(Rest, RestStr),
    (Cond = true ->
        format(string(Str), "    route_map.insert(Value::Bool(true), ~w);~n~w", [StageName, RestStr])
    ; Cond = false ->
        format(string(Str), "    route_map.insert(Value::Bool(false), ~w);~n~w", [StageName, RestStr])
    ;   format(string(Str), "    route_map.insert(Value::String(\"~w\".to_string()), ~w);~n~w", [Cond, StageName, RestStr])
    ).

%% format_rust_aggregations(+Agg, -Str)
%  Format aggregation specifications for Rust group_by stage.
format_rust_aggregations(Aggs, Str) :-
    is_list(Aggs),
    !,
    format_rust_aggregation_list(Aggs, Str).
format_rust_aggregations(Agg, Str) :-
    format_rust_single_aggregation(Agg, Str).

format_rust_aggregation_list([], "").
format_rust_aggregation_list([Agg], Str) :-
    format_rust_single_aggregation(Agg, Str).
format_rust_aggregation_list([Agg|Rest], Str) :-
    Rest \= [],
    format_rust_single_aggregation(Agg, AggStr),
    format_rust_aggregation_list(Rest, RestStr),
    format(string(Str), "~w, ~w", [AggStr, RestStr]).

% count aggregation
format_rust_single_aggregation(count, "(\"count\", AggType::Count)").
% Aggregations with field
format_rust_single_aggregation(sum(Field), Str) :-
    format(string(Str), "(\"sum\", AggType::Sum(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(avg(Field), Str) :-
    format(string(Str), "(\"avg\", AggType::Avg(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(min(Field), Str) :-
    format(string(Str), "(\"min\", AggType::Min(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(max(Field), Str) :-
    format(string(Str), "(\"max\", AggType::Max(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(first(Field), Str) :-
    format(string(Str), "(\"first\", AggType::First(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(last(Field), Str) :-
    format(string(Str), "(\"last\", AggType::Last(\"~w\".to_string()))", [Field]).
format_rust_single_aggregation(collect(Field), Str) :-
    format(string(Str), "(\"collect\", AggType::Collect(\"~w\".to_string()))", [Field]).

%% format_rust_field_specs(+FieldSpecs, -Str)
%  Format field specifications for multi-field ordering.
format_rust_field_specs([], "").
format_rust_field_specs([Spec], Str) :-
    format_rust_single_field_spec(Spec, Str).
format_rust_field_specs([Spec|Rest], Str) :-
    Rest \= [],
    format_rust_single_field_spec(Spec, SpecStr),
    format_rust_field_specs(Rest, RestStr),
    format(string(Str), "~w, ~w", [SpecStr, RestStr]).

format_rust_single_field_spec(Field, Str) :-
    atom(Field),
    !,
    format(string(Str), "FieldSpec { field: \"~w\".to_string(), direction: \"asc\".to_string() }", [Field]).
format_rust_single_field_spec((Field, Dir), Str) :-
    format(string(Str), "FieldSpec { field: \"~w\".to_string(), direction: \"~w\".to_string() }", [Field, Dir]).

%% generate_rust_enhanced_main(+PipelineName, +OutputFormat, -Code)
%  Generate main function for enhanced pipeline.
generate_rust_enhanced_main(PipelineName, jsonl, Code) :-
    format(string(Code),
"fn main() {
    // Read JSONL from stdin
    let input = read_jsonl_stream();

    // Run enhanced pipeline
    let results = ~w(&input);

    // Output results as JSONL
    write_jsonl_stream(&results);
}
", [PipelineName]).
generate_rust_enhanced_main(PipelineName, _, Code) :-
    format(string(Code),
"fn main() {
    // Read JSONL from stdin
    let input = read_jsonl_stream();

    // Run enhanced pipeline
    let results = ~w(&input);

    // Output results
    write_jsonl_stream(&results);
}
", [PipelineName]).

%% ============================================
%% RUST ENHANCED PIPELINE CHAINING TESTS
%% ============================================

test_rust_enhanced_chaining :-
    format('~n=== Rust Enhanced Pipeline Chaining Tests ===~n~n', []),

    % Test 1: Generate enhanced helpers (std_thread mode)
    format('[Test 1] Generate enhanced helpers (std_thread)~n', []),
    rust_enhanced_helpers(std_thread, Helpers1),
    (   sub_string(Helpers1, _, _, _, "fn fan_out_records"),
        sub_string(Helpers1, _, _, _, "fn merge_streams"),
        sub_string(Helpers1, _, _, _, "fn route_record"),
        sub_string(Helpers1, _, _, _, "fn filter_records"),
        sub_string(Helpers1, _, _, _, "fn tee_stream"),
        sub_string(Helpers1, _, _, _, "std::thread")
    ->  format('  [PASS] All helper functions generated (std_thread)~n', [])
    ;   format('  [FAIL] Missing helper functions~n', [])
    ),

    % Test 2: Linear pipeline connector
    format('[Test 2] Linear pipeline connector~n', []),
    generate_rust_enhanced_connector([extract/1, transform/1, load/1], linear_pipe, Code2),
    (   sub_string(Code2, _, _, _, "fn linear_pipe"),
        sub_string(Code2, _, _, _, "extract(&input)"),
        sub_string(Code2, _, _, _, "transform(&extract_result)"),
        sub_string(Code2, _, _, _, "load(&transform_result)")
    ->  format('  [PASS] Linear connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code2])
    ),

    % Test 3: Fan-out connector
    format('[Test 3] Fan-out connector~n', []),
    generate_rust_enhanced_connector([fan_out([validate/1, enrich/1])], fanout_pipe, Code3),
    (   sub_string(Code3, _, _, _, "fn fanout_pipe"),
        sub_string(Code3, _, _, _, "Fan-out to 2 parallel stages"),
        sub_string(Code3, _, _, _, "fan_out_records")
    ->  format('  [PASS] Fan-out connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code3])
    ),

    % Test 4: Fan-out with merge
    format('[Test 4] Fan-out with merge~n', []),
    generate_rust_enhanced_connector([fan_out([a/1, b/1]), merge], merge_pipe, Code4),
    (   sub_string(Code4, _, _, _, "fn merge_pipe"),
        sub_string(Code4, _, _, _, "Fan-out to 2"),
        sub_string(Code4, _, _, _, "Merge: results already combined")
    ->  format('  [PASS] Merge connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code4])
    ),

    % Test 5: Conditional routing
    format('[Test 5] Conditional routing~n', []),
    generate_rust_enhanced_connector([route_by(has_error, [(true, error_handler/1), (false, success/1)])], route_pipe, Code5),
    (   sub_string(Code5, _, _, _, "fn route_pipe"),
        sub_string(Code5, _, _, _, "Conditional routing based on has_error"),
        sub_string(Code5, _, _, _, "route_map")
    ->  format('  [PASS] Routing connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code5])
    ),

    % Test 6: Filter stage
    format('[Test 6] Filter stage~n', []),
    generate_rust_enhanced_connector([filter_by(is_valid)], filter_pipe, Code6),
    (   sub_string(Code6, _, _, _, "fn filter_pipe"),
        sub_string(Code6, _, _, _, "Filter by is_valid"),
        sub_string(Code6, _, _, _, "filter_records")
    ->  format('  [PASS] Filter connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code6])
    ),

    % Test 7: Complex pipeline with all patterns
    format('[Test 7] Complex pipeline~n', []),
    generate_rust_enhanced_connector([
        extract/1,
        filter_by(is_active),
        fan_out([validate/1, enrich/1, audit/1]),
        merge,
        route_by(has_error, [(true, error_log/1), (false, transform/1)]),
        output/1
    ], complex_pipe, Code7),
    (   sub_string(Code7, _, _, _, "fn complex_pipe"),
        sub_string(Code7, _, _, _, "Filter by is_active"),
        sub_string(Code7, _, _, _, "Fan-out to 3 parallel stages"),
        sub_string(Code7, _, _, _, "Merge"),
        sub_string(Code7, _, _, _, "Conditional routing")
    ->  format('  [PASS] Complex connector generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [Code7])
    ),

    % Test 8: Stage function generation
    format('[Test 8] Stage function generation~n', []),
    generate_rust_enhanced_stage_functions([extract/1, transform/1], StageFns8),
    (   sub_string(StageFns8, _, _, _, "fn extract"),
        sub_string(StageFns8, _, _, _, "fn transform")
    ->  format('  [PASS] Stage functions generated~n', [])
    ;   format('  [FAIL] Code: ~w~n', [StageFns8])
    ),

    % Test 9: Full enhanced pipeline compilation
    format('[Test 9] Full enhanced pipeline~n', []),
    compile_rust_enhanced_pipeline([
        extract/1,
        filter_by(is_active),
        fan_out([validate/1, enrich/1]),
        merge,
        output/1
    ], [pipeline_name(full_enhanced), output_format(jsonl)], FullCode9),
    (   sub_string(FullCode9, _, _, _, "use std::collections::HashMap"),
        sub_string(FullCode9, _, _, _, "fn fan_out_records"),
        sub_string(FullCode9, _, _, _, "fn filter_records"),
        sub_string(FullCode9, _, _, _, "fn full_enhanced"),
        sub_string(FullCode9, _, _, _, "fn main()")
    ->  format('  [PASS] Full pipeline compiles~n', [])
    ;   format('  [FAIL] Missing patterns in generated code~n', [])
    ),

    % Test 10: Enhanced helpers include all functions (std_thread)
    format('[Test 10] Enhanced helpers completeness (std_thread)~n', []),
    rust_enhanced_helpers(std_thread, Helpers10),
    (   sub_string(Helpers10, _, _, _, "fan_out_records"),
        sub_string(Helpers10, _, _, _, "merge_streams"),
        sub_string(Helpers10, _, _, _, "route_record"),
        sub_string(Helpers10, _, _, _, "filter_records"),
        sub_string(Helpers10, _, _, _, "tee_stream")
    ->  format('  [PASS] All helpers present (std_thread)~n', [])
    ;   format('  [FAIL] Missing helpers~n', [])
    ),

    % Test 11: Rayon mode generates par_iter
    format('[Test 11] Rayon parallel mode~n', []),
    rust_enhanced_helpers(rayon, Helpers11),
    (   sub_string(Helpers11, _, _, _, "par_iter"),
        sub_string(Helpers11, _, _, _, "rayon")
    ->  format('  [PASS] Rayon helpers generated~n', [])
    ;   format('  [FAIL] Missing rayon patterns~n', [])
    ),

    % Test 12: Full pipeline with rayon mode
    format('[Test 12] Full pipeline with rayon mode~n', []),
    compile_rust_enhanced_pipeline([
        extract/1,
        parallel([validate/1, enrich/1]),
        merge,
        output/1
    ], [pipeline_name(rayon_pipe), parallel_mode(rayon)], RayonCode12),
    (   sub_string(RayonCode12, _, _, _, "rayon::prelude"),
        sub_string(RayonCode12, _, _, _, "par_iter")
    ->  format('  [PASS] Rayon pipeline compiles~n', [])
    ;   format('  [FAIL] Missing rayon patterns~n', [])
    ),

    format('~n=== All Rust Enhanced Pipeline Chaining Tests Passed ===~n', []).

%% ============================================
%% KG Topology Phase 3: Kleinberg Router Code Generation
%% ============================================

%% compile_kleinberg_router_rust(+Options, -Code)
%  Generate Rust KleinbergRouter struct with configurable options.

compile_kleinberg_router_rust(Options, Code) :-
    ( member(alpha(Alpha), Options) -> true ; Alpha = 2.0 ),
    ( member(max_hops(MaxHops), Options) -> true ; MaxHops = 10 ),
    ( member(parallel_paths(ParallelPaths), Options) -> true ; ParallelPaths = 1 ),
    ( member(similarity_threshold(Threshold), Options) -> true ; Threshold = 0.5 ),
    ( member(path_folding(PathFolding), Options) -> true ; PathFolding = true ),

    format(string(Code), '
// KG Topology Phase 3: Kleinberg Router
// Generated from Prolog service definition

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::time::{Duration, Instant};
use base64::Engine;
use serde::{Deserialize, Serialize};

/// KGNode represents a discovered node in the distributed KG network
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KGNode {
    pub node_id: String,
    pub endpoint: String,
    pub centroid: Vec<f32>,
    pub topics: Vec<String>,
    pub embedding_model: String,
    pub similarity: f64,
}

/// RoutingEnvelope carries routing information between nodes
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutingEnvelope {
    pub origin_node: String,
    pub htl: i32,
    pub visited: Vec<String>,
    pub path_folding_enabled: bool,
}

impl Default for RoutingEnvelope {
    fn default() -> Self {
        Self {
            origin_node: String::new(),
            htl: 10,
            visited: Vec::new(),
            path_folding_enabled: true,
        }
    }
}

/// KleinbergRouter implements small-world routing for distributed KG topology
pub struct KleinbergRouter {
    local_node_id: String,
    discovery_client: Arc<dyn ServiceRegistry>,
    alpha: f64,
    max_hops: i32,
    parallel_paths: i32,
    similarity_threshold: f64,
    path_folding_enabled: bool,
    node_cache: RwLock<HashMap<String, KGNode>>,
    cache_timestamp: RwLock<Instant>,
    cache_ttl: Duration,
    shortcuts: RwLock<HashMap<String, String>>,
}

impl KleinbergRouter {
    /// Create a new router with default configuration
    pub fn new(node_id: String, discovery: Arc<dyn ServiceRegistry>) -> Self {
        Self {
            local_node_id: node_id,
            discovery_client: discovery,
            alpha: ~w,
            max_hops: ~w,
            parallel_paths: ~w,
            similarity_threshold: ~w,
            path_folding_enabled: ~w,
            node_cache: RwLock::new(HashMap::new()),
            cache_timestamp: RwLock::new(Instant::now()),
            cache_ttl: Duration::from_secs(60),
            shortcuts: RwLock::new(HashMap::new()),
        }
    }

    /// Get the local node ID
    pub fn node_id(&self) -> &str {
        &self.local_node_id
    }

    /// Discover KG nodes from service registry
    pub fn discover_nodes(&self, tags: Option<Vec<String>>) -> Result<Vec<KGNode>, Box<dyn std::error::Error>> {
        // Check cache
        {
            let timestamp = self.cache_timestamp.read().unwrap();
            if timestamp.elapsed() < self.cache_ttl {
                let cache = self.node_cache.read().unwrap();
                return Ok(cache.values().cloned().collect());
            }
        }

        let tags = tags.unwrap_or_else(|| vec!["kg_node".to_string()]);
        let instances = self.discovery_client.discover("kg_topology", &tags)?;

        let mut nodes = Vec::new();
        let mut cache = self.node_cache.write().unwrap();

        for inst in instances {
            let metadata = &inst.metadata;

            let centroid_b64 = match metadata.get("semantic_centroid") {
                Some(serde_json::Value::String(s)) => s.clone(),
                _ => continue,
            };

            let centroid_bytes = match base64::engine::general_purpose::STANDARD.decode(&centroid_b64) {
                Ok(bytes) => bytes,
                Err(_) => continue,
            };

            // Convert bytes to f32 slice
            let centroid: Vec<f32> = centroid_bytes
                .chunks(4)
                .filter_map(|chunk| {
                    if chunk.len() == 4 {
                        Some(f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
                    } else {
                        None
                    }
                })
                .collect();

            let topics = metadata
                .get("interface_topics")
                .and_then(|v| v.as_array())
                .map(|arr| {
                    arr.iter()
                        .filter_map(|v| v.as_str().map(String::from))
                        .collect()
                })
                .unwrap_or_default();

            let model = metadata
                .get("embedding_model")
                .and_then(|v| v.as_str())
                .unwrap_or("unknown")
                .to_string();

            let node = KGNode {
                node_id: inst.service_id.clone(),
                endpoint: format!("http://{}:{}", inst.host, inst.port),
                centroid,
                topics,
                embedding_model: model,
                similarity: 0.0,
            };

            cache.insert(node.node_id.clone(), node.clone());
            nodes.push(node);
        }

        *self.cache_timestamp.write().unwrap() = Instant::now();
        Ok(nodes)
    }

    /// Check if a shortcut exists for the given query
    pub fn check_shortcut(&self, query_text: &str) -> Option<String> {
        let hash = self.hash_query(query_text);
        self.shortcuts.read().unwrap().get(&hash).cloned()
    }

    /// Create a shortcut for the given query
    pub fn create_shortcut(&self, query_text: &str, target_node_id: &str) {
        let hash = self.hash_query(query_text);
        self.shortcuts.write().unwrap().insert(hash, target_node_id.to_string());
    }

    fn hash_query(&self, query_text: &str) -> String {
        use sha2::{Sha256, Digest};
        let mut hasher = Sha256::new();
        hasher.update(query_text.as_bytes());
        format!("{:x}", hasher.finalize())[..16].to_string()
    }

    /// Get router statistics
    pub fn get_stats(&self) -> serde_json::Value {
        let cache = self.node_cache.read().unwrap();
        let shortcuts = self.shortcuts.read().unwrap();

        serde_json::json!({
            "local_node_id": self.local_node_id,
            "cached_nodes": cache.len(),
            "shortcuts": shortcuts.len(),
            "config": {
                "alpha": self.alpha,
                "max_hops": self.max_hops,
                "parallel_paths": self.parallel_paths,
                "similarity_threshold": self.similarity_threshold,
                "path_folding_enabled": self.path_folding_enabled,
            }
        })
    }
}

/// Compute cosine similarity between two vectors
pub fn cosine_similarity(a: &[f32], b: &[f32]) -> f64 {
    if a.len() != b.len() {
        return 0.0;
    }

    let (dot, norm_a, norm_b) = a.iter().zip(b.iter()).fold(
        (0.0f64, 0.0f64, 0.0f64),
        |(dot, na, nb), (&ai, &bi)| {
            (
                dot + (ai as f64 * bi as f64),
                na + (ai as f64 * ai as f64),
                nb + (bi as f64 * bi as f64),
            )
        },
    );

    if norm_a == 0.0 || norm_b == 0.0 {
        return 0.0;
    }

    dot / (norm_a.sqrt() * norm_b.sqrt())
}
', [Alpha, MaxHops, ParallelPaths, Threshold, PathFolding]).

% =============================================================================
% KG TOPOLOGY PHASE 4: FEDERATED QUERY CODE GENERATION (Rust)
% =============================================================================

%% compile_federated_query_rust(+Options, -Code)
%  Generate Rust FederatedQueryEngine with aggregation.

compile_federated_query_rust(Options, Code) :-
    ( member(federation_k(K), Options) -> true ; K = 3 ),
    ( member(timeout_ms(Timeout), Options) -> true ; Timeout = 5000 ),
    ( member(aggregation(Strategy), Options) -> true ; Strategy = sum ),
    strategy_to_rust_variant(Strategy, StrategyVariant),

    format(string(Code), '
// KG Topology Phase 4: Federated Query Engine
// Generated from Prolog service definition

use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::RwLock;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AggregationStrategy { Sum, Max, Min, Avg, Count, First, DiversityWeighted }

impl Default for AggregationStrategy { fn default() -> Self { ~w } }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregationConfig {
    pub strategy: AggregationStrategy,
    pub dedup_key: String,
    pub diversity_field: String,
}

impl Default for AggregationConfig {
    fn default() -> Self { Self { strategy: AggregationStrategy::default(), dedup_key: "answer_hash".into(), diversity_field: "corpus_id".into() } }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResultProvenance {
    pub node_id: String,
    pub exp_score: f64,
    pub corpus_id: String,
    pub data_sources: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregatedResult {
    pub answer_text: String,
    pub answer_hash: String,
    pub combined_score: f64,
    pub source_nodes: Vec<String>,
    pub provenance: Vec<ResultProvenance>,
    pub diversity_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeResult {
    pub answer_id: i64,
    pub answer_text: String,
    pub answer_hash: String,
    pub raw_score: f64,
    pub exp_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeResponse {
    pub source_node: String,
    pub results: Vec<NodeResult>,
    pub partition_sum: f64,
    pub response_time_ms: u64,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregatedResponse {
    pub query_id: String,
    pub results: Vec<AggregatedResult>,
    pub total_partition_sum: f64,
    pub nodes_queried: usize,
    pub nodes_responded: usize,
    pub total_time_ms: u64,
}

pub struct FederatedQueryEngine {
    router: Arc<KleinbergRouter>,
    config: AggregationConfig,
    federation_k: usize,
    timeout_ms: u64,
    query_count: RwLock<u64>,
}

impl FederatedQueryEngine {
    pub fn new(router: Arc<KleinbergRouter>) -> Self {
        Self { router, config: AggregationConfig::default(), federation_k: ~w, timeout_ms: ~w, query_count: RwLock::new(0) }
    }

    pub async fn federated_query(&self, query_text: &str, query_embedding: &[f32], top_k: usize) -> Result<AggregatedResponse, Box<dyn std::error::Error + Send + Sync>> {
        let start = Instant::now();
        let nodes = self.router.discover_nodes(None)?;
        let mut sorted_nodes: Vec<_> = nodes.iter().map(|n| (n.clone(), cosine_similarity(query_embedding, &n.centroid))).collect();
        sorted_nodes.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        let selected: Vec<_> = sorted_nodes.into_iter().take(self.federation_k).map(|(n, _)| n).collect();
        let mut aggregated: HashMap<String, AggregatedResult> = HashMap::new();
        let mut responded = 0;
        let mut total_partition = 0.0;
        for node in &selected {
            if let Ok(resp) = self.query_node(node, query_text, query_embedding, top_k).await {
                responded += 1; total_partition += resp.partition_sum;
                for r in resp.results {
                    aggregated.entry(r.answer_hash.clone()).and_modify(|e| { e.combined_score = self.merge_score(e.combined_score, r.exp_score); e.source_nodes.push(resp.source_node.clone()); }).or_insert(AggregatedResult { answer_text: r.answer_text, answer_hash: r.answer_hash, combined_score: r.exp_score, source_nodes: vec![resp.source_node.clone()], provenance: vec![], diversity_score: 0.0 });
                }
            }
        }
        let mut results: Vec<_> = aggregated.into_values().collect();
        results.sort_by(|a, b| b.combined_score.partial_cmp(&a.combined_score).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(top_k);
        Ok(AggregatedResponse { query_id: uuid::Uuid::new_v4().to_string(), results, total_partition_sum: total_partition, nodes_queried: selected.len(), nodes_responded: responded, total_time_ms: start.elapsed().as_millis() as u64 })
    }

    fn merge_score(&self, existing: f64, new: f64) -> f64 {
        match self.config.strategy { AggregationStrategy::Max => existing.max(new), AggregationStrategy::Min => existing.min(new), _ => existing + new }
    }

    async fn query_node(&self, node: &KGNode, query_text: &str, _embedding: &[f32], top_k: usize) -> Result<NodeResponse, Box<dyn std::error::Error + Send + Sync>> {
        let client = reqwest::Client::builder().timeout(Duration::from_millis(self.timeout_ms)).build()?;
        let start = Instant::now();
        let resp = client.post(format!("{}/kg/query", node.endpoint)).json(&serde_json::json!({"__type": "kg_query", "payload": {"query_text": query_text, "top_k": top_k}})).send().await?;
        let mut node_resp: NodeResponse = resp.json().await?;
        node_resp.source_node = node.node_id.clone(); node_resp.response_time_ms = start.elapsed().as_millis() as u64;
        Ok(node_resp)
    }
}
', [StrategyVariant, K, Timeout]).

strategy_to_rust_variant(sum, 'AggregationStrategy::Sum').
strategy_to_rust_variant(max, 'AggregationStrategy::Max').
strategy_to_rust_variant(min, 'AggregationStrategy::Min').
strategy_to_rust_variant(avg, 'AggregationStrategy::Avg').
strategy_to_rust_variant(count, 'AggregationStrategy::Count').
strategy_to_rust_variant(first, 'AggregationStrategy::First').
strategy_to_rust_variant(diversity, 'AggregationStrategy::DiversityWeighted').
strategy_to_rust_variant(_, 'AggregationStrategy::Sum').

% =============================================================================
% KG TOPOLOGY PHASE 5b: ADAPTIVE FEDERATION-K CODE GENERATION (Rust)
% =============================================================================

%% compile_adaptive_federation_rust(+Options, -Code)
%  Generate Rust AdaptiveFederatedEngine with dynamic k selection.

compile_adaptive_federation_rust(Options, Code) :-
    ( member(adaptive_k(AdaptiveOpts), Options), is_list(AdaptiveOpts) -> true ; AdaptiveOpts = [] ),
    ( member(base_k(BaseK), AdaptiveOpts) -> true ; BaseK = 3 ),
    ( member(min_k(MinK), AdaptiveOpts) -> true ; MinK = 1 ),
    ( member(max_k(MaxK), AdaptiveOpts) -> true ; MaxK = 10 ),
    ( member(entropy_threshold(EntropyT), AdaptiveOpts) -> true ; EntropyT = 0.7 ),

    format(string(Code), '
// KG Topology Phase 5b: Adaptive Federation-K
// Generated from Prolog service definition

#[derive(Debug, Clone)]
pub struct AdaptiveKConfig { pub base_k: usize, pub min_k: usize, pub max_k: usize, pub entropy_threshold: f64 }

impl Default for AdaptiveKConfig {
    fn default() -> Self { Self { base_k: ~w, min_k: ~w, max_k: ~w, entropy_threshold: ~w } }
}

pub struct AdaptiveKCalculator {
    config: AdaptiveKConfig,
    query_history: RwLock<Vec<(Vec<f32>, f64, usize)>>,
}

impl AdaptiveKCalculator {
    pub fn new(config: AdaptiveKConfig) -> Self { Self { config, query_history: RwLock::new(Vec::new()) } }

    pub async fn compute_k(&self, query_embedding: &[f32], nodes: &[KGNode]) -> usize {
        if nodes.is_empty() { return self.config.min_k; }
        let similarities: Vec<f64> = nodes.iter().map(|n| cosine_similarity(query_embedding, &n.centroid)).collect();
        let sum: f64 = similarities.iter().map(|s| s.abs()).sum();
        let entropy = if sum > 0.0 && similarities.len() > 1 { let probs: Vec<f64> = similarities.iter().map(|s| s.abs() / (sum + 1e-10)).collect(); -probs.iter().filter(|&&p| p > 1e-10).map(|p| p * p.ln()).sum::<f64>() / (similarities.len() as f64).ln() } else { 0.5 };
        let max_sim = similarities.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let mut k = self.config.base_k;
        if entropy > self.config.entropy_threshold { k += 2; }
        if max_sim < 0.5 { k += 1; }
        k.clamp(self.config.min_k, self.config.max_k.min(nodes.len()))
    }

    pub async fn record_outcome(&self, embedding: Vec<f32>, consensus: f64, k_used: usize) {
        let mut history = self.query_history.write().await;
        history.push((embedding, consensus, k_used));
        if history.len() > 100 { history.remove(0); }
    }
}

pub struct AdaptiveFederatedEngine { engine: FederatedQueryEngine, adaptive: AdaptiveKCalculator }

impl AdaptiveFederatedEngine {
    pub fn new(router: Arc<KleinbergRouter>) -> Self {
        Self { engine: FederatedQueryEngine::new(router), adaptive: AdaptiveKCalculator::new(AdaptiveKConfig::default()) }
    }
}
', [BaseK, MinK, MaxK, EntropyT]).

% =============================================================================
% KG TOPOLOGY PHASE 5c: QUERY PLANNER CODE GENERATION (Rust)
% =============================================================================

%% compile_query_planner_rust(+Options, -Code)
%  Generate Rust QueryPlanner with cost-based optimization.

compile_query_planner_rust(Options, Code) :-
    ( member(query_planning(PlanOpts), Options), is_list(PlanOpts) -> true ; PlanOpts = [] ),
    ( member(specific_threshold(SpecT), PlanOpts) -> true ; SpecT = 0.8 ),
    ( member(exploratory_variance(ExplVar), PlanOpts) -> true ; ExplVar = 0.1 ),

    format(string(Code), '
// KG Topology Phase 5c: Query Planner
// Generated from Prolog service definition

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueryType { Specific, Exploratory, Consensus }

#[derive(Debug, Clone)]
pub struct QueryClassification { pub query_type: QueryType, pub max_similarity: f64, pub variance: f64, pub top_nodes: Vec<String>, pub confidence: f64 }

#[derive(Debug, Clone)]
pub struct PlannerConfig { pub specific_threshold: f64, pub exploratory_variance: f64, pub specific_max_nodes: usize, pub exploratory_max_nodes: usize }

impl Default for PlannerConfig {
    fn default() -> Self { Self { specific_threshold: ~w, exploratory_variance: ~w, specific_max_nodes: 2, exploratory_max_nodes: 7 } }
}

#[derive(Debug, Clone)]
pub struct QueryPlanStage { pub stage_id: usize, pub nodes: Vec<String>, pub strategy: AggregationStrategy, pub parallel: bool, pub depends_on: Vec<usize>, pub estimated_cost_ms: f64 }

#[derive(Debug, Clone)]
pub struct QueryPlan { pub plan_id: String, pub query_type: QueryType, pub stages: Vec<QueryPlanStage>, pub total_estimated_cost_ms: f64 }

pub struct QueryPlanner { router: Arc<KleinbergRouter>, config: PlannerConfig, plan_count: RwLock<u64> }

impl QueryPlanner {
    pub fn new(router: Arc<KleinbergRouter>) -> Self { Self { router, config: PlannerConfig::default(), plan_count: RwLock::new(0) } }

    pub fn classify_query(&self, query_embedding: &[f32], nodes: &[KGNode]) -> QueryClassification {
        if nodes.is_empty() { return QueryClassification { query_type: QueryType::Specific, max_similarity: 0.0, variance: 0.0, top_nodes: vec![], confidence: 0.0 }; }
        let mut similarities: Vec<(String, f64)> = nodes.iter().map(|n| (n.node_id.clone(), cosine_similarity(query_embedding, &n.centroid))).collect();
        similarities.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        let max_sim = similarities.first().map(|s| s.1).unwrap_or(0.0);
        let mean: f64 = similarities.iter().map(|s| s.1).sum::<f64>() / similarities.len() as f64;
        let variance = similarities.iter().map(|s| (s.1 - mean).powi(2)).sum::<f64>() / similarities.len() as f64;
        let top_nodes: Vec<String> = similarities.iter().take(5).map(|s| s.0.clone()).collect();
        let (query_type, confidence) = if max_sim >= self.config.specific_threshold { (QueryType::Specific, max_sim.min(1.0)) }
        else if variance >= self.config.exploratory_variance { (QueryType::Exploratory, (variance * 5.0).min(1.0)) }
        else { (QueryType::Consensus, 0.7) };
        QueryClassification { query_type, max_similarity: max_sim, variance, top_nodes, confidence }
    }

    pub async fn build_plan(&self, query_embedding: &[f32], nodes: &[KGNode]) -> QueryPlan {
        let classification = self.classify_query(query_embedding, nodes);
        let mut count = self.plan_count.write().await; *count += 1; let plan_id = format!("plan-{}", *count);
        let (nodes_to_query, strategy) = match classification.query_type {
            QueryType::Specific => (classification.top_nodes[..self.config.specific_max_nodes.min(classification.top_nodes.len())].to_vec(), AggregationStrategy::Max),
            QueryType::Exploratory => (classification.top_nodes[..self.config.exploratory_max_nodes.min(classification.top_nodes.len())].to_vec(), AggregationStrategy::Sum),
            QueryType::Consensus => (classification.top_nodes[..5.min(classification.top_nodes.len())].to_vec(), AggregationStrategy::Sum),
        };
        QueryPlan { plan_id, query_type: classification.query_type, stages: vec![QueryPlanStage { stage_id: 0, nodes: nodes_to_query, strategy, parallel: true, depends_on: vec![], estimated_cost_ms: 100.0 }], total_estimated_cost_ms: 100.0 }
    }
}
', [SpecT, ExplVar]).

% =============================================================================
% KG TOPOLOGY PHASE 5a: HIERARCHICAL FEDERATION CODE GENERATION (Rust)
% =============================================================================

%% compile_hierarchical_federation_rust(+Options, -Code)
%  Generate Rust HierarchicalFederatedEngine with multi-level routing.

compile_hierarchical_federation_rust(Options, Code) :-
    ( member(hierarchical(HierOpts), Options), is_list(HierOpts) -> true ; HierOpts = [] ),
    ( member(min_nodes_per_region(MinNodes), HierOpts) -> true ; MinNodes = 2 ),
    ( member(drill_down_k(DrillK), HierOpts) -> true ; DrillK = 2 ),

    format(string(Code), '
// KG Topology Phase 5a: Hierarchical Federation
// Generated from Prolog service definition

#[derive(Debug, Clone)]
pub struct HierarchyConfig { pub min_nodes_per_region: usize, pub centroid_similarity_threshold: f64 }

impl Default for HierarchyConfig { fn default() -> Self { Self { min_nodes_per_region: ~w, centroid_similarity_threshold: 0.5 } } }

#[derive(Debug, Clone)]
pub struct RegionalNode { pub region_id: String, pub centroid: Vec<f32>, pub child_nodes: Vec<String>, pub level: usize }

pub struct NodeHierarchy {
    config: HierarchyConfig,
    regions: RwLock<HashMap<String, RegionalNode>>,
    node_to_region: RwLock<HashMap<String, String>>,
    leaf_nodes: RwLock<HashMap<String, KGNode>>,
}

impl NodeHierarchy {
    pub fn new(config: HierarchyConfig) -> Self { Self { config, regions: RwLock::new(HashMap::new()), node_to_region: RwLock::new(HashMap::new()), leaf_nodes: RwLock::new(HashMap::new()) } }

    pub async fn build_from_nodes(&self, nodes: Vec<KGNode>) {
        let mut leaves = self.leaf_nodes.write().await; let mut regions = self.regions.write().await; let mut n2r = self.node_to_region.write().await;
        leaves.clear(); regions.clear(); n2r.clear();
        for n in &nodes { leaves.insert(n.node_id.clone(), n.clone()); }
        let mut assigned: std::collections::HashSet<String> = std::collections::HashSet::new();
        let mut group_id = 0;
        for node in &nodes {
            if assigned.contains(&node.node_id) || node.centroid.is_empty() { continue; }
            let mut cluster = vec![node.clone()]; assigned.insert(node.node_id.clone());
            for other in &nodes {
                if assigned.contains(&other.node_id) || other.centroid.is_empty() { continue; }
                if cosine_similarity(&node.centroid, &other.centroid) >= self.config.centroid_similarity_threshold { cluster.push(other.clone()); assigned.insert(other.node_id.clone()); }
            }
            let region_id = format!("region_{}", group_id); group_id += 1;
            let avg: Vec<f32> = if !cluster.is_empty() { (0..cluster[0].centroid.len()).map(|i| cluster.iter().map(|n| n.centroid.get(i).unwrap_or(&0.0)).sum::<f32>() / cluster.len() as f32).collect() } else { vec![] };
            let child_nodes: Vec<String> = cluster.iter().map(|n| n.node_id.clone()).collect();
            for cid in &child_nodes { n2r.insert(cid.clone(), region_id.clone()); }
            regions.insert(region_id.clone(), RegionalNode { region_id, centroid: avg, child_nodes, level: 0 });
        }
    }

    pub async fn get_regional_nodes(&self, level: usize) -> Vec<RegionalNode> { self.regions.read().await.values().filter(|r| r.level == level).cloned().collect() }
    pub async fn get_children(&self, region_id: &str) -> Vec<String> { self.regions.read().await.get(region_id).map(|r| r.child_nodes.clone()).unwrap_or_default() }
}

pub struct HierarchicalFederatedEngine { engine: FederatedQueryEngine, hierarchy: NodeHierarchy, drill_down_k: usize }

impl HierarchicalFederatedEngine {
    pub fn new(router: Arc<KleinbergRouter>) -> Self { Self { engine: FederatedQueryEngine::new(router), hierarchy: NodeHierarchy::new(HierarchyConfig::default()), drill_down_k: ~w } }
}
', [MinNodes, DrillK]).

% =============================================================================
% KG TOPOLOGY PHASE 5d: STREAMING FEDERATION CODE GENERATION (Rust)
% =============================================================================

%% compile_streaming_federation_rust(+Options, -Code)
%  Generate Rust StreamingFederatedEngine with async partial results.

compile_streaming_federation_rust(Options, Code) :-
    ( member(streaming(StreamOpts), Options), is_list(StreamOpts) -> true ; StreamOpts = [] ),
    ( member(min_confidence(MinConf), StreamOpts) -> true ; MinConf = 0.3 ),

    format(string(Code), '
// KG Topology Phase 5d: Streaming Federation
// Generated from Prolog service definition

use tokio::sync::mpsc;

#[derive(Debug, Clone)]
pub struct StreamingConfig { pub min_confidence: f64 }

impl Default for StreamingConfig { fn default() -> Self { Self { min_confidence: ~w } } }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PartialResult {
    pub results: Vec<AggregatedResult>,
    pub confidence: f64,
    pub nodes_responded: usize,
    pub nodes_total: usize,
    pub is_final: bool,
}

pub struct StreamingFederatedEngine { engine: FederatedQueryEngine, config: StreamingConfig }

impl StreamingFederatedEngine {
    pub fn new(router: Arc<KleinbergRouter>) -> Self { Self { engine: FederatedQueryEngine::new(router), config: StreamingConfig::default() } }

    pub async fn streaming_query(&self, query_text: &str, query_embedding: &[f32], top_k: usize) -> Result<mpsc::Receiver<PartialResult>, Box<dyn std::error::Error + Send + Sync>> {
        let nodes = self.engine.router.discover_nodes(None)?;
        let (tx, rx) = mpsc::channel(nodes.len() + 1);
        let nodes_total = nodes.len(); let min_conf = self.config.min_confidence;
        let query_text = query_text.to_string(); let embedding = query_embedding.to_vec();
        tokio::spawn(async move {
            let mut aggregated: HashMap<String, AggregatedResult> = HashMap::new();
            let mut responded = 0;
            for node in nodes {
                responded += 1;
                let confidence = responded as f64 / nodes_total as f64;
                let results: Vec<_> = aggregated.values().cloned().collect();
                if confidence >= min_conf {
                    let _ = tx.send(PartialResult { results: results.clone(), confidence, nodes_responded: responded, nodes_total, is_final: false }).await;
                }
            }
            let results: Vec<_> = aggregated.values().cloned().collect();
            let _ = tx.send(PartialResult { results, confidence: responded as f64 / nodes_total as f64, nodes_responded: responded, nodes_total, is_final: true }).await;
        });
        Ok(rx)
    }
}
', [MinConf]).


% =============================================================================
% KG TOPOLOGY PHASE 7: PROPER SMALL-WORLD NETWORK CODE GENERATION (RUST)
% =============================================================================
%
% This phase generates Rust code for proper Kleinberg small-world networks.
% - k_local: Number of nearest-neighbor connections
% - k_long: Number of probability-weighted long-range shortcuts
% - alpha: Distance exponent for long-range link probability P(v) ~ 1/d^alpha

%% compile_small_world_proper_rust(+Options, -Code)
%  Generate Rust ProperSmallWorldNetwork implementation.

compile_small_world_proper_rust(Options, Code) :-
    ( member(k_local(KLocal), Options) -> true ; KLocal = 10 ),
    ( member(k_long(KLong), Options) -> true ; KLong = 5 ),
    ( member(alpha(Alpha), Options) -> true ; Alpha = 2.0 ),

    format(string(Code), '
// KG Topology Phase 7: Proper Small-World Network
// Generated from Prolog service definition
//
// Network structure enables true Kleinberg routing with O(log²n) path length.
// k_local = ~w nearest neighbors, k_long = ~w long-range shortcuts

use std::collections::{HashMap, HashSet};
use std::sync::{Arc, RwLock};
use rand::Rng;

// Configuration constants
pub const K_LOCAL: usize = ~w;
pub const K_LONG: usize = ~w;
pub const ALPHA: f64 = ~w;

/// Neighbor with precomputed angle for binary search
#[derive(Clone, Debug)]
pub struct Neighbor {
    pub node_id: String,
    pub angle: f64,  // Cosine-based angle
    pub is_long: bool,
}

/// Node in the small-world network
pub struct SmallWorldNode {
    pub id: String,
    pub centroid: Vec<f32>,
    pub neighbors: Vec<Neighbor>,  // Sorted by angle
}

/// Proper small-world network with k_local + k_long structure
pub struct SmallWorldNetwork {
    pub nodes: RwLock<HashMap<String, Arc<RwLock<SmallWorldNode>>>>,
    pub k_local: usize,
    pub k_long: usize,
    pub alpha: f64,
}

impl SmallWorldNetwork {
    pub fn new() -> Self {
        Self {
            nodes: RwLock::new(HashMap::new()),
            k_local: K_LOCAL,
            k_long: K_LONG,
            alpha: ALPHA,
        }
    }

    /// Add a node and establish connections
    pub fn add_node(&self, node_id: &str, centroid: Vec<f32>) {
        let node = Arc::new(RwLock::new(SmallWorldNode {
            id: node_id.to_string(),
            centroid: centroid.clone(),
            neighbors: Vec::new(),
        }));

        {
            let mut nodes = self.nodes.write().unwrap();
            nodes.insert(node_id.to_string(), node.clone());
        }

        if self.nodes.read().unwrap().len() > 1 {
            self.connect_node(node_id, &centroid);
        }
    }

    /// Establish k_local + k_long connections
    fn connect_node(&self, node_id: &str, centroid: &[f32]) {
        let nodes = self.nodes.read().unwrap();

        // Collect similarities to all other nodes
        let mut others: Vec<(String, f64)> = nodes
            .iter()
            .filter(|(id, _)| *id != node_id)
            .map(|(id, n)| {
                let other = n.read().unwrap();
                (id.clone(), cosine_similarity(centroid, &other.centroid))
            })
            .collect();

        // Sort by similarity (descending)
        others.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        let mut neighbors = Vec::new();

        // Add k_local nearest neighbors
        let local_count = self.k_local.min(others.len());
        for (id, _) in others.iter().take(local_count) {
            let other = nodes.get(id).unwrap().read().unwrap();
            let angle = compute_cosine_angle(centroid, &other.centroid);
            neighbors.push(Neighbor {
                node_id: id.clone(),
                angle,
                is_long: false,
            });
        }

        // Add k_long shortcuts using distance-weighted probability
        if others.len() > self.k_local {
            let remaining = &others[local_count..];
            let long_count = self.k_long.min(remaining.len());

            // Compute weights: P(v) ~ 1/distance^alpha
            let weights: Vec<f64> = remaining
                .iter()
                .map(|(_, sim)| {
                    let distance = (1.0 - sim).max(0.001);
                    1.0 / distance.powf(self.alpha)
                })
                .collect();
            let total_weight: f64 = weights.iter().sum();

            // Sample k_long shortcuts
            let mut selected = HashSet::new();
            let mut rng = rand::thread_rng();
            while selected.len() < long_count {
                let r: f64 = rng.gen::<f64>() * total_weight;
                let mut cumulative = 0.0;
                for (i, w) in weights.iter().enumerate() {
                    cumulative += w;
                    if r <= cumulative && !selected.contains(&i) {
                        selected.insert(i);
                        let (id, _) = &remaining[i];
                        let other = nodes.get(id).unwrap().read().unwrap();
                        let angle = compute_cosine_angle(centroid, &other.centroid);
                        neighbors.push(Neighbor {
                            node_id: id.clone(),
                            angle,
                            is_long: true,
                        });
                        break;
                    }
                }
            }
        }

        // Sort neighbors by angle for binary search
        neighbors.sort_by(|a, b| a.angle.partial_cmp(&b.angle).unwrap_or(std::cmp::Ordering::Equal));

        // Update node
        drop(nodes);
        let nodes = self.nodes.read().unwrap();
        if let Some(node) = nodes.get(node_id) {
            node.write().unwrap().neighbors = neighbors;
        }
    }

    /// Route to target using greedy routing on small-world structure
    pub fn route_to_target(&self, query: &[f32], max_hops: usize) -> Vec<String> {
        let nodes = self.nodes.read().unwrap();
        if nodes.is_empty() {
            return Vec::new();
        }

        // Start from first node
        let mut current_id = nodes.keys().next().unwrap().clone();
        let mut path = vec![current_id.clone()];
        let mut visited: HashSet<String> = HashSet::new();
        visited.insert(current_id.clone());

        for _ in 0..max_hops {
            let current = nodes.get(&current_id).unwrap().read().unwrap();
            let current_sim = cosine_similarity(&current.centroid, query);

            // Find best neighbor using binary search
            let query_angle = compute_cosine_angle(&current.centroid, query);
            let neighbors = &current.neighbors;

            if neighbors.is_empty() {
                break;
            }

            // Binary search for closest angle
            let idx = neighbors.partition_point(|n| n.angle < query_angle);

            // Check neighbors around index
            let mut best_id: Option<String> = None;
            let mut best_sim: f64 = -1.0;

            for check_idx in [idx.saturating_sub(1), idx, (idx + 1).min(neighbors.len().saturating_sub(1))] {
                if check_idx < neighbors.len() {
                    let nb = &neighbors[check_idx];
                    if !visited.contains(&nb.node_id) {
                        if let Some(neighbor_node) = nodes.get(&nb.node_id) {
                            let neighbor = neighbor_node.read().unwrap();
                            let sim = cosine_similarity(&neighbor.centroid, query);
                            if sim > best_sim {
                                best_sim = sim;
                                best_id = Some(nb.node_id.clone());
                            }
                        }
                    }
                }
            }

            match best_id {
                Some(next_id) if best_sim > current_sim => {
                    visited.insert(next_id.clone());
                    path.push(next_id.clone());
                    current_id = next_id;
                }
                _ => break,  // No improvement or no unvisited neighbors
            }
        }

        path
    }
}

/// Compute cosine-based angle (not 2D projection)
fn compute_cosine_angle(a: &[f32], b: &[f32]) -> f64 {
    let sim = cosine_similarity(a, b);
    sim.clamp(-1.0, 1.0).acos()
}

fn cosine_similarity(a: &[f32], b: &[f32]) -> f64 {
    let (dot, norm_a, norm_b) = a.iter().zip(b.iter()).fold((0.0, 0.0, 0.0), |(d, na, nb), (x, y)| {
        (d + (*x as f64) * (*y as f64), na + (*x as f64).powi(2), nb + (*y as f64).powi(2))
    });
    if norm_a == 0.0 || norm_b == 0.0 { 0.0 } else { dot / (norm_a.sqrt() * norm_b.sqrt()) }
}
', [KLocal, KLong, KLocal, KLong, Alpha]).


% =============================================================================
% KG TOPOLOGY PHASE 8: MULTI-INTERFACE NODE CODE GENERATION (RUST)
% =============================================================================

%% compile_multi_interface_node_rust(+Options, -Code)
%  Generate Rust MultiInterfaceNode implementation with power-law distribution.

compile_multi_interface_node_rust(Options, Code) :-
    ( member(gamma(Gamma), Options) -> true ; Gamma = 2.5 ),
    ( member(min_interfaces(MinInt), Options) -> true ; MinInt = 1 ),
    ( member(max_interfaces(MaxInt), Options) -> true ; MaxInt = 100 ),

    format(string(Code), '
// KG Topology Phase 8: Multi-Interface Nodes
// Generated from Prolog service definition
//
// Scale-free distribution: P(k) ~ k^(-gamma) where k = interface count

use std::sync::RwLock;
use rand::Rng;

// Configuration
pub const GAMMA: f64 = ~w;
pub const MIN_INTERFACES: usize = ~w;
pub const MAX_INTERFACES: usize = ~w;

/// Semantic interface on a node
#[derive(Clone, Debug)]
pub struct Interface {
    pub id: String,
    pub centroid: Vec<f32>,
    pub topics: Vec<String>,
}

/// Connection entry in unified sorted array
#[derive(Clone, Debug)]
pub struct ConnectionEntry {
    pub angle: f64,
    pub interface_id: String,
    pub target_node: Option<String>,
}

/// Node with multiple interfaces (scale-free distribution)
pub struct MultiInterfaceNode {
    pub node_id: String,
    pub interfaces: Vec<Interface>,
    pub all_connections: RwLock<Vec<ConnectionEntry>>,  // Sorted by angle
}

/// Generate interface count from power-law distribution
pub fn generate_scale_free_interface_count() -> usize {
    // Inverse transform sampling: x = x_min * (1 - u)^(1 / (1 - gamma))
    let mut rng = rand::thread_rng();
    let u: f64 = rng.gen();
    let x = (MIN_INTERFACES as f64) * (1.0 - u).powf(1.0 / (1.0 - GAMMA));
    (x as usize).clamp(MIN_INTERFACES, MAX_INTERFACES)
}

impl MultiInterfaceNode {
    pub fn new(node_id: &str) -> Self {
        Self {
            node_id: node_id.to_string(),
            interfaces: Vec::with_capacity(generate_scale_free_interface_count()),
            all_connections: RwLock::new(Vec::new()),
        }
    }

    /// Add an interface
    pub fn add_interface(&mut self, id: &str, centroid: Vec<f32>, topics: Vec<String>) {
        self.interfaces.push(Interface {
            id: id.to_string(),
            centroid,
            topics,
        });
    }

    /// Build unified index sorted by angle for binary search
    pub fn build_unified_index(&self, reference: &[f32]) {
        let mut connections: Vec<ConnectionEntry> = self
            .interfaces
            .iter()
            .map(|iface| {
                let angle = compute_cosine_angle(&iface.centroid, reference);
                ConnectionEntry {
                    angle,
                    interface_id: iface.id.clone(),
                    target_node: None,
                }
            })
            .collect();

        connections.sort_by(|a, b| a.angle.partial_cmp(&b.angle).unwrap_or(std::cmp::Ordering::Equal));

        *self.all_connections.write().unwrap() = connections;
    }

    /// Find closest interface using binary search
    pub fn find_closest_interface(&self, query: &[f32], reference: &[f32]) -> Option<String> {
        let connections = self.all_connections.read().unwrap();
        if connections.is_empty() {
            return None;
        }

        let query_angle = compute_cosine_angle(query, reference);

        // Binary search
        let idx = connections.partition_point(|c| c.angle < query_angle);

        // Check neighbors
        let mut best_id: Option<String> = None;
        let mut best_dist = f64::MAX;

        for check_idx in [idx.saturating_sub(1), idx] {
            if check_idx < connections.len() {
                let dist = (connections[check_idx].angle - query_angle).abs();
                if dist < best_dist {
                    best_dist = dist;
                    best_id = Some(connections[check_idx].interface_id.clone());
                }
            }
        }

        best_id
    }
}

fn compute_cosine_angle(a: &[f32], b: &[f32]) -> f64 {
    let (dot, norm_a, norm_b) = a.iter().zip(b.iter()).fold((0.0, 0.0, 0.0), |(d, na, nb), (x, y)| {
        (d + (*x as f64) * (*y as f64), na + (*x as f64).powi(2), nb + (*y as f64).powi(2))
    });
    if norm_a == 0.0 || norm_b == 0.0 {
        std::f64::consts::FRAC_PI_2
    } else {
        let sim = (dot / (norm_a.sqrt() * norm_b.sqrt())).clamp(-1.0, 1.0);
        sim.acos()
    }
}
', [Gamma, MinInt, MaxInt]).

% ============================================================================
% MULTIFILE DISPATCH - Tail Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/tail_recursion').
:- multifile tail_recursion:compile_tail_pattern/9.

tail_recursion:compile_tail_pattern(rust, PredStr, Arity, _BaseClauses, _RecClauses, _AccPos, StepOp, _ExitAfterResult, Code) :-
    step_op_to_rust(StepOp, RustStepExpr),
    (   Arity =:= 3 ->
        format(string(Code),
'// Generated by UnifyWeaver Rust Target - Tail Recursion (multifile dispatch)
// Predicate: ~w/~w

fn ~w(items: &[i64]) -> i64 {
    let mut acc: i64 = 0;
    for &item in items {
        acc = ~w;
    }
    acc
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 2 {
        let items: Vec<i64> = args[1]
            .split('','')
            .filter_map(|s| s.parse().ok())
            .collect();
        println!("{}", ~w(&items));
    }
}
', [PredStr, Arity, PredStr, RustStepExpr, PredStr])
    ;   Arity =:= 2 ->
        format(string(Code),
'// Generated by UnifyWeaver Rust Target - Tail Recursion (binary, multifile dispatch)
// Predicate: ~w/~w

fn ~w(items: &[String]) -> i64 {
    items.len() as i64
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 2 {
        let items: Vec<String> = args[1]
            .split('','')
            .map(|s| s.to_string())
            .collect();
        println!("{}", ~w(&items));
    }
}
', [PredStr, Arity, PredStr, PredStr])
    ;   fail
    ).

tail_expr_to_rust(_ + Const, RustExpr) :- integer(Const), !, format(atom(RustExpr), 'acc + ~w', [Const]).
tail_expr_to_rust(_ + _, 'acc + item') :- !.
tail_expr_to_rust(_ - _, 'acc - item') :- !.
tail_expr_to_rust(_ * _, 'acc * item') :- !.
tail_expr_to_rust(_, 'acc + 1').

% ============================================================================
% MULTIFILE DISPATCH - Linear Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/linear_recursion').
:- multifile linear_recursion:compile_linear_pattern/8.

linear_recursion:compile_linear_pattern(rust, PredStr, Arity, BaseClauses, _RecClauses, MemoEnabled, _MemoStrategy, Code) :-
    (   Arity =:= 2 ->
        linear_fold_rust(PredStr, BaseClauses, MemoEnabled, Code)
    ;   linear_generic_rust(PredStr, Arity, MemoEnabled, Code)
    ).

linear_fold_rust(PredStr, BaseClauses, MemoEnabled, Code) :-
    linear_recursion:extract_base_case_info(BaseClauses, BaseInput, BaseOutput),
    linear_recursion:detect_input_type(BaseInput, InputType),
    (   MemoEnabled = true ->
        MemoUse = "use std::collections::HashMap;",
        format(string(MemoParam), ', memo: &mut HashMap<i64, i64>', []),
        format(string(MemoCheck), '    if let Some(&v) = memo.get(&n) { return v; }', []),
        format(string(MemoStore), '    memo.insert(n, result);', []),
        format(string(MemoMain), '    let mut memo = HashMap::new();', []),
        format(string(MemoArg), ', &mut memo', [])
    ;   MemoUse = "// Memoization disabled",
        MemoParam = '',
        MemoCheck = '',
        MemoStore = '',
        MemoMain = '',
        MemoArg = ''
    ),
    % Extract fold expression from recursive clauses
    atom_string(Pred, PredStr),
    functor(Head, Pred, 2),
    findall(clause(Head, Body), user:clause(Head, Body), AllClauses),
    partition(linear_recursion:is_recursive_clause(Pred), AllClauses, ActualRec, _),
    (   ActualRec = [clause(RHead, RBody)|_] ->
        RHead =.. [_, InputVar, _],
        linear_recursion:find_recursive_call(RBody, RecCall),
        RecCall =.. [_, _, AccVar],
        linear_recursion:find_last_is_expression(RBody, _ is FoldExpr),
        translate_fold_expr_rust(FoldExpr, InputVar, AccVar, RustOp)
    ;   RustOp = "current * result"
    ),
    (   InputType = numeric ->
        format(string(Code),
'// Generated by UnifyWeaver Rust Target - Linear Recursion (numeric, multifile dispatch)
// Predicate: ~w/2

~w

fn ~w(n: i64~w) -> i64 {
~w
    if n == ~w { return ~w; }
    let mut result: i64 = ~w;
    for current in 1..=n {
        result = ~w;
    }
~w
    result
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
~w
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n~w));
    }
}
', [PredStr, MemoUse, PredStr, MemoParam, MemoCheck, BaseInput, BaseOutput, BaseOutput, RustOp, MemoStore, MemoMain, PredStr, MemoArg])
    ;   InputType = list ->
        % Re-extract fold with head variable for list patterns
        (   ActualRec = [clause(LRHead, LRBody)|_] ->
            linear_recursion:find_last_is_expression(LRBody, _ is LFoldExpr),
            linear_recursion:find_recursive_call(LRBody, LRecCall),
            LRecCall =.. [_, _, LAccVar],
            LRHead =.. [_, [LHeadVar|_], _],
            translate_list_fold_rust(LFoldExpr, LHeadVar, LAccVar, ListRustOp)
        ;   ListRustOp = "result + current"
        ),
        format(string(Code),
'// Generated by UnifyWeaver Rust Target - Linear Recursion (list, multifile dispatch)
// Predicate: ~w/2

fn ~w(lst: &[i64]) -> i64 {
    if lst.is_empty() { return ~w; }
    lst.iter().fold(~w_i64, |result, &current| ~w)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 2 {
        let items: Vec<i64> = args[1]
            .split('','')
            .filter_map(|s| s.parse().ok())
            .collect();
        println!("{}", ~w(&items));
    }
}
', [PredStr, PredStr, BaseOutput, BaseOutput, ListRustOp, PredStr])
    ;   linear_generic_rust(PredStr, 2, MemoEnabled, Code)
    ).

linear_generic_rust(PredStr, Arity, MemoEnabled, Code) :-
    (   MemoEnabled = true ->
        format(string(Code),
'// Generated by UnifyWeaver Rust Target - Linear Recursion (generic, multifile dispatch)
// Predicate: ~w/~w

use std::collections::HashMap;

fn ~w(n: i64, memo: &mut HashMap<i64, i64>) -> i64 {
    if let Some(&v) = memo.get(&n) { return v; }
    let result;
    if n <= 0 { result = 0; }
    else if n == 1 { result = 1; }
    else { result = ~w(n - 1, memo) + n; }
    memo.insert(n, result);
    result
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut memo = HashMap::new();
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n, &mut memo));
    }
}
', [PredStr, Arity, PredStr, PredStr, PredStr])
    ;   format(string(Code),
'// Generated by UnifyWeaver Rust Target - Linear Recursion (generic, multifile dispatch)
// Predicate: ~w/~w

fn ~w(n: i64) -> i64 {
    if n <= 0 { return 0; }
    if n == 1 { return 1; }
    ~w(n - 1) + n
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n));
    }
}
', [PredStr, Arity, PredStr, PredStr, PredStr])
    ).

translate_fold_expr_rust(A * B, IV, AV, E) :- translate_rust_term(A, IV, AV, AT), translate_rust_term(B, IV, AV, BT), format(string(E), '~w * ~w', [AT, BT]).
translate_fold_expr_rust(A + B, IV, AV, E) :- translate_rust_term(A, IV, AV, AT), translate_rust_term(B, IV, AV, BT), format(string(E), '~w + ~w', [AT, BT]).
translate_fold_expr_rust(A - B, IV, AV, E) :- translate_rust_term(A, IV, AV, AT), translate_rust_term(B, IV, AV, BT), format(string(E), '~w - ~w', [AT, BT]).
translate_fold_expr_rust(T, IV, AV, E) :- translate_rust_term(T, IV, AV, E).

translate_rust_term(T, IV, _, 'current') :- T == IV, !.
translate_rust_term(T, _, AV, 'result') :- T == AV, !.
translate_rust_term(N, _, _, S) :- integer(N), !, format(string(S), '~w', [N]).
translate_rust_term(A, _, _, S) :- format(string(S), '~w', [A]).

%% translate_list_fold_rust(+PrologExpr, +HeadVar, +AccVar, -RustExpr)
%  Maps HeadVar -> 'current' and AccVar -> 'result' for fold closures.
translate_list_fold_rust(A * B, HV, AV, E) :- translate_list_term_rust(A, HV, AV, AT), translate_list_term_rust(B, HV, AV, BT), format(string(E), '~w * ~w', [AT, BT]).
translate_list_fold_rust(A + B, HV, AV, E) :- translate_list_term_rust(A, HV, AV, AT), translate_list_term_rust(B, HV, AV, BT), format(string(E), '~w + ~w', [AT, BT]).
translate_list_fold_rust(A - B, HV, AV, E) :- translate_list_term_rust(A, HV, AV, AT), translate_list_term_rust(B, HV, AV, BT), format(string(E), '~w - ~w', [AT, BT]).
translate_list_fold_rust(T, HV, AV, E) :- translate_list_term_rust(T, HV, AV, E).

translate_list_term_rust(T, HV, _, 'current') :- T == HV, !.
translate_list_term_rust(T, _, AV, 'result') :- T == AV, !.
translate_list_term_rust(N, _, _, S) :- integer(N), !, format(string(S), '~w', [N]).
translate_list_term_rust(A, _, _, S) :- format(string(S), '~w', [A]).

% ============================================================================
% MULTIFILE DISPATCH - Tree Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/tree_recursion').
:- multifile tree_recursion:compile_tree_pattern/6.

tree_recursion:compile_tree_pattern(rust, _Pattern, Pred, _Arity, _UseMemo, RustCode) :-
    atom_string(Pred, PredStr),
    format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Tree Recursion (fibonacci, multifile dispatch)

use std::collections::HashMap;

fn ~w(n: i64, memo: &mut HashMap<i64, i64>) -> i64 {
    if let Some(&v) = memo.get(&n) { return v; }
    if n <= 0 { return 0; }
    if n == 1 { return 1; }
    let result = ~w(n - 1, memo) + ~w(n - 2, memo);
    memo.insert(n, result);
    result
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut memo = HashMap::new();
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n, &mut memo));
    }
}
', [PredStr, PredStr, PredStr, PredStr]).

% ============================================================================
% MULTIFILE DISPATCH - Multicall Linear Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/multicall_linear_recursion').
:- multifile multicall_linear_recursion:compile_multicall_pattern/6.

multicall_linear_recursion:compile_multicall_pattern(rust, PredStr, BaseClauses, _RecClauses, _MemoEnabled, RustCode) :-
    findall(BaseCaseCode, (
        member(clause(BHead, _), BaseClauses),
        BHead =.. [_P, BInput, BOutput],
        format(string(BaseCaseCode), '    if n == ~w { return ~w; }', [BInput, BOutput])
    ), BaseCaseCodes),
    atomic_list_concat(BaseCaseCodes, '\n', BaseCaseStr),
    format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Multicall Linear Recursion (multifile dispatch)

use std::collections::HashMap;

fn ~w(n: i64, memo: &mut HashMap<i64, i64>) -> i64 {
~w
    if let Some(&v) = memo.get(&n) { return v; }
    let result = ~w(n - 1, memo) + ~w(n - 2, memo);
    memo.insert(n, result);
    result
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut memo = HashMap::new();
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n, &mut memo));
    }
}
', [PredStr, BaseCaseStr, PredStr, PredStr, PredStr]).

% ============================================================================
% MULTIFILE DISPATCH - Direct Multi-Call Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/direct_multi_call_recursion').
:- multifile direct_multi_call_recursion:compile_direct_multicall_pattern/5.

direct_multi_call_recursion:compile_direct_multicall_pattern(rust, PredStr, BaseClauses, RecClause, RustCode) :-
    findall(BaseCaseCode, (
        member(clause(BHead, _), BaseClauses),
        BHead =.. [_P, BInput, BOutput],
        format(string(BaseCaseCode), '    if input == ~w { memo.insert(input, ~w); return ~w; }', [BInput, BOutput, BOutput])
    ), BaseCaseCodes),
    atomic_list_concat(BaseCaseCodes, '\n', BaseCaseStr),
    RecClause = clause(RecHead, RecBody),
    RecHead =.. [Pred, _IV, _OV],
    extract_body_components(RecBody, Pred, Computations, RecCalls, Aggregation),
    % Build a stable variable-to-name mapping BEFORE any findall/GC.
    % GC can relocate variables, changing the IDs that term_string reports.
    % We use == (logical identity) for lookup, which survives GC.
    term_variables((Computations, RecCalls, Aggregation), AllVars),
    build_rust_var_map(AllVars, 0, VarMap),
    direct_computations_rust_m(Computations, VarMap, ComputationsCode),
    direct_recursive_calls_rust_m(RecCalls, PredStr, VarMap, RecCallsCode),
    direct_aggregation_rust_m(Aggregation, VarMap, AggCode),
    format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Direct Multicall Recursion (multifile dispatch)

use std::collections::HashMap;

fn ~w(input: i64, memo: &mut HashMap<i64, i64>) -> i64 {
    if let Some(&v) = memo.get(&input) { return v; }
~w
~w
~w
~w
    memo.insert(input, result);
    result
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut memo = HashMap::new();
    if args.len() >= 2 {
        let n: i64 = args[1].parse().unwrap();
        println!("{}", ~w(n, &mut memo));
    }
}
', [PredStr, BaseCaseStr, ComputationsCode, RecCallsCode, AggCode, PredStr]).

%% Build a stable var → name mapping using sequential numbering.
%% Uses == (logical identity) for lookup, which survives GC.
build_rust_var_map([], _, []).
build_rust_var_map([V|Vs], N, [V-Name|Rest]) :-
    format(atom(Name), 'v~w', [N]),
    N1 is N + 1,
    build_rust_var_map(Vs, N1, Rest).

rust_var_lookup(Var, [V-Name|_], Name) :- Var == V, !.
rust_var_lookup(Var, [_|Rest], Name) :- rust_var_lookup(Var, Rest, Name).

%% Mapped versions of code generators (GC-safe).
direct_computations_rust_m([], _, '').
direct_computations_rust_m([Var is Expr|Rest], VarMap, Code) :-
    rust_var_lookup(Var, VarMap, VarName),
    direct_translate_expr_rust(Expr, RustExpr),
    format(string(Line), '    let ~w: i64 = ~w;', [VarName, RustExpr]),
    direct_computations_rust_m(Rest, VarMap, RestCode),
    (Rest = [] -> Code = Line ; atomic_list_concat([Line, RestCode], '\n', Code)).

direct_recursive_calls_rust_m([], _, _, '').
direct_recursive_calls_rust_m([RecCall|Rest], PredStr, VarMap, Code) :-
    RecCall =.. [_Pred, ArgVar, ResultVar],
    rust_var_lookup(ArgVar, VarMap, ArgName),
    rust_var_lookup(ResultVar, VarMap, ResName),
    format(string(Line), '    let ~w: i64 = ~w(~w, memo);', [ResName, PredStr, ArgName]),
    direct_recursive_calls_rust_m(Rest, PredStr, VarMap, RestCode),
    (Rest = [] -> Code = Line ; atomic_list_concat([Line, RestCode], '\n', Code)).

direct_aggregation_rust_m(_ is Expr, VarMap, Code) :-
    direct_translate_agg_expr_rust_m(Expr, VarMap, RustExpr),
    format(string(Code), '    let result: i64 = ~w;', [RustExpr]).

direct_translate_agg_expr_rust_m(A + B, VarMap, Expr) :-
    rust_var_lookup(A, VarMap, AName), rust_var_lookup(B, VarMap, BName),
    format(string(Expr), '~w + ~w', [AName, BName]).
direct_translate_agg_expr_rust_m(A * B, VarMap, Expr) :-
    rust_var_lookup(A, VarMap, AName), rust_var_lookup(B, VarMap, BName),
    format(string(Expr), '~w * ~w', [AName, BName]).

%% direct_var_to_rust_name(+Var, -RustName)
%  Convert Prolog variable to valid Rust identifier.
%  Internal var names like _G12345 become v12345 in Rust.
direct_var_to_rust_name(Var, RustName) :-
    (   var(Var) ->
        term_string(Var, VarStr),
        atom_string(VarAtom, VarStr),
        downcase_atom(VarAtom, LowerName),
        ensure_rust_identifier(LowerName, RustName)
    ;   atom(Var) ->
        downcase_atom(Var, LowerName),
        ensure_rust_identifier(LowerName, RustName)
    ;   term_string(Var, VarStr),
        atom_string(VarAtom, VarStr),
        downcase_atom(VarAtom, LowerName),
        ensure_rust_identifier(LowerName, RustName)
    ).

ensure_rust_identifier(Name, ValidName) :-
    atom_chars(Name, [First|Rest]),
    (   (First = '_' ; char_type(First, digit)) ->
        atom_chars(ValidName, [v|Rest])
    ;   ValidName = Name
    ).

direct_translate_expr_rust(N - K, Expr) :- var(N), integer(K), !,
    format(string(Expr), 'input - ~w', [K]).
direct_translate_expr_rust(N + K, Expr) :- var(N), integer(K), K < 0, !,
    AbsK is abs(K), format(string(Expr), 'input - ~w', [AbsK]).
direct_translate_expr_rust(N + K, Expr) :- var(N), integer(K), !,
    format(string(Expr), 'input + ~w', [K]).
direct_translate_expr_rust(Expr, 'input') :- var(Expr), !.
direct_translate_expr_rust(N, S) :- integer(N), !, format(string(S), '~w', [N]).
direct_translate_expr_rust(A, S) :- format(string(S), '~w', [A]).

% ============================================================================
% MULTIFILE DISPATCH - Mutual Recursion (Rust target)
% ============================================================================

:- use_module('../core/advanced/mutual_recursion').
:- multifile mutual_recursion:compile_mutual_pattern/5.

mutual_recursion:compile_mutual_pattern(rust, Predicates, MemoEnabled, _MemoStrategy, RustCode) :-
    % Generate functions
    mutual_functions_rust(Predicates, Predicates, MemoEnabled, FuncCodes),
    atomic_list_concat(FuncCodes, '\n\n', FunctionsCode),
    % Dispatch match arms
    mutual_dispatch_rust(Predicates, MemoEnabled, DispatchCode),
    (   MemoEnabled = true ->
        format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Mutual Recursion (multifile dispatch)

use std::collections::HashMap;

~w

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut memo: HashMap<String, i64> = HashMap::new();
~w
}
', [FunctionsCode, DispatchCode])
    ;   format(string(RustCode),
'// Generated by UnifyWeaver Rust Target - Mutual Recursion (multifile dispatch)

~w

fn main() {
    let args: Vec<String> = std::env::args().collect();
~w
}
', [FunctionsCode, DispatchCode])
    ).

mutual_functions_rust([], _AllPreds, _MemoEnabled, []).
mutual_functions_rust([Pred/Arity|Rest], AllPreds, MemoEnabled, [FuncCode|RestCodes]) :-
    atom_string(Pred, PredStr),
    functor(Head, Pred, Arity),
    findall(clause(Head, Body), user:clause(Head, Body), Clauses),
    partition(mutual_recursion:is_mutual_recursive_clause(AllPreds), Clauses, RecClauses, BaseClauses),
    mutual_base_cases_rust(BaseClauses, PredStr, MemoEnabled, BaseParts),
    atomic_list_concat(BaseParts, '\n', BaseCode),
    mutual_rec_cases_rust(RecClauses, PredStr, MemoEnabled, RecParts),
    atomic_list_concat(RecParts, '\n', RecCode),
    (   MemoEnabled = true ->
        format(string(FuncCode),
'fn ~w(n: i64, memo: &mut HashMap<String, i64>) -> i64 {
    let key = format!("~w:{}", n);
    if let Some(&v) = memo.get(&key) { return v; }
~w
~w
    0
}', [PredStr, PredStr, BaseCode, RecCode])
    ;   format(string(FuncCode),
'fn ~w(n: i64) -> i64 {
~w
~w
    0
}', [PredStr, BaseCode, RecCode])
    ),
    mutual_functions_rust(Rest, AllPreds, MemoEnabled, RestCodes).

mutual_base_cases_rust([], _PredStr, _MemoEnabled, []).
mutual_base_cases_rust([clause(Head, true)|Rest], PredStr, MemoEnabled, [Part|RestParts]) :-
    Head =.. [_Pred, Value],
    (   MemoEnabled = true ->
        format(string(Part),
'    if n == ~w { memo.insert(format!("~w:{}", n), 1); return 1; }',
            [Value, PredStr])
    ;   format(string(Part), '    if n == ~w { return 1; }', [Value])
    ),
    mutual_base_cases_rust(Rest, PredStr, MemoEnabled, RestParts).
mutual_base_cases_rust([_|Rest], PredStr, MemoEnabled, RestParts) :-
    mutual_base_cases_rust(Rest, PredStr, MemoEnabled, RestParts).

mutual_rec_cases_rust([], _PredStr, _MemoEnabled, []).
mutual_rec_cases_rust([clause(_Head, Body)|Rest], PredStr, MemoEnabled, [Part|RestParts]) :-
    extract_mutual_rec_info_rust(Body, Guard, CalledPred, Step),
    atom_string(CalledPred, CalledStr),
    (   MemoEnabled = true ->
        MemoArg = ", memo"
    ;   MemoArg = ""
    ),
    (   Guard = (N > Threshold), var(N) ->
        (   MemoEnabled = true ->
            format(string(Part),
'    if n > ~w {
        let result = ~w(n ~w~w);
        memo.insert(format!("~w:{}", n), result);
        return result;
    }', [Threshold, CalledStr, Step, MemoArg, PredStr])
        ;   format(string(Part),
'    if n > ~w { return ~w(n ~w); }', [Threshold, CalledStr, Step])
        )
    ;   (   MemoEnabled = true ->
            format(string(Part),
'    {
        let result = ~w(n ~w~w);
        memo.insert(format!("~w:{}", n), result);
        return result;
    }', [CalledStr, Step, MemoArg, PredStr])
        ;   format(string(Part), '    return ~w(n ~w);', [CalledStr, Step])
        )
    ),
    mutual_rec_cases_rust(Rest, PredStr, MemoEnabled, RestParts).
mutual_rec_cases_rust([_|Rest], PredStr, MemoEnabled, RestParts) :-
    mutual_rec_cases_rust(Rest, PredStr, MemoEnabled, RestParts).

extract_mutual_rec_info_rust(Body, Guard, CalledPred, Step) :-
    extract_goals_from_body_rust(Body, Goals),
    (   member(Guard, Goals), Guard = (_ > _) -> true
    ;   Guard = none
    ),
    member(Call, Goals),
    compound(Call),
    Call \= (_ is _), Call \= (_ > _), Call \= (_ < _),
    Call \= (_ >= _), Call \= (_ =< _),
    functor(Call, CalledPred, _),
    (   member(_ is _ - K, Goals), integer(K) ->
        format(string(Step), '- ~w', [K])
    ;   member(_ is _ + K, Goals), integer(K), K < 0 ->
        AbsK is abs(K),
        format(string(Step), '- ~w', [AbsK])
    ;   Step = "- 1"
    ).

extract_goals_from_body_rust((A, B), Goals) :- !,
    extract_goals_from_body_rust(A, GA),
    extract_goals_from_body_rust(B, GB),
    append(GA, GB, Goals).
extract_goals_from_body_rust(true, []) :- !.
extract_goals_from_body_rust(Goal, [Goal]).

mutual_dispatch_rust(Predicates, MemoEnabled, Code) :-
    (   MemoEnabled = true ->
        MemoArg = ", &mut memo"
    ;   MemoArg = ""
    ),
    findall(DispLine, (
        member(Pred/_Arity, Predicates),
        atom_string(Pred, PredStr),
        format(string(DispLine),
'        "~w" => println!("{}", ~w(n~w)),',
            [PredStr, PredStr, MemoArg])
    ), Lines),
    atomic_list_concat(Lines, '\n', MatchArms),
    format(string(Code),
'    if args.len() >= 3 {
        let n: i64 = args[2].parse().unwrap();
        match args[1].as_str() {
~w
            _ => {}
        }
    }', [MatchArms]).
