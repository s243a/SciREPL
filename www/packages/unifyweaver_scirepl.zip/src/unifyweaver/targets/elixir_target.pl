:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2026 John William Creighton (s243a)
%
% elixir_target.pl - Elixir Target for UnifyWeaver
% Generates Elixir programs for record/field processing

:- module(elixir_target, [
    target_info/1,
    compile_predicate/3,
    compile_predicate_to_elixir/3,
    compile_facts_to_elixir/3,
    compile_rules_to_elixir/3,
    compile_mutual_recursion_elixir/3,
    write_elixir_module/2,
    generate_mix_project/3,
    generate_mix_exs/3,
    write_mix_project/3,
    init_elixir_target/0,
    snake_to_camel/2
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module('../core/clause_body_analysis').
:- use_module('../core/semantic_compiler').

% ============================================================================
% SEMANTIC SEARCH DISPATCH (Elixir via Bumblebee/Nx)
% ============================================================================
%
% Generates Elixir code using Bumblebee for transformer model inference
% and Nx for tensor operations. Assumes {:bumblebee, "~> 0.5"},
% {:nx, "~> 0.7"}, and {:exla, "~> 0.7"} in mix.exs deps.

:- multifile semantic_compiler:semantic_dispatch/5.

%% Bumblebee provider (default for Elixir)
semantic_compiler:semantic_dispatch(elixir, Goal, Provider, VarMap, Code) :-
    Goal =.. [_, Query, TopK | _],
    ( option(provider(bumblebee), Provider) ; option(provider(nx), Provider) ),
    !,
    option(model(Model), Provider, 'all-MiniLM-L6-v2'),
    option(device(Device), Provider, auto),

    % Lookup variable names in VarMap
    (   member(Query=QueryVar, VarMap) -> QueryExpr = QueryVar ; QueryExpr = Query ),
    (   member(TopK=TopKVar, VarMap) -> TopKExpr = TopKVar ; TopKExpr = TopK ),

    % Device/backend selection for Nx
    (   Device == gpu
    ->  BackendInit = '{:ok, model} = Bumblebee.load_model({:hf, "~w"}, backend: {EXLA.Backend, client: :cuda})'
    ;   Device == cpu
    ->  BackendInit = '{:ok, model} = Bumblebee.load_model({:hf, "~w"}, backend: EXLA.Backend)'
    ;   BackendInit = '{:ok, model} = Bumblebee.load_model({:hf, "~w"})'  % auto
    ),
    format(string(DeviceCode), BackendInit, [Model]),

    format(string(Code), '
    # Initialize Bumblebee embedding model: ~w
    ~w
    {:ok, tokenizer} = Bumblebee.load_tokenizer({:hf, "~w"})

    serving =
      Bumblebee.Text.TextEmbedding.text_embedding(model, tokenizer,
        compile: [batch_size: 1],
        defn_options: [compiler: EXLA]
      )

    # Embed query and search
    %{embedding: query_emb} = Nx.Serving.run(serving, "~w")
    results =
      store
      |> VectorStore.search(query_emb, top_k: ~w)
      |> Enum.take(~w)
', [Model, DeviceCode, Model, QueryExpr, TopKExpr, TopKExpr]).

% ============================================================================
% FUZZY LOGIC DISPATCH (Elixir target)
% ============================================================================
%
% Generates inline Elixir code for fuzzy operations.
% Assumes term_scores is a Map in scope (e.g., %{"bash" => 0.8, ...}).

:- multifile semantic_compiler:fuzzy_dispatch/3.

%% f_and: Fuzzy AND (product t-norm)
semantic_compiler:fuzzy_dispatch(elixir, f_and(Terms, _Result), Code) :-
    generate_elixir_product_terms(Terms, TermCode),
    format(string(Code),
'    # Fuzzy AND (product t-norm)
    result =
      1.0
~w', [TermCode]).

%% f_or: Fuzzy OR (probabilistic sum)
semantic_compiler:fuzzy_dispatch(elixir, f_or(Terms, _Result), Code) :-
    generate_elixir_complement_terms(Terms, TermCode),
    format(string(Code),
'    # Fuzzy OR (probabilistic sum)
    complement =
      1.0
~w    result = 1.0 - complement
', [TermCode]).

%% f_dist_or: Distributed OR
semantic_compiler:fuzzy_dispatch(elixir, f_dist_or(BaseScore, Terms, _Result), Code) :-
    (number(BaseScore) -> format(string(BaseExpr), "~w", [BaseScore]) ; BaseExpr = BaseScore),
    generate_elixir_dist_complement_terms(BaseExpr, Terms, TermCode),
    format(string(Code),
'    # Fuzzy distributed OR
    complement =
      1.0
~w    result = 1.0 - complement
', [TermCode]).

%% f_union: Non-distributed OR
semantic_compiler:fuzzy_dispatch(elixir, f_union(BaseScore, Terms, _Result), Code) :-
    (number(BaseScore) -> format(string(BaseExpr), "~w", [BaseScore]) ; BaseExpr = BaseScore),
    generate_elixir_complement_terms(Terms, TermCode),
    format(string(Code),
'    # Fuzzy union (base * OR)
    complement =
      1.0
~w    result = ~w * (1.0 - complement)
', [TermCode, BaseExpr]).

%% f_not: Fuzzy NOT
semantic_compiler:fuzzy_dispatch(elixir, f_not(Score, _Result), Code) :-
    (number(Score) -> format(string(SE), "~w", [Score]) ; SE = Score),
    format(string(Code), '    result = 1.0 - ~w\n', [SE]).

%% blend_scores
semantic_compiler:fuzzy_dispatch(elixir, blend_scores(Alpha, Scores1, Scores2, _Result), Code) :-
    (number(Alpha) -> format(string(AE), "~w", [Alpha]) ; AE = Alpha),
    format(string(Code),
'    # Blend scores
    result =
      Enum.zip(~w, ~w)
      |> Enum.map(fn {s1, s2} -> ~w * s1 + (1.0 - ~w) * s2 end)
', [Scores1, Scores2, AE, AE]).

%% top_k
semantic_compiler:fuzzy_dispatch(elixir, top_k(Items, K, _Result), Code) :-
    format(string(Code),
'    # Top-K selection
    result =
      ~w
      |> Enum.sort_by(& &1.score, :desc)
      |> Enum.take(~w)
', [Items, K]).

% ---- Elixir fuzzy term helpers ----

generate_elixir_product_terms([], '').
generate_elixir_product_terms([w(Term, Weight)|Rest], Code) :-
    generate_elixir_product_terms(Rest, RestCode),
    format(string(Line), '      |> Kernel.*(~w * Map.get(term_scores, "~w", 0.5))\n', [Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_elixir_product_terms([Term|Rest], Code) :-
    atom(Term),
    generate_elixir_product_terms(Rest, RestCode),
    format(string(Line), '      |> Kernel.*(Map.get(term_scores, "~w", 0.5))\n', [Term]),
    string_concat(Line, RestCode, Code).

generate_elixir_complement_terms([], '').
generate_elixir_complement_terms([w(Term, Weight)|Rest], Code) :-
    generate_elixir_complement_terms(Rest, RestCode),
    format(string(Line), '      |> Kernel.*(1.0 - ~w * Map.get(term_scores, "~w", 0.5))\n', [Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_elixir_complement_terms([Term|Rest], Code) :-
    atom(Term),
    generate_elixir_complement_terms(Rest, RestCode),
    format(string(Line), '      |> Kernel.*(1.0 - Map.get(term_scores, "~w", 0.5))\n', [Term]),
    string_concat(Line, RestCode, Code).

generate_elixir_dist_complement_terms(_, [], '').
generate_elixir_dist_complement_terms(BaseExpr, [w(Term, Weight)|Rest], Code) :-
    generate_elixir_dist_complement_terms(BaseExpr, Rest, RestCode),
    format(string(Line), '      |> Kernel.*(1.0 - ~w * ~w * Map.get(term_scores, "~w", 0.5))\n', [BaseExpr, Weight, Term]),
    string_concat(Line, RestCode, Code).
generate_elixir_dist_complement_terms(BaseExpr, [Term|Rest], Code) :-
    atom(Term),
    generate_elixir_dist_complement_terms(BaseExpr, Rest, RestCode),
    format(string(Line), '      |> Kernel.*(1.0 - ~w * Map.get(term_scores, "~w", 0.5))\n', [BaseExpr, Term]),
    string_concat(Line, RestCode, Code).

%% ============================================
%% TARGET INFO
%% ============================================

target_info(info{
    name: "Elixir",
    family: beam,
    file_extension: ".ex",
    runtime: beam,
    features: [pattern_matching, tail_recursion, streams, actors, functional],
    recursion_patterns: [tail_recursion, linear_recursion, mutual_recursion, transitive_closure],
    compile_command: "elixirc"
}).

%% ============================================
%% INIT
%% ============================================

init_elixir_target :-
    format('[Elixir Target] Initialized~n', []).

%% ============================================
%% MAIN DISPATCH
%% ============================================

compile_predicate(PredArity, Options, Code) :-
    compile_predicate_to_elixir(PredArity, Options, Code).

compile_predicate_to_elixir(Pred/Arity, Options, ElixirCode) :-
    (   option(type(facts), Options)
    ->  compile_facts_to_elixir(Pred, Arity, ElixirCode)
    ;   option(type(mutual_recursion), Options)
    ->  compile_mutual_recursion_elixir(Pred/Arity, Options, ElixirCode)
    ;   option(generator_mode(true), Options)
    ->  compile_generator_mode_elixir(Pred, Arity, Options, ElixirCode)
    ;   option(pipeline_input(true), Options)
    ->  compile_pipeline_mode_elixir(Pred, Arity, Options, ElixirCode)
    ;   compile_simple_mode_elixir(Pred, Arity, Options, ElixirCode)
    ).

compile_rules_to_elixir(Pred/Arity, Options, Code) :-
    compile_simple_mode_elixir(Pred, Arity, Options, Code).

%% ============================================
%% FACTS COMPILATION
%% ============================================

compile_facts_to_elixir(Pred, Arity, ElixirCode) :-
    atom_string(Pred, PredStr),
    snake_to_camel(Pred, PredCap),
    functor(Head, Pred, Arity),
    
    findall(Args, (user:clause(Head, true), Head =.. [_|Args]), AllFacts),
    
    (   AllFacts == []
    ->  FactEntries = "  @facts []"
    ;   findall(Entry, (
            member(Args, AllFacts),
            format_elixir_fact_entry(Args, Entry)
        ), Entries),
        atomic_list_concat(Entries, ',\n    ', FactList),
        format(string(FactEntries), "  @facts [\n    ~w\n  ]", [FactList])
    ),
    
    format(string(ElixirCode),
'# Generated by UnifyWeaver Elixir Target
# Facts for ~w/~w

defmodule Generated.~w do
  @moduledoc "Generated facts for ~w/~w"

~w

  @doc "Return all facts"
  def all, do: @facts

  @doc "Check if tuple is a fact"
  def member?(args), do: args in @facts

  @doc "Stream all facts lazily"
  def stream, do: Stream.map(@facts, & &1)
end
', [PredStr, Arity, PredCap, PredStr, Arity, FactEntries]).

format_elixir_fact_entry(Args, Entry) :-
    findall(Formatted, (
        member(Arg, Args),
        (   number(Arg) -> format(string(Formatted), "~w", [Arg])
        ;   atom(Arg)   -> format(string(Formatted), "\"~w\"", [Arg])
        ;   string(Arg) -> format(string(Formatted), "\"~w\"", [Arg])
        ;   format(string(Formatted), "\"~w\"", [Arg])
        )
    ), FormattedArgs),
    atomic_list_concat(FormattedArgs, ', ', ArgsStr),
    format(string(Entry), '{~w}', [ArgsStr]).

%% ============================================
%% SIMPLE MODE
%% ============================================

% Try native clause body lowering first
compile_simple_mode_elixir(Pred, Arity, _Options, ElixirCode) :-
    atom_string(Pred, PredStr),
    snake_to_camel(Pred, PredCap),
    functor(Head, Pred, Arity),
    findall(Head-Body, user:clause(Head, Body), Clauses),
    Clauses \= [],
    native_elixir_clause_body(Pred/Arity, Clauses, FuncBody),
    !,
    Arity1 is Arity - 1,
    build_elixir_arg_list(Arity1, ArgList),
    format(string(ElixirCode),
'# Generated by UnifyWeaver Elixir Target - Native Clause Lowering
# Predicate: ~w/~w

defmodule Generated.~w do
  def ~w(~w) do
~w
  end
end
', [PredStr, Arity, PredCap, PredStr, ArgList, FuncBody]).

% Fallback to existing simple mode
compile_simple_mode_elixir(Pred, Arity, _Options, ElixirCode) :-
    atom_string(Pred, PredStr),
    snake_to_camel(Pred, PredCap),

    functor(Head, Pred, Arity),
    findall((Head, Body), user:clause(Head, Body), Clauses),

    (   Clauses == []
    ->  FuncBody = "  def process(_), do: nil"
    ;   generate_simple_clauses_elixir(PredStr, Arity, Clauses, FuncBody)
    ),

    format(string(ElixirCode),
'# Generated by UnifyWeaver Elixir Target
# Predicate: ~w/~w

defmodule Generated.~w do
~w
end
', [PredStr, Arity, PredCap, FuncBody]).

%% generate_simple_clauses_elixir(+Name, +Arity, +Clauses, -Code)
%  Generates multi-clause def with pattern-matched heads.
%  Ground args become literal matches; variable args become Elixir variables.
generate_simple_clauses_elixir(Name, Arity, Clauses, Code) :-
    % Generate standard parameter names for the function
    numlist(1, Arity, Indices),
    findall(ArgName, (
        member(I, Indices),
        format(atom(ArgName), 'arg~w', [I])
    ), StdArgNames),
    
    findall(ClauseCode, (
        member((Head, Body), Clauses),
        Head =.. [_|HeadArgs],
        generate_clause_head_elixir(Name, HeadArgs, StdArgNames, HeadStr, Guards, VarMap, PatternArgs),
        translate_body_elixir(Body, VarMap, BodyCode),
        format_clause_elixir(HeadStr, Guards, BodyCode, PatternArgs, ClauseCode)
    ), Codes),
    atomic_list_concat(Codes, '\n\n', Code).

%% generate_clause_head_elixir(+Name, +HeadArgs, +StdArgNames, -HeadStr, -Guards, -VarMap, -PatternArgs)
%  Build a pattern-matched function head from clause arguments.
%  PatternArgs are the actual in-scope identifiers/literals for the result tuple.
generate_clause_head_elixir(Name, HeadArgs, StdArgNames, HeadStr, Guards, VarMap, PatternArgs) :-
    map_head_args_elixir(HeadArgs, StdArgNames, PatternArgs, GuardList, VarPairs),
    exclude(==(""), GuardList, Guards),
    flatten(VarPairs, VarMap),
    atomic_list_concat(PatternArgs, ', ', ArgsStr),
    format(string(HeadStr), "~w(~w)", [Name, ArgsStr]).

%% map_head_args_elixir(+HeadArgs, +StdNames, -Patterns, -Guards, -VarPairs)
map_head_args_elixir([], [], [], [], []).
map_head_args_elixir([Arg|Args], [Std|Stds], [Pat|Pats], [Guard|Guards], [VP|VPs]) :-
    format_head_arg_elixir(Arg, Std, Pat, Guard, VP),
    map_head_args_elixir(Args, Stds, Pats, Guards, VPs).

%% format_head_arg_elixir(+HeadArg, +StdName, -Pattern, -Guard, -VarPair)
%  For each head arg: ground → literal match, var → named param.
format_head_arg_elixir(Arg, StdName, Pattern, "", [Arg-StdName]) :-
    var(Arg), !,
    Pattern = StdName.
format_head_arg_elixir(Arg, _StdName, Pattern, "", []) :-
    number(Arg), !,
    format(atom(Pattern), "~w", [Arg]).
format_head_arg_elixir(Arg, _StdName, Pattern, "", []) :-
    atom(Arg), !,
    format(atom(Pattern), "\"~w\"", [Arg]).
format_head_arg_elixir(Arg, _StdName, Pattern, "", []) :-
    format(atom(Pattern), "~w", [Arg]).

%% format_clause_elixir(+HeadStr, +Guards, +BodyCode, +ArgNames, -Code)
format_clause_elixir(HeadStr, [], BodyCode, ArgNames, Code) :-
    atomic_list_concat(ArgNames, ', ', ResultArgs),
    format(string(Code),
"  def ~w do\n    try do\n~w\n      {:ok, [~w]}\n    catch\n      :fail -> :fail\n    end\n  end",
        [HeadStr, BodyCode, ResultArgs]).
format_clause_elixir(HeadStr, Guards, BodyCode, ArgNames, Code) :-
    Guards \= [],
    atomic_list_concat(Guards, ' and ', GuardStr),
    atomic_list_concat(ArgNames, ', ', ResultArgs),
    format(string(Code),
"  def ~w when ~w do\n    try do\n~w\n      {:ok, [~w]}\n    catch\n      :fail -> :fail\n    end\n  end",
        [HeadStr, GuardStr, BodyCode, ResultArgs]).

%% ============================================
%% NATIVE CLAUSE BODY LOWERING
%% ============================================

%% build_elixir_arg_list(+N, -ArgList)
build_elixir_arg_list(0, "") :- !.
build_elixir_arg_list(N, ArgList) :-
    findall(ArgName, (
        between(1, N, I),
        format(string(ArgName), 'arg~w', [I])
    ), ArgNames),
    atomic_list_concat(ArgNames, ', ', ArgList).

%% native_elixir_clause_body(+PredSpec, +Clauses, -Code)

% Single clause
native_elixir_clause_body(PredSpec, [Head-Body], Code) :-
    native_elixir_clause(PredSpec, Head, Body, Condition, ClauseCode),
    !,
    (   Condition == "true"
    ->  Code = ClauseCode
    ;   format(string(Code),
'    if ~w do
~w
    else
      raise "No matching clause for ~w"
    end', [Condition, ClauseCode, PredSpec])
    ).

% Multi-clause
native_elixir_clause_body(PredSpec, Clauses, Code) :-
    Clauses = [_|[_|_]],
    maplist(native_elixir_clause_pair(PredSpec), Clauses, Branches),
    Branches \= [],
    branches_to_elixir_cond(Branches, PredSpec, Code).

native_elixir_clause_pair(PredSpec, Head-Body, branch(Condition, ClauseCode)) :-
    native_elixir_clause(PredSpec, Head, Body, Condition, ClauseCode),
    !.

%% native_elixir_clause(+PredSpec, +Head, +Body, -Condition, -Code)
native_elixir_clause(_PredSpec, Head, Body, Condition, Code) :-
    Head =.. [_Pred|HeadArgs],
    length(HeadArgs, Arity),
    build_head_varmap(HeadArgs, 1, VarMap),
    (   Arity > 1
    ->  append(_InputHeadArgs, [OutputHeadArg], HeadArgs),
        elixir_head_conditions(HeadArgs, 1, Arity, HeadConditions)
    ;   OutputHeadArg = _,
        elixir_head_conditions(HeadArgs, 1, Arity, HeadConditions)
    ),
    normalize_goals(Body, Goals),
    (   Goals == []
    ->  elixir_resolve_value(VarMap, OutputHeadArg, OutputExpr),
        format(string(Code), '      ~w', [OutputExpr]),
        GoalConditions = []
    ;   (   Arity > 1, nonvar(OutputHeadArg)
        ->  clause_guard_output_split(Goals, VarMap, GuardGoals, OutputGoals),
            maplist(elixir_guard_condition(VarMap), GuardGoals, GoalConditions),
            (   OutputGoals == []
            ->  elixir_literal(OutputHeadArg, OutputLit),
                format(string(Code), '      ~w', [OutputLit])
            ;   elixir_output_goals(OutputGoals, VarMap, Code)
            )
        ;   native_elixir_goal_sequence(Goals, VarMap, GoalConditions, Code)
        )
    ),
    append(HeadConditions, GoalConditions, AllConditions),
    combine_elixir_conditions(AllConditions, Condition).

%% elixir_head_conditions(+HeadArgs, +Index, +Arity, -Conditions)
%  Skip the last arg (output) when generating conditions.
elixir_head_conditions([], _, _, []).
elixir_head_conditions([_], _, Arity, []) :- Arity > 1, !.  % Skip last (output) arg
elixir_head_conditions([HeadArg|Rest], Index, Arity, Conditions) :-
    (   var(HeadArg)
    ->  Conditions = RestConditions
    ;   format(string(ArgName), 'arg~w', [Index]),
        elixir_literal(HeadArg, Literal),
        format(string(Cond), '~w == ~w', [ArgName, Literal]),
        Conditions = [Cond|RestConditions]
    ),
    NextIndex is Index + 1,
    elixir_head_conditions(Rest, NextIndex, Arity, RestConditions).

%% native_elixir_goal_sequence(+Goals, +VarMap, -Conditions, -Code)
%  Uses classify_goal_sequence for advanced pattern detection.
%  Falls back to clause_guard_output_split if classification fails.
native_elixir_goal_sequence(Goals, VarMap, Conditions, Code) :-
    classify_goal_sequence(Goals, VarMap, ClassifiedGoals),
    ClassifiedGoals \= [],
    elixir_render_classified_goals(ClassifiedGoals, VarMap, Conditions, Lines),
    Lines \= [],
    atomic_list_concat(Lines, '\n', Code),
    !.
native_elixir_goal_sequence(Goals, VarMap, Conditions, Code) :-
    clause_guard_output_split(Goals, VarMap, GuardGoals, OutputGoals),
    maplist(elixir_guard_condition(VarMap), GuardGoals, Conditions),
    elixir_output_goals(OutputGoals, VarMap, Code).

%% elixir_render_classified_goals(+ClassifiedGoals, +VarMap, -Conditions, -Lines)
elixir_render_classified_goals([], _VarMap, [], []).
elixir_render_classified_goals([Classified], VarMap, Conds, Lines) :-
    !,
    elixir_render_classified_last(Classified, VarMap, Conds, Lines).
%% Guarded tail: output followed by guard(s)
elixir_render_classified_goals([output(Goal, _, _)|Rest], VarMap, [], Lines) :-
    Rest = [guard(_, _)|_],
    !,
    elixir_output_goal(Goal, VarMap, AssignLine, VarMap1),
    elixir_collect_trailing_guards(Rest, VarMap1, GuardGoals, _Remaining),
    maplist(elixir_guard_condition(VarMap1), GuardGoals, GuardConds),
    atomic_list_concat(GuardConds, ' and ', GuardExpr),
    (   goal_output_var(Goal, OutVar), lookup_var(OutVar, VarMap1, OutName)
    ->  true
    ;   OutName = '_'
    ),
    format(string(IfLine), '      if ~w do', [GuardExpr]),
    format(string(RetLine), '        ~w', [OutName]),
    EndLine = '      end',
    Lines = [AssignLine, IfLine, RetLine, EndLine].
elixir_render_classified_goals([Classified|Rest], VarMap, Conds, Lines) :-
    elixir_render_classified_mid(Classified, VarMap, MidConds, MidLines, VarMap1),
    elixir_render_classified_goals(Rest, VarMap1, RestConds, RestLines),
    append(MidConds, RestConds, Conds),
    append(MidLines, RestLines, Lines).

%% elixir_render_classified_mid(+Classified, +VarMap, -Conds, -Lines, -VarMapOut)
elixir_render_classified_mid(guard(Goal, _), VarMap, [Cond], [], VarMap) :-
    elixir_guard_condition(VarMap, Goal, Cond).
elixir_render_classified_mid(output(Goal, _, _), VarMap0, [], [Line], VarMapOut) :-
    elixir_output_goal(Goal, VarMap0, Line, VarMapOut).
elixir_render_classified_mid(output_ite(If, Then, Else, _SharedVars), VarMap0, [], Lines, VarMap0) :-
    elixir_guard_condition(VarMap0, If, Cond),
    elixir_branch_value(Then, VarMap0, ThenExpr),
    elixir_branch_value(Else, VarMap0, ElseExpr),
    format(string(IfLine), '      if ~w do', [Cond]),
    format(string(ThenLine), '        ~w', [ThenExpr]),
    ElseLine = '      else',
    format(string(ElseRetLine), '        ~w', [ElseExpr]),
    EndLine = '      end',
    Lines = [IfLine, ThenLine, ElseLine, ElseRetLine, EndLine].
elixir_render_classified_mid(passthrough(Goal), VarMap0, [], [Line], VarMapOut) :-
    elixir_output_goal(Goal, VarMap0, Line, VarMapOut).
elixir_render_classified_mid(_, VarMap, [], [], VarMap).

%% elixir_render_classified_last(+Classified, +VarMap, -Conds, -Lines)
elixir_render_classified_last(guard(Goal, _), VarMap, [Cond], []) :-
    elixir_guard_condition(VarMap, Goal, Cond).
elixir_render_classified_last(output(Goal, _, _), VarMap, [], Lines) :-
    elixir_render_output_goal_last(Goal, VarMap, Lines).
elixir_render_classified_last(output_ite(If, Then, Else, _), VarMap, [], Lines) :-
    elixir_guard_condition(VarMap, If, Cond),
    elixir_branch_value(Then, VarMap, ThenExpr),
    elixir_branch_value(Else, VarMap, ElseExpr),
    format(string(IfLine), '      if ~w do', [Cond]),
    format(string(ThenLine), '        ~w', [ThenExpr]),
    ElseLine = '      else',
    format(string(ElseRetLine), '        ~w', [ElseExpr]),
    EndLine = '      end',
    Lines = [IfLine, ThenLine, ElseLine, ElseRetLine, EndLine].
elixir_render_classified_last(output_disj(Alternatives, _SharedVars), VarMap, [], Lines) :-
    elixir_disj_case_chain(Alternatives, VarMap, Lines).
elixir_render_classified_last(passthrough(Goal), VarMap, [], Lines) :-
    elixir_render_output_goal_last(Goal, VarMap, Lines).
elixir_render_classified_last(_, _, [], []).

%% elixir_render_output_goal_last(+Goal, +VarMap, -Lines)
%  3-arg wrapper used by classified goal renderers.
elixir_render_output_goal_last(Goal, VarMap, Lines) :-
    elixir_output_goal_last(Goal, VarMap, Lines, _VarMapOut),
    !.
elixir_render_output_goal_last(Goal, VarMap, [Line]) :-
    elixir_branch_value(Goal, VarMap, Expr),
    format(string(Line), '      ~w', [Expr]).

%% elixir_collect_trailing_guards(+ClassifiedGoals, +VarMap, -GuardGoals, -Remaining)
elixir_collect_trailing_guards([guard(Goal, _)|Rest], VarMap, [Goal|Guards], Remaining) :-
    !, elixir_collect_trailing_guards(Rest, VarMap, Guards, Remaining).
elixir_collect_trailing_guards(Remaining, _, [], Remaining).

%% elixir_disj_case_chain(+Alternatives, +VarMap, -Lines)
%  Renders disjunctions as a cond block in Elixir.
elixir_disj_case_chain([], _, []).
elixir_disj_case_chain(Alternatives, VarMap, Lines) :-
    CondOpen = '      cond do',
    elixir_disj_cond_branches(Alternatives, VarMap, BranchLines),
    CondClose = '      end',
    append([[CondOpen], BranchLines, [CondClose]], Lines).

%% elixir_disj_cond_branches(+Alternatives, +VarMap, -Lines)
elixir_disj_cond_branches([], _, []).
elixir_disj_cond_branches([Alt], VarMap, [ArrowLine, RetLine]) :-
    !,
    elixir_branch_value(Alt, VarMap, ValExpr),
    ArrowLine = '        true ->',
    format(string(RetLine), '          ~w', [ValExpr]).
elixir_disj_cond_branches([Alt|Rest], VarMap, [ArrowLine, RetLine|RestLines]) :-
    normalize_goals(Alt, Goals),
    clause_guard_output_split(Goals, VarMap, Guards, _Outputs),
    (   Guards \= []
    ->  maplist(elixir_guard_condition(VarMap), Guards, CondStrs),
        atomic_list_concat(CondStrs, ' and ', CondExpr)
    ;   CondExpr = 'true'
    ),
    elixir_branch_value(Alt, VarMap, ValExpr),
    format(string(ArrowLine), '        ~w ->', [CondExpr]),
    format(string(RetLine), '          ~w', [ValExpr]),
    elixir_disj_cond_branches(Rest, VarMap, RestLines).

%% elixir_guard_condition(+VarMap, +Goal, -Condition)
elixir_guard_condition(VarMap, _Module:Goal, Condition) :-
    !, elixir_guard_condition(VarMap, Goal, Condition).
elixir_guard_condition(VarMap, Goal, Condition) :-
    compound(Goal),
    Goal =.. [Op, Left, Right],
    expr_op(Op, StdOp),
    !,
    elixir_expr(Left, VarMap, ExLeft),
    elixir_expr(Right, VarMap, ExRight),
    elixir_op(StdOp, ExOp),
    format(string(Condition), '~w ~w ~w', [ExLeft, ExOp, ExRight]).
elixir_guard_condition(VarMap, integer(X), Condition) :-
    !, elixir_expr(X, VarMap, ExX),
    format(string(Condition), 'is_integer(~w)', [ExX]).
elixir_guard_condition(VarMap, float(X), Condition) :-
    !, elixir_expr(X, VarMap, ExX),
    format(string(Condition), 'is_float(~w)', [ExX]).
elixir_guard_condition(VarMap, number(X), Condition) :-
    !, elixir_expr(X, VarMap, ExX),
    format(string(Condition), 'is_number(~w)', [ExX]).
elixir_guard_condition(VarMap, atom(X), Condition) :-
    !, elixir_expr(X, VarMap, ExX),
    format(string(Condition), 'is_atom(~w)', [ExX]).
elixir_guard_condition(VarMap, is_list(X), Condition) :-
    !, elixir_expr(X, VarMap, ExX),
    format(string(Condition), 'is_list(~w)', [ExX]).

%% elixir_output_goals(+Goals, +VarMap, -Code)
elixir_output_goals([], _VarMap, '      raise "no output"') :- !.
elixir_output_goals(Goals, VarMap, Code) :-
    elixir_output_goals_acc(Goals, VarMap, Lines, _VarMapOut),
    atomic_list_concat(Lines, '\n', Code).

elixir_output_goals_acc([], VarMap, [], VarMap).
elixir_output_goals_acc([Goal], VarMap, Lines, VarMapOut) :-
    !, elixir_output_goal_last(Goal, VarMap, Lines, VarMapOut).
elixir_output_goals_acc([Goal|Rest], VarMap0, [Line|RestLines], VarMapOut) :-
    elixir_output_goal(Goal, VarMap0, Line, VarMap1),
    elixir_output_goals_acc(Rest, VarMap1, RestLines, VarMapOut).

%% elixir_output_goal_last — produce a return expression (Elixir implicit return)
elixir_output_goal_last(_Module:Goal, VarMap, Lines, VarMapOut) :-
    !, elixir_output_goal_last(Goal, VarMap, Lines, VarMapOut).
elixir_output_goal_last(Goal, VarMap0, Lines, VarMapOut) :-
    if_then_else_goal(Goal, IfGoal, ThenGoal, ElseGoal),
    !,
    elixir_if_then_else_output(IfGoal, ThenGoal, ElseGoal, VarMap0, Lines, VarMapOut).
elixir_output_goal_last(=(Var, Expr), VarMap, [Line], VarMap) :-
    var(Var), !,
    elixir_expr(Expr, VarMap, ExExpr),
    format(string(Line), '      ~w', [ExExpr]).
elixir_output_goal_last(is(Var, Expr), VarMap, [Line], VarMap) :-
    var(Var), !,
    elixir_expr(Expr, VarMap, ExExpr),
    format(string(Line), '      ~w', [ExExpr]).
elixir_output_goal_last(Goal, VarMap0, [AssignLine, ReturnLine], VarMapOut) :-
    elixir_output_goal(Goal, VarMap0, AssignLine, VarMapOut),
    (   goal_output_var(Goal, OutVar),
        lookup_var(OutVar, VarMapOut, OutName)
    ->  format(string(ReturnLine), '      ~w', [OutName])
    ;   ReturnLine = '      raise "no output"'
    ).

%% elixir_output_goal — produce a variable binding
elixir_output_goal(_Module:Goal, VarMap0, Line, VarMapOut) :-
    !, elixir_output_goal(Goal, VarMap0, Line, VarMapOut).
elixir_output_goal(=(Var, Expr), VarMap0, Line, VarMapOut) :-
    var(Var), !,
    ensure_var(VarMap0, Var, VarName, VarMapOut),
    elixir_expr(Expr, VarMap0, ExExpr),
    format(string(Line), '      ~w = ~w', [VarName, ExExpr]).
elixir_output_goal(is(Var, Expr), VarMap0, Line, VarMapOut) :-
    var(Var), !,
    ensure_var(VarMap0, Var, VarName, VarMapOut),
    elixir_expr(Expr, VarMap0, ExExpr),
    format(string(Line), '      ~w = ~w', [VarName, ExExpr]).

%% elixir_if_then_else_output — generate if/else for output
elixir_if_then_else_output(IfGoal, ThenGoal, ElseGoal, VarMap0, Lines, VarMapOut) :-
    flatten_elixir_if_elif_branches(IfGoal, ThenGoal, ElseGoal, Branches, DefaultGoal),
    elixir_cond_return_lines(Branches, DefaultGoal, VarMap0, Lines),
    VarMapOut = VarMap0.

flatten_elixir_if_elif_branches(If, Then, Else, [branch(If, Then)|RestBranches], Default) :-
    if_then_else_goal(Else, If2, Then2, Else2),
    !,
    flatten_elixir_if_elif_branches(If2, Then2, Else2, RestBranches, Default).
flatten_elixir_if_elif_branches(If, Then, Else, [branch(If, Then)], Else).

elixir_cond_return_lines(Branches, DefaultGoal, VarMap, Lines) :-
    elixir_cond_branch_lines(Branches, DefaultGoal, VarMap, BranchLines),
    append(['      cond do'|BranchLines], ['      end'], Lines).

elixir_cond_branch_lines([], DefaultGoal, VarMap, [DefaultLine]) :-
    !,
    elixir_branch_value(DefaultGoal, VarMap, DefVal),
    format(string(DefaultLine), '        true -> ~w', [DefVal]).
elixir_cond_branch_lines([branch(If, Then)|Rest], DefaultGoal, VarMap, [CondLine|RestLines]) :-
    elixir_guard_condition(VarMap, If, IfCond),
    elixir_branch_value(Then, VarMap, ThenVal),
    format(string(CondLine), '        ~w -> ~w', [IfCond, ThenVal]),
    elixir_cond_branch_lines(Rest, DefaultGoal, VarMap, RestLines).

%% elixir_branch_value — extract result value from a branch
elixir_branch_value(_Module:Goal, VarMap, Value) :-
    !, elixir_branch_value(Goal, VarMap, Value).
elixir_branch_value(Goal, VarMap, Value) :-
    if_then_else_goal(Goal, If, Then, Else),
    !,
    elixir_guard_condition(VarMap, If, Cond),
    elixir_branch_value(Then, VarMap, ThenVal),
    elixir_branch_value(Else, VarMap, ElseVal),
    format(string(Value), 'if(~w, do: ~w, else: ~w)', [Cond, ThenVal, ElseVal]).
elixir_branch_value((A, B), VarMap, Value) :-
    !,
    normalize_goals((A, B), Goals),
    last(Goals, LastGoal),
    elixir_branch_value(LastGoal, VarMap, Value).
elixir_branch_value(=(_, Expr), VarMap, Value) :-
    !, elixir_expr(Expr, VarMap, Value).
elixir_branch_value(is(_, Expr), VarMap, Value) :-
    !, elixir_expr(Expr, VarMap, Value).
elixir_branch_value(Goal, VarMap, Value) :-
    elixir_expr(Goal, VarMap, Value).

% ============================================================================
% MULTIFILE HOOKS — Register Elixir renderers for shared compile_expression
% ============================================================================

clause_body_analysis:render_output_goal(elixir, Goal, VarMap, Line, VarName, VarMapOut) :-
    elixir_output_goal(Goal, VarMap, Line, VarMapOut),
    (   goal_output_var(Goal, OutVar), lookup_var(OutVar, VarMapOut, VarName)
    ->  true
    ;   VarName = "_"
    ).

clause_body_analysis:render_guard_condition(elixir, Goal, VarMap, CondStr) :-
    elixir_guard_condition(VarMap, Goal, CondStr).

clause_body_analysis:render_branch_value(elixir, Branch, VarMap, ExprStr) :-
    elixir_branch_value(Branch, VarMap, ExprStr).

clause_body_analysis:render_ite_block(elixir, Cond, ThenLines, ElseLines, Indent, _ReturnVars, Lines) :-
    format(string(IfLine), '~wif ~w do', [Indent, Cond]),
    elixir_indent_lines(ThenLines, Indent, IndentedThen),
    (   ElseLines \= []
    ->  format(string(ElseLine), '~welse', [Indent]),
        elixir_indent_lines(ElseLines, Indent, IndentedElse),
        format(string(EndLine), '~wend', [Indent]),
        append([IfLine|IndentedThen], [ElseLine|IndentedElse], PreEnd),
        append(PreEnd, [EndLine], Lines)
    ;   format(string(EndLine), '~wend', [Indent]),
        append([IfLine|IndentedThen], [EndLine], Lines)
    ).

elixir_indent_lines([], _, []).
elixir_indent_lines([Line|Rest], Indent, [Indented|RestIndented]) :-
    format(string(Indented), '~w  ~w', [Indent, Line]),
    elixir_indent_lines(Rest, Indent, RestIndented).

%% elixir_expr — convert Prolog expression to Elixir syntax
elixir_expr(Var, VarMap, ExExpr) :-
    var(Var), !,
    (   lookup_var(Var, VarMap, Name)
    ->  ExExpr = Name
    ;   term_string(Var, ExExpr)
    ).
elixir_expr(Expr, VarMap, ExExpr) :-
    compound(Expr),
    Expr =.. [Op, Left, Right],
    expr_op(Op, StdOp),
    !,
    elixir_expr(Left, VarMap, ExLeft),
    elixir_expr(Right, VarMap, ExRight),
    elixir_op(StdOp, ExOp),
    format(string(ExExpr), '(~w ~w ~w)', [ExLeft, ExOp, ExRight]).
elixir_expr(-Expr, VarMap, ExExpr) :-
    !,
    elixir_expr(Expr, VarMap, Inner),
    format(string(ExExpr), '(-~w)', [Inner]).
elixir_expr(abs(Expr), VarMap, ExExpr) :-
    !,
    elixir_expr(Expr, VarMap, Inner),
    format(string(ExExpr), 'abs(~w)', [Inner]).
elixir_expr(min(A, B), VarMap, ExExpr) :-
    !,
    elixir_expr(A, VarMap, ExA),
    elixir_expr(B, VarMap, ExB),
    format(string(ExExpr), 'min(~w, ~w)', [ExA, ExB]).
elixir_expr(max(A, B), VarMap, ExExpr) :-
    !,
    elixir_expr(A, VarMap, ExA),
    elixir_expr(B, VarMap, ExB),
    format(string(ExExpr), 'max(~w, ~w)', [ExA, ExB]).
elixir_expr(Atom, _VarMap, ExExpr) :-
    atom(Atom), !,
    elixir_literal(Atom, ExExpr).
elixir_expr(Number, _VarMap, ExExpr) :-
    number(Number), !,
    format(string(ExExpr), '~w', [Number]).
elixir_expr(String, _VarMap, ExExpr) :-
    string(String), !,
    format(string(ExExpr), '"~w"', [String]).

%% elixir_literal — convert Prolog value to Elixir literal
elixir_literal(Value, 'nil') :- var(Value), !.
elixir_literal(true, 'true') :- !.
elixir_literal(false, 'false') :- !.
elixir_literal([], '[]') :- !.
elixir_literal(Value, ExLiteral) :-
    number(Value), !,
    format(string(ExLiteral), '~w', [Value]).
elixir_literal(Value, ExLiteral) :-
    atom(Value), !,
    format(string(ExLiteral), '"~w"', [Value]).
elixir_literal(Value, ExLiteral) :-
    string(Value), !,
    format(string(ExLiteral), '"~w"', [Value]).
elixir_literal(Value, ExLiteral) :-
    term_string(Value, ExLiteral).

%% elixir_resolve_value — resolve variable or constant to Elixir expression
elixir_resolve_value(VarMap, Var, ExExpr) :-
    var(Var), !,
    lookup_var(Var, VarMap, ExExpr).
elixir_resolve_value(_VarMap, Value, ExExpr) :-
    elixir_literal(Value, ExExpr).

%% elixir_op — map standard operator to Elixir syntax
elixir_op('>', '>').
elixir_op('<', '<').
elixir_op('>=', '>=').
elixir_op('<=', '<=').
elixir_op('==', '==').
elixir_op('!=', '!=').
elixir_op('+', '+').
elixir_op('-', '-').
elixir_op('*', '*').
elixir_op('/', 'div').
elixir_op('%', 'rem').
elixir_op('&&', 'and').
elixir_op('||', 'or').

%% combine_elixir_conditions — join conditions with "and"
combine_elixir_conditions([], "true") :- !.
combine_elixir_conditions([Condition], Condition) :- !.
combine_elixir_conditions(Conditions, Combined) :-
    atomic_list_concat(Conditions, ' and ', Combined).

%% branches_to_elixir_cond — build Elixir cond do block
branches_to_elixir_cond(Branches, PredSpec, Code) :-
    findall(BranchLine, (
        member(branch(Condition, ClauseCode), Branches),
        % ClauseCode comes with leading spaces, strip them for cond branches
        (   sub_string(ClauseCode, _, _, _, "\n")
        ->  format(string(BranchLine), '      ~w ->\n~w', [Condition, ClauseCode])
        ;   atom_string(ClauseCode, ClauseStr),
            split_string(ClauseStr, "", " ", [Trimmed]),
            format(string(BranchLine), '      ~w -> ~w', [Condition, Trimmed])
        )
    ), BranchLines),
    format(string(DefaultLine), '      true ->\n        raise "No matching clause for ~w"', [PredSpec]),
    append(BranchLines, [DefaultLine], AllLines),
    atomic_list_concat(AllLines, '\n', CondBody),
    format(string(Code), '    cond do\n~w\n    end', [CondBody]).

%% ============================================
%% PIPELINE MODE
%% ============================================

compile_pipeline_mode_elixir(Pred, Arity, _Options, ElixirCode) :-
    atom_string(Pred, PredStr),
    snake_to_camel(Pred, PredCap),
    
    functor(Head, Pred, Arity),
    findall((Head, Body), user:clause(Head, Body), Clauses),
    
    (   Clauses == []
    ->  FuncBody = "    record"
    ;   generate_pipeline_clauses_elixir(Clauses, FuncBody)
    ),
    
    format(string(ElixirCode),
'# Generated by UnifyWeaver Elixir Target - Pipeline Mode
# Predicate: ~w/~w
# Requires: Jason 

defmodule Generated.~wPipeline do

  def process(record) do
~w
  end

  def run do
    IO.stream(:stdio, :line)
    |> Stream.reject(&(&1 == "\\n"))
    |> Stream.map(&String.trim/1)
    |> Stream.map(&Jason.decode!/1)
    |> Stream.map(&process/1)
    |> Stream.reject(&is_nil/1)
    |> Enum.each(&(IO.puts(Jason.encode!(&1))))
  end
end

case System.argv() do
  [] -> :ok
  ["--run"|_] -> Generated.~wPipeline.run()
  _ -> :ok
end
', [PredStr, Arity, PredCap, FuncBody, PredCap]).

generate_pipeline_clauses_elixir([], "    record").
generate_pipeline_clauses_elixir(Clauses, Code) :-
    Clauses = [(Head, _)|_],
    functor(Head, Name, _),
    (   is_recursive_predicate_elixir(Name, Clauses)
    ->  include(is_base_clause_elixir(Name), Clauses, BaseClauses),
        exclude(is_base_clause_elixir(Name), Clauses, RecClauses),
        compile_recursive_elixir(Name, BaseClauses, RecClauses, Code)
    ;   findall(ClauseCode, (
            member((H, B), Clauses),
            translate_pipeline_clause_elixir(H, B, ClauseCode)
        ), Codes),
        atomic_list_concat(Codes, '\n\n', Code)
    ).

%% is_base_clause_elixir(+Name, +Clause)
%  A base clause does NOT contain a recursive call.
is_base_clause_elixir(Name, (_, Body)) :-
    \+ contains_recursive_call_elixir(Body, Name).

translate_pipeline_clause_elixir(Head, Body, Code) :-
    Head =.. [_Pred|_Args],
    % For pipeline, input is 'record' map
    (   Body == true
    ->  BodyCode = "    record"
    ;   translate_body_elixir(Body, [], TransBody),
        format(string(BodyCode), "    try do\n~w\n      record\n    catch\n      :fail -> nil\n    end", [TransBody])
    ),
    Code = BodyCode.

%% ============================================
%% GENERATOR MODE
%% ============================================

compile_generator_mode_elixir(Pred, Arity, Options, ElixirCode) :-
    compile_pipeline_mode_elixir(Pred, Arity, Options, PipelineCode),
    snake_to_camel(Pred, PredCap),
    format(string(ElixirCode),
'~w
# Wrapper for Generator
defmodule Generated.~wGen do
  def generate(init_record) do
    Stream.unfold(init_record, fn record ->
      case Generated.~wPipeline.process(record) do
        nil -> nil
        next -> {next, next}
      end
    end)
  end
end
', [PipelineCode, PredCap, PredCap]).

%% ============================================
%% MUTUAL RECURSION
%% ============================================

%% compile_mutual_recursion_elixir(+PredList, +Options, -Code)
%  Collects clauses for each predicate in PredList and generates
%  a single defmodule containing all mutually-recursive functions.
compile_mutual_recursion_elixir(PredList, _Options, Code) :-
    (   is_list(PredList)
    ->  generate_mutual_module_elixir(PredList, FuncDefs)
    ;   % Single Pred/Arity passed — wrap in list
        generate_mutual_module_elixir([PredList], FuncDefs)
    ),
    format(string(Code),
'# Generated by UnifyWeaver Elixir Target
# Mutual Recursion module

defmodule Generated.MutualGroup do
~w
end

case System.argv() do
  [func, n_str | _] ->
    {n, _} = Integer.parse(n_str)
    result = apply(Generated.MutualGroup, String.to_atom(func), [n])
    case result do
      {:ok, _} -> IO.puts(true)
      :fail -> IO.puts(false)
      other -> IO.puts(inspect(other))
    end
  _ -> :ok
end
', [FuncDefs]).

%% generate_mutual_module_elixir(+PredArityList, -FuncDefs)
%  For each Pred/Arity, collect user clauses and generate def clauses.
generate_mutual_module_elixir(PredArityList, FuncDefs) :-
    findall(FuncCode, (
        member(Pred/Arity, PredArityList),
        atom_string(Pred, PredStr),
        functor(Head, Pred, Arity),
        findall((Head, Body), user:clause(Head, Body), Clauses),
        (   Clauses \== []
        ->  generate_simple_clauses_elixir(PredStr, Arity, Clauses, FuncCode)
        ;   format(string(FuncCode),
                "  # ~w/~w: no clauses found\n  def ~w(_), do: raise \"not implemented\"",
                [PredStr, Arity, PredStr])
        )
    ), FuncCodes),
    (   FuncCodes == []
    ->  FuncDefs = "  # No predicates found"
    ;   atomic_list_concat(FuncCodes, '\n\n', FuncDefs)
    ).

%% ============================================
%% BODY TRANSLATION
%% ============================================

%% translate_body_elixir(+Body, +VarMap, -Code)
%  VarMap maps Prolog vars to Elixir arg names from head pattern matching.
translate_body_elixir((Goal, Rest), VarMap, Code) :-
    !,
    translate_goal_elixir(Goal, VarMap, Code1),
    translate_body_elixir(Rest, VarMap, Code2),
    format(string(Code), "~w\n~w", [Code1, Code2]).
translate_body_elixir(Goal, VarMap, Code) :-
    translate_goal_elixir(Goal, VarMap, Code).

translate_goal_elixir(>(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w > ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(<(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w < ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(>=(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w >= ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(=<(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w <= ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(=:=(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w === ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(=\=(X, Y), VM, Code) :-
    !, expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
    format(string(Code), "      if not (~w !== ~w), do: throw(:fail)", [CX, CY]).

translate_goal_elixir(is(Var, Expr), VM, Code) :-
    !,
    var_to_elixir(Var, VM, EVar),
    expr_to_elixir(Expr, VM, EExpr),
    format(string(Code), "      ~w = ~w", [EVar, EExpr]).

translate_goal_elixir(true, _VM, "      # true") :- !.

% Handle predicate calls (e.g., mutual recursive calls like is_odd(N1))
translate_goal_elixir(Goal, VM, Code) :-
    compound(Goal),
    Goal =.. [Pred|Args],
    Pred \= ',',
    Pred \= ';',
    maplist(translate_call_arg_elixir(VM), Args, ElixirArgs),
    atomic_list_concat(ElixirArgs, ', ', ArgsStr),
    format(string(Code), "      ~w(~w)", [Pred, ArgsStr]),
    !.

translate_goal_elixir(Goal, _VM, Code) :-
    format(string(Code), "      # TODO: translate ~w", [Goal]).

%% translate_call_arg_elixir(+VM, +Arg, -ElixirArg)
%  Translate a predicate call argument to Elixir.
translate_call_arg_elixir(VM, Arg, ElixirArg) :-
    expr_to_elixir(Arg, VM, ElixirArg).

%% ============================================
%% EXPRESSIONS AND VARIABLES
%% ============================================

%% var_to_elixir(+Var, +VarMap, -ElixirVar)
%  Translate a Prolog variable to an Elixir variable name.
%  Uses VarMap from head pattern matching when available.
var_to_elixir(Var, VarMap, ElixirVar) :-
    (   var(Var), lookup_varmap(Var, VarMap, Name)
    ->  ElixirVar = Name
    ;   var(Var)
    ->  term_to_atom(Var, VarAtom),
        format(atom(ElixirVar), "v_~w", [VarAtom])
    ;   Var = '$VAR'(N)
    ->  format(atom(ElixirVar), "v_~w", [N])
    ;   atom(Var)
    ->  % Use downcase_atom for portability (works on all SWI-Prolog builds)
        downcase_atom(Var, ElixirVar)
    ;   term_to_atom(Var, ElixirVar)
    ).

%% lookup_varmap(+Var, +VarMap, -Name)
lookup_varmap(Var, [V-Name|_], Name) :- Var == V, !.
lookup_varmap(Var, [_|Rest], Name) :- lookup_varmap(Var, Rest, Name).

%% expr_to_elixir(+Expr, +VarMap, -ElixirExpr)
expr_to_elixir(Expr, VM, ElixirExpr) :-
    (   number(Expr)
    ->  format(atom(ElixirExpr), "~w", [Expr])
    ;   var(Expr)
    ->  var_to_elixir(Expr, VM, ElixirExpr)
    ;   Expr = '$VAR'(N)
    ->  format(atom(ElixirExpr), "v_~w", [N])
    ;   Expr = X + Y
    ->  expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
        format(atom(ElixirExpr), "(~w + ~w)", [CX, CY])
    ;   Expr = X - Y
    ->  expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
        format(atom(ElixirExpr), "(~w - ~w)", [CX, CY])
    ;   Expr = X * Y
    ->  expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
        format(atom(ElixirExpr), "(~w * ~w)", [CX, CY])
    ;   Expr = X / Y
    ->  expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
        format(atom(ElixirExpr), "div(~w, ~w)", [CX, CY])
    ;   Expr = X mod Y
    ->  expr_to_elixir(X, VM, CX), expr_to_elixir(Y, VM, CY),
        format(atom(ElixirExpr), "rem(~w, ~w)", [CX, CY])
    ;   atom(Expr)
    ->  format(atom(ElixirExpr), "\"~w\"", [Expr])
    ;   format(atom(ElixirExpr), "~w", [Expr])
    ).

%% ============================================
%% RECURSION UTILS
%% ============================================

is_recursive_predicate_elixir(Name, Clauses) :-
    member((_, Body), Clauses),
    contains_recursive_call_elixir(Body, Name).

contains_recursive_call_elixir(Body, Name) :-
    extract_goal_elixir(Body, Goal),
    functor(Goal, Name, _),
    !.

extract_goal_elixir(Goal, Goal) :-
    compound(Goal),
    \+ Goal = (_,_),
    \+ Goal = (_;_).
extract_goal_elixir((A, _), Goal) :- extract_goal_elixir(A, Goal).
extract_goal_elixir((_, B), Goal) :- extract_goal_elixir(B, Goal).

compile_recursive_elixir(Name, BaseClauses, _RecClauses, Code) :-
    (   BaseClauses = [(BaseHead, _)|_]
    ->  generate_base_condition_elixir(BaseHead, BaseCondition)
    ;   BaseCondition = "false"
    ),
    
    format(string(Code),
"    # Recursive predicate: ~w
    iter = fn iter_fn, current, depth ->
      if depth > 10000 do
        IO.puts(:stderr, \"Warning: Max depth for ~w\")
        current
      else
        if ~w do
          current
        else
          iter_fn.(iter_fn, current, depth + 1)
        end
      end
    end

    iter.(iter, record, 0)", [Name, Name, BaseCondition]).

generate_base_condition_elixir(Head, Condition) :-
    Head =.. [_|Args],
    (   Args = [Arg|_],
        (   number(Arg)
        ->  format(string(Condition), "Map.get(current, \"arg0\") == ~w", [Arg])
        ;   atom(Arg)
        ->  format(string(Condition), "Map.get(current, \"arg0\") == \"~w\"", [Arg])
        ;   Condition = "false"
        )
    ;   Condition = "false"
    ).

%% ============================================
%% UTILS
%% ============================================

%% snake_to_camel(+SnakeAtom, -CamelAtom)
%  Convert snake_case atom to CamelCase atom for Elixir module names.
%  e.g. elix_greet -> ElixGreet, my_parent -> MyParent
snake_to_camel(Atom, CamelAtom) :-
    atom_string(Atom, Str),
    split_string(Str, "_", "", Parts),
    maplist(capitalize_part, Parts, CapParts),
    atomics_to_string(CapParts, CamelStr),
    atom_string(CamelAtom, CamelStr).

%% capitalize_part(+Part, -Capitalized)
capitalize_part("", "") :- !.
capitalize_part(Part, Capitalized) :-
    string_chars(Part, [H|T]),
    upcase_atom(H, HU),
    atom_chars(Upper, [HU]),
    atom_string(Upper, UpperStr),
    string_chars(Rest, T),
    string_concat(UpperStr, Rest, Capitalized).

%% atomics_to_string(+List, -String)
atomics_to_string([], "").
atomics_to_string([H|T], Result) :-
    atomics_to_string(T, Rest),
    string_concat(H, Rest, Result).

%% upcase_atom_first(+Atom, -CapAtom) - kept for backward compat
upcase_atom_first(Atom, CapAtom) :-
    snake_to_camel(Atom, CapAtom).

write_elixir_module(ElixirCode, FilePath) :-
    setup_call_cleanup(
        open(FilePath, write, Stream, [encoding(utf8)]),
        format(Stream, '~w', [ElixirCode]),
        close(Stream)
    ),
    format('Written Elixir program to: ~w~n', [FilePath]).

%% ============================================
%% MIX PROJECT GENERATION
%% ============================================

%% generate_mix_project(+ProjectName, +Options, -Files)
%  Generates a list of file(Path, Content) pairs for a Mix project.
%  Options:
%    deps(List)       - explicit dependency list, e.g. [jason, plug]
%    pipeline(true)   - auto-adds jason dependency
%    generator(true)  - auto-adds jason dependency
%    elixir_version(V)- minimum Elixir version (default: "~> 1.14")
%    description(D)   - project description
generate_mix_project(ProjectName, Options, Files) :-
    atom_string(ProjectName, ProjStr),
    snake_to_camel(ProjectName, ProjCap),
    % Determine dependencies
    collect_deps(Options, Deps),
    % Generate mix.exs
    generate_mix_exs(ProjStr, Options, MixExs),
    % Generate config/config.exs
    generate_config_exs(ProjCap, ConfigExs),
    % Generate lib/<project>.ex with a placeholder module
    format(string(LibModule),
'defmodule ~w do
  @moduledoc """
  Generated by UnifyWeaver Elixir Target.
  """
end
', [ProjCap]),
    % Generate test/test_helper.exs
    TestHelper = "ExUnit.start()\n",
    % Generate test/<project>_test.exs
    format(string(TestFile),
'defmodule ~wTest do
  use ExUnit.Case
  doctest ~w

  test "module exists" do
    assert Code.ensure_loaded?(~w)
  end
end
', [ProjCap, ProjCap, ProjCap]),
    % Generate .formatter.exs
    FormatterExs = "[
  inputs: [\"{mix,.formatter}.exs\", \"{config,lib,test}/**/*.{ex,exs}\"]
]
",
    % Generate .gitignore
    GitIgnore = "/_build/\n/cover/\n/deps/\n/doc/\n/.fetch\n/erl_crash.dump\n*.ez\n*.beam\n",
    % Generate README.md
    (   option(description(Desc), Options)
    ->  true
    ;   format(string(Desc), "Generated by UnifyWeaver for ~w", [ProjStr])
    ),
    format(string(ReadmeMd),
'# ~w

~w

## Setup

```bash
mix deps.get
mix compile
```
~w
## Generated by UnifyWeaver

This project was scaffolded by UnifyWeaver\'s Elixir target.
', [ProjCap, Desc, (Deps \== [] -> "
## Dependencies\n\nThis project requires the following dependencies (auto-installed by `mix deps.get`):\n\n" ; "")]),
    % Assemble file list
    format(atom(LibPath), 'lib/~w.ex', [ProjStr]),
    format(atom(TestPath), 'test/~w_test.exs', [ProjStr]),
    Files = [
        file('mix.exs', MixExs),
        file('config/config.exs', ConfigExs),
        file(LibPath, LibModule),
        file('test/test_helper.exs', TestHelper),
        file(TestPath, TestFile),
        file('.formatter.exs', FormatterExs),
        file('.gitignore', GitIgnore),
        file('README.md', ReadmeMd)
    ].

%% generate_mix_exs(+ProjectName, +Options, -MixExsCode)
%  Generates just the mix.exs content.
generate_mix_exs(ProjStr, Options, MixExs) :-
    atom_string(ProjAtom, ProjStr),
    snake_to_camel(ProjAtom, ProjCap),
    % Elixir version
    (   option(elixir_version(ElixirVer), Options)
    ->  true
    ;   ElixirVer = "~> 1.14"
    ),
    % Description
    (   option(description(Desc), Options)
    ->  true
    ;   format(string(Desc), "Generated by UnifyWeaver for ~w", [ProjStr])
    ),
    % Collect dependencies
    collect_deps(Options, Deps),
    format_deps(Deps, DepsStr),
    format(string(MixExs),
'defmodule ~w.MixProject do
  use Mix.Project

  def project do
    [
      app: :~w,
      version: "0.1.0",
      elixir: "~w",
      start_permanent: Mix.env() == :prod,
      deps: deps(),
      description: "~w"
    ]
  end

  def application do
    [
      extra_applications: [:logger]
    ]
  end

  defp deps do
    [~w
    ]
  end
end
', [ProjCap, ProjStr, ElixirVer, Desc, DepsStr]).

%% generate_config_exs(+ProjCap, -ConfigCode)
generate_config_exs(ProjCap, ConfigExs) :-
    format(string(ConfigExs),
'import Config

# Configuration for ~w
# This file is generated by UnifyWeaver.

config :logger, level: :info
', [ProjCap]).

%% collect_deps(+Options, -Deps)
%  Auto-detect required dependencies from Options.
collect_deps(Options, Deps) :-
    findall(Dep, (
        (   option(pipeline_input(true), Options)
        ;   option(generator_mode(true), Options)
        ),
        Dep = jason
    ), AutoDeps0),
    sort(AutoDeps0, AutoDeps),
    (   option(deps(ExplicitDeps), Options)
    ->  append(ExplicitDeps, AutoDeps, AllDeps0),
        sort(AllDeps0, Deps)
    ;   Deps = AutoDeps
    ).

%% format_deps(+DepList, -FormattedString)
format_deps([], "").
format_deps(Deps, DepsStr) :-
    Deps \== [],
    findall(DepStr, (
        member(Dep, Deps),
        dep_version(Dep, Ver),
        format(string(DepStr), '\n      {:~w, "~w"}', [Dep, Ver])
    ), DepStrs),
    atomic_list_concat(DepStrs, ',', DepsStr).

%% dep_version(+DepName, -VersionSpec)
%  Known dependency versions.
dep_version(jason, '~> 1.4') :- !.
dep_version(plug, '~> 1.14') :- !.
dep_version(plug_cowboy, '~> 2.6') :- !.
dep_version(ecto, '~> 3.10') :- !.
dep_version(req, '~> 0.4') :- !.
dep_version(_, '~> 0.1').

%% write_mix_project(+ProjectName, +Options, +OutputDir)
%  Generates and writes a complete Mix project to the given directory.
write_mix_project(ProjectName, Options, OutputDir) :-
    generate_mix_project(ProjectName, Options, Files),
    atom_string(ProjectName, ProjStr),
    format(atom(ProjDir), '~w/~w', [OutputDir, ProjStr]),
    forall(
        member(file(RelPath, Content), Files),
        (
            format(atom(FullPath), '~w/~w', [ProjDir, RelPath]),
            % Ensure parent directory exists
            file_directory_name(FullPath, ParentDir),
            make_directory_path(ParentDir),
            setup_call_cleanup(
                open(FullPath, write, S, [encoding(utf8)]),
                format(S, '~w', [Content]),
                close(S)
            )
        )
    ),
    format('Mix project written to: ~w~n', [ProjDir]),
    format('Run: cd ~w && mix deps.get && mix compile~n', [ProjDir]).

%% ============================================
%% MULTIFILE DISPATCH - Tail Recursion
%% ============================================

:- use_module('../core/advanced/tail_recursion').
:- multifile tail_recursion:compile_tail_pattern/9.

tail_recursion:compile_tail_pattern(elixir, PredStr, Arity, _BaseClauses, _RecClauses, _AccPos, StepOp, _ExitAfterResult, ElixirCode) :-
    atom_string(PredAtom, PredStr),
    snake_to_camel(PredAtom, PredCap),
    numlist(1, Arity, Indices),
    findall(ArgName, (member(I, Indices), format(atom(ArgName), 'arg~w', [I])), ArgNames),
    atomic_list_concat(ArgNames, ', ', ArgList),
    % Determine step operation for the accumulator
    (   StepOp = arithmetic(_ + _)
    ->  StepStr = "acc + item"
    ;   StepOp = arithmetic(_ * _)
    ->  StepStr = "acc * item"
    ;   StepOp = arithmetic(_ - _)
    ->  StepStr = "acc - item"
    ;   % Unknown step op — warn and use a placeholder
        print_message(warning, format('[Elixir Target] Unknown step operation ~w for ~w — defaulting to acc + 1. Review generated code.', [StepOp, PredStr])),
        StepStr = "acc + 1  # WARNING: unknown step op, review this"
    ),
    format(string(ElixirCode),
'# ~w - tail recursive pattern (Elixir, BEAM native TCO)
defmodule Generated.~w do
  def ~w(~w) do
    # BEAM provides native tail-call optimization.
    # This is a template — customize base case and step.
    {~w}
  end

  @doc "Tail-recursive helper with accumulator"
  def ~w_acc([], acc), do: acc
  def ~w_acc([item | rest], acc) do
    ~w_acc(rest, ~w)
  end
end

case System.argv() do
  [items_str | _] ->
    items = items_str |> String.split(",") |> Enum.map(&String.to_integer/1)
    IO.puts(Generated.~w.~w_acc(items, 0))
  _ -> :ok
end
', [PredStr, PredCap, PredStr, ArgList, ArgList, PredStr, PredStr, PredStr, StepStr, PredCap, PredStr]).

%% ============================================
%% MULTIFILE DISPATCH - Linear Recursion
%% ============================================

:- use_module('../core/advanced/linear_recursion').
:- multifile linear_recursion:compile_linear_pattern/8.

linear_recursion:compile_linear_pattern(elixir, PredStr, Arity, BaseClauses, _RecClauses, _BaseValues, _StepOp, ElixirCode) :-
    (   Arity =:= 2 ->
        linear_fold_elixir(PredStr, BaseClauses, ElixirCode)
    ;   linear_generic_elixir(PredStr, Arity, ElixirCode)
    ).

%% linear_fold_elixir(+PredStr, +BaseClauses, -Code)
linear_fold_elixir(PredStr, BaseClauses, Code) :-
    linear_recursion:extract_base_case_info(BaseClauses, BaseInput, BaseOutput),
    linear_recursion:detect_input_type(BaseInput, InputType),
    (   InputType = numeric ->
        linear_numeric_elixir(PredStr, BaseInput, BaseOutput, Code)
    ;   InputType = list ->
        linear_list_elixir(PredStr, BaseOutput, Code)
    ;   linear_generic_elixir(PredStr, 2, Code)
    ).

%% linear_numeric_elixir(+PredStr, +BaseInput, +BaseOutput, -Code)
linear_numeric_elixir(PredStr, BaseInput, BaseOutput, Code) :-
    atom_string(Pred, PredStr),
    functor(Head, Pred, 2),
    findall(clause(Head, Body), user:clause(Head, Body), AllClauses),
    partition(linear_recursion:is_recursive_clause(Pred), AllClauses, ActualRec, _),
    (   ActualRec = [clause(RHead, RBody)|_] ->
        RHead =.. [_, InputVar, _],
        linear_recursion:find_recursive_call(RBody, RecCall),
        RecCall =.. [_, _, AccVar],
        linear_recursion:find_last_is_expression(RBody, _ is FoldExpr),
        translate_fold_expr_elixir(FoldExpr, InputVar, AccVar, ElixirFoldOp)
    ;   ElixirFoldOp = "current * acc"
    ),
    % Extract step size and direction
    (   linear_recursion:extract_step_info_for(Pred/2, Step, down) ->
        (   Step =:= 1 ->
            format(string(StepExpr), 'n - 1', [])
        ;   format(string(StepExpr), 'n - ~w', [Step])
        )
    ;   StepExpr = "n - 1"
    ),
    atom_string(PredAtom, PredStr),
    snake_to_camel(PredAtom, PredCap),
    format(string(Code),
'# Generated by UnifyWeaver Elixir Target - Linear Recursion (numeric fold, multifile dispatch)
# Predicate: ~w/2
defmodule Generated.~w do
  def ~w(~w), do: ~w

  def ~w(n) when n > 0 do
    current = n
    acc = ~w(~w)
    ~w
  end
end

case System.argv() do
  [n_str | _] ->
    {n, _} = Integer.parse(n_str)
    IO.puts(Generated.~w.~w(n))
  _ -> :ok
end
', [PredStr, PredCap, PredStr, BaseInput, BaseOutput, PredStr, PredStr, StepExpr, ElixirFoldOp, PredCap, PredStr]).

%% linear_list_elixir(+PredStr, +BaseOutput, -Code)
linear_list_elixir(PredStr, BaseOutput, Code) :-
    atom_string(PredAtom, PredStr),
    snake_to_camel(PredAtom, PredCap),
    format(string(Code),
'# Generated by UnifyWeaver Elixir Target - Linear Recursion (list fold, multifile dispatch)
# Predicate: ~w/2
defmodule Generated.~w do
  def ~w([]), do: ~w
  def ~w([h | t]), do: h + ~w(t)
end

case System.argv() do
  [items_str | _] ->
    items = items_str |> String.split(",") |> Enum.map(&String.to_integer/1)
    IO.puts(Generated.~w.~w(items))
  _ -> :ok
end
', [PredStr, PredCap, PredStr, BaseOutput, PredStr, PredStr, PredCap, PredStr]).

%% linear_generic_elixir(+PredStr, +Arity, -Code)
linear_generic_elixir(PredStr, Arity, Code) :-
    atom_string(PredAtom, PredStr),
    snake_to_camel(PredAtom, PredCap),
    format(string(Code),
'# Generated by UnifyWeaver Elixir Target - Linear Recursion (generic, multifile dispatch)
# Predicate: ~w/~w
defmodule Generated.~w do
  def ~w(0), do: 0
  def ~w(n) when n > 0, do: ~w(n - 1) + n
end

case System.argv() do
  [n_str | _] ->
    {n, _} = Integer.parse(n_str)
    IO.puts(Generated.~w.~w(n))
  _ -> :ok
end
', [PredStr, Arity, PredCap, PredStr, PredStr, PredStr, PredCap, PredStr]).

%% translate_fold_expr_elixir(+PrologExpr, +InputVar, +AccVar, -ElixirExpr)
translate_fold_expr_elixir(A * B, InputVar, AccVar, ElixirExpr) :-
    translate_elixir_term(A, InputVar, AccVar, AT),
    translate_elixir_term(B, InputVar, AccVar, BT),
    format(string(ElixirExpr), '~w * ~w', [AT, BT]).
translate_fold_expr_elixir(A + B, InputVar, AccVar, ElixirExpr) :-
    translate_elixir_term(A, InputVar, AccVar, AT),
    translate_elixir_term(B, InputVar, AccVar, BT),
    format(string(ElixirExpr), '~w + ~w', [AT, BT]).
translate_fold_expr_elixir(A - B, InputVar, AccVar, ElixirExpr) :-
    translate_elixir_term(A, InputVar, AccVar, AT),
    translate_elixir_term(B, InputVar, AccVar, BT),
    format(string(ElixirExpr), '~w - ~w', [AT, BT]).
translate_fold_expr_elixir(Term, InputVar, AccVar, ElixirExpr) :-
    translate_elixir_term(Term, InputVar, AccVar, ElixirExpr).

translate_elixir_term(Term, InputVar, _AccVar, 'current') :- Term == InputVar, !.
translate_elixir_term(Term, _InputVar, AccVar, 'acc') :- Term == AccVar, !.
translate_elixir_term(Number, _, _, ElixirTerm) :- integer(Number), !,
    format(string(ElixirTerm), '~w', [Number]).
translate_elixir_term(Atom, _, _, ElixirTerm) :-
    format(string(ElixirTerm), '~w', [Atom]).

%% ============================================
%% MULTIFILE DISPATCH - Mutual Recursion
%% ============================================

:- use_module('../core/advanced/mutual_recursion').
:- multifile mutual_recursion:compile_mutual_pattern/5.

mutual_recursion:compile_mutual_pattern(elixir, Predicates, _MemoEnabled, _MemoStrategy, ElixirCode) :-
    compile_mutual_recursion_elixir(Predicates, [], ElixirCode).

% ============================================================================
% TREE RECURSION - Elixir target delegation (multifile)
% ============================================================================

:- use_module('../core/advanced/tree_recursion').
:- multifile tree_recursion:compile_tree_pattern/6.

tree_recursion:compile_tree_pattern(elixir, _Pattern, Pred, _Arity, _UseMemo, ExCode) :-
    atom_string(Pred, PredStr),
    upcase_atom(Pred, PredCap),
    format(string(ExCode),
'# Generated by UnifyWeaver Elixir Target - Tree Recursion (fibonacci, multifile dispatch)
defmodule ~w do
  use Agent

  def start_link do
    Agent.start_link(fn -> %{} end, name: __MODULE__)
  end

  def ~w(0), do: 0
  def ~w(1), do: 1
  def ~w(n) do
    case Agent.get(__MODULE__, &Map.get(&1, n)) do
      nil ->
        result = ~w(n - 1) + ~w(n - 2)
        Agent.update(__MODULE__, &Map.put(&1, n, result))
        result
      cached -> cached
    end
  end
end

case System.argv() do
  [n_str | _] ->
    ~w.start_link()
    {n, _} = Integer.parse(n_str)
    IO.puts(~w.~w(n))
  _ -> :ok
end
', [PredCap, PredStr, PredStr, PredStr, PredStr, PredStr, PredCap, PredCap, PredStr]).

% ============================================================================
% MULTICALL LINEAR RECURSION - Elixir target delegation (multifile)
% ============================================================================

:- use_module('../core/advanced/multicall_linear_recursion').
:- multifile multicall_linear_recursion:compile_multicall_pattern/6.

multicall_linear_recursion:compile_multicall_pattern(elixir, PredStr, BaseClauses, _RecClauses, _MemoEnabled, ExCode) :-
    atom_string(PredAtom, PredStr),
    upcase_atom(PredAtom, PredCap),
    findall(BaseCaseCode, (
        member(clause(BHead, _), BaseClauses),
        BHead =.. [_P, BInput, BOutput],
        format(string(BaseCaseCode), '  def ~w(~w), do: ~w', [PredStr, BInput, BOutput])
    ), BaseCaseCodes0),
    sort(BaseCaseCodes0, BaseCaseCodes),
    atomic_list_concat(BaseCaseCodes, '\n', BaseCaseStr),
    format(string(ExCode),
'# Generated by UnifyWeaver Elixir Target - Multicall Linear Recursion (multifile dispatch)
defmodule ~w do
  use Agent

  def start_link do
    Agent.start_link(fn -> %{} end, name: __MODULE__)
  end

~w
  def ~w(n) do
    case Agent.get(__MODULE__, &Map.get(&1, n)) do
      nil ->
        result = ~w(n - 1) + ~w(n - 2)
        Agent.update(__MODULE__, &Map.put(&1, n, result))
        result
      cached -> cached
    end
  end
end

case System.argv() do
  [n_str | _] ->
    ~w.start_link()
    {n, _} = Integer.parse(n_str)
    IO.puts(~w.~w(n))
  _ -> :ok
end
', [PredCap, BaseCaseStr, PredStr, PredStr, PredStr, PredCap, PredCap, PredStr]).

% ============================================================================
% DIRECT MULTI-CALL RECURSION - Elixir target delegation (multifile)
% ============================================================================

:- use_module('../core/advanced/direct_multi_call_recursion').
:- use_module('../core/advanced/pattern_matchers', [is_per_path_visited_pattern/4]).
:- multifile direct_multi_call_recursion:compile_direct_multicall_pattern/5.

direct_multi_call_recursion:compile_direct_multicall_pattern(elixir, PredStr, BaseClauses, _RecClause, ExCode) :-
    atom_string(PredAtom, PredStr),
    upcase_atom(PredAtom, PredCap),
    findall(BaseCaseCode, (
        member(clause(BHead, _), BaseClauses),
        BHead =.. [_P, BInput, BOutput],
        format(string(BaseCaseCode), '  def ~w(~w), do: ~w', [PredStr, BInput, BOutput])
    ), BaseCaseCodes0),
    sort(BaseCaseCodes0, BaseCaseCodes),
    atomic_list_concat(BaseCaseCodes, '\n', BaseCaseStr),
    format(string(ExCode),
'# Generated by UnifyWeaver Elixir Target - Direct Multicall Recursion (multifile dispatch)
defmodule ~w do
  use Agent

  def start_link do
    Agent.start_link(fn -> %{} end, name: __MODULE__)
  end

~w
  def ~w(input) do
    case Agent.get(__MODULE__, &Map.get(&1, input)) do
      nil ->
        result = ~w(input - 1) + ~w(input - 2)
        Agent.update(__MODULE__, &Map.put(&1, input, result))
        result
      cached -> cached
    end
  end
end

case System.argv() do
  [n_str | _] ->
    ~w.start_link()
    {n, _} = Integer.parse(n_str)
    IO.puts(~w.~w(n))
  _ -> :ok
end
', [PredCap, BaseCaseStr, PredStr, PredStr, PredStr, PredCap, PredCap, PredStr]).

%% ============================================
%% GENERAL RECURSIVE PATTERN (visited-set cycle safety)
%% ============================================

:- multifile advanced_recursive_compiler:compile_general_recursive_pattern/6.

%% No-visited-pattern — plain recursive without cycle detection
advanced_recursive_compiler:compile_general_recursive_pattern(elixir, PredStr, Arity, BaseClauses, RecClauses, Code) :-
    atom_string(Pred, PredStr),
    append(BaseClauses, RecClauses, AllClauses),
    \+ is_per_path_visited_pattern(Pred, Arity, AllClauses, _),
    !,
    (   BaseClauses = [(BaseHead, _)|_],
        BaseHead =.. [_|BaseArgs], last(BaseArgs, BaseResult)
    ->  term_to_atom(BaseResult, BaseValAtom), atom_string(BaseValAtom, BaseValStr),
        BaseArgs = [BaseInput|_], term_to_atom(BaseInput, BaseInAtom), atom_string(BaseInAtom, BaseInStr)
    ;   BaseValStr = "[]", BaseInStr = "0"
    ),
    format(string(Code),
'# General recursive: ~w (plain, no visited pattern)\n\c
\n\c
defmodule GeneralRecursion do\n\c
  def ~w(arg1) do\n\c
    if arg1 == ~w do\n\c
      [~w]\n\c
    else\n\c
      ~w(to_string(arg1))\n\c
    end\n\c
  end\n\c
end\n',
    [PredStr, PredStr, BaseInStr, BaseValStr, PredStr]).

advanced_recursive_compiler:compile_general_recursive_pattern(elixir, PredStr, _Arity, BaseClauses, _RecClauses, Code) :-
    %% Extract base value from first base clause
    (   BaseClauses = [(BaseHead, _BaseBody)|_],
        BaseHead =.. [_|BaseArgs],
        last(BaseArgs, BaseResult)
    ->  term_to_atom(BaseResult, BaseValAtom),
        atom_string(BaseValAtom, BaseValStr)
    ;   BaseValStr = "[]"
    ),
    %% Extract base input from first base clause
    (   BaseClauses = [(BaseHead2, _)|_],
        BaseHead2 =.. [_|BaseArgs2],
        BaseArgs2 = [BaseInput|_]
    ->  term_to_atom(BaseInput, BaseInAtom),
        atom_string(BaseInAtom, BaseInStr)
    ;   BaseInStr = "0"
    ),
    %% Convert pred_name to worker name
    string_concat(PredStr, "_worker", WorkerStr),
    format(string(Code),
'# Generated by UnifyWeaver Elixir Target - General Recursion with Visited Set

defmodule GeneralRecursion do
  def ~w(arg1), do: ~w(arg1, MapSet.new())

  defp ~w(arg1, visited) do
    if MapSet.member?(visited, arg1) do
      []
    else
      if arg1 == ~w do
        [~w]
      else
        visited = MapSet.put(visited, arg1)
        ~w(to_string(arg1), visited)
      end
    end
  end
end',
        [PredStr, WorkerStr,
         WorkerStr,
         BaseInStr, BaseValStr,
         WorkerStr]).
