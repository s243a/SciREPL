:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)
%
% wam_elixir_lowered_emitter.pl - WAM-to-Elixir Lowered Emitter
%
% Compiles WAM instructions directly to Elixir function calls/expressions
% instead of instruction-array interpretation.

:- module(wam_elixir_lowered_emitter, [
    lower_predicate_to_elixir/4,  % +PredIndicator, +WamCode, +Options, -Code
    wam_elixir_lower_instr/6,     % +Instr, +PC, +Labels, +FuncName, +Suffix, -Code
    % Phase A fact-shape classification (see docs/proposals/WAM_FACT_SHAPE_*.md).
    % Emitter-internal for now; may move to its own module once other
    % targets adopt the same classification.
    classify_predicate/4,         % +PredIndicator, +Segments, +Options, -Info
    clause_count/2,               % +Segments, -N
    fact_only/2,                  % +Segments, -Bool
    first_arg_groundness/3,       % +Segments, +Arity, -Status
    % Phase B fact extraction. Exported so tests can exercise it.
    extract_facts/3,              % +Segments, +Arity, -ElixirListLiteral
    % Phase C first-argument indexing.
    extract_arg1_index/3,         % +Segments, +Arity, -IndexResult
    % Tier-2 purity gate (see docs/design/WAM_TIERED_LOWERING.md).
    % Consumed by `par_wrap_segment/4` to decide whether a predicate
    % is eligible for host-native parallel emission.
    tier2_purity_eligible/3,      % +Pred, +Arity, -Cert
    % Tier-2 super-wrapper emitter. Takes clause segments + options,
    % emits either the cond-based Task.async_stream fan-out or an
    % empty string (gates rejected). Not wired into the main emission
    % path yet — live hook-up is a follow-on PR.
    par_wrap_segment/4            % +Pred/Arity, +Segments, +Options, -Code
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module(library(pairs), [group_pairs_by_key/2]).
:- use_module('wam_elixir_utils', [reg_id/2, is_label_part/1, camel_case/2, parse_arity/2]).
:- use_module('../targets/wam_text_parser', [wam_classify_constant_token/2]).
:- use_module('../core/purity_certificate', [analyze_predicate_purity/2]).
:- use_module('../core/predicate_preprocessing',
              [declared_preprocess_metadata/4]).

% ============================================================================
% MAIN ENTRY POINT
% ============================================================================

%% lower_predicate_to_elixir(+PredIndicator, +WamCode, +Options, -Code)
%
%  Dispatches on the Phase-A classification layout:
%    - `compiled`    — emit one `defp` per clause (unchanged path)
%    - `inline_data` — emit `@facts [{...}, ...]` and a single
%      `run/1` that delegates to `WamRuntime.stream_facts/3`
%    - `external_source` — Phase D, currently falls back to `compiled`
%
%  Falling back to `compiled` is always safe and preserves correctness,
%  so an extraction failure (e.g., a compound head arg we can\'t yet
%  represent inline) silently falls back instead of erroring.
lower_predicate_to_elixir(Pred/Arity, WamCode, Options, Code) :-
    atom_string(WamCode, WamStr),
    split_string(WamStr, "\n", "", Lines),
    collect_labels(Lines, 1, Labels),
    split_into_segments(Lines, 1, Segments0),
    clause_body_segments(Segments0, ClauseSegments),
    atom_string(Pred, PredStr),
    camel_case(PredStr, CamelPred),
    option(module_name(ModName), Options, 'WamPredLow'),
    camel_case(ModName, CamelMod),
    classify_predicate(Pred/Arity, ClauseSegments, Options, Info),
    format_fact_shape_comment(Info, ShapeComment),
    Info = fact_shape_info(_, _, _, Layout),
    (   Layout = external_source(_)
    ->  render_external_source_module(CamelMod, CamelPred, PredStr, Arity,
                                      ShapeComment, Layout, Code)
    ;   Layout = external_source(_, _)
    ->  render_external_source_module(CamelMod, CamelPred, PredStr, Arity,
                                      ShapeComment, Layout, Code)
    ;   Layout = inline_data(_),
        catch(extract_facts(ClauseSegments, Arity, FactsLiteral), _, fail),
        choose_index(ClauseSegments, Arity, Options, IndexResult)
    ->  render_inline_data_module(CamelMod, CamelPred, PredStr, Arity,
                                  ShapeComment, FactsLiteral, IndexResult, Code)
    ;   render_compiled_module(CamelMod, CamelPred, Pred/Arity, PredStr,
                               ShapeComment, Segments0, Labels, Options, Code)
    ).

%% choose_index(+Segments, +Arity, +Options, -IndexResult)
%  IndexResult is `indexed(MapLiteral)` when Phase-C first-arg indexing
%  applies (arity >= 1 ∧ every clause has a ground arg1 ∧ policy allows
%  it), or `no_index` otherwise. The policy is the `fact_index_policy`
%  option: `none` disables; `auto` (default) and `first_arg` enable.
choose_index(_Segments, 0, _Options, no_index) :- !.
choose_index(Segments, Arity, Options, IndexResult) :-
    Arity >= 1,
    option(fact_index_policy(Policy), Options, auto),
    (   Policy == none
    ->  IndexResult = no_index
    ;   catch(extract_arg1_index(Segments, Arity, IndexResult), _, IndexResult = no_index)
    ).

render_compiled_module(CamelMod, CamelPred, PredIndicator, PredStr, ShapeComment,
                       Segments, Labels, Options, Code) :-
    PredIndicator = Pred/Arity,
    % Tier-2 decision point: if par_wrap_segment/4 emits a super-wrapper,
    % the per-clause bodies need to live under `_impl`-suffixed names so
    % the canonical `clause_main` slot can be taken by the super-wrapper.
    % When the gate rejects, Tier2Wrapper = "" and Suffix = "" — every
    % emitted byte is byte-for-byte identical to the pre-wiring output.
    par_wrap_segment(Pred/Arity, Segments, Options, Tier2Wrapper),
    (   Tier2Wrapper == ""
    ->  Suffix = "",
        Tier2Extras = "",
        Tier2ModAttr = "",
        BranchFuncCodes = []
    ;   Suffix = "_impl",
        % The super-wrapper (Tier2Wrapper) already calls the
        % `*_impl` entry directly from its gate-miss cond arms, so
        % no separate sequential alias is emitted here.
        Tier2Extras = Tier2Wrapper,
        Tier2ModAttr = '  @tier2_eligible true\n',
        % Phase 4b.5: Tier-2-eligible predicates ALSO emit `_branch`
        % variants of each clause function. The super-wrappers
        % parallel branches (in BranchImplFuncs) point at these.
        % The `_branch` versions run only their own clause body
        % without pushing a try_me_else CP for the next clause —
        % each branch enumerates ONLY its own clauses solutions,
        % avoiding the duplicate-enumeration finding from #1706.
        generate_all_segments(Segments, Labels, "_branch", BranchFuncCodes)
    ),
    generate_all_segments(Segments, Labels, Suffix, ImplFuncCodes),
    append(ImplFuncCodes, BranchFuncCodes, FuncCodes),
    atomic_list_concat(FuncCodes, '\n\n', FuncsBody),
    % `def run(state)` always delegates to `clause_main` — which is the
    % super-wrapper under Tier 2, or the first clause's body pre-Tier-2.
    % Both end up at the same surface name.
    Segments = [FirstSegName-_|_],
    segment_func_name(FirstSegName, "", FirstFunc),
    format(string(Code),
'defmodule ~w.~w do
  @moduledoc "Lowered WAM-compiled predicate: ~w/~w"
~w
~w

  # run/1 is a plain tail call into the first clause segment. No
  # try/catch here — failures propagate via throw({:fail, state}) up to
  # the outermost catch in run(args). Without this, every cross-predicate
  # dispatch (WamDispatcher.call → Pred.run) would add a try frame that
  # defeats tail-call optimisation. Carrying state in the throw lets each
  # enclosing catch backtrack on the most-current state (with CPs pushed
  # during body execution intact), not the pre-try snapshot.
  def run(%WamRuntime.WamState{} = state), do: ~w(state)

  def run(args) when is_list(args) do
    state = %WamRuntime.WamState{code: {}, labels: %{}, pc: 1}
    {state, arg_vars} = Enum.with_index(args, 1)
    |> Enum.reduce({state, []}, fn {arg, i}, {s, vars} ->
      case arg do
        {:unbound, _} ->
          v = {:unbound, make_ref()}
          {%{s | regs: Map.put(s.regs, i, v)}, [{i, v} | vars]}
        other ->
          {%{s | regs: Map.put(s.regs, i, other)}, vars}
      end
    end)
    state = %{state | arg_vars: arg_vars, cp: &WamRuntime.terminal_cp/1}
    try do
      case run(state) do
        {:ok, final} -> {:ok, WamRuntime.materialise_args(final)}
        other -> other
      end
    catch
      {:fail, _} -> :fail
      {:return, result} -> result
      # PR #2: an uncaught Prolog throw (no enclosing catch/3 on
      # the BEAM stack matched the thrown term) reaches here. Mirror
      # the empty-catcher_frames case in execute_throw — diagnostic
      # to stderr, return :fail rather than crash.
      {:wam_throw, term, _heap, _heap_len} ->
        IO.puts(:stderr, "Uncaught Prolog throw: #{inspect(term)}")
        :fail
      error ->
        IO.puts("Predicate ~w CRASHED: #{inspect(error)}")
        :fail
    end
  end

~w

~w
end', [CamelMod, CamelPred, PredStr, Arity, ShapeComment, Tier2ModAttr,
       FirstFunc, CamelPred, FuncsBody, Tier2Extras]).

render_inline_data_module(CamelMod, CamelPred, PredStr, Arity, ShapeComment,
                          FactsLiteral, IndexResult, Code) :-
    inline_data_index_block(IndexResult, IndexBlock),
    inline_data_run1_body(IndexResult, Arity, RunBody),
    format(string(Code),
'defmodule ~w.~w do
  @moduledoc "Lowered WAM-compiled predicate: ~w/~w (inline_data)"

~w

  # Phase-B inline_data layout: facts live as a module attribute, not as
  # per-fact defp functions. run/1 delegates to WamRuntime.stream_facts,
  # which iterates @facts, attempts unification on each tuple, and
  # pushes a fact-stream CP on success so backtracking resumes at the
  # next tuple. :_var in a tuple slot means the head arg was a variable
  # — it unifies trivially with any incoming value.
  @facts ~w
~w

  def run(%WamRuntime.WamState{} = state) do
~w  end

  def run(args) when is_list(args) do
    state = %WamRuntime.WamState{code: {}, labels: %{}, pc: 1}
    {state, arg_vars} = Enum.with_index(args, 1)
    |> Enum.reduce({state, []}, fn {arg, i}, {s, vars} ->
      case arg do
        {:unbound, _} ->
          v = {:unbound, make_ref()}
          {%{s | regs: Map.put(s.regs, i, v)}, [{i, v} | vars]}
        other ->
          {%{s | regs: Map.put(s.regs, i, other)}, vars}
      end
    end)
    state = %{state | arg_vars: arg_vars, cp: &WamRuntime.terminal_cp/1}
    try do
      case run(state) do
        {:ok, final} -> {:ok, WamRuntime.materialise_args(final)}
        other -> other
      end
    catch
      {:fail, _} -> :fail
      {:return, result} -> result
      # PR #2: uncaught Prolog throw -> :fail + stderr (not crash).
      {:wam_throw, term, _heap, _heap_len} ->
        IO.puts(:stderr, "Uncaught Prolog throw: #{inspect(term)}")
        :fail
      error ->
        IO.puts("Predicate ~w CRASHED: #{inspect(error)}")
        :fail
    end
  end
end', [CamelMod, CamelPred, PredStr, Arity, ShapeComment,
       FactsLiteral, IndexBlock, RunBody, CamelPred]).

%% inline_data_index_block(+IndexResult, -Block)
%  Emits the `@facts_by_arg1` module attribute when indexing is on;
%  otherwise empty string.
inline_data_index_block(no_index, "").
inline_data_index_block(indexed(IndexLit), Block) :-
    format(string(Block), '  @facts_by_arg1 ~w', [IndexLit]).

%% inline_data_run1_body(+IndexResult, +Arity, -Body)
%  `run(%WamState{} = state)` body. Indexed: deref arg1 and pick either
%  the matching bucket or the full list. Non-indexed: stream the full
%  list unconditionally.
inline_data_run1_body(no_index, Arity, Body) :-
    format(string(Body),
           '    WamRuntime.stream_facts(state, @facts, ~w)\n', [Arity]).
inline_data_run1_body(indexed(_), Arity, Body) :-
    format(string(Body),
'    arg1 = WamRuntime.deref_var(state, Map.get(state.regs, 1))
    facts = case arg1 do
      {:unbound, _} -> @facts
      key -> Map.get(@facts_by_arg1, key, [])
    end
    WamRuntime.stream_facts(state, facts, ~w)
', [Arity]).

%% render_external_source_module(+CamelMod, +CamelPred, +PredStr, +Arity,
%%                               +ShapeComment, +Layout, -Code)
%  Phase-D external_source layout: no inline facts. `run/1` looks the
%  source up in the FactSourceRegistry (drivers must register before
%  calling), then dispatches to stream_all/lookup_by_arg1 through the
%  FactSource behaviour facade. The SourceSpec the user passed in
%  fact_layout/2 remains opaque to the runtime adaptor path, but the
%  generated module now also exposes any shared preprocess declaration
%  metadata that was attached to the layout so manifest- / provider-like
%  tooling can inspect the intended access contract.
render_external_source_module(CamelMod, CamelPred, PredStr, Arity, ShapeComment,
                              Layout, Code) :-
    format(string(PredIndicator), '~w/~w', [PredStr, Arity]),
    external_source_layout_parts(Layout, SourceSpec, Metadata),
    external_source_metadata_block(SourceSpec, Metadata, MetadataBlock),
    format(string(Code),
'defmodule ~w.~w do
  @moduledoc "Lowered WAM-compiled predicate: ~w/~w (external_source)"

~w

~w

  # Phase-D external_source layout: facts live outside the compiled
  # module. A driver registers a concrete WamRuntime.FactSource (e.g.
  # Tsv) for this predicate before calling run/1; the registry lookup
  # returns the handle which dispatches via the FactSource behaviour.
  @pred_indicator "~w"

  def run(%WamRuntime.WamState{} = state) do
    source = WamRuntime.FactSourceRegistry.lookup!(@pred_indicator)
    arg1 = WamRuntime.deref_var(state, Map.get(state.regs, 1))
    facts = case arg1 do
      {:unbound, _} -> WamRuntime.FactSource.stream_all(source, state)
      key -> WamRuntime.FactSource.lookup_by_arg1(source, key, state)
    end
    WamRuntime.stream_facts(state, facts, ~w)
  end

  def run(args) when is_list(args) do
    state = %WamRuntime.WamState{code: {}, labels: %{}, pc: 1}
    {state, arg_vars} = Enum.with_index(args, 1)
    |> Enum.reduce({state, []}, fn {arg, i}, {s, vars} ->
      case arg do
        {:unbound, _} ->
          v = {:unbound, make_ref()}
          {%{s | regs: Map.put(s.regs, i, v)}, [{i, v} | vars]}
        other ->
          {%{s | regs: Map.put(s.regs, i, other)}, vars}
      end
    end)
    state = %{state | arg_vars: arg_vars, cp: &WamRuntime.terminal_cp/1}
    try do
      case run(state) do
        {:ok, final} -> {:ok, WamRuntime.materialise_args(final)}
        other -> other
      end
    catch
      {:fail, _} -> :fail
      {:return, result} -> result
      # PR #2: uncaught Prolog throw -> :fail + stderr (not crash).
      {:wam_throw, term, _heap, _heap_len} ->
        IO.puts(:stderr, "Uncaught Prolog throw: #{inspect(term)}")
        :fail
      error ->
        IO.puts("Predicate ~w CRASHED: #{inspect(error)}")
        :fail
    end
  end
end', [CamelMod, CamelPred, PredStr, Arity, ShapeComment, MetadataBlock,
       PredIndicator, Arity, CamelPred]).

external_source_layout_parts(external_source(SourceSpec), SourceSpec, none).
external_source_layout_parts(external_source(SourceSpec, Metadata), SourceSpec, Metadata).

external_source_metadata_block(SourceSpec, Metadata, Block) :-
    elixir_term_string_literal(SourceSpec, SourceSpecLit),
    external_source_preprocess_map(Metadata, PreprocessMap),
    format(string(Block),
'  @external_source_spec ~w
  @external_source_metadata %{source_spec: @external_source_spec, preprocess: ~w}
  def external_source_metadata, do: @external_source_metadata',
           [SourceSpecLit, PreprocessMap]).

external_source_preprocess_map(none, 'nil').
external_source_preprocess_map(preprocess_metadata(Source, Mode, Kind, Format,
                                                   AccessContracts, Options),
                               MapLiteral) :-
    elixir_term_string_literal(Source, SourceLit),
    elixir_term_string_literal(Mode, ModeLit),
    elixir_term_string_literal(Kind, KindLit),
    elixir_term_string_literal(Format, FormatLit),
    elixir_string_list_literal(AccessContracts, AccessLit),
    elixir_string_list_literal(Options, OptionsLit),
    format(string(MapLiteral),
           '%{source: ~w, mode: ~w, kind: ~w, format: ~w, access_contracts: ~w, options: ~w}',
           [SourceLit, ModeLit, KindLit, FormatLit, AccessLit, OptionsLit]).

elixir_string_list_literal(Terms, Literal) :-
    maplist(elixir_term_string_literal, Terms, Literals),
    sort(Literals, SortedLiterals),
    atomic_list_concat(SortedLiterals, ', ', Body),
    format(atom(Literal), '[~w]', [Body]).

elixir_term_string_literal(Term, Literal) :-
    term_string(Term, TermString),
    escape_elixir_string(TermString, Escaped),
    format(atom(Literal), '"~w"', [Escaped]).

escape_elixir_string(In, Out) :-
    split_string(In, "\\", "", Parts1),
    atomic_list_concat(Parts1, "\\\\", Tmp1),
    split_string(Tmp1, "\"", "", Parts2),
    atomic_list_concat(Parts2, "\\\"", Out).

% ============================================================================
% PHASE A: FACT-SHAPE CLASSIFICATION
% ============================================================================
%
% Observation-only in this phase — the chosen `Layout` field is
% surfaced as a module-level comment, but every predicate still emits
% via the existing `compiled` code path. Phase B switches actual
% emission on Layout. See docs/proposals/WAM_FACT_SHAPE_SPEC.md for
% the wider contract.

%% classify_predicate(+PredIndicator, +Segments, +Options, -Info)
%  Info is the term `fact_shape_info(NClauses, FactOnly, FirstArg, Layout)`.
classify_predicate(Pred/Arity, Segments0, Options, Info) :-
    clause_body_segments(Segments0, Segments),
    clause_count(Segments, NClauses),
    fact_only(Segments, FactOnly),
    first_arg_groundness(Segments, Arity, FirstArg),
    pick_layout(Pred/Arity, NClauses, FactOnly, Options, Layout),
    Info = fact_shape_info(NClauses, FactOnly, FirstArg, Layout).

%% clause_body_segments(+Segments0, -Segments) is det.
%  Keep actual clause-body segments and drop WAM indexing / choice-chain
%  scaffolding segments. Newer WAM output can insert retry/trust-only labels
%  between fact body labels; counting those as clauses broke Phase-A layout
%  classification and inline-data extraction.
clause_body_segments(Segments0, Segments) :-
    include(clause_body_segment, Segments0, Segments).

clause_body_segment(_Name-Instrs) :-
    member(_PC-Instr, Instrs),
    \+ classifier_scaffold_instr(Instr),
    !.

classifier_scaffold_instr(try_me_else(_)).
classifier_scaffold_instr(retry_me_else(_)).
classifier_scaffold_instr(trust_me).
classifier_scaffold_instr(switch_on_constant(_)).
classifier_scaffold_instr(switch_on_constant_a2(_)).
classifier_scaffold_instr(switch_on_constant_fallthrough(_)).
classifier_scaffold_instr(switch_on_constant_a2_fallthrough(_)).
classifier_scaffold_instr(switch_on_structure(_)).
classifier_scaffold_instr(switch_on_structure_a2(_)).
classifier_scaffold_instr(switch_on_term(_)).
classifier_scaffold_instr(switch_on_term_a2(_)).

%% clause_count(+Segments, -N)
%  Counts semantic clause-body segments. Raw split_into_segments/3 output may
%  include indexing / choice-chain scaffolding labels; those are ignored.
clause_count(Segments0, N) :-
    clause_body_segments(Segments0, Segments),
    length(Segments, N).

%% fact_only(+Segments, -Bool)
%  `true` iff no semantic clause has a body-level call.
fact_only(Segments0, true) :-
    clause_body_segments(Segments0, Segments),
    forall(member(_-Instrs, Segments),
           forall(member(_-Instr, Instrs),
                  \+ is_body_call_instr(Instr))), !.
fact_only(_, false).

is_body_call_instr(call(_, _)).
is_body_call_instr(execute(_)).
is_body_call_instr(builtin_call(_, _)).

%% first_arg_groundness(+Segments, +Arity, -Status)
%  Status is one of: `none` (arity 0), `all_ground`, `all_variable`,
%  `mixed`. Determined by which head-unification instruction binds A1
%  in each clause.
first_arg_groundness(_Segments, 0, none) :- !.
first_arg_groundness(Segments0, Arity, Status) :-
    Arity > 0,
    clause_body_segments(Segments0, Segments),
    maplist(clause_arg1_type, Segments, Types),
    combine_groundness(Types, Status).

clause_arg1_type(_-Instrs, Type) :-
    (   member(_-get_constant(_, "A1"), Instrs) -> Type = ground
    ;   member(_-get_structure(_, "A1"), Instrs) -> Type = ground
    ;   member(_-get_variable(_, "A1"), Instrs) -> Type = variable
    ;   member(_-get_value(_, "A1"), Instrs)    -> Type = variable
    ;   Type = unknown
    ).

combine_groundness(Types, all_ground)   :- forall(member(T, Types), T == ground), !.
combine_groundness(Types, all_variable) :- forall(member(T, Types), T == variable), !.
combine_groundness(_, mixed).

%% pick_layout(+PredIndicator, +NClauses, +FactOnly, +Options, -Layout)
%  User override via `fact_layout/2` in Options or `user:fact_layout/2`
%  always wins. Otherwise dispatches to the Phase-E pluggable policy
%  `layout_policy/5` — the default `auto` policy implements the
%  pre-Phase-E rule (fact-only ∧ count > threshold → `inline_data`),
%  but callers can select a different built-in or register their own
%  via the multifile `user:wam_elixir_layout_policy/5` hook.
pick_layout(PredIndicator, _NClauses, _FactOnly, Options, Layout) :-
    option(fact_layout(PredIndicator, UserLayout0), Options), !,
    augment_layout_metadata(PredIndicator, UserLayout0, Layout).
pick_layout(PredIndicator, _NClauses, _FactOnly, _Options, Layout) :-
    catch(user:fact_layout(PredIndicator, UserLayout0), _, fail), !,
    augment_layout_metadata(PredIndicator, UserLayout0, Layout).
pick_layout(PredIndicator, NClauses, FactOnly, Options, Layout) :-
    option(fact_layout_policy(PolicyName), Options, auto),
    layout_policy(PolicyName, PredIndicator, NClauses, FactOnly, Options, Layout0),
    augment_layout_metadata(PredIndicator, Layout0, Layout).

augment_layout_metadata(_PredIndicator, external_source(SourceSpec, Metadata),
                        external_source(SourceSpec, Metadata)) :-
    !.
augment_layout_metadata(PredIndicator, external_source(SourceSpec),
                        external_source(SourceSpec, MetadataTerm)) :-
    declared_preprocess_metadata(PredIndicator, Mode,
                                 preprocess_info(Kind, Options),
                                 Metadata),
    !,
    MetadataTerm = preprocess_metadata(shared_preprocess, Mode, Kind,
                                       Metadata.format,
                                       Metadata.access_contracts,
                                       Options).
augment_layout_metadata(_PredIndicator, Layout, Layout).

%% layout_policy(+Policy, +PredIndicator, +NClauses, +FactOnly, +Options, -Layout)
%  Phase-E pluggable layout selector. Three built-in policies:
%
%    auto            — Fact-only ∧ count > threshold → `inline_data`,
%                      else `compiled`. Threshold from
%                      `fact_count_threshold` option (default 100).
%                      Mirrors the pre-Phase-E default.
%    compiled_only   — Always `compiled`. Useful for bisecting
%                      regressions or for hosts where the inline
%                      literal cost is too high.
%    inline_eager    — Fact-only always → `inline_data([])`,
%                      ignoring the count threshold. Rule-bearing
%                      predicates still fall to `compiled`.
%
%  Users can add their own by asserting clauses on the multifile
%  `user:wam_elixir_layout_policy/5`; those take precedence over the
%  built-ins for the same policy name.
:- multifile user:wam_elixir_layout_policy/5.

layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout) :-
    catch(user:wam_elixir_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Layout0),
          _, fail),
    !,
    (   nonvar(Layout0)
    ->  Layout = Layout0
    ;   builtin_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout)
    ).
layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout) :-
    builtin_layout_policy(Policy, PredIndicator, NClauses, FactOnly, Options, Layout).

builtin_layout_policy(auto, _PredIndicator, NClauses, FactOnly, Options, Layout) :-
    option(fact_count_threshold(Threshold), Options, 100),
    (   FactOnly == true, NClauses > Threshold
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).
builtin_layout_policy(compiled_only, _PredIndicator, _NClauses, _FactOnly, _Options, compiled).
builtin_layout_policy(inline_eager, _PredIndicator, _NClauses, FactOnly, _Options, Layout) :-
    (   FactOnly == true
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).
builtin_layout_policy(cost_aware, _Pred/Arity, NClauses, FactOnly, Options, Layout) :-
    % Static cost estimate: NClauses × max(1, Arity). Proxies the
    % generated-module size since each clause contributes a tuple
    % of Arity slots. Default threshold 200 keeps the classic
    % arity-2 /count≥100 boundary (100 × 2 = 200) — same shape as
    % the `auto` policy for 2-column fact predicates, but smarter
    % when arity varies (arity-1 stays `compiled` longer; wide
    % arities flip to `inline_data` sooner).
    option(fact_cost_threshold(Threshold), Options, 200),
    Mult is max(1, Arity),
    CostScore is NClauses * Mult,
    (   FactOnly == true, CostScore > Threshold
    ->  Layout = inline_data([])
    ;   Layout = compiled
    ).

%% format_fact_shape_comment(+Info, -Comment)
%  Renders `Info` as an Elixir comment surfaced in the generated
%  module. Phase A uses this purely as documentation; Phase B+ reads
%  Info to pick the emission path.
format_fact_shape_comment(fact_shape_info(N, FactOnly, FirstArg, Layout), Comment) :-
    format(string(Comment),
'  # Fact-shape classification:
  #   clauses=~w fact_only=~w first_arg=~w layout=~w',
           [N, FactOnly, FirstArg, Layout]).

% ============================================================================
% TIER-2 PURITY GATE
% ============================================================================
%
% `par_wrap_segment/3` (PR2) checks a predicate\'s purity certificate
% before emitting the host-native parallel wrapper. Encapsulated here
% so the threshold (0.85) lives alongside the other emitter-facing
% classification helpers — and so a failing certificate fails the
% whole gate predicate (no partial-match leakage of Cert into the
% sequential fallback path). The 0.85 threshold matches Haskell\'s
% Tier-2 implementation (Phase P4).
%
% This is the Tier-2 infrastructure hand-off: the gate is wired but
% nothing calls it yet. PR2 adds `par_wrap_segment/3` in the
% SEGMENTATION section, which depends on this predicate.

%% tier2_purity_eligible(+Pred, +Arity, -Cert)
%  Succeeds iff `Pred/Arity` has a purity certificate with verdict
%  `pure` and confidence ≥ 0.85. Binds `Cert` for downstream logging
%  / debug. Fails silently for any other verdict — Tier-2 emission
%  defers to the Tier-3 sequential fallback when this fails.
tier2_purity_eligible(Pred, Arity, Cert) :-
    analyze_predicate_purity(Pred/Arity, Cert),
    Cert = purity_cert(pure, _Proof, Confidence, _Reasons),
    Confidence >= 0.85.

% ============================================================================
% PHASE B: INLINE_DATA FACT EXTRACTION
% ============================================================================
%
% Walks each clause\'s instruction list to build an Elixir tuple of the
% head args. Constants (from `get_constant`) become quoted strings.
% Variables (from `get_variable`) become `:_var`, meaning the head was
% a variable at that slot and any incoming value unifies trivially.
% Compound args (`get_structure` / `get_list`) are not representable
% inline yet — extraction fails and the caller falls back to `compiled`.

%% extract_facts(+Segments, +Arity, -ElixirLiteral)
%  ElixirLiteral is a string like "[\n    {\"a\", \"b\"},\n    ...\n  ]"
%  suitable for dropping into a module attribute.
extract_facts(Segments0, Arity, ElixirLiteral) :-
    clause_body_segments(Segments0, Segments),
    maplist(extract_clause_tuple(Arity), Segments, TupleLiterals),
    (   TupleLiterals = []
    ->  ElixirLiteral = '[]'
    ;   atomic_list_concat(TupleLiterals, ',\n    ', Joined),
        format(string(ElixirLiteral), '[\n    ~w\n  ]', [Joined])
    ).

extract_clause_tuple(Arity, _Name-Instrs, TupleLiteral) :-
    numlist(1, Arity, Slots),
    maplist(extract_arg_value(Instrs), Slots, Values),
    atomic_list_concat(Values, ', ', Inner),
    format(string(TupleLiteral), '{~w}', [Inner]).

extract_arg_value(Instrs, Slot, ElixirVal) :-
    format(string(AStr), 'A~w', [Slot]),
    (   member(_-get_constant(C, AStr), Instrs)
    ->  elixir_string_literal(C, ElixirVal)
    ;   member(_-get_variable(_, AStr), Instrs)
    ->  ElixirVal = ':_var'
    ;   member(_-get_value(_, AStr), Instrs)
    ->  ElixirVal = ':_var'
    ;   % get_structure / get_list / anything else → unrepresentable;
        % fail the whole extraction so lower_predicate_to_elixir/4
        % falls back to the compiled path.
        fail
    ).

%% elixir_string_literal(+RawString, -Literal)
%  Format a WAM constant token as an Elixir string. Quoted WAM atoms are
%  unquoted by wam_classify_constant_token/2 first, so atoms containing
%  separators round-trip through inline fact extraction.
elixir_string_literal(C, Literal) :-
    wam_classify_constant_token(C, Class),
    (   Class = atom(Value)
    ->  true
    ;   Class = integer(N)
    ->  number_string(N, Value)
    ;   Class = float(F)
    ->  number_string(F, Value)
    ),
    string_chars(Value, Chars),
    maplist(escape_elixir_char, Chars, NestedChars),
    append(NestedChars, EscapedChars),
    string_chars(Escaped, EscapedChars),
    format(string(Literal), '"~w"', [Escaped]).

escape_elixir_char('\\', ['\\', '\\']).
escape_elixir_char('"', ['\\', '"']).
escape_elixir_char(C, [C]).

% ============================================================================
% PHASE C: FIRST-ARGUMENT INDEXING
% ============================================================================
%
% When every clause has a ground first argument, an `@facts_by_arg1` map
% accompanies `@facts`. `run/1` derefs regs[1] and picks the matching
% bucket if ground, else falls back to the full list. This turns seeded
% queries from O(N) linear scan into O(1) bucket lookup + O(M) scan of
% just that bucket.

%% extract_arg1_index(+Segments, +Arity, -IndexResult)
%  IndexResult is `indexed(MapLiteral)` when a first-arg index applies;
%  `no_index` if any clause has a variable (or otherwise non-ground)
%  arg1 that we cannot use as a map key.
extract_arg1_index(Segments0, Arity, IndexResult) :-
    Arity >= 1,
    clause_body_segments(Segments0, Segments),
    maplist(extract_clause_arg1(Arity), Segments, KeyTuplePairs),
    (   all_pairs_have_ground_key(KeyTuplePairs)
    ->  group_and_render_index(KeyTuplePairs, MapLiteral),
        IndexResult = indexed(MapLiteral)
    ;   IndexResult = no_index
    ).

extract_clause_arg1(Arity, _Name-Instrs, Arg1Key-TupleLiteral) :-
    numlist(1, Arity, Slots),
    maplist(extract_arg_value(Instrs), Slots, Values),
    atomic_list_concat(Values, ', ', Inner),
    format(string(TupleLiteral), '{~w}', [Inner]),
    Values = [Arg1Literal | _],
    (   Arg1Literal == ':_var'
    ->  Arg1Key = var
    ;   Arg1Key = Arg1Literal
    ).

all_pairs_have_ground_key([]).
all_pairs_have_ground_key([Key-_ | Rest]) :-
    Key \== var,
    all_pairs_have_ground_key(Rest).

group_and_render_index(Pairs, MapLiteral) :-
    sort(0, @=<, Pairs, SortedPairs),
    group_pairs_by_key(SortedPairs, Grouped),
    maplist(render_index_entry, Grouped, Entries),
    atomic_list_concat(Entries, ',\n    ', Joined),
    format(string(MapLiteral), '%{\n    ~w\n  }', [Joined]).

render_index_entry(Key-Tuples, Entry) :-
    atomic_list_concat(Tuples, ', ', TupleList),
    format(string(Entry), '~w => [~w]', [Key, TupleList]).

% ============================================================================
% QUOTE-AWARE LINE TOKENIZATION
% ============================================================================
%
% The WAM text uses ` `, `,`, `\t` as token separators. Atoms containing
% those characters (e.g. `'Washington,_D.C.'`) are wrapped in single
% quotes by `wam_target:quote_wam_constant/2`. This tokenizer recognises
% the quotes, strips them, and honours `\'` / `\\` escapes so quoted
% tokens reparse to the original atom text.
%
% Unquoted tokens pass through unchanged — keeping hot paths (identifier
% atoms like `A1` or labels like `L_parent_2_2`) as cheap as the previous
% split_string-based code.

%% elixir_constant_literal(+TokenStr, -ElixirLiteral)
%  Format a WAM-bytecode constant token (atoms/numbers — quotes already
%  stripped by the tokenizer) as the Elixir literal that should appear
%  in lowered code. Numeric tokens emit as bare numbers; everything
%  else as a double-quoted string. Without this, every constant in the
%  lowered emitter is force-stringified, which silently breaks numeric
%  head-match: `iterate(0) :- ...` lowers to `val == "0"` instead of
%  `val == 0`, so iterate/1 fails for any caller passing an integer.
%
%  When intern_atoms_enabled/0 is asserted (set by the
%  intern_atoms(true) project Option), identifier-shape constants
%  emit as Elixir atom literals (`:foo`) instead of binaries
%  (`"foo"`). BEAM atoms compare via pointer equality (cheaper
%  than binary equality on hot paths) and avoid binary copies in
%  ETS / process-message-passing, at the cost of pressuring BEAMs
%  atom table. Bounded by the number of distinct atoms in the
%  source, which for typical Prolog programs is well below the
%  default ~1M atom table limit. See the experiment writeup for
%  measurements.
elixir_constant_literal(TokenStr, ElixirLiteral) :-
    %% Atom-vs-number disambiguation via wam_text_parser. A bare
    %% token `5` is the integer 5 (emit as bare); a quoted token
    %% `'5'` is the atom whose name is "5" (emit as :5 or "5" per
    %% the intern_atoms_enabled toggle).
    wam_classify_constant_token(TokenStr, Class),
    (   Class = integer(N)
    ->  format(string(ElixirLiteral), "~w", [N])
    ;   Class = float(F)
    ->  format(string(ElixirLiteral), "~w", [F])
    ;   Class = atom(Name),
        intern_atoms_enabled,
        valid_elixir_atom_name(Name)
    ->  format(string(ElixirLiteral), ':~w', [Name])
    ;   Class = atom(Name),
        format(string(ElixirLiteral), '"~w"', [Name])
    ).

%% intern_atoms_enabled is asserted by write_wam_elixir_project/3
%  (in wam_elixir_target.pl) when the project Options include
%  intern_atoms(true). Set/retract is wrapped in setup_call_cleanup
%  so a failed lowering doesnt leave the flag asserted across
%  subsequent generations.
:- dynamic intern_atoms_enabled/0.

%% valid_elixir_atom_name(+Str)
%  True if Str matches Elixirs unquoted-atom rule: starts with a
%  lowercase letter or underscore, rest is alphanumeric or
%  underscore. Constants that dont match (whitespace, punctuation,
%  uppercase-leading, etc.) emit as quoted strings even under
%  intern_atoms — emitting `:Foo` would mean "the module Foo" in
%  Elixir, not what we want.
valid_elixir_atom_name(Str) :-
    string_chars(Str, [First|Rest]),
    valid_atom_first_char(First),
    forall(member(C, Rest), valid_atom_rest_char(C)).

valid_atom_first_char(C) :- char_type(C, lower).
valid_atom_first_char('_').

valid_atom_rest_char(C) :- char_type(C, alnum).
valid_atom_rest_char('_').

%% tokenize_wam_line(+Line, -Tokens)
%  `Line` is any string or atom; `Tokens` is a list of strings, in order,
%  with separators removed and quoted regions unquoted/unescaped.
tokenize_wam_line(Line, Tokens) :-
    (   string(Line) -> LineStr = Line ; atom_string(Line, LineStr) ),
    string_chars(LineStr, Chars),
    tokenize_chars(Chars, Tokens).

tokenize_chars([], []).
tokenize_chars([C | Rest], Tokens) :-
    (   wam_separator_char(C)
    ->  tokenize_chars(Rest, Tokens)
    ;   C == '\''
    ->  read_quoted_chars(Rest, TokenChars, Remainder),
        % Preserve the outer single quotes attached to the token so
        % atom-vs-number is recoverable downstream via
        % wam_text_parser:wam_classify_constant_token/2 (bare `5`
        % is the integer 5; quoted `'5'` is the atom whose name is "5").
        string_chars(Token, ['\''|TokenChars]),
        Tokens = [Token | RestTokens],
        tokenize_chars(Remainder, RestTokens)
    ;   read_unquoted_chars([C | Rest], TokenChars, Remainder),
        string_chars(Token, TokenChars),
        Tokens = [Token | RestTokens],
        tokenize_chars(Remainder, RestTokens)
    ).

wam_separator_char(' ').
wam_separator_char('\t').
wam_separator_char(',').

% read_quoted_chars/3: returns the inner unescaped chars WITH the
% trailing closing quote appended. The caller prepends the opening
% quote so the produced token has both outer quotes preserved.
read_quoted_chars([], [], []).             % unterminated quote — yield what we have
read_quoted_chars(['\'' | Rest], ['\''], Rest).
read_quoted_chars(['\\', Escaped | Rest], [Real | More], Remainder) :-
    !,
    unescape_wam_char(Escaped, Real),
    read_quoted_chars(Rest, More, Remainder).
read_quoted_chars([C | Rest], [C | More], Remainder) :-
    read_quoted_chars(Rest, More, Remainder).

unescape_wam_char('\'', '\'').
unescape_wam_char('\\', '\\').
unescape_wam_char(C, C).

read_unquoted_chars([], [], []).
read_unquoted_chars([C | Rest], [], [C | Rest]) :- wam_separator_char(C), !.
read_unquoted_chars([C | Rest], [C | More], Remainder) :-
    read_unquoted_chars(Rest, More, Remainder).

% ============================================================================
% LABEL COLLECTION
% ============================================================================

collect_labels([], _, []).
collect_labels([Line|Rest], PC, OutLabels) :-
    tokenize_wam_line(Line, CleanParts),
    (   CleanParts = [First|_], is_label_part(First)
    ->  sub_string(First, 0, _, 1, LabelName),
        OutLabels = [LabelName-PC|RestLabels],
        collect_labels(Rest, PC, RestLabels)
    ;   CleanParts = []
    ->  collect_labels(Rest, PC, OutLabels)
    ;   NPC is PC + 1,
        collect_labels(Rest, NPC, OutLabels)
    ).

% ============================================================================
% SEGMENTATION & CODE GENERATION
% ============================================================================

split_into_segments([], _, []).
split_into_segments([Line|Rest], PC, Segments) :-
    tokenize_wam_line(Line, CleanParts),
    (   CleanParts == [] -> split_into_segments(Rest, PC, Segments)
    ;   CleanParts = [First|_], is_label_part(First)
    ->  sub_string(First, 0, _, 1, LabelName),
        extract_segment_body(Rest, PC, BodyLines, NextLines, NPC),
        Segments = [LabelName-BodyLines | RestSegments],
        split_into_segments(NextLines, NPC, RestSegments)
    ;   extract_segment_body([Line|Rest], PC, BodyLines, NextLines, NPC),
        Segments = ["clause_start"-BodyLines | RestSegments],
        split_into_segments(NextLines, NPC, RestSegments)
    ).

extract_segment_body([], PC, [], [], PC).
extract_segment_body([Line|Rest], PC, Body, Next, NPC) :-
    tokenize_wam_line(Line, CleanParts),
    (   CleanParts = [First|_], is_label_part(First)
    ->  Body = [], Next = [Line|Rest], NPC = PC
    ;   CleanParts == [] -> extract_segment_body(Rest, PC, Body, Next, NPC)
    ;   Body = [PC-Instr | RestBody],
        instr_from_parts(CleanParts, Instr),
        PC1 is PC + 1,
        extract_segment_body(Rest, PC1, RestBody, Next, NPC)
    ).

generate_all_segments(Segments, Labels, Suffix, SegCodes) :-
    % Build a list of per-segment code-lists and flatten with append/2
    % at the end. The previous recursive append(ThisSegCodes,
    % RestCodes, _) was O(N²) over segment count — noticeable on
    % predicates with thousands of fact clauses.
    %
    % Suffix is threaded through so Tier-2-eligible predicates can
    % emit `clause_X_impl` names while the surface `clause_X` slot is
    % taken by the super-wrapper. For the default Suffix="" path every
    % emitted byte is byte-for-byte identical to the pre-wiring output.
    maplist(generate_one_segment(Labels, Suffix, Segments), Segments, SegCodesNested),
    append(SegCodesNested, SegCodes).

generate_one_segment(Labels, Suffix, AllSegments, Name-Instrs, ThisSegCodes) :-
    segment_func_name(Name, Suffix, FuncName),
    % If this segment's body does not end in a control-transfer
    % instruction, control falls through to the next label in WAM
    % order. The lowered segments are independent functions, so make
    % that fall-through explicit by appending a synthetic jump to the
    % next segment. This is what wires an if-then-else else-branch
    % (which ends in plain head/body instructions, not a jump) to its
    % continuation; without it the else segment returned a raw
    % mid-execution state instead of proceeding. Well-formed clause
    % segments already end in proceed/execute/fail, so this is a no-op
    % for every non-ITE predicate (output stays byte-identical).
    maybe_add_fallthrough(Name, Instrs, AllSegments, Instrs1),
    classify_segment_head(Instrs1, HeadType, Prefix, BodyInstrs0),
    % When a retry/trust segment has an empty body (all instructions
    % were placed in a sibling _body segment for switch_on_constant
    % dispatch), inject a tail-call to the body function so the
    % retry path is not dead code.
    (   BodyInstrs0 == [],
        HeadType \= none,
        atom_string(Name, NameStr),
        string_concat(NameStr, "_body", BodyNameStr),
        member(BodyName-BodySiblingInstrs, AllSegments),
        atom_string(BodyName, BodyNameStr)
    ->  BodyInstrs = BodySiblingInstrs
    ;   BodyInstrs = BodyInstrs0
    ),
    split_body_at_calls(BodyInstrs, SubSegs),
    emit_sub_segments(SubSegs, FuncName, HeadType, Prefix, Labels, Suffix, ThisSegCodes).

%% maybe_add_fallthrough(+Name, +Instrs, +AllSegments, -Instrs1)
%  Append a synthetic `jump(NextLabel)` when this segment's last
%  instruction is not a control transfer and another segment follows it
%  in WAM order — making the implicit PC fall-through explicit for the
%  independent lowered segment functions. No-op (Instrs1 == Instrs) for
%  the last segment or any segment that already ends in a terminal, so
%  every non-ITE predicate is unaffected.
maybe_add_fallthrough(Name, Instrs, AllSegments, Instrs1) :-
    (   Instrs \= [],
        last(Instrs, _-LastInstr),
        \+ is_terminal_instr(LastInstr),
        next_segment_label(Name, AllSegments, NextLabel)
    ->  append(Instrs, [fallthrough-jump(NextLabel)], Instrs1)
    ;   Instrs1 = Instrs
    ).

%% is_terminal_instr(+Instr)
%  Instructions that transfer control away from the straight-line flow,
%  so the following label is NOT reached by fall-through. call/execute
%  carry their own continuation; end_aggregate throws fail.
is_terminal_instr(proceed).
is_terminal_instr(execute(_)).
is_terminal_instr(fail).
is_terminal_instr(halt).
is_terminal_instr(jump(_)).
is_terminal_instr(call(_, _)).
is_terminal_instr(end_aggregate(_)).
% A segment consisting of (or ending in) a choice-point head dispatches
% through the CP / empty-body sibling injection, never via PC fall-through,
% so it must not receive a synthetic jump.
is_terminal_instr(try_me_else(_)).
is_terminal_instr(retry_me_else(_)).
is_terminal_instr(trust_me).

%% next_segment_label(+Name, +AllSegments, -NextLabel)
%  The label of the segment immediately following Name in WAM order.
%  Fails when Name is the last segment.
next_segment_label(Name, AllSegments, NextLabel) :-
    append(_, [Name-_, NextLabel-_ | _], AllSegments), !.

%% split_body_at_calls(+Instrs, -SubSegs)
%  Splits a flat instr list into sub-segment lists, cutting after every
%  `call P, N` opcode AND after every `end_aggregate ValReg` opcode.
%  The terminator is the last element of its sub-segment; the next
%  sub-segment starts with the first instr after it. A body with
%  no terminators yields exactly one sub-segment.
%
%  Splitting at end_aggregate is what makes multiple findalls in one
%  clause body compose correctly: the post-end_aggregate code lives
%  in its own sub-segment, and end_aggregates lowering uses
%  WamRuntime.update_topmost_agg_cp/2 to point the agg frame at it
%  before throwing fail. Without this split, the post-end_aggregate
%  code ends up in the same sub-segment as end_aggregates throw fail
%  (dead code), and finalise tail-calls a stale agg_cp.cp.
split_body_at_calls(Instrs, SubSegs) :-
    split_body_at_calls_(Instrs, [], SubSegs).

split_body_at_calls_([], AccRev, [Seg]) :-
    reverse(AccRev, Seg).
split_body_at_calls_([PC-call(P, N) | Rest], AccRev, [Seg | RestSegs]) :-
    !,
    reverse([PC-call(P, N) | AccRev], Seg),
    split_body_at_calls_(Rest, [], RestSegs).
split_body_at_calls_([PC-end_aggregate(V) | Rest], AccRev, [Seg | RestSegs]) :-
    !,
    reverse([PC-end_aggregate(V) | AccRev], Seg),
    split_body_at_calls_(Rest, [], RestSegs).
split_body_at_calls_([Instr | Rest], AccRev, Segs) :-
    split_body_at_calls_(Rest, [Instr | AccRev], Segs).

%% emit_sub_segments(+SubSegs, +BaseFunc, +HeadType, +Labels, +Suffix, -Codes)
%  Emits one `defp` per sub-segment. The first uses wrap_segment (with
%  CP push for try_me_else / retry_me_else). Subsequent sub-segments are
%  plain `defp BaseFunc_kN(state) do ... end` continuations. Every
%  sub-segment except the last ends with a tail call to the next
%  continuation; the last ends with its natural tail (execute/proceed).
%
%  Suffix propagates to wrap_segment (for FallbackFunc resolution) and
%  to lower_instr_list (so switch_on_constant arms pick up the right
%  target names). BaseFunc is already suffixed by the caller, so the
%  `_kN` continuation format produces e.g. `clause_main_impl_k1`.
emit_sub_segments([OnlySeg], BaseFunc, HeadType, Prefix, Labels, Suffix, [Code]) :-
    lower_prefix_code(Prefix, Labels, BaseFunc, Suffix, PfxCode),
    lower_instr_list(OnlySeg, Labels, BaseFunc, Suffix, Exprs),
    atomic_list_concat(Exprs, '\n', BodyCode),
    wrap_segment(BaseFunc, HeadType, PfxCode, BodyCode, Suffix, Code).

emit_sub_segments([FirstSeg | MoreSegs], BaseFunc, HeadType, Prefix, Labels, Suffix, [FirstCode | MoreCodes]) :-
    MoreSegs = [_|_],
    format(string(NextFunc), '~w_k1', [BaseFunc]),
    lower_prefix_code(Prefix, Labels, BaseFunc, Suffix, PfxCode),
    lower_seg_with_continuation(FirstSeg, NextFunc, Labels, BaseFunc, Suffix, FirstBody),
    wrap_segment(BaseFunc, HeadType, PfxCode, FirstBody, Suffix, FirstCode),
    emit_cont_segments(MoreSegs, BaseFunc, 1, Labels, Suffix, MoreCodes).

%% lower_prefix_code(+Prefix, +Labels, +BaseFunc, +Suffix, -PfxCode)
%  Lower the pre-head instructions to Elixir source. "" when there is no
%  prefix (every ordinary clause), which keeps wrap_segment output
%  byte-for-byte identical to before.
lower_prefix_code([], _Labels, _BaseFunc, _Suffix, "") :- !.
lower_prefix_code(Prefix, Labels, BaseFunc, Suffix, PfxCode) :-
    lower_instr_list(Prefix, Labels, BaseFunc, Suffix, Exprs),
    atomic_list_concat(Exprs, '\n', PfxCode).

emit_cont_segments([FinalSeg], BaseFunc, Idx, Labels, Suffix, [Code]) :-
    format(string(FuncName), '~w_k~w', [BaseFunc, Idx]),
    lower_instr_list(FinalSeg, Labels, FuncName, Suffix, Exprs),
    atomic_list_concat(Exprs, '\n', BodyCode),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, BodyCode]).
emit_cont_segments([Seg | More], BaseFunc, Idx, Labels, Suffix, [Code | RestCodes]) :-
    More = [_|_],
    format(string(FuncName), '~w_k~w', [BaseFunc, Idx]),
    NextIdx is Idx + 1,
    format(string(NextFunc), '~w_k~w', [BaseFunc, NextIdx]),
    lower_seg_with_continuation(Seg, NextFunc, Labels, FuncName, Suffix, Body),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, Body]),
    emit_cont_segments(More, BaseFunc, NextIdx, Labels, Suffix, RestCodes).

%% lower_seg_with_continuation(+Instrs, +NextFunc, +Labels, +FuncName, +Suffix, -Body)
%  Lowers a sub-segment that ends with either `call P, N` or
%  `end_aggregate ValReg` — the two segment terminators recognised by
%  split_body_at_calls/2.
%
%  For `call`: emits pre-call instrs, sets state.cp = &NextFunc/1, then
%  tail-calls WamDispatcher.call. The called predicates `proceed`
%  routes control back to NextFunc rather than collapsing the stack.
%
%  For `end_aggregate`: emits pre-end_aggregate instrs, then updates
%  the topmost agg frames cp via update_topmost_agg_cp/2 to point at
%  NextFunc, then aggregate_collect, then throws fail. The throw
%  drives backtrack-to-finalise; finalise tail-calls the now-updated
%  agg_cp.cp = NextFunc, which is the post-end_aggregate sub-segment.
%  This lets multiple findalls in one body compose correctly.
lower_seg_with_continuation(Instrs, NextFunc, Labels, FuncName, Suffix, Body) :-
    append(InitInstrs, [_PC-Last], Instrs),
    (   Last = call(P, _N)
    ->  lower_call_terminator(InitInstrs, P, NextFunc, Labels, FuncName, Suffix, Body)
    ;   Last = end_aggregate(ValReg)
    ->  lower_end_aggregate_terminator(InitInstrs, ValReg, NextFunc, Labels, FuncName, Suffix, Body)
    ;   throw(error(unexpected_seg_terminator(Last), lower_seg_with_continuation/6))
    ).

lower_call_terminator(InitInstrs, P, NextFunc, Labels, FuncName, Suffix, Body) :-
    lower_instr_list(InitInstrs, Labels, FuncName, Suffix, InitExprs),
    format(string(TailCallCode),
'    state = %{state | cp: &~w/1}
    WamDispatcher.call("~w", state)', [NextFunc, P]),
    append(InitExprs, [TailCallCode], AllExprs),
    atomic_list_concat(AllExprs, '\n', Body).

lower_end_aggregate_terminator(InitInstrs, ValReg, NextFunc, Labels, FuncName, Suffix, Body) :-
    reg_id(ValReg, ValRegId),
    lower_instr_list(InitInstrs, Labels, FuncName, Suffix, InitExprs),
    format(string(EndAggCode),
'    state = WamRuntime.update_topmost_agg_cp(state, &~w/1)
    state = WamRuntime.aggregate_collect(state, ~w)
    throw({:fail, state})', [NextFunc, ValRegId]),
    append(InitExprs, [EndAggCode], AllExprs),
    atomic_list_concat(AllExprs, '\n', Body).

%% split_last_colon(+Entry, -Key, -Label)
%  Splits an "apple:L1" entry into Key="apple" and Label="L1".
%  For entries with multiple colons, splits at the LAST colon.
%  For entries with no colon, Label defaults to "default".
split_last_colon(Entry, Key, Label) :-
    split_string(Entry, ":", "", Parts),
    (   Parts = [_, _|_]
    ->  append(KeyParts, [LabelStr], Parts),
        atomic_list_concat(KeyParts, ':', KeyAtom),
        atom_string(KeyAtom, Key),
        Label = LabelStr
    ;   Key = Entry, Label = "default"
    ).

%% build_switch_arms(+Entries, -ArmsStr)
%  Builds inline Elixir case arms for switch_on_constant. Groups entries by
%  key first, because the WAM emitter may produce multiple entries for the
%  same first-arg constant (when multiple clauses share a first arg) — and
%  Elixir would then warn that later case-arms are unreachable.
%
%  For a key with a single non-"default" entry: dispatch directly to the
%  labeled clause (the switch's whole reason for existing — skip the
%  try_me_else chain). For any key with multiple entries OR a single
%  "default" entry: fall through to :ok, letting the surrounding
%  try_me_else / retry_me_else chain handle the choice non-deterministically.
build_switch_arms(Entries, Suffix, ArmsStr) :-
    maplist([E,K-L]>>split_last_colon(E, K, L), Entries, Pairs),
    keysort(Pairs, SortedPairs),
    group_pairs_by_key(SortedPairs, Groups),
    maplist(build_switch_arm_group(Suffix), Groups, Arms),
    atomic_list_concat(Arms, '\n          ', ArmsStr).

build_switch_arm_group(Suffix, Key-Labels, Arm) :-
    elixir_constant_literal(Key, KeyLit),
    (   Labels = [OnlyLabel],
        OnlyLabel \== "default"
    ->  segment_func_name(OnlyLabel, Suffix, LocalFunc),
        % Drop the outer try_me_else CP (pushed just before this switch):
        % we are deterministically dispatching to LocalFunc, so the outer
        % CP — which points at that same clause — would cause a duplicate
        % solution on backtracking. The inline-dispatched clause pushes
        % its own retry CP, which remains correct.
        format(string(Body),
               'throw({:return, ~w(%{state | choice_points: tl(state.choice_points)})})',
               [LocalFunc])
    ;   Body = ':ok'
    ),
    build_switch_arm_aliases(Key, KeyLit, Body, Arm).

build_switch_arm_aliases("[]", KeyLit, Body, Arm) :- !,
    format(string(Arm), '~w -> ~w\n          [] -> ~w', [KeyLit, Body, Body]).
build_switch_arm_aliases(_, KeyLit, Body, Arm) :-
    format(string(Arm), '~w -> ~w', [KeyLit, Body]).

segment_func_name("clause_start", "clause_main") :- !.
segment_func_name(Label, Name) :-
    camel_case(Label, Camel),
    format(string(Name), "clause_~w", [Camel]).

%% segment_func_name(+Label, +Suffix, -Name)
%  Suffix-aware variant used when the Tier-2 super-wrapper has taken
%  the canonical `clause_main` name and the per-clause bodies need to
%  live under an `_impl`-suffixed name (see
%  docs/proposals/WAM_ELIXIR_TIER2_WIRING.md). For Suffix="" the result
%  is identical to segment_func_name/2 — byte-for-byte regression
%  check is the existing test suite.
segment_func_name(Label, Suffix, Name) :-
    segment_func_name(Label, BaseName),
    (   Suffix == "" -> Name = BaseName
    ;   format(string(Name), "~w~w", [BaseName, Suffix])
    ).

% classify_segment_head(+Instrs, -HeadType, -Prefix, -BodyInstrs)
%
% Prefix holds any instructions that precede the choice-point head
% (try_me_else / retry_me_else / trust_me). For ordinary clauses the head
% is the first instruction so Prefix is []. For an if-then-else the WAM
% emits the shared head-arg setup (allocate, get_variable Y1.., get_level)
% BEFORE the try_me_else; those must run before the choice point is
% snapshotted so the else branch (which restores to that snapshot on
% backtrack) still sees the permanent registers. Using append/3 (rather
% than the former select/3) preserves that prefix in order.
classify_segment_head(Instrs, HeadType, Prefix, BodyInstrs) :-
    (   append(Pre0, [_-try_me_else(L)|Body0], Instrs) -> HeadType = try_me_else(L)
    ;   append(Pre0, [_-retry_me_else(L)|Body0], Instrs) -> HeadType = retry_me_else(L)
    ;   append(Pre0, [_-trust_me|Body0], Instrs) -> HeadType = trust_me
    ;   HeadType = none, Pre0 = [], Body0 = Instrs
    ), !,
    % switch_on_* indexing instructions can precede the head try_me_else
    % (multi-clause first-argument indexing); they manipulate the choice
    % point this segment pushes, so they must run AFTER it — keep them at
    % the front of the body, not in the pre-snapshot prefix. The remaining
    % pre-head instructions (an if-then-else's allocate / get_variable /
    % get_level head setup) form the real prefix. For ordinary clauses
    % Pre0 is [] (or all switches), so Prefix is [] and output is
    % byte-for-byte identical to before.
    partition(is_switch_instr_pc, Pre0, SwitchPre, Prefix),
    append(SwitchPre, Body0, BodyInstrs).

is_switch_instr_pc(_-Instr) :-
    functor(Instr, F, _),
    atom_concat(switch_on_, _, F).

% Phase 4b.5: _branch variant emission. When Suffix is "_branch" the
% function is called directly by the Tier-2 super-wrapper as one of
% its parallel branches — it must run only its own clause body
% without pushing a CP for the next clause (which would cause the
% branchs local backtrack to chain into subsequent clauses,
% producing duplicate solutions across branches; the chain-CP
% finding from Phase 4b's runtime probe). The no-push shape mirrors
% the existing trust_me / none templates.
% PfxCode (3rd arg) is the lowered pre-head prefix — empty "" for every
% ordinary clause (head is the first instruction), non-empty only for an
% if-then-else's shared head-arg setup. For the choice-point heads
% (try_me_else / retry_me_else) the prefix is emitted BEFORE the cp
% snapshot so the snapshot captures the permanent registers the else
% branch needs; for the no-snapshot heads it is prepended to the body.
% wrap_pfx_lead/2 and wrap_pfx_body/3 collapse to byte-identical output
% when PfxCode is "".
wrap_pfx_body("", Body, Body) :- !.
wrap_pfx_body(PfxCode, Body, Combined) :-
    atomic_list_concat([PfxCode, '\n', Body], Combined).

wrap_segment(FuncName, _HeadType, PfxCode, BodyCode0, "_branch", Code) :-
    !,
    wrap_pfx_body(PfxCode, BodyCode0, BodyCode),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, BodyCode]).

% No prefix (every ordinary clause): the cp snapshot sits before the
% try, byte-for-byte identical to the pre-change emitter.
wrap_segment(FuncName, try_me_else(L), "", BodyCode, Suffix, Code) :-
    !,
    segment_func_name(L, Suffix, FallbackFunc),
    format(string(Code),
'  defp ~w(state) do
    cp = %{pc: &~w/1, regs: state.regs, y_regs: state.y_regs,
           heap: state.heap, heap_len: state.heap_len,
           cp: state.cp, trail: state.trail, trail_len: state.trail_len, stack: state.stack}
    state = %{state | choice_points: [cp | state.choice_points]}
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, FallbackFunc, BodyCode]).
% if-then-else prefix: run the shared head setup INSIDE the try and take
% the cp snapshot after it, so the else branch (which restores to the
% snapshot on backtrack) sees the permanent registers, and any failing
% head match in the prefix backtracks cleanly through the existing choice
% points rather than escaping the function.
wrap_segment(FuncName, try_me_else(L), PfxCode, BodyCode, Suffix, Code) :-
    segment_func_name(L, Suffix, FallbackFunc),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    cp = %{pc: &~w/1, regs: state.regs, y_regs: state.y_regs,
           heap: state.heap, heap_len: state.heap_len,
           cp: state.cp, trail: state.trail, trail_len: state.trail_len, stack: state.stack}
    state = %{state | choice_points: [cp | state.choice_points]}
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, PfxCode, FallbackFunc, BodyCode]).

wrap_segment(FuncName, retry_me_else(L), "", BodyCode, Suffix, Code) :-
    !,
    segment_func_name(L, Suffix, FallbackFunc),
    format(string(Code),
'  defp ~w(state) do
    cp = %{pc: &~w/1, regs: state.regs, y_regs: state.y_regs,
           heap: state.heap, heap_len: state.heap_len,
           cp: state.cp, trail: state.trail, trail_len: state.trail_len, stack: state.stack}
    state = %{state | choice_points: [cp | state.choice_points]}
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, FallbackFunc, BodyCode]).
wrap_segment(FuncName, retry_me_else(L), PfxCode, BodyCode, Suffix, Code) :-
    segment_func_name(L, Suffix, FallbackFunc),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    cp = %{pc: &~w/1, regs: state.regs, y_regs: state.y_regs,
           heap: state.heap, heap_len: state.heap_len,
           cp: state.cp, trail: state.trail, trail_len: state.trail_len, stack: state.stack}
    state = %{state | choice_points: [cp | state.choice_points]}
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, PfxCode, FallbackFunc, BodyCode]).

% Suffix is unused here because trust_me / none clauses have no
% try_me_else fallback label to resolve through segment_func_name/3
% — only the try_me_else / retry_me_else arms above need it. Suffix
% still flows into BodyCode via lower_instr_list/5, so any
% switch_on_constant inside the body picks the right `_impl` target.
wrap_segment(FuncName, trust_me, PfxCode, BodyCode0, _Suffix, Code) :-
    wrap_pfx_body(PfxCode, BodyCode0, BodyCode),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, BodyCode]).

wrap_segment(FuncName, none, PfxCode, BodyCode0, _Suffix, Code) :-
    wrap_pfx_body(PfxCode, BodyCode0, BodyCode),
    format(string(Code),
'  defp ~w(state) do
    try do
~w
    catch
      {:fail, s} ->
        case WamRuntime.backtrack(s) do
          :fail -> throw({:fail, %{s | choice_points: []}})
          other -> other
        end
    end
  end', [FuncName, BodyCode]).

lower_instr_list([], _, _, _, []).
lower_instr_list([PC-Instr|Rest], Labels, FuncName, Suffix, [Expr|Exprs]) :-
    wam_elixir_lower_instr(Instr, PC, Labels, FuncName, Suffix, Expr),
    lower_instr_list(Rest, Labels, FuncName, Suffix, Exprs).

% ============================================================================
% TIER-2 SUPER-WRAPPER EMITTER
% ============================================================================
%
% `par_wrap_segment/4` is the emitter-side analogue of Haskell\'s
% `parWrapSegment` (purity_certificate Phase P4). It replaces the
% sequential clause-chain entry point with a `cond`-based super-wrapper
% that:
%
%   - checks `in_forkable_aggregate_frame?/1` — outside a forkable
%     aggregate (findall / aggregate_all), falls back to sequential;
%   - checks `parallel_depth > 0` — nested forks suppressed, fall back;
%   - otherwise pins the cut barrier, increments parallel_depth, fans
%     out via `Task.async_stream` with a per-branch try/catch so CPS
%     throws convert to return values (see
%     `examples/debug_tier2_async_stream_throw_catch.exs` — naked throws
%     crash the parent process on any BEAM node, not just termux), and
%     hands full-exhaustion branch results to `merge_into_aggregate/2`.
%
% Three static gates at Prolog level:
%   1. `intra_query_parallel(false)` option absent — runtime kill-switch.
%   2. `tier2_purity_eligible/3` succeeds (purity ≥ 0.85, verdict pure).
%   3. Segment count ≥ 3 — matches Haskell\'s `forkMinBranches`.
%
% Wired into `render_compiled_module/8` via the `Suffix` parameter
% threaded through the segment-emission pipeline. On gate-pass the
% super-wrapper takes the canonical `clause_main` slot and per-clause
% bodies are emitted as `clause_X_impl`; on gate-reject Suffix=""
% and output is byte-for-byte identical to pre-wiring.

%% par_wrap_segment(+Pred/Arity, +Segments, +Options, -Code)
%  On gate-pass: Code is the emitted Elixir super-wrapper. On
%  gate-reject: Code is the empty string `""`.
%
%  The super-wrapper\'s function name matches the FIRST segment\'s
%  no-suffix name — so `run/1`\'s existing tail call into the first
%  segment reaches the super-wrapper, and the per-clause bodies
%  (emitted under `_impl`-suffixed names by the generate_all_segments
%  flow) are reachable via the super-wrapper\'s cond arms.
par_wrap_segment(Pred/Arity, Segments, Options, Code) :-
    \+ option(intra_query_parallel(false), Options),
    tier2_purity_eligible(Pred, Arity, _Cert),
    length(Segments, N), N >= 3,
    % Cost-aware gate: opt-in via `forkMinCost(N)` Option. The
    % per-clause body is statically scored (1 unit baseline, 5 for
    % calls/builtin_calls, 10 for begin_aggregate, etc.); only the
    % MAX clause cost has to clear the threshold (worst-case branch
    % cost dominates the parallel-overhead amortisation). Default
    % MinCost=0 keeps behaviour unchanged — anything passes — so
    % existing Tier-2 tests that exercise the parallel arm with
    % low-cost bodies still fire.
    %
    % Calibrated default for production use is `forkMinCost(10)` —
    % rejects fact-only Tier-2 predicates (cost ~3-4) while admitting
    % rule bodies (cost 9+). See the "Calibration" section of
    % benchmarks/wam_elixir_tier2_findall.md for the derivation.
    option(forkMinCost(MinCost), Options, 0),
    predicate_cost(Segments, EstCost),
    EstCost >= MinCost,
    !,
    Segments = [FirstName-_|_],
    segment_func_name(FirstName, "", EntryFunc),
    segment_func_name(FirstName, "_impl", EntryImplFunc),
    % Phase 4b.5: BranchFuncs reference the `_branch` variants
    % (emitted alongside `_impl` by render_compiled_module/8 when
    % Tier-2 is eligible). The `_branch` versions skip the
    % try_me_else / retry_me_else CP push so each branch enumerates
    % ONLY its own clauses solutions — avoids the chain-CP
    % duplicates from Phase 4bs runtime probe.
    maplist([Name-_Instrs, BranchFunc]>>segment_func_name(Name, "_branch", BranchFunc),
            Segments, BranchFuncs),
    % Companion to forkMinCost (static codegen-time gate): if the
    % user passes runtime_cost_probe(ThresholdUs), emit a probe-
    % wrapped super-wrapper that measures the first sequential call
    % and switches subsequent calls to parallel only when measured
    % us > ThresholdUs. State persists across calls via an ETS table
    % managed in WamRuntime. Without the option, emit the existing
    % unconditional-parallel template (default behaviour preserved).
    format(atom(PredKey), '~w/~w', [Pred, Arity]),
    (   option(runtime_cost_probe(ThresholdUs), Options),
        integer(ThresholdUs)
    ->  emit_par_tier2_wrapper_with_probe(EntryFunc, EntryImplFunc,
            BranchFuncs, PredKey, ThresholdUs, Code)
    ;   emit_par_tier2_wrapper(EntryFunc, EntryImplFunc, BranchFuncs, Code)
    ).
par_wrap_segment(_Pred, _Segments, _Options, "").

%% predicate_cost(+Segments, -Cost)
%  Static per-execution cost estimate for a Tier-2 candidates worst-
%  case branch. Segments are Name-Instrs pairs; we sum the per-
%  instruction weights for each clause and take the max — parallel
%  speedup is bounded by the slowest branch, so the heaviest clause
%  body is what determines whether parallel-overhead amortises.
predicate_cost(Segments, Cost) :-
    maplist([_-Instrs, C]>>clause_cost(Instrs, C), Segments, ClauseCosts),
    (   ClauseCosts == []
    ->  Cost = 0
    ;   max_list(ClauseCosts, Cost)
    ).

clause_cost(Instrs, Cost) :-
    % Segments hold PC-Instr pairs (the PC is the source-line index
    % attached during parsing); strip the PC tag before scoring.
    maplist([Pair, C]>>(Pair = _-Instr, instr_cost(Instr, C)), Instrs, Costs),
    sum_list(Costs, Cost).

%% instr_cost(+Instr, -Weight)
%  Static weights for WAM instructions in BEAM-interpreted Elixir.
%  Per the calibration in benchmarks/wam_elixir_tier2_findall.md, the
%  benchmark predicate bodies score: fact-only ~3-4, single-call body
%  ~9, inline-findall body ~26. forkMinCost(10) is the recommended
%  production default — rejects fact-only without affecting rule
%  bodies. The static gate cant predict the runtime crossover by
%  itself (it only sees the body shape, not the inner-iteration
%  count); pair it with runtime_cost_probe(1500) for full coverage.
instr_cost(builtin_call(_, _),    5) :- !.
instr_cost(call(_, _),            5) :- !.
instr_cost(execute(_),            5) :- !.
instr_cost(begin_aggregate(_, _, _), 10) :- !.
instr_cost(begin_aggregate(_, _, _, _), 10) :- !.
instr_cost(end_aggregate(_),      5) :- !.
instr_cost(put_structure(_, _),   3) :- !.
instr_cost(get_structure(_, _),   3) :- !.
instr_cost(put_list(_),           3) :- !.
instr_cost(get_list(_),           3) :- !.
instr_cost(switch_on_constant(_), 2) :- !.
instr_cost(switch_on_constant_a2(_), 2) :- !.
instr_cost(switch_on_constant_fallthrough(_), 2) :- !.
instr_cost(switch_on_constant_a2_fallthrough(_), 2) :- !.
instr_cost(switch_on_term(_), 3) :- !.
instr_cost(switch_on_term_a2(_), 3) :- !.
instr_cost(switch_on_structure(_), 2) :- !.
instr_cost(switch_on_structure_a2(_), 2) :- !.
instr_cost(_,                     1).

%% emit_par_tier2_wrapper(+EntryFunc, +EntryImplFunc, +BranchImplFuncs, -Code)
%  Formats the `cond`-based super-wrapper per the template in
%  `docs/design/WAM_TIERED_LOWERING.md`. EntryFunc is the no-suffix
%  surface name (what `run/1` delegates to). EntryImplFunc is that
%  name + "_impl" — the sequential fallback target. BranchImplFuncs
%  is the list of per-clause `_impl` function names that the
%  parallel fan-out dispatches across.
%
%  Both gate-miss `cond` arms (`not in_forkable_aggregate_frame?` and
%  `parallel_depth > 0`) intentionally call the same EntryImplFunc:
%  outside a forkable aggregate or under a nested fork, the only safe
%  option is to fall back to sequential evaluation via the renamed
%  clause chain. Two arms rather than a combined predicate so each
%  fall-through reason stays self-documenting in the emitted Elixir.
% Phase 4b finding (deferred to a focused follow-up): each clause
% _impl function pushes a try_me_else CP for the next clause as
% part of its standard sequential-enumeration setup. When the
% super-wrapper dispatches branch i = clause i_impl, branch is
% local backtrack pops the next-clause CP and resumes clause i+1
% — branch 1 ends up enumerating ALL clauses, branch 2 enumerates
% from clause 2, etc., producing duplicate solutions. The fix
% requires emitting _branch variants of clause functions that
% omit the next-clause CP push (analogous to trust_me's no-push
% pattern, which already exists). Tracked as Phase 4b.5 / Phase 4c
% follow-up. Phase 4b's super-wrapper substrate (branch_mode
% dispatch, branch_backtrack-aware backtrack, merge-then-throw
% pattern) is structurally correct and shipped here; the chain-CP
% issue prevents activating intra_query_parallel(true) in tests
% but doesn't affect any sequential scenario (intra_query_parallel
% defaults to true but the Phase 3 kill-switch scenarios use
% explicit `intra_query_parallel(false)`).
emit_par_tier2_wrapper(EntryFunc, EntryImplFunc, BranchImplFuncs, Code) :-
    maplist([F, Ref]>>format(string(Ref), '&~w/1', [F]),
            BranchImplFuncs, BranchRefs),
    atomic_list_concat(BranchRefs, ', ', BranchListInner),
    format(string(Code),
'  defp ~w(state) do
    cond do
      not WamRuntime.in_forkable_aggregate_frame?(state) ->
        ~w(state)

      Map.get(state, :parallel_depth, 0) > 0 ->
        ~w(state)

      true ->
        # Phase 4b: branch wrapper rework. Each branch runs with
        # branch_mode: true so backtrack/1 routes the parents agg-
        # frame CP to the {:branch_exhausted, accum} return shape
        # (instead of finalising on the branchs partial state). See
        # WAM_ELIXIR_TIER2_FINDALL_PHASE4.md section 4 for the
        # protocol; #1694 added branch_backtrack/1 substrate.
        #
        # Phase 4d: stamp the parents agg CP with branch_sentinel:
        # true so backtrack/1 only fires :branch_exhausted on THAT
        # CP — not on nested agg CPs pushed by inner findalls inside
        # the branchs clause body. Nested aggregates finalise
        # normally; only the branchs parent agg returns to the
        # super-wrapper for parent-side merge. Without this, a
        # nested findall inside a branch would leak its accum up
        # as the branchs return value.
        [parent_agg_cp | rest_cps] = state.choice_points
        stamped_parent = Map.put(parent_agg_cp, :branch_sentinel, true)

        branch_state = %{state |
          branch_mode: true,
          cut_point: state.choice_points,
          parallel_depth: Map.get(state, :parallel_depth, 0) + 1,
          choice_points: [stamped_parent | rest_cps]
        }

        branches = [~w]

        branch_results =
          branches
          |> Task.async_stream(fn branch ->
               try do
                 # Branchs clause body proceeds via state.cp = the
                 # parents post-call continuation (typically the
                 # findalls k1, which contains aggregate_collect +
                 # throw fail). The throw drives backtrack-in-branch-
                 # mode, which returns {:branch_exhausted, accum} as
                 # the wrap_segment catchs `other` arm. That tuple
                 # propagates up through state.cp.(state) as the
                 # branchs return value.
                 case branch.(branch_state) do
                   {:branch_exhausted, accum} when is_list(accum) -> accum
                   _ -> []
                 end
               catch
                 # If backtrack ever re-throws fail (no more CPs at
                 # all — shouldnt happen in normal flow because the
                 # agg frame stays as a sentinel), the branch
                 # contributes nothing.
                 {:fail, _s} -> []
                 # Phase 4 risk #1: multi-clause helpers called from
                 # the branchs body use switch_on_constant + throw
                 # {:return, _} to short-circuit clause dispatch. The
                 # short-circuited clauses eventual proceed reaches
                 # the branchs stub cp and produces a
                 # {:branch_exhausted, accum} result; thats what gets
                 # wrapped in :return. Unwrap it here so it counts as
                 # this branchs contribution. Other :return shapes
                 # (which shouldnt occur in branch context) collapse
                 # to no contribution.
                 {:return, {:branch_exhausted, accum}} when is_list(accum) -> accum
                 {:return, _} -> []
               end
             end,
             on_timeout: :kill_task,
             ordered: false,
             max_concurrency: System.schedulers_online())
          |> Enum.flat_map(fn
            {:ok, solutions} when is_list(solutions) -> solutions
            _ -> []
          end)

        # Merge all branch contributions into the parents agg frame,
        # then throw fail to drive the parents standard backtrack ->
        # finalise_aggregate flow on the merged accum. The parent is
        # NOT in branch_mode, so finalise fires normally.
        merged = WamRuntime.merge_into_aggregate(state, branch_results)
        throw({:fail, merged})
    end
  end',
    [EntryFunc, EntryImplFunc, EntryImplFunc, BranchListInner]).

%% emit_par_tier2_wrapper_with_probe(+EntryFunc, +EntryImplFunc,
%%   +BranchImplFuncs, +PredKey, +ThresholdUs, -Code)
%
%  Probe-wrapped variant of the super-wrapper. The `true ->` arm of
%  the cond block dispatches to one of three behaviours based on a
%  per-predicate decision in the WamRuntime ETS table:
%
%    :go_parallel    — fan out via Task.async_stream (existing
%                      parallel-arm code, inlined verbatim).
%    :go_sequential  — call the sequential _impl directly.
%    :probe          — measure the sequential call via :timer.tc/1,
%                      then update the decision table with the
%                      measured us vs ThresholdUs.
%
%  First call is always sequential (probe). Subsequent calls follow
%  the recorded decision. Decision is sticky.
emit_par_tier2_wrapper_with_probe(EntryFunc, EntryImplFunc, BranchImplFuncs,
                                  PredKey, ThresholdUs, Code) :-
    maplist([F, Ref]>>format(string(Ref), '&~w/1', [F]),
            BranchImplFuncs, BranchRefs),
    atomic_list_concat(BranchRefs, ', ', BranchListInner),
    format(string(Code),
'  defp ~w(state) do
    cond do
      not WamRuntime.in_forkable_aggregate_frame?(state) ->
        ~w(state)

      Map.get(state, :parallel_depth, 0) > 0 ->
        ~w(state)

      true ->
        # Runtime cost probe (PR follow-up to forkMinCost static gate).
        # Per-predicate decision lives in :tier2_cost_probe ETS table;
        # see WamRuntime.tier2_probe_decision/1 + tier2_probe_update/3.
        case WamRuntime.tier2_probe_decision("~w") do
          :go_sequential ->
            ~w(state)

          :probe ->
            {us, result} = :timer.tc(fn -> ~w(state) end)
            WamRuntime.tier2_probe_update("~w", us, ~w)
            result

          :go_parallel ->
            [parent_agg_cp | rest_cps] = state.choice_points
            stamped_parent = Map.put(parent_agg_cp, :branch_sentinel, true)

            branch_state = %{state |
              branch_mode: true,
              cut_point: state.choice_points,
              parallel_depth: Map.get(state, :parallel_depth, 0) + 1,
              choice_points: [stamped_parent | rest_cps]
            }

            branches = [~w]

            branch_results =
              branches
              |> Task.async_stream(fn branch ->
                   try do
                     case branch.(branch_state) do
                       {:branch_exhausted, accum} when is_list(accum) -> accum
                       _ -> []
                     end
                   catch
                     {:fail, _s} -> []
                     {:return, {:branch_exhausted, accum}} when is_list(accum) -> accum
                     {:return, _} -> []
                   end
                 end,
                 on_timeout: :kill_task,
                 ordered: false,
                 max_concurrency: System.schedulers_online())
              |> Enum.flat_map(fn
                {:ok, solutions} when is_list(solutions) -> solutions
                _ -> []
              end)

            merged = WamRuntime.merge_into_aggregate(state, branch_results)
            throw({:fail, merged})
        end
    end
  end',
    [EntryFunc, EntryImplFunc, EntryImplFunc, PredKey,
     EntryImplFunc, EntryImplFunc, PredKey, ThresholdUs, BranchListInner]).

% ============================================================================
% INSTRUCTION PARSING
% ============================================================================

instr_from_parts(["get_constant", C, Ai], get_constant(C, Ai)).
instr_from_parts(["get_variable", Xn, Ai], get_variable(Xn, Ai)).
instr_from_parts(["get_value", Xn, Ai], get_value(Xn, Ai)).
instr_from_parts(["put_structure", F, Ai], put_structure(F, Ai)).
instr_from_parts(["get_structure", F, Ai], get_structure(F, Ai)).
instr_from_parts(["unify_variable", Xn], unify_variable(Xn)).
instr_from_parts(["unify_value", Xn], unify_value(Xn)).
instr_from_parts(["unify_constant", C], unify_constant(C)).
instr_from_parts(["try_me_else", L], try_me_else(L)).
instr_from_parts(["retry_me_else", L], retry_me_else(L)).
instr_from_parts(["trust_me"], trust_me).
instr_from_parts(["allocate"], allocate).
instr_from_parts(["deallocate"], deallocate).
instr_from_parts(["call", P, N], call(P, N)).
instr_from_parts(["execute", P], execute(P)).
instr_from_parts(["builtin_call", Op, Ar], builtin_call(Op, Ar)).
instr_from_parts(["put_constant", C, Ai], put_constant(C, Ai)).
instr_from_parts(["put_variable", Xn, Ai], put_variable(Xn, Ai)).
instr_from_parts(["put_value", Xn, Ai], put_value(Xn, Ai)).
instr_from_parts(["put_list", Ai], put_list(Ai)).
instr_from_parts(["get_list", Ai], get_list(Ai)).
instr_from_parts(["set_variable", Xn], set_variable(Xn)).
instr_from_parts(["set_value", Xn], set_value(Xn)).
instr_from_parts(["set_constant", C], set_constant(C)).
instr_from_parts(["switch_on_constant"|Entries], switch_on_constant(Entries)).
instr_from_parts(["switch_on_constant_a2"|Entries], switch_on_constant_a2(Entries)).
instr_from_parts(["switch_on_constant_fallthrough"|Entries], switch_on_constant_fallthrough(Entries)).
instr_from_parts(["switch_on_constant_a2_fallthrough"|Entries], switch_on_constant_a2_fallthrough(Entries)).
instr_from_parts(["switch_on_term"|Tokens], switch_on_term(Tokens)).
instr_from_parts(["switch_on_term_a2"|Tokens], switch_on_term_a2(Tokens)).
instr_from_parts(["switch_on_structure"|Entries], switch_on_structure(Entries)).
instr_from_parts(["switch_on_structure_a2"|Entries], switch_on_structure_a2(Entries)).
instr_from_parts(["proceed"], proceed).
instr_from_parts(["begin_aggregate", Type, ValReg, ResReg], begin_aggregate(Type, ValReg, ResReg)).
% bagof/setof with witness-group backtracking: the 4th token is a
% semicolon-delimited list of witness register names (e.g. "'Y2;Y3'").
% Passed through to push_aggregate_frame so the runtime can snapshot
% witness values per solution and group at finalise time.
instr_from_parts(["begin_aggregate", Type, ValReg, ResReg, WitnessStr],
                 begin_aggregate(Type, ValReg, ResReg, WitnessStr)).
instr_from_parts(["end_aggregate", ValReg], end_aggregate(ValReg)).
% if-then-else / negation / once soft-cut commit and the unconditional
% jump that ends a then-branch. Previously these fell through to raw/1
% and raised "TODO" at runtime, so any predicate containing ( C -> T ; E ),
% \+ G or once/1 crashed (cut_ite) or returned a malformed mid-execution
% state (the else branch never reached its continuation).
instr_from_parts(["cut_ite"], cut_ite).
instr_from_parts(["jump", L], jump(L)).
instr_from_parts(Parts, raw(Combined)) :-
    atomic_list_concat(Parts, ' ', Combined).

% ============================================================================
% INSTRUCTION LOWERING
% ============================================================================

wam_elixir_lower_instr(get_constant(C, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    elixir_constant_literal(C, CLit),
    format(string(Code),
'    val = Map.get(state.regs, ~w)
    state = cond do
      WamRuntime.constant_match?(val, ~w) -> state
      match?({:unbound, _}, val) ->
        {:unbound, id} = val
        state |> WamRuntime.trail_binding(id) |> WamRuntime.put_reg(id, ~w)
      true -> throw({:fail, state})
    end', [Ai, CLit, CLit]).

wam_elixir_lower_instr(get_variable(XnName, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn), reg_id(AiName, Ai),
    format(string(Code),
'    val = Map.get(state.regs, ~w)
    state = state |> WamRuntime.trail_binding(~w) |> WamRuntime.put_reg(~w, val)', [Ai, Xn, Xn]).

wam_elixir_lower_instr(get_value(XnName, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn), reg_id(AiName, Ai),
    format(string(Code),
'    val_a = WamRuntime.deref_var(state, Map.get(state.regs, ~w))
    val_x = WamRuntime.get_reg(state, ~w)
    state = case WamRuntime.unify(state, val_a, val_x) do
      {:ok, s} -> s
      :fail -> throw({:fail, state})
    end', [Ai, Xn]).

wam_elixir_lower_instr(put_structure(F, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    format(string(Code),
'    addr = state.heap_len
    new_ref = {:ref, addr}
    new_heap = Map.put(state.heap, addr, {:str, "~w"})
    # If the target reg currently holds an unbound heap_ref (i.e.,
    # a prior set_variable created a placeholder there), bind that
    # heap cell to the new structure ref. Without this, an inline
    # `[1,2,3]` literals tail-of-first-cons stays a self-pointing
    # unbound and list-walking builtins (length, append, member)
    # silently terminate at the broken link.
    prev = Map.get(state.regs, ~w, :not_set)
    state = case prev do
      {:unbound, {:heap_ref, link_addr}} ->
        state
        |> WamRuntime.trail_binding({:heap_ref, link_addr})
        |> Map.put(:heap, Map.put(new_heap, link_addr, new_ref))
      _ -> %{state | heap: new_heap}
    end
    state = state
    |> WamRuntime.trail_binding(~w)
    |> Map.put(:regs, Map.put(state.regs, ~w, new_ref))
    |> Map.put(:heap_len, addr + 1)', [F, Ai, Ai, Ai]).

wam_elixir_lower_instr(get_structure(F, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    parse_arity(F, Arity),
    format(string(Code),
'    val = Map.get(state.regs, ~w)
    state = cond do
      match?({:unbound, _}, val) ->
        addr = state.heap_len
        new_heap = Map.put(state.heap, addr, {:str, "~w"})
        state
        |> WamRuntime.trail_binding(~w)
        |> Map.put(:regs, Map.put(state.regs, ~w, {:ref, addr}))
        |> Map.put(:heap, new_heap)
        |> Map.put(:heap_len, addr + 1)
        |> Map.put(:stack, [{:write_ctx, ~w} | state.stack])
      match?({:ref, _}, val) ->
        {:ref, addr} = val
        case WamRuntime.step_get_structure_ref(state, "~w", ~w, addr) do
          :fail -> throw({:fail, state})
          s -> s
        end
      true -> throw({:fail, state})
    end', [Ai, F, Ai, Ai, Arity, F, Arity]).

wam_elixir_lower_instr(unify_variable(XnName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn),
    format(string(Code),
'    state = case WamRuntime.step_unify_variable(state, ~w) do
      :fail -> throw({:fail, state})
      s -> s
    end', [Xn]).

wam_elixir_lower_instr(unify_value(XnName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn),
    format(string(Code),
'    state = case WamRuntime.step_unify_value(state, ~w) do
      :fail -> throw({:fail, state})
      s -> s
    end', [Xn]).

wam_elixir_lower_instr(unify_constant(C), _PC, _Labels, _FuncName, _Suffix, Code) :-
    elixir_constant_literal(C, CLit),
    format(string(Code),
'    state = case WamRuntime.step_unify_constant(state, ~w) do
      :fail -> throw({:fail, state})
      s -> s
    end', [CLit]).

% cut_ite — the soft-cut commit of ( Cond -> Then ; Else ) / \+ / once.
% When the condition succeeds we commit to the then-branch by discarding
% the choice point the ITE's try_me_else pushed (it points at the else
% segment). Dropping the top CP is the standard cut_ite semantics; the
% guard keeps it safe if the CP stack is unexpectedly empty.
wam_elixir_lower_instr(cut_ite, _PC, _Labels, _FuncName, _Suffix, Code) :-
    Code = '    state = case state.choice_points do
      [_ite_cp | rest] -> %{state | choice_points: rest}
      [] -> state
    end'.

% jump L — unconditional transfer to label L's segment. Ends a then-branch
% (jump to the continuation) and is also injected as the else branch's
% fall-through (see maybe_add_fallthrough/4). Tail-calls the segment
% function, threading the current Suffix so _impl jumps to _impl and
% _branch to _branch.
wam_elixir_lower_instr(jump(L), _PC, _Labels, _FuncName, Suffix, Code) :-
    segment_func_name(L, Suffix, Target),
    format(string(Code), '    ~w(state)', [Target]).

% A try_me_else reaching this clause is in BODY position (the segment's
% head try_me_else is removed by classify_segment_head and realised by
% wrap_segment). That only happens for a NESTED if-then-else, where the
% inner ITE's try_me_else follows the outer commit with no intervening
% label. Push its choice point here, pointing at the inner else segment,
% mirroring wrap_segment's snapshot — without this the inner else is
% unreachable and the inner condition's failure escapes the predicate.
wam_elixir_lower_instr(try_me_else(L), _PC, _Labels, _FuncName, Suffix, Code) :-
    segment_func_name(L, Suffix, ElseFunc),
    format(string(Code),
'    cp = %{pc: &~w/1, regs: state.regs, y_regs: state.y_regs,
           heap: state.heap, heap_len: state.heap_len,
           cp: state.cp, trail: state.trail, trail_len: state.trail_len, stack: state.stack}
    state = %{state | choice_points: [cp | state.choice_points]}', [ElseFunc]).

wam_elixir_lower_instr(retry_me_else(_L), _PC, _Labels, _FuncName, _Suffix, Code) :-
    Code = '    :ok # Handled by wrap_segment'.

wam_elixir_lower_instr(trust_me, _PC, _Labels, _FuncName, _Suffix, Code) :-
    Code = '    :ok # Handled by wrap_segment'.

wam_elixir_lower_instr(allocate, _PC, _Labels, _FuncName, _Suffix, Code) :-
    Code = '    # Save caller Y-regs so the callee can freely overwrite
    # slots 201-299 without corrupting the outer frame. Also snapshot
    # the current choice_points as the new cut barrier so `!` inside
    # this predicate truncates only CPs pushed during its own body,
    # not the caller CPs. Env popped by deallocate restores both.
    # Y-regs live in their own state field so swap is O(1).
    new_env = %{cp: state.cp, y_regs_saved: state.y_regs, cut_point: state.cut_point}
    state = %{state | stack: [new_env | state.stack], y_regs: %{},
                      cut_point: state.choice_points}'.

wam_elixir_lower_instr(deallocate, _PC, _Labels, _FuncName, _Suffix, Code) :-
    Code = '    state = case state.stack do
      [env | rest] ->
        %{state | cp: env.cp, stack: rest,
                  y_regs: Map.get(env, :y_regs_saved, %{}),
                  cut_point: Map.get(env, :cut_point, state.cut_point)}
      _ -> state
    end'.

wam_elixir_lower_instr(call(P, _N), PC, _Labels, _FuncName, _Suffix, Code) :-
    NPC is PC + 1,
    format(string(Code),
'    state = case WamDispatcher.call("~w", state) do
      {:ok, s} -> %{s | pc: ~w}
      :fail -> throw({:fail, state})
    end', [P, NPC]).

wam_elixir_lower_instr(execute(P), _PC, _Labels, _FuncName, _Suffix, Code) :-
    format(string(Code),
'    WamDispatcher.call("~w", state)', [P]).

wam_elixir_lower_instr(builtin_call(Op, Ar), _PC, _Labels, _FuncName, _Suffix, Code) :-
    escape_backslashes_for_elixir(Op, OpEsc),
    format(string(Code),
'    state = case WamRuntime.execute_builtin(state, "~w", ~w) do
      :fail -> throw({:fail, state})
      s -> s
    end', [OpEsc, Ar]).

wam_elixir_lower_instr(put_constant(C, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    elixir_constant_literal(C, CLit),
    format(string(Code), '    state = %{state | regs: Map.put(state.regs, ~w, ~w)}', [Ai, CLit]).

wam_elixir_lower_instr(put_variable(XnName, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn), reg_id(AiName, Ai),
    format(string(Code),
'    fresh = {:unbound, make_ref()}
    state = state
    |> WamRuntime.trail_binding(~w)
    |> WamRuntime.put_reg(~w, fresh)
    |> WamRuntime.put_reg(~w, fresh)', [Xn, Xn, Ai]).

wam_elixir_lower_instr(put_value(XnName, AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn), reg_id(AiName, Ai),
    format(string(Code),
'    val = WamRuntime.get_reg(state, ~w)
    state = state
    |> WamRuntime.trail_binding(~w)
    |> Map.put(:regs, Map.put(state.regs, ~w, val))', [Xn, Ai, Ai]).

wam_elixir_lower_instr(put_list(AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    format(string(Code),
'    addr = state.heap_len
    new_ref = {:ref, addr}
    new_heap = Map.put(state.heap, addr, {:str, "./2"})
    # Same heap-link semantics as put_structure: if the target reg
    # held an unbound heap_ref (placeholder from set_variable),
    # bind that cell to the new cons-cell ref so chains link up.
    prev = Map.get(state.regs, ~w, :not_set)
    state = case prev do
      {:unbound, {:heap_ref, link_addr}} ->
        state
        |> WamRuntime.trail_binding({:heap_ref, link_addr})
        |> Map.put(:heap, Map.put(new_heap, link_addr, new_ref))
      _ -> %{state | heap: new_heap}
    end
    state = state
    |> WamRuntime.trail_binding(~w)
    |> Map.put(:regs, Map.put(state.regs, ~w, new_ref))
    |> Map.put(:heap_len, addr + 1)', [Ai, Ai, Ai]).

wam_elixir_lower_instr(get_list(AiName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(AiName, Ai),
    format(string(Code),
'    val = Map.get(state.regs, ~w)
    state = cond do
      match?({:unbound, _}, val) ->
        addr = state.heap_len
        new_heap = Map.put(state.heap, addr, {:str, "./2"})
        state
        |> WamRuntime.trail_binding(~w)
        |> Map.put(:regs, Map.put(state.regs, ~w, {:ref, addr}))
        |> Map.put(:heap, new_heap)
        |> Map.put(:heap_len, addr + 1)
        |> Map.put(:stack, [{:write_ctx, 2} | state.stack])
      match?({:ref, _}, val) ->
        {:ref, addr} = val
        case WamRuntime.step_get_structure_ref(state, "./2", 2, addr) do
          :fail -> throw({:fail, state})
          s -> s
        end
      is_list(val) ->
        [h | t] = val
        %{state | stack: [{:unify_ctx, [h, t]} | state.stack]}
      true -> throw({:fail, state})
    end', [Ai, Ai, Ai]).

wam_elixir_lower_instr(set_variable(XnName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn),
    format(string(Code),
'    addr = state.heap_len
    fresh = {:unbound, {:heap_ref, addr}}
    new_heap = Map.put(state.heap, addr, fresh)
    state = state
    |> WamRuntime.put_reg(~w, fresh)
    |> Map.put(:heap, new_heap)
    |> Map.put(:heap_len, addr + 1)', [Xn]).

wam_elixir_lower_instr(set_value(XnName), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(XnName, Xn),
    format(string(Code),
'    val = WamRuntime.get_reg(state, ~w)
    addr = state.heap_len
    state = %{state | heap: Map.put(state.heap, addr, val), heap_len: addr + 1}', [Xn]).

wam_elixir_lower_instr(set_constant(C), _PC, _Labels, _FuncName, _Suffix, Code) :-
    elixir_constant_literal(C, CLit),
    format(string(Code),
'    addr = state.heap_len
    state = %{state | heap: Map.put(state.heap, addr, ~w), heap_len: addr + 1}', [CLit]).

wam_elixir_lower_instr(switch_on_constant(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_arms(Entries, Suffix, ArmsStr),
    format(string(Code),
'    val = WamRuntime.deref_var(state, WamRuntime.get_reg(state, 1))
    case val do
      {:unbound, _} -> :ok
      _ ->
        case val do
          ~w
          _ -> throw({:fail, state})
        end
    end', [ArmsStr]).

wam_elixir_lower_instr(switch_on_constant_a2(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_arms(Entries, Suffix, ArmsStr),
    format(string(Code),
'    val = WamRuntime.deref_var(state, WamRuntime.get_reg(state, 2))
    case val do
      {:unbound, _} -> :ok
      _ ->
        case val do
          ~w
          _ -> throw({:fail, state})
        end
    end', [ArmsStr]).

wam_elixir_lower_instr(switch_on_constant_fallthrough(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_arms(Entries, Suffix, ArmsStr),
    format(string(Code),
'    val = WamRuntime.deref_var(state, WamRuntime.get_reg(state, 1))
    case val do
      {:unbound, _} -> :ok
      _ ->
        case val do
          ~w
          _ -> :ok
        end
    end', [ArmsStr]).

wam_elixir_lower_instr(switch_on_constant_a2_fallthrough(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_arms(Entries, Suffix, ArmsStr),
    format(string(Code),
'    val = WamRuntime.deref_var(state, WamRuntime.get_reg(state, 2))
    case val do
      {:unbound, _} -> :ok
      _ ->
        case val do
          ~w
          _ -> :ok
        end
    end', [ArmsStr]).

wam_elixir_lower_instr(switch_on_term(Tokens), _PC, _Labels, _FuncName, Suffix, Code) :-
    parse_switch_on_term_tokens(Tokens, ConstEntries, StructEntries, ListLabel),
    build_switch_on_term_code(1, ConstEntries, StructEntries, ListLabel, Suffix, Code).

wam_elixir_lower_instr(switch_on_term_a2(Tokens), _PC, _Labels, _FuncName, Suffix, Code) :-
    parse_switch_on_term_tokens(Tokens, ConstEntries, StructEntries, ListLabel),
    build_switch_on_term_code(2, ConstEntries, StructEntries, ListLabel, Suffix, Code).

wam_elixir_lower_instr(switch_on_structure(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_on_term_code(1, [], Entries, "none", Suffix, Code).

wam_elixir_lower_instr(switch_on_structure_a2(Entries), _PC, _Labels, _FuncName, Suffix, Code) :-
    build_switch_on_term_code(2, [], Entries, "none", Suffix, Code).

wam_elixir_lower_instr(proceed, _PC, _Labels, _FuncName, _Suffix, Code) :-
    % CPS: proceed = tail-call the continuation stored in state.cp. The
    % caller\'s post-call code (or the driver\'s terminal_cp) lives in
    % state.cp — this tail call invokes it. BEAM TCO collapses the stack
    % so deep recursion doesn\'t grow it.
    Code = '    state.cp.(state)'.

% begin_aggregate / end_aggregate lowering — Phase 2 of the findall
% implementation per docs/proposals/WAM_ELIXIR_TIER2_FINDALL.md §4.2/§4.3.
% Substrate helpers live in WamRuntime (PR #1627).

wam_elixir_lower_instr(begin_aggregate(AggTypeStr, ValueReg, ResultReg),
                       _PC, _Labels, _FuncName, _Suffix, Code) :-
    agg_type_atom(AggTypeStr, AggType),
    reg_id(ValueReg, ValReg),
    reg_id(ResultReg, ResReg),
    format(string(Code),
'    state = WamRuntime.push_aggregate_frame(state, :~w, ~w, ~w)',
        [AggType, ValReg, ResReg]).

wam_elixir_lower_instr(begin_aggregate(AggTypeStr, ValueReg, ResultReg, WitnessStr),
                       _PC, _Labels, _FuncName, _Suffix, Code) :-
    agg_type_atom(AggTypeStr, AggType),
    reg_id(ValueReg, ValReg),
    reg_id(ResultReg, ResReg),
    witness_str_to_reg_ids(WitnessStr, WitnessRegIds),
    format(string(Code),
'    state = WamRuntime.push_aggregate_frame(state, :~w, ~w, ~w, ~w)',
        [AggType, ValReg, ResReg, WitnessRegIds]).

% Control flow note: the throw({:fail, state}) here is caught by the
% enclosing wrap_segment\'s try/catch, which calls WamRuntime.backtrack
% on the thrown state. backtrack/1 sees the aggregate CP at the top of
% choice_points (pushed by the matching begin_aggregate), checks
% Map.get(cp, :agg_type), and routes to finalise_aggregate/4 — which
% binds the aggregated result and tail-calls the saved continuation.
% The control flow is non-obvious from the emitted Elixir alone: throw →
% segment catch → backtrack → finalise. See WAM_ELIXIR_TIER2_FINDALL.md
% §3.3 (LLVM precedent) and §4.4 (backtrack extension).
wam_elixir_lower_instr(end_aggregate(ValueReg), _PC, _Labels, _FuncName, _Suffix, Code) :-
    reg_id(ValueReg, ValReg),
    format(string(Code),
'    state = WamRuntime.aggregate_collect(state, ~w)
    throw({:fail, state})', [ValReg]).

wam_elixir_lower_instr(raw(Combined), _PC, _Labels, _FuncName, _Suffix, Code) :-
    format(string(Code), '    # raw: ~w\n    raise "TODO: ~w"', [Combined, Combined]).

%% witness_str_to_reg_ids(+WitnessStr, -RegIdList)
%  Converts the WAM witness string (e.g. "'Y2;Y3'") to an Elixir list
%  literal of integer reg IDs (e.g. "[203, 204]").
witness_str_to_reg_ids(WitnessStr, RegIdList) :-
    (   atom(WitnessStr) -> atom_string(WitnessStr, WStr0)
    ;   WStr0 = WitnessStr
    ),
    ( string_concat("'", Rest0, WStr0),
      string_concat(Inner, "'", Rest0)
    -> WStr = Inner
    ;  WStr = WStr0
    ),
    split_string(WStr, ";", " ", Parts),
    maplist(witness_part_to_id, Parts, Ids),
    format(string(RegIdList), "~w", [Ids]).

witness_part_to_id(Part, Id) :-
    atom_string(RegAtom, Part),
    reg_id(RegAtom, Id).

%% parse_switch_on_term_tokens(+Tokens, -ConstEntries, -StructEntries, -ListLabel)
%  Parses the flat token list from `switch_on_term CLen <consts...> SLen <structs...> ListLabel`.
parse_switch_on_term_tokens(Tokens, ConstEntries, StructEntries, ListLabel) :-
    Tokens = [CLenStr|Rest0],
    (atom(CLenStr) -> atom_number(CLenStr, CLen) ; number_string(CLen, CLenStr)),
    length(ConstEntries, CLen),
    append(ConstEntries, [SLenStr|Rest1], Rest0),
    (atom(SLenStr) -> atom_number(SLenStr, SLen) ; number_string(SLen, SLenStr)),
    length(StructEntries, SLen),
    append(StructEntries, [ListLabel], Rest1).

%% build_switch_on_term_code(+RegIdx, +ConstEntries, +StructEntries, +ListLabel, +Suffix, -Code)
%  Generates Elixir code for switch_on_term / switch_on_term_a2.
%  Type-dispatches on the dereferenced register value:
%    unbound   → fall through (:ok)
%    {:ref, _} → heap lookup: list functor → list arm, else struct arm
%    other     → constant arm
build_switch_on_term_code(RegIdx, ConstEntries, StructEntries, ListLabel, Suffix, Code) :-
    build_sot_list_dispatch(ListLabel, Suffix, ListCode),
    build_sot_struct_dispatch(StructEntries, Suffix, StructCode),
    build_sot_const_dispatch(ConstEntries, Suffix, ConstCode),
    format(string(Code),
'    val = WamRuntime.deref_var(state, WamRuntime.get_reg(state, ~w))
    cond do
      match?({:unbound, _}, val) -> :ok
      match?({:ref, _}, val) ->
        {:ref, __sot_addr} = val
        case Map.get(state.heap, __sot_addr) do
          {:str, sot_fn} ->
            cond do
              sot_fn == "./2" or sot_fn == "[|]/2" ->
~w
              true ->
~w
            end
          _ -> throw({:fail, state})
        end
      true ->
~w
    end', [RegIdx, ListCode, StructCode, ConstCode]).

%% build_sot_list_dispatch(+ListLabel, +Suffix, -Code)
build_sot_list_dispatch(ListLabel, _Suffix, Code) :-
    (ListLabel == "none" ; ListLabel == none), !,
    Code = "                throw({:fail, state})".
build_sot_list_dispatch(ListLabel, _Suffix, Code) :-
    (ListLabel == "default" ; ListLabel == default), !,
    Code = "                :ok".
build_sot_list_dispatch(ListLabel, Suffix, Code) :-
    atom_string(ListLabel, LabelStr),
    segment_func_name(LabelStr, Suffix, Func),
    format(string(Code),
           "                throw({:return, ~w(%{state | choice_points: tl(state.choice_points)})})",
           [Func]).

%% build_sot_struct_dispatch(+StructEntries, +Suffix, -Code)
build_sot_struct_dispatch(StructEntries, Suffix, Code) :-
    (   StructEntries == []
    ->  Code = "                throw({:fail, state})"
    ;   maplist(build_sot_struct_arm(Suffix), StructEntries, Arms),
        atomic_list_concat(Arms, '\n                  ', ArmsJoined),
        format(string(Code),
               "                case sot_fn do\n                  ~w\n                  _ -> throw({:fail, state})\n                end",
               [ArmsJoined])
    ).

build_sot_struct_arm(Suffix, Entry, Arm) :-
    split_last_colon(Entry, Key, Label),
    (   (Label == "default" ; Label == default)
    ->  format(string(Arm), '"~w" -> :ok', [Key])
    ;   atom_string(Label, LabelStr),
        segment_func_name(LabelStr, Suffix, Func),
        format(string(Arm),
               '"~w" -> throw({:return, ~w(%{state | choice_points: tl(state.choice_points)})})',
               [Key, Func])
    ).

%% build_sot_const_dispatch(+ConstEntries, +Suffix, -Code)
build_sot_const_dispatch(ConstEntries, Suffix, Code) :-
    (   ConstEntries == []
    ->  Code = "        throw({:fail, state})"
    ;   build_switch_arms(ConstEntries, Suffix, ArmsStr),
        format(string(Code),
               "        case val do\n          ~w\n          _ -> throw({:fail, state})\n        end",
               [ArmsStr])
    ).

%% escape_backslashes_for_elixir(+Token, -Escaped)
%  Double backslashes when emitting `Token` into an Elixir double-
%  quoted string literal. Without this, an op name like `=\=/2`
%  becomes Elixir source `"=\=/2"` — and Elixir 1.14+ silently
%  DROPS the unrecognised `\=` escape, producing the runtime string
%  `==/2` instead of `=\=/2`. The execute_builtin pattern then
%  never matches and the call falls through to the default :fail
%  arm. Doubling the backslash gives Elixir source `"=\\=/2"`
%  which parses as runtime `=\=/2` (5 chars including backslash).
escape_backslashes_for_elixir(Token, Escaped) :-
    (   atom(Token) -> atom_string(Token, S) ; S = Token ),
    string_chars(S, Chars),
    backslash_double(Chars, DoubledChars),
    string_chars(Escaped, DoubledChars).

backslash_double([], []).
backslash_double(['\\' | Rest], ['\\', '\\' | More]) :- !,
    backslash_double(Rest, More).
backslash_double([C | Rest], [C | More]) :-
    backslash_double(Rest, More).

%% agg_type_atom(+Str, -Atom)
%  Translates the WAM-text aggregator name to the Elixir runtime atom.
%
%  The WAM compiler emits `:collect` for findall/3 (via the
%  `collect-Template` wrapper in compile_findall/5). The Tier-2 gate
%  `in_forkable_aggregate_frame?/1` (PR #1586) only recognises
%  `:findall` and `:aggregate_all` as forkable, so we translate
%  `collect → findall` at the emission site rather than broadening the
%  substrate. Decision per WAM_ELIXIR_TIER2_FINDALL.md §6.4 and §9 Q5.
%
%  All other aggregator atoms (sum/count/max/min/bag/set/aggregate_all)
%  pass through unchanged — finalise_aggregate/4 (PR #1627) handles the
%  full alphabet.
agg_type_atom("collect", findall) :- !.
agg_type_atom(Str, Atom) :- atom_string(Atom, Str).

%% pred_to_module(+PredStr, -ModuleName)
pred_to_module(PredStr, ModName) :-
    (   sub_string(PredStr, Before, _, _, "/")
    ->  sub_string(PredStr, 0, Before, _, Name)
    ;   Name = PredStr
    ),
    camel_case(Name, CamelName),
    format(atom(ModName), 'WamPredLow.~w', [CamelName]).
