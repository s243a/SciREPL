:- encoding(utf8).
% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (@s243a)
%
% wam_target.pl - WAM (Warren Abstract Machine) Code Generation Target
% Compiles Prolog predicates to symbolic WAM instructions.
% This serves as a universal low-level fallback hub.

:- module(wam_target, [
    target_info/1,
    compile_predicate_to_wam/3,          % +PredIndicator, +Options, -WAMCode
    compile_predicate_to_wam_text/3,     % +PredIndicator, +Options, -WAMCode
    compile_predicate_to_wam_items/3,    % +PredIndicator, +Options, -Items
    compile_predicate/3,                 % +PredIndicator, +Options, -WAMCode (dispatch alias)
    compile_facts_to_wam/3,              % +Pred, +Arity, -WAMCode
    compile_wam_module/3,                % +Predicates, +Options, -WAMCode
    write_wam_program/2,                 % +Code, +Filename
    init_wam_target/0,                   % Initialize target
    % WAM constant quoting — exported so downstream tokenizers can
    % share the same rules (see wam_elixir_lowered_emitter:tokenize_wam_line/2).
    quote_wam_constant/2                 % +Value, -QuotedString
]).

:- use_module(library(lists)).
:- use_module(library(option)).
:- use_module(library(gensym)).
:- use_module('../core/clause_body_analysis').
:- use_module('../core/template_system').
:- use_module('../core/binding_state_analysis').
:- use_module('../targets/wam_text_parser', [wam_text_to_items/2]).

%% target_info(-Info)
target_info(info{
    name: "WAM",
    family: low_level,
    file_extension: ".wam",
    runtime: wam,
    features: [backtracking, unification, choice_points, environments, tail_call_optimization],
    recursion_patterns: [tail_recursion, linear_recursion, tree_recursion, mutual_recursion],
    compile_command: "wam_asm"
}).

%% init_wam_target
init_wam_target :-
    % Initialize any WAM-specific state or bindings if needed
    nb_setval(wam_ite_counter, 0).

%% compile_predicate/3 - dispatch alias for target_registry
compile_predicate(PredArity, Options, Code) :-
    compile_predicate_to_wam(PredArity, Options, Code).

%% compile_predicate_to_wam(+PredIndicator, +Options, -Code)
%  Compatibility wrapper: returns canonical WAM text, matching the historical
%  API. New callers that want an explicit format should use
%  compile_predicate_to_wam_text/3 or compile_predicate_to_wam_items/3.
compile_predicate_to_wam(PredIndicator, Options, Code) :-
    compile_predicate_to_wam_text(PredIndicator, Options, Code).

%% resolve_wam_predicate_indicator(+PredIndicator, +Options,
%%                                 -Module, -Pred, -Arity) is semidet.
%  Normalise the supported predicate-indicator forms used by both text and
%  items producers.
resolve_wam_predicate_indicator(PredIndicator, Options, Module, Pred, Arity) :-
    (   PredIndicator = Module:Pred/Arity
    ->  true
    ;   PredIndicator = Pred/Arity
    ->  option(module(Module), Options, user)
    ;   format(user_error, 'WAM target: invalid predicate indicator ~w~n', [PredIndicator]),
        fail
    ).

%% wam_predicate_clauses(+PredIndicator, +Options, -Pred, -Arity, -Clauses)
%  Fetch clauses once so the text and items entry points share identical
%  predicate resolution and missing-predicate behaviour.
wam_predicate_clauses(PredIndicator, Options, Pred, Arity, Clauses) :-
    resolve_wam_predicate_indicator(PredIndicator, Options, Module, Pred, Arity),
    functor(Head, Pred, Arity),
    findall(Head-Body, clause(Module:Head, Body), Clauses),
    (   Clauses = []
    ->  format(user_error, 'WAM target: no clauses for ~w:~w/~w~n', [Module, Pred, Arity]),
        fail
    ;   true
    ).

%% compile_predicate_to_wam_text(+PredIndicator, +Options, -Code)
%  Compile a predicate to canonical WAM text.
compile_predicate_to_wam_text(PredIndicator, Options, Code) :-
    wam_predicate_clauses(PredIndicator, Options, Pred, Arity, Clauses),
    compile_clauses_to_wam(Pred, Arity, Clauses, Options, Code).

%% compile_predicate_to_wam_items(+PredIndicator, +Options, -Items)
%  Compile a predicate to structured WAM items. Simple native shapes use direct
%  item emission. More complex predicates fall back to the text generator plus
%  shared parser until the full WAM emitter is items-first.
compile_predicate_to_wam_items(PredIndicator, Options, Items) :-
    wam_predicate_clauses(PredIndicator, Options, Pred, Arity, Clauses),
    (   compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, NativeItems)
    ->  peephole_optimize_items(NativeItems, Items)
    ;   compile_clauses_to_wam(Pred, Arity, Clauses, Options, Code),
        wam_text_to_items(Code, Items)
    ).

%% compile_wam_module(+Predicates, +Options, -Code) is det.
%
%   Compiles a list of predicates to a single WAM module using templates.
compile_wam_module(Predicates, Options, Code) :-
    maplist({Options}/[PI, PredCode]>> (
        compile_predicate_to_wam_text(PI, Options, PredCode)
    ), Predicates, PredCodes),
    
    atomic_list_concat(PredCodes, '\n\n', AllPredsCode),
    
    option(module_name(ModuleName), Options, 'GeneratedWAM'),
    get_time(TimeStamp),
    format_time(string(Date), "%Y-%m-%d %H:%M:%S", TimeStamp),
    
    % template_system:render_named_template/3 takes [Key=Value] list
    TemplateData = [
        module_name=ModuleName,
        target_name="UnifyWeaver WAM",
        date=Date,
        predicates_code=AllPredsCode
    ],
    
    % Use named template from template_system
    render_named_template(wam_module, TemplateData, CodeAtom),
    atom_string(CodeAtom, Code).

%% compile_clauses_to_wam(+Pred, +Arity, +Clauses, +Options, -Code)
compile_clauses_to_wam(Pred, Arity, Clauses, Options, Code) :-
    format(string(Label), "~w/~w:", [Pred, Arity]),
    (   option(inline_bagof_setof(true), Options)
    ->  b_setval(wam_inline_bagof_setof, true)
    ;   b_setval(wam_inline_bagof_setof, false)
    ),
    % M10: \+ G inlines to (G -> fail ; true) by default. Opt out
    % with inline_not_as_failure(false) -- builds a builtin_call
    % \+/1 instead, which the runtime must metacall.
    (   option(inline_not_as_failure(false), Options)
    ->  b_setval(wam_inline_not, false)
    ;   b_setval(wam_inline_not, true)
    ),
    % M17: emit if-then-else with get_level Y_n / cut Y_n bytecode
    % instead of the legacy cut_ite. Targets that opt in (currently
    % LLVM) implement the new instructions properly; others keep the
    % cut_ite pattern. Default off so existing C++/Go/Lua/etc. paths
    % don''t see new opcodes they don''t parse.
    (   option(ite_use_y_level(true), Options)
    ->  b_setval(wam_ite_use_y_level, true)
    ;   b_setval(wam_ite_use_y_level, false)
    ),
    % Reset cut scope to clause level at the start of each predicate
    % compilation (see current_cut_target/1).
    set_cut_target(clause),
    % args_first_emission: emit set_variable for ALL outer-compound
    % args BEFORE any nested put_structure. The legacy emit
    % interleaved `set_variable Xn ; put_structure F/N, Xn ;
    % <nested args>` — fine for runtimes that store compound args
    % in a Value-internal vector (C++), wrong for flat-heap runtimes
    % (Elixir, and likely Rust/Haskell when they hit the same case)
    % because nested put_structure grows heap_len past the outer's
    % later arg slots.
    %
    % New emit: same instruction count, same per-instruction semantics
    % — pure reordering. Tested ON via the audit-against-baseline
    % methodology in PR-2278 (test_wam_target, test_wam_c_target,
    % test_wam_clojure_generator, test_wam_cpp_generator, test_wam_e2e,
    % test_wam_go_generator, test_wam_haskell_target,
    % test_wam_ilasm_target, test_wam_jvm_target, test_wam_lua_generator,
    % test_wam_python_target, test_wam_r_generator, test_wam_rust_target,
    % test_wam_cross_target_consistency, test_wam_dict,
    % test_wam_fact_table, test_wam_rule_index): zero new failures
    % attributable to the flip; pre-existing main-branch failures
    % preserved.
    %
    % Now the DEFAULT. Opt out via args_first_emission(false) if you
    % need byte-identical bytecode against a legacy snapshot.
    (   option(args_first_emission(false), Options)
    ->  b_setval(wam_args_first_emission, false)
    ;   b_setval(wam_args_first_emission, true)
    ),
    (   length(Clauses, 1)
    ->  Clauses = [Clause],
        compile_single_clause_wam(Clause, Options, ClausesCode0)
    ;   compile_multi_clause_wam(Pred, Arity, Clauses, Options, ClausesCode0)
    ),
    % Apply peephole optimization
    peephole_optimize(ClausesCode0, ClausesCode),
    % Generate argument index (try first arg, fall back to second arg).
    % Index is (HeaderLine, DispatchChainsCode) — the header is the
    % switch_on_* instruction; chains are dedicated try/retry/trust
    % sequences for groups with >1 matching clause, placed AFTER the
    % linear chain so switch_on_term's "default" / fall-through path
    % reaches the linear chain's try_me_else, not a chain.
    (   length(Clauses, NC), NC > 1,
        (   build_first_arg_index(Pred, Arity, Clauses, IndexHeader, DispatchChains)
        ;   Arity >= 2,
            build_second_arg_index(Pred, Arity, Clauses, IndexHeader, DispatchChains)
        )
    ->  combine_clauses_and_chains(ClausesCode, DispatchChains, ChainedClauses),
        format(string(Code), "~w~n~w~n~w", [Label, IndexHeader, ChainedClauses])
    ;   format(string(Code), "~w~n~w", [Label, ClausesCode])
    ).

%% compile_clauses_to_wam_items_native(+Pred, +Arity, +Clauses, +Options, -Items)
%  Direct items path for simple predicates. This incremental native producer
%  slice covers facts, simple user calls, generic builtin calls, compound body
%  arguments using the default args-first set_* ordering, conjunctions of those
%  shapes, non-indexed linear multi-clause predicates composed of the same
%  clause shapes, and the simplest A1/A2 switch_on_constant / fallthrough indexed
%  variants. Aggregates, dispatch-chain indexing, lowered builtins, control flow, legacy
%  interleaved compound-arg emission, and other peephole-sensitive shapes
%  intentionally fall back to the text bridge.
compile_clauses_to_wam_items_native(Pred, Arity, [Clause], Options, Items) :-
    compile_clause_body_items_native(Clause, Options, InstrItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label)|InstrItems].
compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, Items) :-
    Clauses = [_,_|_],
    native_first_arg_constant_index_item(Pred, Arity, Clauses, SwitchItem),
    length(Clauses, N),
    compile_multi_clause_items_linear(Clauses, 1, N, Pred, Arity, Options, ClauseItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label), SwitchItem|ClauseItems].
compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, Items) :-
    Clauses = [_,_|_],
    native_first_arg_constant_fallthrough_index_item(Pred, Arity, Clauses, SwitchItem),
    length(Clauses, N),
    compile_multi_clause_items_linear(Clauses, 1, N, Pred, Arity, Options, ClauseItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label), SwitchItem|ClauseItems].
compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, Items) :-
    Clauses = [_,_|_],
    native_second_arg_constant_index_item(Pred, Arity, Clauses, SwitchItem),
    length(Clauses, N),
    compile_multi_clause_items_linear(Clauses, 1, N, Pred, Arity, Options, ClauseItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label), SwitchItem|ClauseItems].
compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, Items) :-
    Clauses = [_,_|_],
    native_second_arg_constant_fallthrough_index_item(Pred, Arity, Clauses, SwitchItem),
    length(Clauses, N),
    compile_multi_clause_items_linear(Clauses, 1, N, Pred, Arity, Options, ClauseItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label), SwitchItem|ClauseItems].
compile_clauses_to_wam_items_native(Pred, Arity, Clauses, Options, Items) :-
    Clauses = [_,_|_],
    \+ native_clauses_would_index(Pred, Arity, Clauses),
    length(Clauses, N),
    compile_multi_clause_items_linear(Clauses, 1, N, Pred, Arity, Options, ClauseItems),
    !,
    format(string(Label), "~w/~w", [Pred, Arity]),
    Items = [label(Label)|ClauseItems].

compile_clause_body_items_native(Head-Body, Options, Items) :-
    set_clause_binding_context(Head, Body),
    set_clause_visited_context(Head),
    Head =.. [_|Args],
    normalize_goals(Body, Goals),
    empty_varmap(V0),
    (   Goals == []
    ->  compile_head_arguments_items(Args, 1, V0, _V1, HeadItems),
        append(HeadItems, [proceed], Items)
    ;   Goals = [_|_],
        native_simple_goal_sequence(Goals, Options),
        expand_aggregate_goals_for_perm_vars(Goals, ExpandedGoals),
        (   native_simple_goals_need_env(Goals, ExpandedGoals)
        ->  pre_assign_permanent_vars(ExpandedGoals, V0, V0a),
            compile_head_arguments_items(Args, 1, V0a, V1, HeadItems),
            compile_goals_items_simple(Goals, V1, yes, _Vf, GoalItems),
            append([allocate|HeadItems], GoalItems, Items)
        ;   compile_head_arguments_items(Args, 1, V0, V1, HeadItems),
            compile_goals_items_simple(Goals, V1, no, _Vf, GoalItems),
            append(HeadItems, GoalItems, Items)
        )
    ).

native_clauses_would_index(Pred, Arity, Clauses) :-
    (   build_first_arg_index(Pred, Arity, Clauses, _IndexHeader, _DispatchChains)
    ;   Arity >= 2,
        build_second_arg_index(Pred, Arity, Clauses, _IndexHeader, _DispatchChains)
    ),
    !.

native_first_arg_constant_index_item(Pred, Arity, Clauses, switch_on_constant(ItemEntries)) :-
    classify_first_args(Clauses, Types),
    Types = [_|_],
    forall(member(Type, Types), Type = constant),
    collect_const_groups(Clauses, 1, ConstGroups),
    groups_to_entries_and_chains(ConstGroups, Pred, Arity, const,
                                 Entries, ""),
    Entries = [_|_],
    index_entries_to_item_entries(Entries, ItemEntries).

native_first_arg_constant_fallthrough_index_item(Pred, Arity, Clauses,
                                                switch_on_constant_fallthrough(ItemEntries)) :-
    classify_first_args(Clauses, Types),
    member(variable, Types),
    indexed_prefix(Types, Clauses, PrefixTypes, PrefixClauses),
    PrefixClauses = [_|_],
    forall(member(Type, PrefixTypes), Type = constant),
    build_constant_index(PrefixClauses, 1, Pred, Arity, Entries),
    Entries = [_|_],
    index_entries_to_item_entries(Entries, ItemEntries).

native_second_arg_constant_index_item(Pred, Arity, Clauses, switch_on_constant_a2(ItemEntries)) :-
    Arity >= 2,
    \+ build_first_arg_index(Pred, Arity, Clauses, _IndexHeader, _DispatchChains),
    classify_second_args(Clauses, Types),
    Types = [_|_],
    forall(member(Type, Types), Type = constant),
    build_constant_index_on(Clauses, 2, 1, Pred, Arity, Entries),
    Entries = [_|_],
    index_entries_to_item_entries(Entries, ItemEntries).

native_second_arg_constant_fallthrough_index_item(Pred, Arity, Clauses,
                                                 switch_on_constant_a2_fallthrough(ItemEntries)) :-
    Arity >= 2,
    \+ build_first_arg_index(Pred, Arity, Clauses, _IndexHeader, _DispatchChains),
    classify_second_args(Clauses, Types),
    member(variable, Types),
    indexed_prefix(Types, Clauses, PrefixTypes, PrefixClauses),
    PrefixClauses = [_|_],
    forall(member(Type, PrefixTypes), Type = constant),
    build_constant_index_on(PrefixClauses, 2, 1, Pred, Arity, Entries),
    Entries = [_|_],
    index_entries_to_item_entries(Entries, ItemEntries).

index_entries_to_item_entries([], []).
index_entries_to_item_entries([Key-Label|Rest], [Entry|RestEntries]) :-
    quote_wam_constant(Key, KeyString),
    format(string(Entry), "~w:~w", [KeyString, Label]),
    index_entries_to_item_entries(Rest, RestEntries).

compile_multi_clause_items_linear([], _, _, _, _, _, []).
compile_multi_clause_items_linear([Clause|Rest], I, N, Pred, Arity, Options, Items) :-
    linear_clause_choice_items(I, N, Pred, Arity, ChoiceItems),
    compile_clause_body_items_native(Clause, Options, BodyItems),
    append(ChoiceItems, BodyItems, ThisItems),
    NextI is I + 1,
    compile_multi_clause_items_linear(Rest, NextI, N, Pred, Arity, Options, RestItems),
    append(ThisItems, RestItems, Items).

linear_clause_choice_items(1, _N, Pred, Arity, [try_me_else(NextLabel)]) :-
    !,
    format(string(NextLabel), "L_~w_~w_2", [Pred, Arity]).
linear_clause_choice_items(I, I, Pred, Arity,
                           [label(Label), trust_me, label(BodyLabel)]) :-
    !,
    format(string(Label), "L_~w_~w_~w", [Pred, Arity, I]),
    format(string(BodyLabel), "L_~w_~w_~w_body", [Pred, Arity, I]).
linear_clause_choice_items(I, _N, Pred, Arity,
                           [label(Label), retry_me_else(NextLabel), label(BodyLabel)]) :-
    NextI is I + 1,
    format(string(Label), "L_~w_~w_~w", [Pred, Arity, I]),
    format(string(NextLabel), "L_~w_~w_~w", [Pred, Arity, NextI]),
    format(string(BodyLabel), "L_~w_~w_~w_body", [Pred, Arity, I]).

peephole_optimize_items(Items, Optimized) :-
    peephole_item_list(Items, Optimized).

peephole_item_list([], []).
peephole_item_list([put_value(Reg, Ai), get_variable(Reg, Ai)|Rest], Result) :-
    !,
    peephole_item_list(Rest, Result).
peephole_item_list([Item, Item|Rest], [Item|Result]) :-
    put_instruction_item(Item),
    !,
    peephole_item_list(Rest, Result).
peephole_item_list([get_variable(Reg, Ai), put_value(Reg, Ai)|Rest], Result) :-
    \+ item_reg_used_in_rest(Reg, Rest),
    !,
    peephole_item_list(Rest, Result).
peephole_item_list([put_variable(Reg, Ai), put_value(Reg, Ai)|Rest],
                   [put_variable(Reg, Ai)|Result]) :-
    !,
    peephole_item_list(Rest, Result).
peephole_item_list([Item|Rest], [Item|Result]) :-
    peephole_item_list(Rest, Result).

put_instruction_item(Item) :-
    compound(Item),
    functor(Item, Name, _),
    atom(Name),
    sub_atom(Name, 0, 4, _, 'put_').

item_reg_used_in_rest(Reg, Items) :-
    member(Item, Items),
    term_string(Item, ItemString),
    sub_string(ItemString, _, _, _, Reg),
    !.

native_simple_goals_need_env(Goals, ExpandedGoals) :-
    (   length(ExpandedGoals, N), N > 1
    ;   goals_contain_call_or_aggregate(Goals)
    ),
    !.

native_simple_goal_sequence(Goals, Options) :-
    forall(member(Goal, Goals), native_simple_goal(Goal, Options)).

native_simple_goal(M:InnerGoal, Options) :-
    (atom(M) ; string(M)),
    !,
    native_simple_goal(InnerGoal, Options).
native_simple_goal(Goal, Options) :-
    callable(Goal),
    \+ native_special_goal(Goal),
    Goal =.. [_GoalPred|Args],
    \+ goal_has_visited_set_arg(Goal),
    forall(member(Arg, Args), native_simple_goal_arg(Arg, Options)).

native_special_goal('!') :- !.
native_special_goal(Goal) :-
    nonvar(Goal),
    (   Goal = aggregate_all(_, _, _)
    ;   Goal = findall(_, _, _)
    ;   Goal = bagof(_, _, _)
    ;   Goal = setof(_, _, _)
    ;   Goal = (_ -> _ ; _)
    ;   Goal = (_ -> _)
    ;   Goal = (_ ; _)
    ;   Goal = \+(_)
    ;   Goal = once(_)
    ;   Goal = forall(_, _)
    ;   is_term_construction_goal(Goal)
    ).

native_simple_goal_arg(Arg, _Options) :-
    var(Arg), !.
native_simple_goal_arg(Arg, _Options) :-
    atomic(Arg), !.
native_simple_goal_arg(Arg, Options) :-
    compound(Arg),
    \+ option(args_first_emission(false), Options).

compile_goals_items_simple([], V, _, V, []).
compile_goals_items_simple([Goal], V0, HasEnv, Vf, Items) :-
    !,
    compile_last_goal_items_simple(Goal, V0, HasEnv, Vf, Items).
compile_goals_items_simple([Goal|Rest], V0, HasEnv, Vf, Items) :-
    compile_goal_call_items_simple(Goal, V0, V1, GoalItems),
    compile_goals_items_simple(Rest, V1, HasEnv, Vf, RestItems),
    append(GoalItems, RestItems, Items).

compile_goal_call_items_simple(M:InnerGoal, V0, Vf, Items) :-
    (atom(M) ; string(M)),
    !,
    compile_goal_call_items_simple(InnerGoal, V0, Vf, Items).
compile_goal_call_items_simple(Goal, V0, Vf, Items) :-
    Goal =.. [GoalPred|Args],
    length(Args, Arity),
    compile_put_arguments_items_simple(Args, 1, V0, Vf, PutItems),
    wam_functor_token(GoalPred, Arity, PredTok),
    wam_arity_token(Arity, ArityTok),
    (   is_builtin_pred(GoalPred, Arity)
    ->  CallItem = builtin_call(PredTok, ArityTok)
    ;   CallItem = call(PredTok, ArityTok)
    ),
    append(PutItems, [CallItem], Items).

compile_last_goal_items_simple(M:InnerGoal, V0, HasEnv, Vf, Items) :-
    (atom(M) ; string(M)),
    !,
    compile_last_goal_items_simple(InnerGoal, V0, HasEnv, Vf, Items).
compile_last_goal_items_simple(Goal, V0, yes, Vf, Items) :-
    Goal =.. [GoalPred|Args],
    length(Args, Arity),
    compile_put_arguments_items_simple(Args, 1, V0, Vf, PutItems),
    wam_functor_token(GoalPred, Arity, PredTok),
    wam_arity_token(Arity, ArityTok),
    (   is_builtin_pred(GoalPred, Arity)
    ->  append(PutItems, [builtin_call(PredTok, ArityTok), deallocate, proceed], Items)
    ;   append(PutItems, [deallocate, execute(PredTok)], Items)
    ).
compile_last_goal_items_simple(Goal, V0, no, Vf, Items) :-
    Goal =.. [GoalPred|Args],
    length(Args, Arity),
    compile_put_arguments_items_simple(Args, 1, V0, Vf, PutItems),
    wam_functor_token(GoalPred, Arity, PredTok),
    wam_arity_token(Arity, ArityTok),
    (   is_builtin_pred(GoalPred, Arity)
    ->  append(PutItems, [builtin_call(PredTok, ArityTok), proceed], Items)
    ;   append(PutItems, [execute(PredTok)], Items)
    ).

compile_put_arguments_items_simple([], _, V, V, []).
compile_put_arguments_items_simple([Arg|Rest], I, V0, Vf, Items) :-
    compile_put_argument_items_simple(Arg, I, V0, V1, ArgItems),
    NI is I + 1,
    compile_put_arguments_items_simple(Rest, NI, V1, Vf, RestItems),
    append(ArgItems, RestItems, Items).

compile_put_argument_items_simple(Arg, I, V0, V1, Items) :-
    wam_arg_register(I, Ai),
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  wam_operand_string(Reg, RegTok),
            Items = [put_value(RegTok, Ai)],
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  wam_operand_string(YReg, YRegTok),
            Items = [put_variable(YRegTok, Ai)]
        ;   next_x_reg(V0, XReg, VTemp),
            bind_var(Arg, XReg, VTemp, V1),
            wam_operand_string(XReg, XRegTok),
            Items = [put_variable(XRegTok, Ai)]
        )
    ;   atomic(Arg)
    ->  wam_constant_token(Arg, ArgTok),
        Items = [put_constant(ArgTok, Ai)],
        V1 = V0
    ;   is_list_term(Arg),
        proper_list(Arg, _)
    ->  Arg = [H|T],
        next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V2),
        compile_set_arguments_items_split([H, T], V2, V1, SetItems),
        Items = [put_list(Ai)|SetItems]
    ;   compound(Arg)
    ->  Arg =.. [F|SubArgs],
        length(SubArgs, SArity),
        next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V2),
        wam_functor_token(F, SArity, FunctorTok),
        compile_set_arguments_items_split(SubArgs, V2, V1, SetItems),
        Items = [put_structure(FunctorTok, Ai)|SetItems]
    ;   next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V1),
        wam_operand_string(XReg, XRegTok),
        Items = [put_variable(XRegTok, Ai)]
    ).

compile_set_arguments_items_split(Args, V0, Vf, Items) :-
    compile_set_arguments_items_split_(Args, V0, Vf, ImmItems, DeferredItems),
    append(ImmItems, DeferredItems, Items).

compile_set_arguments_items_split_([], V, V, [], []).
compile_set_arguments_items_split_([Arg|Rest], V0, Vf, Items, Deferred) :-
    arg_items_split(Arg, V0, V1, ImmArg, DefArg),
    compile_set_arguments_items_split_(Rest, V1, Vf, ImmRest, DefRest),
    append(ImmArg, ImmRest, Items),
    append(DefArg, DefRest, Deferred).

arg_items_split(Arg, V0, V1, Items, []) :-
    var(Arg),
    !,
    (   get_var_reg(Arg, V0, Reg)
    ->  wam_operand_string(Reg, RegTok),
        Items = [set_value(RegTok)],
        V1 = V0
    ;   get_yi_alloc(Arg, V0, YReg, V1)
    ->  wam_operand_string(YReg, YRegTok),
        Items = [set_variable(YRegTok)]
    ;   next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V1),
        wam_operand_string(XReg, XRegTok),
        Items = [set_variable(XRegTok)]
    ).
arg_items_split(Arg, V0, V0, Items, []) :-
    atomic(Arg),
    !,
    wam_constant_token(Arg, ArgTok),
    Items = [set_constant(ArgTok)].
arg_items_split(Arg, V0, V1, Items, Deferred) :-
    compound(Arg),
    !,
    Arg =.. [F|NestedArgs],
    length(NestedArgs, NArity),
    next_x_reg(V0, XReg, VTemp),
    bind_var(Arg, XReg, VTemp, V1a),
    wam_operand_string(XReg, XRegTok),
    wam_functor_token(F, NArity, FunctorTok),
    compile_set_arguments_items_split_(NestedArgs, V1a, V1,
                                       NestedImm, NestedDef),
    Items = [set_variable(XRegTok)],
    append([put_structure(FunctorTok, XRegTok)|NestedImm], NestedDef, Deferred).
arg_items_split(Arg, V0, V1, Items, []) :-
    next_x_reg(V0, XReg, VTemp),
    bind_var(Arg, XReg, VTemp, V1),
    wam_operand_string(XReg, XRegTok),
    Items = [set_variable(XRegTok)].

compile_head_arguments_items([], _, V, V, []).
compile_head_arguments_items([Arg|Rest], I, V0, Vf, Items) :-
    compile_head_argument_items(Arg, I, V0, V1, ArgItems),
    NI is I + 1,
    compile_head_arguments_items(Rest, NI, V1, Vf, RestItems),
    append(ArgItems, RestItems, Items).

compile_head_argument_items(Arg, I, V0, V1, Items) :-
    wam_arg_register(I, Ai),
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  wam_operand_string(Reg, RegTok),
            Items = [get_value(RegTok, Ai)],
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  wam_operand_string(YReg, YRegTok),
            Items = [get_variable(YRegTok, Ai)]
        ;   next_x_reg(V0, XReg, VTemp),
            bind_var(Arg, XReg, VTemp, V1),
            wam_operand_string(XReg, XRegTok),
            Items = [get_variable(XRegTok, Ai)]
        )
    ;   atomic(Arg)
    ->  wam_constant_token(Arg, ArgTok),
        Items = [get_constant(ArgTok, Ai)],
        V1 = V0
    ;   is_list_term(Arg)
    ->  Arg = [H|T],
        compile_unify_arguments_items([H, T], V0, V1, SubItems),
        Items = [get_list(Ai)|SubItems]
    ;   compound(Arg)
    ->  Arg =.. [F|SubArgs],
        length(SubArgs, SArity),
        wam_functor_token(F, SArity, FunctorTok),
        compile_unify_arguments_items(SubArgs, V0, V1, SubItems),
        Items = [get_structure(FunctorTok, Ai)|SubItems]
    ).

compile_unify_arguments_items([], V, V, []).
compile_unify_arguments_items([Arg|Rest], V0, Vf, Items) :-
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  wam_operand_string(Reg, RegTok),
            ArgItems = [unify_value(RegTok)],
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  wam_operand_string(YReg, YRegTok),
            ArgItems = [unify_variable(YRegTok)]
        ;   next_x_reg(V0, XReg, VTemp),
            bind_var(Arg, XReg, VTemp, V1),
            wam_operand_string(XReg, XRegTok),
            ArgItems = [unify_variable(XRegTok)]
        )
    ;   atomic(Arg)
    ->  wam_constant_token(Arg, ArgTok),
        ArgItems = [unify_constant(ArgTok)],
        V1 = V0
    ;   compound(Arg)
    ->  Arg =.. [F|NestedArgs],
        length(NestedArgs, NArity),
        next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V1a),
        wam_operand_string(XReg, XRegTok),
        wam_functor_token(F, NArity, FunctorTok),
        compile_unify_arguments_items(NestedArgs, V1a, V1, NestedItems),
        ArgItems = [unify_variable(XRegTok), get_structure(FunctorTok, XRegTok)|NestedItems]
    ;   next_x_reg(V0, XReg, VTemp),
        bind_var(Arg, XReg, VTemp, V1),
        wam_operand_string(XReg, XRegTok),
        ArgItems = [unify_variable(XRegTok)]
    ),
    compile_unify_arguments_items(Rest, V1, Vf, RestItems),
    append(ArgItems, RestItems, Items).

wam_arg_register(I, Ai) :-
    format(string(Ai), "A~w", [I]).

wam_functor_token(F, Arity, Token) :-
    format(string(Token), "~w/~w", [F, Arity]).

wam_arity_token(Arity, Token) :-
    number_string(Arity, Token).

wam_constant_token(Value, Token) :-
    quote_wam_constant(Value, RawToken),
    wam_operand_string(RawToken, Token).

wam_operand_string(Value, String) :-
    (   string(Value)
    ->  String = Value
    ;   atom(Value)
    ->  atom_string(Value, String)
    ;   number(Value)
    ->  number_string(Value, String)
    ;   term_string(Value, String)
    ).

combine_clauses_and_chains(ClausesCode, "", ClausesCode) :- !.
combine_clauses_and_chains(ClausesCode, Chains, Combined) :-
    format(string(Combined), "~w~n~w", [ClausesCode, Chains]).

%% build_first_arg_index(+Pred, +Arity, +Clauses, -IndexCode)
%  Analyzes first arguments of all clauses and emits indexing instructions.
%  - All atomic first args → switch_on_constant
%  - All compound first args → switch_on_structure
%  - Mixed types → switch_on_term (type-based dispatch)
%  - Mixed with variable A1 clauses: the prefix up to (but not
%    including) the first variable clause is the "indexed prefix";
%    if it's all-constant, emit switch_on_constant_fallthrough — the
%    runtime jumps to a matching indexed entry, otherwise falls
%    through to the try_me_else chain (which catches the variable
%    clauses). v1 limits the prefix to constant-only; structure /
%    mixed prefixes with a trailing variable clause skip indexing.
build_first_arg_index(Pred, Arity, Clauses, IndexHeader, DispatchChains) :-
    classify_first_args(Clauses, Types),
    (   \+ member(variable, Types)
    ->  build_first_arg_index_homogeneous(Pred, Arity, Clauses, Types,
                                          IndexHeader, DispatchChains)
    ;   build_first_arg_index_with_fallthrough(Pred, Arity, Clauses, Types,
                                               IndexHeader),
        DispatchChains = ""
    ).

build_first_arg_index_homogeneous(Pred, Arity, Clauses, Types,
                                  IndexHeader, DispatchChains) :-
    (   forall(member(T, Types), T = constant)
    ->  collect_const_groups(Clauses, 1, ConstGroups),
        groups_to_entries_and_chains(ConstGroups, Pred, Arity, const,
                                     Entries, DispatchChains),
        Entries \= [],
        format_index_entries(Entries, EntriesStr),
        format(string(IndexHeader), "    switch_on_constant ~w", [EntriesStr])
    ;   forall(member(T, Types), T = structure),
        \+ first_args_contain_list(Clauses)
    ->  collect_struct_groups(Clauses, 1, StructGroups),
        groups_to_entries_and_chains(StructGroups, Pred, Arity, struct,
                                     Entries, DispatchChains),
        Entries \= [],
        format_index_entries(Entries, EntriesStr),
        format(string(IndexHeader), "    switch_on_structure ~w", [EntriesStr])
    ;   % Mixed — emit switch_on_term with type-based dispatch
        build_term_index_with_chains(Clauses, Pred, Arity,
            ConstEntries, StructEntries, ListLabel, DispatchChains),
        format_switch_on_term(ConstEntries, StructEntries, ListLabel, IndexHeader)
    ).

build_first_arg_index_with_fallthrough(Pred, Arity, Clauses, Types, IndexCode) :-
    indexed_prefix(Types, Clauses, PrefixTypes, PrefixClauses),
    PrefixClauses \= [],
    % v1: only handle constant prefix.
    forall(member(T, PrefixTypes), T = constant),
    build_constant_index(PrefixClauses, 1, Pred, Arity, Entries),
    Entries \= [],
    format_index_entries(Entries, EntriesStr),
    format(string(IndexCode),
           "    switch_on_constant_fallthrough ~w", [EntriesStr]).

%% indexed_prefix(+Types, +Clauses, -PrefixTypes, -PrefixClauses)
%  Take clauses up to (but not including) the first one whose A1 is
%  a variable. Used for mixed-mode A1 indexing.
indexed_prefix([], [], [], []).
indexed_prefix([variable|_], _, [], []) :- !.
indexed_prefix([T|Ts], [C|Cs], [T|PT], [C|PC]) :-
    indexed_prefix(Ts, Cs, PT, PC).

classify_first_args([], []).
classify_first_args([Head-_|Rest], [Type|RestTypes]) :-
    Head =.. [_|[FirstArg|_]],
    (   var(FirstArg) -> Type = variable
    ;   atomic(FirstArg) -> Type = constant
    ;   is_list_term(FirstArg) -> Type = structure  % lists are './2' structures
    ;   compound(FirstArg) -> Type = structure
    ;   Type = variable
    ),
    classify_first_args(Rest, RestTypes).

first_args_contain_list([Head-_|_]) :-
    Head =.. [_|[FirstArg|_]],
    is_list_term(FirstArg), !.
first_args_contain_list([_|Rest]) :-
    first_args_contain_list(Rest).

build_constant_index([], _, _, _, []).
build_constant_index([Head-_|Rest], I, Pred, Arity, [FirstArg-Label|RestEntries]) :-
    Head =.. [_|[FirstArg|_]],
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_constant_index(Rest, NextI, Pred, Arity, RestEntries).

build_structure_index([], _, _, _, []).
build_structure_index([Head-_|Rest], I, Pred, Arity, [FN-Label|RestEntries]) :-
    Head =.. [_|[FirstArg|_]],
    FirstArg =.. [F|SubArgs],
    length(SubArgs, SArity),
    format(atom(FN), "~w/~w", [F, SArity]),
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_structure_index(Rest, NextI, Pred, Arity, RestEntries).

build_term_index([], _, _, _, _, [], [], none).
build_term_index([Head-_|Rest], I, Pred, Arity, [Type|RestTypes],
                 ConstEntries, StructEntries, ListLabel) :-
    Head =.. [_|[FirstArg|_]],
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_term_index(Rest, NextI, Pred, Arity, RestTypes,
                     RestConst, RestStruct, RestListLabel),
    (   Type = constant
    ->  ConstEntries = [FirstArg-Label|RestConst],
        StructEntries = RestStruct,
        ListLabel = RestListLabel
    ;   Type = structure,
        is_list_term(FirstArg)
    ->  ConstEntries = RestConst,
        StructEntries = RestStruct,
        ListLabel = Label
    ;   Type = structure
    ->  FirstArg =.. [F|SubArgs],
        length(SubArgs, SArity),
        format(atom(FN), "~w/~w", [F, SArity]),
        ConstEntries = RestConst,
        StructEntries = [FN-Label|RestStruct],
        ListLabel = RestListLabel
    ;   ConstEntries = RestConst,
        StructEntries = RestStruct,
        ListLabel = RestListLabel
    ).

format_switch_on_term(ConstEntries, StructEntries, ListLabel, IndexCode) :-
    length(ConstEntries, CLen),
    length(StructEntries, SLen),
    format_index_entries(ConstEntries, CStr),
    format_index_entries(StructEntries, SStr),
    format(string(IndexCode),
           "    switch_on_term ~w ~w ~w ~w ~w",
           [CLen, CStr, SLen, SStr, ListLabel]).

%% ========================================================================
%% Indexed-dispatch group collection + chain emission
%%
%% Standard-WAM indexed dispatch (switch_on_term / switch_on_constant /
%% switch_on_structure) needs to jump into a clause body WITHOUT
%% reusing the linear chain's `try_me_else / retry_me_else / trust_me`
%% protocol — those instructions assume the top CP is "ours" (pushed
%% by the predicate's leading try_me_else), but an indexed jump
%% bypasses that push.  Reusing them corrupts the outer caller's CP
%% (see issue #2400).
%%
%% Fix: for each dispatch group with >1 matching clauses (and not
%% including clause 1, which is reached by fall-through), synthesize
%% a dedicated `try / retry … / trust` chain pointing at the
%% `L_<Pred>_<Arity>_<I>_body` labels emitted by
%% compile_clauses_fragments/7.  The chain pushes/modifies/pops a CP
%% owned by THIS predicate, leaving outer CPs untouched.
%% ========================================================================

%% collect_const_groups(+Clauses, +I, -Groups)
%  Groups: list of GroupKey-IndexList pairs (clause indices in order).
collect_const_groups(Clauses, StartI, Groups) :-
    collect_const_groups_aux(Clauses, StartI, Pairs0),
    pairs_group_keys(Pairs0, Groups).

collect_const_groups_aux([], _, []).
collect_const_groups_aux([Head-_|Rest], I, [FirstArg-I|RestPairs]) :-
    Head =.. [_|[FirstArg|_]],
    NextI is I + 1,
    collect_const_groups_aux(Rest, NextI, RestPairs).

%% collect_struct_groups(+Clauses, +I, -Groups)
collect_struct_groups(Clauses, StartI, Groups) :-
    collect_struct_groups_aux(Clauses, StartI, Pairs0),
    pairs_group_keys(Pairs0, Groups).

collect_struct_groups_aux([], _, []).
collect_struct_groups_aux([Head-_|Rest], I, [FN-I|RestPairs]) :-
    Head =.. [_|[FirstArg|_]],
    FirstArg =.. [F|SubArgs],
    length(SubArgs, SArity),
    format(atom(FN), "~w/~w", [F, SArity]),
    NextI is I + 1,
    collect_struct_groups_aux(Rest, NextI, RestPairs).

%% pairs_group_keys(+KVPairs, -Groups)
%  Preserves first-occurrence order of keys; values for the same key
%  accumulate in encounter order.
pairs_group_keys([], []).
pairs_group_keys([K-V|Rest], [K-[V|Vs]|GroupedRest]) :-
    partition_by_key(K, Rest, Vs, NonMatching),
    pairs_group_keys(NonMatching, GroupedRest).

partition_by_key(_, [], [], []).
partition_by_key(K, [K-V|Rest], [V|Match], NonMatch) :-
    !,
    partition_by_key(K, Rest, Match, NonMatch).
partition_by_key(K, [Other|Rest], Match, [Other|NonMatch]) :-
    partition_by_key(K, Rest, Match, NonMatch).

%% groups_to_entries_and_chains(+Groups, +Pred, +Arity, +Kind,
%%                              -Entries, -DispatchCode)
%  Each group becomes a `Key-Label` index entry.  Label is:
%    - "default" if the first matching clause is clause 1;
%    - L_<Pred>_<Arity>_<I>_body if exactly one clause matches and
%      it is not clause 1;
%    - L_<Pred>_<Arity>_<kind>_<sanitized_key>_dispatch when >1
%      clauses match (none of which is clause 1) — a chain is
%      emitted in DispatchCode targeting the body labels.
groups_to_entries_and_chains([], _, _, _, [], "").
groups_to_entries_and_chains([Key-Indices|Rest], Pred, Arity, Kind,
                             [Key-Label|RestEntries], DispatchCode) :-
    group_label_and_chain(Key, Indices, Pred, Arity, Kind,
                          Label, ChainCode),
    groups_to_entries_and_chains(Rest, Pred, Arity, Kind,
                                 RestEntries, RestDispatchCode),
    (   ChainCode == ""
    ->  DispatchCode = RestDispatchCode
    ;   RestDispatchCode == ""
    ->  DispatchCode = ChainCode
    ;   format(string(DispatchCode), "~w~n~w", [ChainCode, RestDispatchCode])
    ).

%% group_label_and_chain(+Key, +Indices, +Pred, +Arity, +Kind,
%%                       -Label, -ChainCode)
group_label_and_chain(_, [1|_], _, _, _, default, "") :- !.
group_label_and_chain(_, [I], Pred, Arity, _, Label, "") :-
    !,
    format(atom(Label), "L_~w_~w_~w_body", [Pred, Arity, I]).
group_label_and_chain(Key, Indices, Pred, Arity, Kind, Label, ChainCode) :-
    sanitize_dispatch_key(Key, Kind, KeyAtom),
    format(atom(Label), "L_~w_~w_~w_~w_dispatch",
           [Pred, Arity, Kind, KeyAtom]),
    format_dispatch_chain(Label, Indices, Pred, Arity, ChainCode).

%% sanitize_dispatch_key(+Key, +Kind, -Atom)
%  Map a dispatch key (atom / integer / float / "name/arity" /
%  list-bucket sentinel) to a label-safe atom.
sanitize_dispatch_key(Key, _, Atom) :-
    (   atom(Key)
    ->  atom_chars(Key, Chars),
        maplist(safe_label_char, Chars, SafeChars),
        atom_chars(Atom, SafeChars)
    ;   format(atom(Atom), "~w", [Key])
    ).

safe_label_char(Ch, '_') :-
    \+ char_type(Ch, alnum),
    Ch \== '_', !.
safe_label_char(Ch, Ch).

%% format_dispatch_chain(+Label, +Indices, +Pred, +Arity, -Code)
%  Synthesizes a try/retry/trust chain pointing at the body labels
%  of the matching clauses.  Format:
%    Label:
%        try L_<Pred>_<Arity>_<I1>_body
%        retry L_<Pred>_<Arity>_<I2>_body
%        ...
%        trust L_<Pred>_<Arity>_<IN>_body
format_dispatch_chain(Label, Indices, Pred, Arity, Code) :-
    length(Indices, N),
    chain_lines(Indices, 1, N, Pred, Arity, Lines),
    atomic_list_concat([Label, ":\n" | Lines], "", Code).

chain_lines([], _, _, _, _, []).
chain_lines([I|Rest], Pos, N, Pred, Arity, [Line|RestLines]) :-
    (   Pos == 1, N > 1
    ->  Op = try
    ;   Pos == N
    ->  Op = trust
    ;   Op = retry
    ),
    format(atom(BodyLabel), "L_~w_~w_~w_body", [Pred, Arity, I]),
    format(string(Line), "    ~w ~w~n", [Op, BodyLabel]),
    NextPos is Pos + 1,
    chain_lines(Rest, NextPos, N, Pred, Arity, RestLines).

%% build_term_index_with_chains(+Clauses, +Pred, +Arity,
%%                              -ConstEntries, -StructEntries,
%%                              -ListLabel, -DispatchCode)
%  Like build_term_index but groups multi-clause matches and
%  synthesizes try/retry/trust dispatch chains for them.
build_term_index_with_chains(Clauses, Pred, Arity,
        ConstEntries, StructEntries, ListLabel, DispatchCode) :-
    collect_term_groups(Clauses, 1, ConstGroupsRaw, StructGroupsRaw,
                        ListIndicesRaw),
    pairs_group_keys(ConstGroupsRaw, ConstGroups),
    pairs_group_keys(StructGroupsRaw, StructGroups),
    sort(ListIndicesRaw, ListIndices),
    groups_to_entries_and_chains(ConstGroups, Pred, Arity, const,
                                 ConstEntries, CConstDC),
    groups_to_entries_and_chains(StructGroups, Pred, Arity, struct,
                                 StructEntries, CStructDC),
    list_indices_to_label(ListIndices, Pred, Arity, ListLabel, CListDC),
    concat_nonempty([CConstDC, CStructDC, CListDC], DispatchCode).

list_indices_to_label([], _, _, none, "") :- !.
list_indices_to_label([1|_], _, _, default, "") :- !.
list_indices_to_label([I], Pred, Arity, Label, "") :-
    !,
    format(atom(Label), "L_~w_~w_~w_body", [Pred, Arity, I]).
list_indices_to_label(Indices, Pred, Arity, Label, ChainCode) :-
    format(atom(Label), "L_~w_~w_list_dispatch", [Pred, Arity]),
    format_dispatch_chain(Label, Indices, Pred, Arity, ChainCode).

concat_nonempty(Parts, Result) :-
    include([P]>>(P \== ""), Parts, NonEmpty),
    atomic_list_concat(NonEmpty, "\n", Result).

%% collect_term_groups(+Clauses, +I, -ConstPairs, -StructPairs, -ListIdxs)
collect_term_groups([], _, [], [], []).
collect_term_groups([Head-_|Rest], I, ConstPairs, StructPairs, ListIdxs) :-
    Head =.. [_|[FirstArg|_]],
    NextI is I + 1,
    collect_term_groups(Rest, NextI, RestConst, RestStruct, RestList),
    (   atomic(FirstArg)
    ->  ConstPairs = [FirstArg-I|RestConst],
        StructPairs = RestStruct,
        ListIdxs = RestList
    ;   is_list_term(FirstArg)
    ->  ConstPairs = RestConst,
        StructPairs = RestStruct,
        ListIdxs = [I|RestList]
    ;   compound(FirstArg)
    ->  FirstArg =.. [F|SubArgs],
        length(SubArgs, SArity),
        format(atom(FN), "~w/~w", [F, SArity]),
        ConstPairs = RestConst,
        StructPairs = [FN-I|RestStruct],
        ListIdxs = RestList
    ;   % Variable / other — not indexable here.
        ConstPairs = RestConst,
        StructPairs = RestStruct,
        ListIdxs = RestList
    ).

%% build_second_arg_index(+Pred, +Arity, +Clauses, -IndexCode)
%  When first-arg indexing fails (e.g., all variable first args),
%  try indexing on the second argument instead. Mirrors the A1
%  decision: all atomic → switch_on_constant_a2; all compound →
%  switch_on_structure_a2; mixed atomic/compound → switch_on_term_a2.
%  When the predicate has variable A2 clauses, the constant prefix
%  (up to the first variable A2) is still dispatched via
%  switch_on_constant_a2_fallthrough — symmetric with A1''s
%  switch_on_constant_fallthrough.
build_second_arg_index(Pred, Arity, Clauses, IndexCode) :-
    classify_second_args(Clauses, Types),
    (   \+ member(variable, Types)
    ->  build_second_arg_index_homogeneous(Pred, Arity, Clauses, Types,
                                           IndexCode)
    ;   build_second_arg_index_with_fallthrough(Pred, Arity, Clauses, Types,
                                                IndexCode)
    ).

%% Compat wrapper: build_first_arg_index/5 above expects
%% (IndexHeader, DispatchChains).  Second-arg indexing still uses the
%% legacy single-output shape — TODO: extend with dispatch chains too,
%% but the SwitchOnTerm-via-A2 path is rarer and the same fix applies
%% mechanically.  For now wrap so the calling site type-checks.
build_second_arg_index(Pred, Arity, Clauses, IndexHeader, DispatchChains) :-
    build_second_arg_index(Pred, Arity, Clauses, IndexHeader),
    DispatchChains = "".

build_second_arg_index_homogeneous(Pred, Arity, Clauses, Types, IndexCode) :-
    (   forall(member(T, Types), T = constant)
    ->  build_constant_index_on(Clauses, 2, 1, Pred, Arity, Entries),
        Entries \= [],
        format_index_entries(Entries, EntriesStr),
        format(string(IndexCode), "    switch_on_constant_a2 ~w", [EntriesStr])
    ;   forall(member(T, Types), T = structure),
        \+ second_args_contain_list(Clauses)
    ->  build_structure_index_on(Clauses, 2, 1, Pred, Arity, Entries),
        Entries \= [],
        format_index_entries(Entries, EntriesStr),
        format(string(IndexCode), "    switch_on_structure_a2 ~w", [EntriesStr])
    ;   % Mixed atomic/compound (possibly including lists) — emit
        % switch_on_term_a2 with type-based dispatch, same shape as
        % the A1 switch_on_term.
        build_term_index_on(Clauses, 2, 1, Pred, Arity, Types,
                            ConstEntries, StructEntries, ListLabel),
        format_switch_on_term_a2(ConstEntries, StructEntries, ListLabel,
                                 IndexCode)
    ).

build_second_arg_index_with_fallthrough(Pred, Arity, Clauses, Types,
                                        IndexCode) :-
    indexed_prefix(Types, Clauses, PrefixTypes, PrefixClauses),
    PrefixClauses \= [],
    % v1: only handle constant prefix, matching the A1 scope.
    forall(member(T, PrefixTypes), T = constant),
    build_constant_index_on(PrefixClauses, 2, 1, Pred, Arity, Entries),
    Entries \= [],
    format_index_entries(Entries, EntriesStr),
    format(string(IndexCode),
           "    switch_on_constant_a2_fallthrough ~w", [EntriesStr]).

classify_second_args([], []).
classify_second_args([Head-_|Rest], [Type|RestTypes]) :-
    Head =.. [_|Args],
    (   length(Args, L), L >= 2, nth1(2, Args, SecondArg)
    ->  (   var(SecondArg) -> Type = variable
        ;   atomic(SecondArg) -> Type = constant
        ;   is_list_term(SecondArg) -> Type = structure
        ;   compound(SecondArg) -> Type = structure
        ;   Type = variable
        )
    ;   Type = variable
    ),
    classify_second_args(Rest, RestTypes).

second_args_contain_list([Head-_|_]) :-
    Head =.. [_|Args],
    nth1(2, Args, SecondArg),
    is_list_term(SecondArg), !.
second_args_contain_list([_|Rest]) :-
    second_args_contain_list(Rest).

build_structure_index_on([], _, _, _, _, []).
build_structure_index_on([Head-_|Rest], ArgPos, I, Pred, Arity,
                         [FN-Label|RestEntries]) :-
    Head =.. [_|Args],
    nth1(ArgPos, Args, ArgVal),
    ArgVal =.. [F|SubArgs],
    length(SubArgs, SArity),
    format(atom(FN), "~w/~w", [F, SArity]),
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_structure_index_on(Rest, ArgPos, NextI, Pred, Arity, RestEntries).

build_term_index_on([], _, _, _, _, _, [], [], none).
build_term_index_on([Head-_|Rest], ArgPos, I, Pred, Arity,
                    [Type|RestTypes],
                    ConstEntries, StructEntries, ListLabel) :-
    Head =.. [_|Args],
    nth1(ArgPos, Args, ArgVal),
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_term_index_on(Rest, ArgPos, NextI, Pred, Arity, RestTypes,
                        RestConst, RestStruct, RestListLabel),
    (   Type = constant
    ->  ConstEntries = [ArgVal-Label|RestConst],
        StructEntries = RestStruct,
        ListLabel = RestListLabel
    ;   Type = structure,
        is_list_term(ArgVal)
    ->  ConstEntries = RestConst,
        StructEntries = RestStruct,
        ListLabel = Label
    ;   Type = structure
    ->  ArgVal =.. [F|SubArgs],
        length(SubArgs, SArity),
        format(atom(FN), "~w/~w", [F, SArity]),
        ConstEntries = RestConst,
        StructEntries = [FN-Label|RestStruct],
        ListLabel = RestListLabel
    ;   ConstEntries = RestConst,
        StructEntries = RestStruct,
        ListLabel = RestListLabel
    ).

format_switch_on_term_a2(ConstEntries, StructEntries, ListLabel, IndexCode) :-
    length(ConstEntries, CLen),
    length(StructEntries, SLen),
    format_index_entries(ConstEntries, CStr),
    format_index_entries(StructEntries, SStr),
    format(string(IndexCode),
           "    switch_on_term_a2 ~w ~w ~w ~w ~w",
           [CLen, CStr, SLen, SStr, ListLabel]).

build_constant_index_on([], _, _, _, _, []).
build_constant_index_on([Head-_|Rest], ArgPos, I, Pred, Arity, [Val-Label|RestEntries]) :-
    Head =.. [_|Args],
    nth1(ArgPos, Args, Val),
    (   I == 1 -> Label = default
    ;   format(atom(Label), "L_~w_~w_~w", [Pred, Arity, I])
    ),
    NextI is I + 1,
    build_constant_index_on(Rest, ArgPos, NextI, Pred, Arity, RestEntries).

format_index_entries(Entries, Str) :-
    maplist([K-V, S]>>(quote_wam_constant(K, KStr),
                       format(atom(S), "~w:~w", [KStr, V])),
            Entries, Parts),
    atomic_list_concat(Parts, ' ', Str).

% ---------------------------------------------------------------------------
% Constant quoting
% ---------------------------------------------------------------------------
%
% The symbolic WAM text uses ` `, `,`, and `\t` as token separators and
% `:` as the key/label separator inside `switch_on_constant` entries.
% Prolog atoms freely contain any of those characters, so a naive
% `~w` serialisation produces output the downstream line tokenizer
% cannot reparse (`get_constant Washington,_D.C., A1` splits on the
% embedded comma and emits a `raw/1` catch-all).
%
% `quote_wam_constant/2` wraps constants that need quoting in
% single quotes, escaping embedded `'` as `\'` and `\` as `\\`.
% Unambiguous unquoted atoms (identifier-like, numeric) pass through
% unchanged, keeping the common case readable.
%
% Downstream tokenizers (see `wam_elixir_lowered_emitter:tokenize_wam_line/2`)
% must recognise the same quote syntax.

%% quote_wam_constant(+Value, -QuotedString)
%  Value is an atom, string, or number. QuotedString is a string
%  suitable to embed after `get_constant`, `put_constant`, etc.
%
%  Atom-vs-number disambiguation: atoms whose textual form would
%  re-parse as a number (`''5''`, `''42''`, `''-3.14''`) are emitted
%  in single quotes (`''5''`). The discriminator is the presence of
%  outer quotes in the emitted text. Downstream tokenizers must
%  preserve that signal — either by keeping the quotes attached to
%  the token (the convention used by wam_text_parser and the F#
%  splitter) or by exposing a parallel quote-state flag — so that
%  constant-emitters can branch on atom-vs-number without re-parsing
%  the textual form. See
%  wam_text_parser:wam_classify_constant_token/2 for the shared
%  classification helper.
quote_wam_constant(Value, Quoted) :-
    (   number(Value)
    ->  format(string(Quoted), "~w", [Value])
    ;   ( atom(Value) -> atom_string(Value, Str) ; Str = Value ),
        (   ( atom_looks_like_number(Str)
            ; constant_needs_quoting(Str)
            )
        ->  escape_for_wam_quoting(Str, Escaped),
            format(string(Quoted), "'~w'", [Escaped])
        ;   Quoted = Str
        )
    ).

%% atom_looks_like_number(+Str) is semidet.
%  True iff Str (which is the textual form of an atom) would re-parse
%  as a number. Used by quote_wam_constant to decide whether to force
%  quoting so the round-trip preserves atom-vs-number.
atom_looks_like_number(Str) :-
    catch(number_string(_, Str), _, fail).

constant_needs_quoting("") :- !.
constant_needs_quoting(Str) :-
    string_chars(Str, Chars),
    member(C, Chars),
    separator_or_special_char(C), !.

separator_or_special_char(' ').
separator_or_special_char('\t').
separator_or_special_char(',').
separator_or_special_char(':').
separator_or_special_char('\'').
separator_or_special_char('\\').

escape_for_wam_quoting(Str, Escaped) :-
    string_chars(Str, Chars),
    maplist(escape_wam_char, Chars, NestedChars),
    append(NestedChars, EscChars),
    string_chars(Escaped, EscChars).

escape_wam_char('\\', ['\\', '\\']).
escape_wam_char('\'', ['\\', '\'']).
escape_wam_char(C, [C]).

%% compile_single_clause_wam(+Clause, +Options, -Code)
compile_single_clause_wam(Head-Body, Options, Code) :-
    set_clause_binding_context(Head, Body),
    set_clause_visited_context(Head),
    Head =.. [_|Args],
    normalize_goals(Body, Goals),
    empty_varmap(V0),
    % Force permanent variable allocation when the body contains a
    % Call (including aggregate_all/findall whose inner goals contain
    % Calls). Without this, a single-goal clause like
    %   p(X,Y) :- aggregate_all(sum(W), q(X,…), Y).
    % assigns X/Y to X-registers (< 200) which get clobbered by the
    % inner Call to q.
    % Expand aggregates so pre_assign_permanent_vars sees the inner
    % goals. Variables shared between the head and the aggregate body
    % must be permanent (Y-registers) because the inner Call clobbers
    % X-registers.
    expand_aggregate_goals_for_perm_vars(Goals, ExpandedGoals),
    (   ( length(ExpandedGoals, N), N > 1
        ; goals_contain_call_or_aggregate(Goals)
        )
    ->  % Pre-assign Yi registers, emit allocate before head so Yi
        % registers can be stored in the environment frame immediately.
        pre_assign_permanent_vars(ExpandedGoals, V0, V0a),
        compile_head_arguments(Args, 1, V0a, V1, HeadCode),
        compile_goals(Goals, V1, yes, _, GoalsCode),
        format(string(Code), "    allocate~n~w~n~w", [HeadCode, GoalsCode])
    ;   compile_head_arguments(Args, 1, V0, V1, HeadCode),
        (   Goals == []
        ->  BodyCode = "    proceed"
        ;   compile_body_goals(Goals, V1, Options, BodyCode)
        ),
        format(string(Code), "~w~n~w", [HeadCode, BodyCode])
    ).

%% goals_contain_call_or_aggregate(+Goals)
%  True if any goal in the list is a Call to a user predicate or an
%  aggregate_all/findall/bagof/setof that internally produces Call
%  instructions.
%  Used to force permanent variable allocation in single-goal clauses
%  that would otherwise skip it (since length(Goals) == 1).
goals_contain_call_or_aggregate(Goals) :-
    member(G, Goals),
    ( G = aggregate_all(_, _, _)
    ; G = findall(_, _, _)
    ; wam_inline_bagof_setof_enabled, G = bagof(_, _, _)
    ; wam_inline_bagof_setof_enabled, G = setof(_, _, _)
    ; callable(G), functor(G, F, _), \+ is_builtin_goal(F)
    ),
    !.

wam_inline_bagof_setof_enabled :-
    catch(b_getval(wam_inline_bagof_setof, true), _, fail).

wam_inline_not_enabled :-
    catch(b_getval(wam_inline_not, true), _, fail).

wam_ite_use_y_level_enabled :-
    catch(b_getval(wam_ite_use_y_level, true), _, fail).

% Current cut scope for a plain `!` emission. `clause` (the default)
% means a `!` is transparent to the enclosing clause and emits
% `builtin_call !/0` (the runtime cuts to the clause B0). Inside an
% if-then-else CONDITION the cut is OPAQUE (local to the condition, like
% call/1): the target is set to the condition''s barrier Y-register and a
% `!` emits `cut Yn`, pruning only the condition''s own choicepoints and
% leaving the if-then-else choicepoint intact. Saved/restored around
% condition compilation so Then/Else branches revert to the enclosing
% scope. Only meaningful under wam_ite_use_y_level_enabled (get_level/cut
% targets); legacy targets always emit builtin_call !/0.
current_cut_target(Target) :-
    ( catch(b_getval(wam_cut_target, T), _, fail) -> Target = T ; Target = clause ).

set_cut_target(Target) :-
    b_setval(wam_cut_target, Target).

is_builtin_goal(is).
is_builtin_goal(=).
is_builtin_goal(\=).
is_builtin_goal(>).
is_builtin_goal(<).
is_builtin_goal(>=).
is_builtin_goal(=<).
is_builtin_goal(=:=).
is_builtin_goal(=\=).
is_builtin_goal(true).
is_builtin_goal(fail).
is_builtin_goal(write).
is_builtin_goal(display).
is_builtin_goal(nl).
is_builtin_goal(format).
is_builtin_goal(member).
is_builtin_goal(length).
is_builtin_goal(is_list).
is_builtin_goal(append).
is_builtin_goal((\+)).
is_builtin_goal(atom_length).
is_builtin_goal(atom_codes).
is_builtin_goal(atom_chars).
is_builtin_goal(char_code).
is_builtin_goal(between).

%% expand_aggregate_goals_for_perm_vars(+Goals, -Expanded)
%  For permanent-variable detection, expand aggregate_all/findall/
%  bagof/setof into their inner goals + a synthetic "result" goal. This ensures
%  variables shared between the clause head and the aggregate body
%  are detected as permanent (appear in >1 "goal").
expand_aggregate_goals_for_perm_vars([], []).
expand_aggregate_goals_for_perm_vars([G|Rest], Expanded) :-
    (   G = aggregate_all(_Template, InnerGoal, _Result)
    ->  flatten_conjunction(InnerGoal, InnerGoals),
        % Add the aggregate itself as a separate "goal" so that
        % variables appearing in the aggregate arguments AND in the
        % inner body register as permanent (cross-goal).
        append([G|InnerGoals], RestExpanded, Expanded)
    ;   G = findall(_Template, InnerGoal, _Result)
    ->  flatten_conjunction(InnerGoal, InnerGoals),
        append([G|InnerGoals], RestExpanded, Expanded)
    ;   wam_inline_bagof_setof_enabled,
        G = bagof(_Template, InnerGoal, _Result)
    ->  flatten_conjunction(InnerGoal, InnerGoals),
        append([G|InnerGoals], RestExpanded, Expanded)
    ;   wam_inline_bagof_setof_enabled,
        G = setof(_Template, InnerGoal, _Result)
    ->  flatten_conjunction(InnerGoal, InnerGoals),
        append([G|InnerGoals], RestExpanded, Expanded)
    ;   ( G = (_;_) ; G = (_->_) )
    ->  % ITE / soft-cut: expose branch goals so variables shared
        %  between the clause head and the ITE branches are detected as
        %  permanent (they appear in the "later" expanded goals).
        (   G = (If -> Then ; Else)
        ->  flatten_conjunction(If,   IfGoals),
            flatten_conjunction(Then, ThenGoals),
            flatten_conjunction(Else, ElseGoals),
            append(IfGoals, ThenGoals, IfThen),
            append(IfThen,  ElseGoals, BranchGoals)
        ;   G = (If -> Then)
        ->  flatten_conjunction(If,  IfGoals),
            flatten_conjunction(Then, ThenGoals),
            append(IfGoals, ThenGoals, BranchGoals)
        ;   G = (A ; B)
        ->  flatten_conjunction(A, AGls),
            flatten_conjunction(B, BGls),
            append(AGls, BGls, BranchGoals)
        ;   BranchGoals = [G]
        ),
        append([G|BranchGoals], RestExpanded, Expanded)
    ;   Expanded = [G|RestExpanded]
    ),
    expand_aggregate_goals_for_perm_vars(Rest, RestExpanded).

%% compile_multi_clause_wam(+Pred, +Arity, +Clauses, +Options, -Code)
compile_multi_clause_wam(Pred, Arity, Clauses, Options, Code) :-
    length(Clauses, N),
    % Build a list of per-clause fragment strings, then atomic_list_concat
    % once at the end. The previous nested format/3 recursion rebuilt the
    % growing accumulator at each step — O(N²) for fact-only predicates
    % with thousands of clauses (6009-clause category_parent/2 took ~85s
    % before; ~3s after).
    compile_clauses_fragments(Clauses, 1, N, Pred, Arity, Options, Fragments),
    atomic_list_concat(Fragments, '\n', Code).

compile_clauses_fragments([], _, _, _, _, _, []).
compile_clauses_fragments([Head-Body|Rest], I, N, Pred, Arity, Options,
                         [Choice, HeadCode, BodyCode | RestFragments]) :-
    %% Clauses 2..N also get an `L_<Pred>_<Arity>_<I>_body:` label
    %% emitted immediately AFTER the retry_me_else / trust_me line.
    %% Indexed dispatch (try/retry/trust chains synthesized by
    %% build_first_arg_index) jumps to this body label so the
    %% clause body runs without re-entering the linear chain's CP
    %% protocol.  Clause 1 has no separate body label because
    %% indexed dispatch never targets it (groups containing clause 1
    %% use "default" → fall through to the leading try_me_else).
    (   I == 1
    ->  format(string(Choice), "    try_me_else L_~w_~w_~w", [Pred, Arity, 2])
    ;   I == N
    ->  format(string(Choice),
               "L_~w_~w_~w:~n    trust_me~nL_~w_~w_~w_body:",
               [Pred, Arity, I, Pred, Arity, I])
    ;   Next is I + 1,
        format(string(Choice),
               "L_~w_~w_~w:~n    retry_me_else L_~w_~w_~w~nL_~w_~w_~w_body:",
               [Pred, Arity, I, Pred, Arity, Next, Pred, Arity, I])
    ),
    % Compile clause body — pre-assign Yi for permanent vars before head
    set_clause_binding_context(Head, Body),
    set_clause_visited_context(Head),
    Head =.. [_|Args],
    normalize_goals(Body, Goals),
    empty_varmap(V0),
    % Force permanent variable allocation when the body contains a Call
    % or aggregate (findall/aggregate_all), or a Cut (!/0), even for
    % single-goal bodies.
    % Without an env frame, the post-aggregate continuation has nowhere
    % to retrieve the caller's saved cp from, so finalise_aggregate's
    % update_topmost_agg_cp + restored.cp.(restored) chain loops back
    % into k2 forever. Also, Cut needs an environment frame to access
    % the cut barrier in some targets (like LLVM).
    % The single-clause path applies the same condition at line ~327;
    % this keeps multi-clause in sync.
    expand_aggregate_goals_for_perm_vars(Goals, ExpandedGoals),
    (   ( length(ExpandedGoals, NG), NG > 1
        ; goals_contain_call_or_aggregate(Goals)
        ; member(builtin_call('!/0', _), Goals)
        )
    ->  pre_assign_permanent_vars(ExpandedGoals, V0, V0a),
        compile_head_arguments(Args, 1, V0a, V1, HeadCode0),
        compile_goals(Goals, V1, yes, _, GoalsCode),
        format(string(HeadCode), "    allocate~n~w", [HeadCode0]),
        BodyCode = GoalsCode
    ;   compile_head_arguments(Args, 1, V0, V1, HeadCode),
        (   Goals == []
        ->  BodyCode = "    proceed"
        ;   compile_body_goals(Goals, V1, Options, BodyCode)
        )
    ),
    NextI is I + 1,
    compile_clauses_fragments(Rest, NextI, N, Pred, Arity, Options, RestFragments).

%% compile_head_arguments(+Args, +ArgIndex, +VIn, -VOut, -Code)
compile_head_arguments([], _, V, V, "").
compile_head_arguments([Arg|Rest], I, V0, Vf, Code) :-
    compile_head_argument(Arg, I, V0, V1, ArgCode),
    NI is I + 1,
    compile_head_arguments(Rest, NI, V1, Vf, RestCode),
    (   RestCode == ""
    ->  Code = ArgCode
    ;   format(string(Code), "~w~n~w", [ArgCode, RestCode])
    ).

compile_head_argument(Arg, I, V0, V1, Code) :-
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  format(string(Code), "    get_value ~w, A~w", [Reg, I]),
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  format(string(Code), "    get_variable ~w, A~w", [YReg, I])
        ;   next_x_reg(V0, XReg, V_temp),
            bind_var(Arg, XReg, V_temp, V1),
            format(string(Code), "    get_variable ~w, A~w", [XReg, I])
        )
    ;   atomic(Arg)
    ->  quote_wam_constant(Arg, ArgStr),
        format(string(Code), "    get_constant ~w, A~w", [ArgStr, I]),
        V1 = V0
    ;   is_list_term(Arg)
    ->  Arg = [H|T],
        format(string(Fst), "    get_list A~w", [I]),
        compile_unify_arguments([H, T], V0, V1, SubCode),
        format(string(Code), "~w~n~w", [Fst, SubCode])
    ;   compound(Arg)
    ->  Arg =.. [F|SubArgs],
        length(SubArgs, Arity),
        format(string(Fst), "    get_structure ~w/~w, A~w", [F, Arity, I]),
        compile_unify_arguments(SubArgs, V0, V1, SubCode),
        format(string(Code), "~w~n~w", [Fst, SubCode])
    ).

%% is_list_term(+Term) — true if Term is a non-empty list cons cell [H|T].
is_list_term(Term) :- nonvar(Term), Term = [_|_].

compile_unify_arguments([], V, V, "").
compile_unify_arguments([Arg|Rest], V0, Vf, Code) :-
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  format(string(ArgCode), "    unify_value ~w", [Reg]),
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  format(string(ArgCode), "    unify_variable ~w", [YReg])
        ;   next_x_reg(V0, XReg, V_temp),
            bind_var(Arg, XReg, V_temp, V1),
            format(string(ArgCode), "    unify_variable ~w", [XReg])
        )
    ;   atomic(Arg)
    ->  quote_wam_constant(Arg, ArgStr),
        format(string(ArgCode), "    unify_constant ~w", [ArgStr]),
        V1 = V0
    ;   % Nested structure — emit unify_variable for a temp register,
        % then get_structure + unify_* for the nested sub-arguments.
        compound(Arg)
    ->  Arg =.. [F|NestedArgs],
        length(NestedArgs, NArity),
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1a),
        format(string(UnifyCode), "    unify_variable ~w", [XReg]),
        format(string(GetCode), "    get_structure ~w/~w, ~w", [F, NArity, XReg]),
        compile_unify_arguments(NestedArgs, V1a, V1, NestedCode),
        format(string(ArgCode), "~w~n~w~n~w", [UnifyCode, GetCode, NestedCode])
    ;   % Fallback
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1),
        format(string(ArgCode), "    unify_variable ~w", [XReg])
    ),
    compile_unify_arguments(Rest, V1, Vf, RestCode),
    (   RestCode == ""
    ->  Code = ArgCode
    ;   format(string(Code), "~w~n~w", [ArgCode, RestCode])
    ).

%% compile_body_goals(+Goals, +VarMap, +Options, -Code)
compile_body_goals(Goals, V, _Options, Code) :-
    length(Goals, N),
    (   N > 1
    ->  % allocate + Yi promotion handled by the clause compiler.
        compile_goals(Goals, V, yes, _, GoalsCode),
        format(string(Code), "    allocate~n~w", [GoalsCode])
    ;   compile_goals(Goals, V, no, _, Code)
    ).

%% pre_assign_permanent_vars(+Goals, +VarMapIn, -VarMapOut)
%  Identifies permanent variables and pre-assigns them Yi registers.
%  A variable is permanent if it is used in any non-first goal (i.e., it
%  must survive across at least one call instruction). This includes
%  head-bound variables referenced after the first call.
pre_assign_permanent_vars(Goals, vmap(Bindings, X), vmap(NewBindings, XOut)) :-
    collect_goal_vars(Goals, GoalVarSets),
    find_permanent_vars(GoalVarSets, PermVars),
    reassign_to_yi(Bindings, PermVars, 1, ReassignedBindings, NextY),
    pre_bind_unbound_yi(PermVars, ReassignedBindings, NextY, NewBindings),
    %% Bump the X register counter past all allocated Yi indices.
    %% Yi and Xi share the same register-file range (both map to
    %% N + 31 in reg_name_to_index), so a subsequent next_x_reg
    %% must not hand out an Xi that collides with an allocated Yi.
    max_yi_index(NewBindings, 0, MaxY),
    XOut is max(X, MaxY + 1).

%% max_yi_index(+Bindings, +Acc, -Max)
%  Finds the highest Y-register number among b(_, Yi) and y_alloc(_, Yi)
%  entries. Returns 0 if there are no Y registers.
max_yi_index([], Max, Max).
max_yi_index([Entry|Rest], Acc, Max) :-
    (   ( Entry = b(_, Reg) ; Entry = y_alloc(_, Reg) ),
        atom_string(Reg, S),
        string_codes(S, [0'Y|Digits]),
        number_codes(N, Digits)
    ->  NewAcc is max(Acc, N)
    ;   NewAcc = Acc
    ),
    max_yi_index(Rest, NewAcc, Max).

collect_goal_vars([], []).
collect_goal_vars([Goal|Rest], [Vars|RestVars]) :-
    term_variables(Goal, Vars),
    collect_goal_vars(Rest, RestVars).

%% find_permanent_vars(+GoalVarSets, -PermVars)
%  A variable is permanent if it appears in any non-first goal, since the
%  first goal's call instruction may clobber Xi registers. This captures
%  both cross-goal variables and head-bound variables used after a call.
find_permanent_vars(GoalVarSets, PermVars) :-
    (   GoalVarSets = [_|RestGoalSets]
    ->  append(RestGoalSets, AllLaterVars),
        unique_vars(AllLaterVars, PermVars)
    ;   PermVars = []
    ).

unique_vars([], []).
unique_vars([V|Rest], Result) :-
    unique_vars(Rest, Acc),
    (   member(A, Acc), A == V
    ->  Result = Acc
    ;   Result = [V|Acc]
    ).

var_in_list(List, Var) :-
    member(V, List), V == Var, !.

union_vars([], Acc, Acc).
union_vars([V|Rest], Acc, Result) :-
    (   member(A, Acc), A == V
    ->  union_vars(Rest, Acc, Result)
    ;   union_vars(Rest, [V|Acc], Result)
    ).

%% reassign_to_yi(+Bindings, +PermVars, +YI, -NewBindings, -NextY)
%  Reassigns already-bound permanent variables from Xi to Yi.
reassign_to_yi([], _, YI, [], YI).
reassign_to_yi([b(Var, _Reg)|Rest], PermVars, YI, [b(Var, YReg)|NewRest], NextY) :-
    member(PV, PermVars), PV == Var, !,
    format(atom(YReg), "Y~w", [YI]),
    NYI is YI + 1,
    reassign_to_yi(Rest, PermVars, NYI, NewRest, NextY).
reassign_to_yi([B|Rest], PermVars, YI, [B|NewRest], NextY) :-
    reassign_to_yi(Rest, PermVars, YI, NewRest, NextY).

%% pre_bind_unbound_yi(+PermVars, +Bindings, +YI, -NewBindings)
%  For permanent variables not yet in the varmap, pre-allocate a Yi register
%  using y_alloc (not yet seen — will be promoted to b() on first use).
pre_bind_unbound_yi([], Bindings, _, Bindings).
pre_bind_unbound_yi([Var|Rest], Bindings, YI, NewBindings) :-
    (   (member(b(V, _), Bindings), V == Var ; member(y_alloc(V, _), Bindings), V == Var)
    ->  pre_bind_unbound_yi(Rest, Bindings, YI, NewBindings)
    ;   format(atom(YReg), "Y~w", [YI]),
        NYI is YI + 1,
        pre_bind_unbound_yi(Rest, [y_alloc(Var, YReg)|Bindings], NYI, NewBindings)
    ).

%% compile_goals(+Goals, +VarMap, +HasEnv, -Vf, -Code)
compile_goals([], V, _, V, "").
compile_goals([Goal|Rest], V0, HasEnv, Vf, Code) :-
    % Check for aggregate_all/findall/bagof/setof first — these are
    % always compiled inline.
    (   Goal = aggregate_all(Template, InnerGoal, Result)
    ->  compile_aggregate_all(Template, InnerGoal, Result, V0, V1, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    ;   Goal = findall(Template, InnerGoal, Result)
    ->  compile_findall(Template, InnerGoal, Result, V0, V1, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    ;   wam_inline_bagof_setof_enabled,
        Goal = bagof(Template, InnerGoal, Result)
    ->  compile_bagof(Template, InnerGoal, Result, V0, V1, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    ;   wam_inline_bagof_setof_enabled,
        Goal = setof(Template, InnerGoal, Result)
    ->  compile_setof(Template, InnerGoal, Result, V0, V1, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    % If-then-else: (Cond -> Then ; Else)
    ;   Goal = (CondGoal -> ThenGoal ; ElseGoal)
    ->  compile_if_then_else(CondGoal, ThenGoal, ElseGoal, V0, V1, HasEnv, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    % Negation-as-failure: \+ G. Rewrite to ((G, !, fail) ; true) so
    % the existing disjunction compiler handles the bookkeeping.
    % `!/0` cuts to the env frame''s cut_barrier (set by allocate to
    % the cpn at clause entry), wiping the outer disjunction''s
    % choice point AND any inner CPs that the condition''s multi-
    % clause calls may have left behind -- exactly the cleanup that
    % a proper \+ needs. `fail` then propagates up. The alternate
    % `(G -> fail ; true)` rewrite goes through `cut_ite` which is
    % a soft cut and only pops one CP -- it gets the wrong CP when
    % G pushes its own choice points.
    ;   nonvar(Goal),
        Goal = \+(NotGoal),
        wam_inline_not_enabled
    ->  (   wam_ite_use_y_level_enabled
        % M17 targets (get_level/cut): use the soft-cut form
        % (NotGoal -> fail ; true). cut Yn truncates choicepoints back to
        % the snapshot taken BEFORE the negation try_me_else, so it wipes
        % the negation CP AND any CPs NotGoal pushed above it -- the same
        % correctness the hard-cut form gives, but WITHOUT a clause-scope
        % `!`. That matters because a clause-scope cut would (via the
        % runtime''s B0 mechanism) cut to the enclosing clause''s level and
        % wrongly prune sibling choicepoints created before the \+. The
        % soft cut is scoped to the negation alone.
        ->  compile_goals([((NotGoal -> fail ; true)) | Rest],
                          V0, HasEnv, Vf, Code)
        % Legacy targets (no get_level/cut): keep the hard-cut rewrite
        % ((G, !, fail) ; true) -- see note below on why soft-cut+cut_ite
        % gets the wrong CP when G is nondeterministic on these targets.
        ;   compile_goals([((NotGoal, !, fail) ; true) | Rest],
                          V0, HasEnv, Vf, Code)
        )
    % M71: forall(Cond, Action) inlines as
    %   ((Cond, (Action -> fail ; true)) -> fail ; true)
    % i.e., \+ (Cond, \+ Action) using soft-cut (-> form) for BOTH
    % negations. The cut-based ((G, !, fail) ; true) rewrite that \+
    % uses by default doesn''t nest correctly here: the inner ! and
    % outer ! both target the clause''s single cut_barrier, so the
    % inner cut wipes the outer disjunction''s CP and forall always
    % fails. Soft-cut (-> ; ) gives proper local-scope cuts.
    ;   nonvar(Goal),
        Goal = forall(ForallCond, ForallAction)
    ->  compile_goals(
            [((ForallCond, (ForallAction -> fail ; true)) -> fail ; true)
             | Rest],
            V0, HasEnv, Vf, Code)
    % Bare if-then: (Cond -> Then) without an Else clause. Reuses the
    % if-then-else compiler with Else=fail — semantically identical
    % for the success path; Cond-failure just falls through to fail
    % (which is what bare ->/2 does).
    ;   Goal = (CondGoal -> ThenGoal)
    ->  compile_if_then_else(CondGoal, ThenGoal, fail, V0, V1, HasEnv, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    % Bare disjunction: (A ; B) without ->
    ;   Goal = (LeftGoal ; RightGoal),
        \+ (LeftGoal = (_ -> _))
    ->  compile_disjunction(LeftGoal, RightGoal, V0, V1, HasEnv, GoalCode),
        (   Rest == []
        ->  Vf = V1,
            (   HasEnv == yes
            ->  format(string(Code), "~w~n    deallocate~n    proceed", [GoalCode])
            ;   format(string(Code), "~w~n    proceed", [GoalCode])
            )
        ;   compile_goals(Rest, V1, HasEnv, Vf, RestCode),
            format(string(Code), "~w~n~w", [GoalCode, RestCode])
        )
    % once(G) — succeed once with G''s first solution, fail if G has
    % none. Desugars to (G -> true): if-then-else with Else=fail
    % already gives the right semantics (bare ->/2 fails on Cond
    % failure). Recurse so the rewritten goal flows through the
    % normal dispatch (including if-then-else inlining).
    ;   Goal = once(OnceGoal)
    ->  compile_goals([(OnceGoal -> true) | Rest], V0, HasEnv, Vf, Code)
    % M71: forall/2 now handled by the earlier M71 clause that uses
    % the soft-cut rewrite. This stale clause used \+ (G, \+ T) which
    % was broken for nested negation (both cuts hit the same barrier);
    % the earlier clause takes precedence so this would never fire,
    % but remove it to avoid confusion if the earlier clause ever moves.
    ;   Rest == []
    ->  % Last goal: execute (Tail Call Optimization)
        (   %% Term-construction builtins (=../2 and functor/3) only
            %% take the `deallocate-before-execute` fast path when the
            %% compose-mode lowering (emit_put_structure_dyn_lowering)
            %% actually fires — that path reads from input registers
            %% rather than Y registers, so the env frame can be popped
            %% beforehand without consequence.  When the binding-state
            %% preconditions don''t hold (e.g. `Term =.. [Name|Args]`
            %% with Args runtime-variable, as in parse_atom_head''s
            %% functor-call clause), compile_goal_execute falls through
            %% to the generic builtin path which emits PutList +
            %% SetValue Y_n reads inline.  Emitting Deallocate before
            %% that body is the codegen bug behind issue #2400''s
            %% `p(a)` parser regression: the Y reg reads see a stale
            %% env frame and the =.. compose builds garbage.
            %%
            %% Fix: route the fast path only when the special lowering
            %% will actually apply.  Otherwise fall through to the
            %% generic builtin-with-env handling below, which emits
            %% PutCode + BuiltinCall + Deallocate + Proceed in the
            %% right order.
            is_term_construction_goal(Goal),
            HasEnv == yes,
            term_construction_uses_special_lowering(Goal)
        ->  compile_goal_execute(Goal, V0, Vf, ExecCode),
            format(string(Code), "    deallocate~n~w", [ExecCode])
        ;   is_term_construction_goal(Goal),
            term_construction_uses_special_lowering(Goal)
        ->  compile_goal_execute(Goal, V0, Vf, Code)
        ;   %% Visited-set lowering (Layer 2.5) routes through
            %% compile_goal_execute where the rewrite clause fires.
            %% Without this the inline put_arguments path below would
            %% bypass the rewrite for TCO-position goals.
            goal_has_visited_set_arg(Goal),
            HasEnv == yes
        ->  compile_goal_execute(Goal, V0, Vf, ExecCode),
            format(string(Code), "    deallocate~n~w", [ExecCode])
        ;   goal_has_visited_set_arg(Goal)
        ->  compile_goal_execute(Goal, V0, Vf, Code)
        ;   HasEnv == yes
        ->  Goal =.. [Pred|Args],
            length(Args, Arity),
            compile_put_arguments(Args, 1, V0, Vf, PutCode),
            (   is_builtin_pred(Pred, Arity)
            ->  format(string(ExecCode), "    builtin_call ~w/~w, ~w", [Pred, Arity, Arity]),
                (   PutCode == ""
                ->  format(string(Code), "~w~n    deallocate~n    proceed", [ExecCode])
                ;   format(string(Code), "~w~n~w~n    deallocate~n    proceed", [PutCode, ExecCode])
                )
            ;   format(string(ExecCode), "    execute ~w/~w", [Pred, Arity]),
                (   PutCode == ""
                ->  format(string(Code), "    deallocate~n~w", [ExecCode])
                ;   format(string(Code), "~w~n    deallocate~n~w", [PutCode, ExecCode])
                )
            )
        ;   compile_goal_execute(Goal, V0, Vf, Code)
        )
    ;   % Non-last goal: call
        compile_goal_call(Goal, V0, V1, GoalCode),
        advance_clause_goal_idx,
        compile_goals(Rest, V1, HasEnv, Vf, RestCode),
        format(string(Code), "~w~n~w", [GoalCode, RestCode])
    ).

%% compile_aggregate_all(+Template, +InnerGoal, +Result, +V0, -Vf, -Code)
%  Compile aggregate_all(Template, Goal, Result) to WAM instructions.
%  Emits: begin_aggregate, Goal body, end_aggregate
%  The WAM runtime handles solution collection and aggregation.
compile_aggregate_all(Template, InnerGoal, Result, V0, Vf, Code) :-
    % Determine aggregation type from Template
    (   Template = sum(ValueVar) -> AggType = sum
    ;   Template = count       -> AggType = count, ValueVar = 1
    ;   Template = max(ValueVar) -> AggType = max
    ;   Template = min(ValueVar) -> AggType = min
    ;   Template = bag(ValueVar) -> AggType = bag
    ;   Template = set(ValueVar) -> AggType = set
    ;   Template = bagof-BagVar -> AggType = bagof, ValueVar = BagVar
    ;   Template = setof-SetVar -> AggType = setof, ValueVar = SetVar
    % findall/3 → compile_findall/5 wraps Template as `collect-Template`.
    % Unwrap to expose the real ValueVar so the var(ValueVar) branch
    % below allocates a Y-register and emits put_variable Y_n, A1.
    % Without this, ValueReg defaults to A1 and survives the inner
    % call only when no instruction along the inner-goal path
    % overwrites A1 — false in the module-qualified case where the
    % `:/2` builtin lowering puts the module-name string into A1
    % (Phase 3 finding from #1647). Y-reg version is preserved
    % across any inner-call register churn.
    ;   Template = collect-CollectVar -> AggType = collect, ValueVar = CollectVar
    ;   AggType = collect, ValueVar = Template  % default: direct callers
    ),
    % Find or allocate the Result register (where output goes).  If the
    % result is a local variable first introduced by this aggregate,
    % initialize its register before begin_aggregate so finalization has
    % an unbound cell to unify with; head-bound results are already
    % initialized by get_variable/get_value.
    (   var(Result), get_var_reg(Result, V0, ResultReg0)
    ->  V1 = V0,
        InitResultCode = ""
    ;   var(Result)
    ->  allocate_var(Result, V0, V1, ResultReg0),
        format(string(InitResultCode), "    put_variable ~w, ~w",
               [ResultReg0, ResultReg0])
    ;   allocate_var(Result, V0, V1, ResultReg0),
        InitResultCode = ""
    ),
    % Compile the Value register (what gets collected per solution)
    (   var(ValueVar)
    ->  % ValueVar is a Prolog variable — allocate a Y-register for it
        allocate_var(ValueVar, V1, V2, ValueReg),
        % Emit put_variable to actually create the Y-register in the env
        % frame. Use the SELF-INIT form (put_variable Y_n, Y_n) rather
        % than (put_variable Y_n, A1): the latter would share a fresh
        % unbound between Y_n and A1, and if the inner goal's first
        % arg is a constructed compound (e.g.
        % `findall(X, fact_in_range(p/2, ..., [X,_]), L)` where A1
        % holds `p/2`), put_structure_'s auto-bind in append_build_arg
        % would bind the shared unbound to the new struct -- silently
        % capturing the inner goal's first arg into the template var.
        % Self-init avoids the A1 share entirely; the inner goal's
        % compilation emits `put_value Y_n, A_k` when the template
        % var IS a direct call arg, so cases that don't have the
        % struct-first-arg conflict are unaffected.
        format(string(InitValueCode), "    put_variable ~w, ~w",
               [ValueReg, ValueReg]),
        ConstructionCode = ""
    ;   compound(ValueVar)
    ->  % Compound Template — `findall(p(X, Y), Goal, L)` and similar.
        % Allocate Y-regs for each variable arg, init via put_variable so
        % each iteration starts with fresh refs (the inner goal binds
        % them through head unification). After the inner returns, build
        % the Template structure on the heap via put_structure +
        % set_value/set_constant. ValueReg = A1 holds the heap ref so
        % end_aggregate captures it. aggregate_collect on the Elixir
        % runtime side deep-copies the heap structure into a self-
        % contained value before backtrack rewinds the heap.
        compile_compound_template(ValueVar, V1, V2, InitValueCode, ConstructionCode),
        ValueReg = 'A1'
    ;   % Constant value (e.g., count uses 1) — use A1 as placeholder
        ValueReg = 'A1', V2 = V1, InitValueCode = "", ConstructionCode = ""
    ),
    % Flatten the InnerGoal conjunction into a list of goals
    flatten_conjunction(InnerGoal, GoalList),
    % Compile each inner goal as a call (never TCO/execute) so control
    % returns to end_aggregate after each solution.
    % Note: permanent variable allocation for inner-goal variables that
    % survive across Calls is handled by the OUTER clause''s
    % pre_assign_permanent_vars (via expand_aggregate_goals_for_perm_vars
    % in compile_single_clause_wam). Do NOT add a second
    % pre_assign_permanent_vars call here — it would reassign variables
    % that already have Y-register slots from the outer pass.
    compile_inner_call_goals(GoalList, V2, Vf, InnerCode),
    % For compound Templates, the construction code runs AFTER the
    % inner-goal call but BEFORE end_aggregate captures.
    (   ConstructionCode == ""
    ->  FullInnerCode = InnerCode
    ;   format(string(FullInnerCode), "~w~n~w", [InnerCode, ConstructionCode])
    ),
    % For bagof/setof: compute free witnesses (vars in InnerGoal NOT
    % in Template and NOT under ^/2) and emit their registers as a
    % 4th `begin_aggregate` arg. Runtimes that recognise the 4-arg
    % form use the witness regs for ISO grouping. The 3-arg form
    % stays untouched for findall/count/sum/min/max/bag/set —
    % grouping doesn''t apply there.
    % Use Vf (post-inner-compile varmap) so witness vars allocated
    % during inner-goal compilation have register slots available
    % for lookup.
    aggregate_witness_clause(AggType, ValueVar, InnerGoal, Vf,
                             WitnessRegsClause),
    (   InitResultCode == ""
    ->  InitAggregateCode = InitValueCode
    ;   InitValueCode == ""
    ->  InitAggregateCode = InitResultCode
    ;   format(string(InitAggregateCode), "~w~n~w",
               [InitResultCode, InitValueCode])
    ),
    (   InitAggregateCode \= ""
    ->  format(string(Code),
            "~w~n    begin_aggregate ~w, ~w, ~w~w~n~w~n    end_aggregate ~w",
            [InitAggregateCode, AggType, ValueReg, ResultReg0,
             WitnessRegsClause, FullInnerCode, ValueReg])
    ;   format(string(Code),
            "    begin_aggregate ~w, ~w, ~w~w~n~w~n    end_aggregate ~w",
            [AggType, ValueReg, ResultReg0, WitnessRegsClause,
             FullInnerCode, ValueReg])
    ).

%% aggregate_witness_clause(+AggType, +ValueVar, +InnerGoal, +V, -Clause)
%  Build the trailing ", 'W1;W2;...'" string for begin_aggregate
%  when AggType is bagof or setof. Returns "" for other kinds (so
%  the existing 3-arg shape stays).
aggregate_witness_clause(AggType, ValueVar, InnerGoal, V, Clause) :-
    (   ( AggType == bagof ; AggType == setof )
    ->  find_free_witnesses(ValueVar, InnerGoal, Witnesses),
        witness_var_regs(Witnesses, V, WitnessRegs),
        atomic_list_concat(WitnessRegs, ';', WitnessStr),
        format(string(Clause), ", '~w'", [WitnessStr])
    ;   Clause = ""
    ).

%% find_free_witnesses(+Template, +InnerGoal, -Witnesses)
%  Vars in InnerGoal not in Template and not under ^/2.
find_free_witnesses(Template, InnerGoal, Witnesses) :-
    term_variables(Template, TemplateVars),
    free_witness_walk(InnerGoal, TemplateVars, [], WitnessesRev),
    list_to_set_var(WitnessesRev, Witnesses).

free_witness_walk(Var, Exclude, Acc, Out) :-
    var(Var), !,
    (   memberchk_var(Var, Exclude)
    ->  Out = Acc
    ;   Out = [Var|Acc]
    ).
free_witness_walk(Atomic, _, Acc, Acc) :- atomic(Atomic), !.
free_witness_walk(LHS^RHS, Exclude, Acc, Out) :- !,
    term_variables(LHS, LHSVars),
    append(LHSVars, Exclude, Exclude2),
    free_witness_walk(RHS, Exclude2, Acc, Out).
% Nested aggregate-style binders introduce their own scope: vars in
% the inner Template (and the inner Result) are local to the inner
% aggregate and don''t escape as witnesses of the outer. Walk only
% the inner Goal with those vars added to the exclude set.
free_witness_walk(bagof(T, G, R), Exclude, Acc, Out) :- !,
    nested_aggregate_walk(T, G, R, Exclude, Acc, Out).
free_witness_walk(setof(T, G, R), Exclude, Acc, Out) :- !,
    nested_aggregate_walk(T, G, R, Exclude, Acc, Out).
free_witness_walk(findall(T, G, R), Exclude, Acc, Out) :- !,
    nested_aggregate_walk(T, G, R, Exclude, Acc, Out).
free_witness_walk(aggregate_all(T, G, R), Exclude, Acc, Out) :- !,
    nested_aggregate_walk(T, G, R, Exclude, Acc, Out).
free_witness_walk(Compound, Exclude, Acc, Out) :-
    Compound =.. [_|Args],
    free_witness_walk_list(Args, Exclude, Acc, Out).

nested_aggregate_walk(T, G, R, Exclude, Acc, Out) :-
    term_variables(T, TVars),
    term_variables(R, RVars),
    append(TVars, RVars, Local0),
    append(Local0, Exclude, Exclude2),
    free_witness_walk(G, Exclude2, Acc, Out).

free_witness_walk_list([], _, Acc, Acc).
free_witness_walk_list([G|Gs], Exclude, Acc, Out) :-
    free_witness_walk(G, Exclude, Acc, Acc2),
    free_witness_walk_list(Gs, Exclude, Acc2, Out).

memberchk_var(V, [X|_]) :- V == X, !.
memberchk_var(V, [_|Rest]) :- memberchk_var(V, Rest).

list_to_set_var([], []).
list_to_set_var([V|Rest], [V|Out]) :-
    \+ memberchk_var(V, Rest), !,
    list_to_set_var(Rest, Out).
list_to_set_var([_|Rest], Out) :-
    list_to_set_var(Rest, Out).

%% witness_var_regs(+Vars, +Varmap, -Regs)
%  Look up each witness var''s register name in Varmap. If a var
%  doesn''t have a register yet (rare — would mean it''s an
%  unallocated singleton), it''s skipped silently.
witness_var_regs([], _, []).
witness_var_regs([V|Vs], Varmap, [Reg|Rest]) :-
    catch(get_var_reg(V, Varmap, Reg), _, fail), !,
    witness_var_regs(Vs, Varmap, Rest).
witness_var_regs([_|Vs], Varmap, Rest) :-
    witness_var_regs(Vs, Varmap, Rest).

%% compile_compound_template(+Template, +V0, -Vf, -InitCode, -ConstructionCode)
%  For findall(Functor(Arg1, Arg2, ...), Goal, L) with compound Template:
%  - Each Arg is a variable, an atomic, or a NESTED compound. Variable
%    leaves get Y-regs allocated (via allocate_var) and initialized
%    directly so they have stable slots across the inner-goal call.
%    Do not initialize through A-registers: those are scratch argument
%    registers for the inner goal, and aliasing a template variable
%    through A2 can bind it when the inner goal builds its own A2 term
%    (for example findall(Y-L, bagof(X, p(X,Y), L), Groups)).
%  - ConstructionCode emits put_structure + set_value/set_constant
%    after the inner goal returns; A1 holds the heap ref to the
%    constructed Template.
%  - Nested compound args (e.g. findall(K-V-B, ...) where the template
%    is -/2(-/2(K,V), B)) use the WAM set_variable trick: the outer
%    put_structure starts in A1, set_variable X_subN allocates a
%    fresh cell into the parent''s arg slot, then put_structure on
%    X_subN mutates the same cell to the sub-compound — visible
%    through the parent because cells are shared by pointer.
compile_compound_template(Template, V0, Vf, InitCode, ConstructionCode) :-
    init_template_leaf_vars(Template, V0, V1, InitLines),
    (   InitLines == []
    ->  InitCode = ""
    ;   atomic_list_concat(InitLines, '\n', InitCode)
    ),
    % Construct the structure top-down, root first into A1; sub-
    % compounds get fresh X-regs (named "_XT<N>") that the outer
    % parent''s set_variable allocates and the inner put_structure
    % mutates in place.
    construct_template(Template, 'A1', 0, _, V1, Vf, Lines),
    atomic_list_concat(Lines, '\n', ConstructionCode).

%% init_template_leaf_vars(+Template, +V0, -Vf, -Lines)
%  Walks Template recursively and allocates a Y-register per variable
%  leaf, emitting put_variable lines so each Y-reg starts as a fresh
%  unbound cell on every aggregate iteration.
init_template_leaf_vars(T, V0, Vf, Lines) :-
    (   var(T)
    ->  allocate_var(T, V0, Vf, Reg),
        format(string(Line), "    put_variable ~w, ~w", [Reg, Reg]),
        Lines = [Line]
    ;   atomic(T)
    ->  Vf = V0,
        Lines = []
    ;   T =.. [_|Args],
        init_template_leaf_vars_list(Args, V0, Vf, Lines)
    ).
init_template_leaf_vars_list([], V, V, []).
init_template_leaf_vars_list([H|T], V0, Vf, Lines) :-
    init_template_leaf_vars(H, V0, V1, HLines),
    init_template_leaf_vars_list(T, V1, Vf, TLines),
    append(HLines, TLines, Lines).

%% construct_template(+Template, +TargetReg, +T0, -Tf, +V0, -Vf, -Lines)
%  Emits WAM instructions that build Template into TargetReg. T0/Tf
%  is a counter for naming fresh "_XT<N>" sub-compound registers so
%  nested compounds each get their own scratch slot. Lines is a flat
%  list in correct emission order.
construct_template(T, TargetReg, T0, Tf, V0, Vf, Lines) :-
    T =.. [Functor|Args],
    length(Args, Arity),
    format(string(HeadLine), "    put_structure ~w/~w, ~w",
           [Functor, Arity, TargetReg]),
    % Pass over the args: for each, emit a fill line (set_value /
    % set_constant / set_variable + record a pending sub-compound)
    % and collect any pending sub-compound construction tasks.
    construct_template_args(Args, T0, T1, V0, V1, FillLines, Pending),
    % Sub-compounds are constructed AFTER the outer put_structure +
    % its fill lines, in left-to-right order.
    construct_pending(Pending, T1, Tf, V1, Vf, PendingLines),
    append([HeadLine | FillLines], PendingLines, Lines).

% Wrapper: emit fill lines for the outer compound''s args, and
% collect (SubReg, SubTemplate) tasks for sub-compounds.
construct_template_args([], T, T, V, V, [], []).
construct_template_args([A|Rest], T0, Tf, V0, Vf,
                       [FillLine|FillTail], Pending) :-
    (   var(A)
    ->  get_var_reg(A, V0, Reg),
        format(string(FillLine), "    set_value ~w", [Reg]),
        T1 = T0, V1 = V0, ThisPending = []
    ;   atomic(A)
    ->  quote_wam_constant(A, AStr),
        format(string(FillLine), "    set_constant ~w", [AStr]),
        T1 = T0, V1 = V0, ThisPending = []
    ;   % Compound — allocate a fresh sub-reg, emit set_variable
        % which attaches a fresh cell to the parent''s arg slot AND
        % binds the X-reg to it. The pending entry holds the X-reg
        % and the sub-template for later put_structure-based
        % mutation of that same cell.
        format(atom(SubReg), "_XT~w", [T0]),
        T1 is T0 + 1,
        format(string(FillLine), "    set_variable ~w", [SubReg]),
        V1 = V0,
        ThisPending = [SubReg-A]
    ),
    construct_template_args(Rest, T1, Tf, V1, Vf, FillTail, RestPending),
    append(ThisPending, RestPending, Pending).

% Construct each pending sub-compound into its allocated reg.
construct_pending([], T, T, V, V, []).
construct_pending([Reg-Sub|Rest], T0, Tf, V0, Vf, Lines) :-
    construct_template(Sub, Reg, T0, T1, V0, V1, SubLines),
    construct_pending(Rest, T1, Tf, V1, Vf, RestLines),
    append(SubLines, RestLines, Lines).

flatten_once([], []).
flatten_once([L|Ls], Out) :- append(L, Rest, Out), flatten_once(Ls, Rest).

%% compile_findall(+Template, +InnerGoal, +Result, +V0, -Vf, -Code)
compile_findall(Template, InnerGoal, Result, V0, Vf, Code) :-
    compile_aggregate_all(collect-Template, InnerGoal, Result, V0, Vf, Code).

%% compile_bagof(+Template, +InnerGoal, +Result, +V0, -Vf, -Code)
%  Compile the no-witness-group subset of bagof/3. The runtime fails
%  empty bags, unlike findall/3.
compile_bagof(Template, InnerGoal, Result, V0, Vf, Code) :-
    compile_aggregate_all(bagof-Template, InnerGoal, Result, V0, Vf, Code).

%% compile_setof(+Template, +InnerGoal, +Result, +V0, -Vf, -Code)
%  Compile the no-witness-group subset of setof/3. The runtime fails
%  empty sets, then sorts/deduplicates collected values.
compile_setof(Template, InnerGoal, Result, V0, Vf, Code) :-
    compile_aggregate_all(setof-Template, InnerGoal, Result, V0, Vf, Code).

%% next_ite_label(-ElseLabel, -ContLabel)
%  Generate unique labels for if-then-else compilation.
next_ite_label(ElseLabel, ContLabel) :-
    (   nb_current(wam_ite_counter, N) -> true ; N = 0 ),
    N1 is N + 1,
    nb_setval(wam_ite_counter, N1),
    format(atom(ElseLabel), "L_ite_else_~w", [N1]),
    format(atom(ContLabel), "L_ite_cont_~w", [N1]).

%% flatten_conjunction(+Conj, -GoalList)
%  Flatten (A, B, C) into [A, B, C].
flatten_conjunction((A, B), Goals) :- !,
    flatten_conjunction(A, AG),
    flatten_conjunction(B, BG),
    append(AG, BG, Goals).
flatten_conjunction(Goal, [Goal]).

%% compile_if_then_else(+Cond, +Then, +Else, +V0, -Vf, +HasEnv, -Code)
%  Compile (Cond -> Then ; Else) to WAM try/cut/trust + jump pattern.
%  The condition runs in a temporary choice point; if it succeeds, cut
%  commits to Then. If it fails, backtrack to Else.
%
%  When Else is itself another if-then-else (`(C2 -> T2 ; E2)`) or a
%  bare `(C2 -> T2)` (implicit `; fail`), we recurse so a chain like
%  `(A -> B ; C -> D ; E)` compiles to nested cut_ite/try_me_else
%  pairs. Without this, the second `->` in Else position would emit
%  as a regular `Call("->", 2)` -- which has no runtime
%  implementation and just fails.
compile_if_then_else(CondGoal, ThenGoal, ElseGoal, V0, Vf, _HasEnv, Code) :-
    next_ite_label(ElseLabel, ContLabel),
    ( wam_ite_use_y_level_enabled
    -> % M17: allocate a fresh permanent Y for the cut barrier.
       % get_level Y_n snapshots cp_count BEFORE try_me_else; cut Y_n
       % at the commit site sets cp_count = Y_n. Together they cut
       % the ITE choice point AND any inner CPs the condition''s
       % multi-clause calls left behind -- the naive cut_ite (which
       % decrements cp_count by 1) silently picked the wrong CP in
       % that case.
       %
       % allocate_var falls back to X if no y_alloc reservation
       % exists for the var; X regs are caller-saved and the inner
       % call would clobber the snapshot before cut reads it. Reserve
       % a fresh Y at the top so allocate_var picks it up.
       V0 = vmap(Bindings0, XCount0),
       max_yi_index(Bindings0, 0, MaxY),
       NextY is MaxY + 1,
       format(atom(BarrierReg), "Y~w", [NextY]),
       gensym('$ite_barrier_', BarrierVar),
       % A cut in the CONDITION is local to it (ISO: the condition of
       % ->/2 is opaque to cut, like call/1). If the condition has a
       % top-level cut, reserve a SECOND Y and snapshot the condition''s
       % entry level into it with a get_level emitted AFTER try_me_else
       % (so it captures the level WITH the ITE choice point but BEFORE
       % any CP the condition pushes). A `!` in the condition then emits
       % `cut CondBarrierReg`, pruning only the condition''s own CPs and
       % leaving the ITE choice point intact -- so e.g. \+ (G, !, fail)
       % (which desugars to ((G,!,fail) -> fail ; true)) correctly
       % succeeds when the cut-guarded condition fails.
       flatten_conjunction(CondGoal, CondGoals),
       (   memberchk('!', CondGoals)
       ->  CondY is MaxY + 2,
           format(atom(CondBarrierReg), "Y~w", [CondY]),
           gensym('$ite_cond_barrier_', CondBarrierVar),
           V0a = vmap([b(BarrierVar, BarrierReg),
                       b(CondBarrierVar, CondBarrierReg)|Bindings0], XCount0),
           format(string(CondGetLevel), "    get_level ~w~n", [CondBarrierReg])
       ;   CondBarrierReg = none,
           V0a = vmap([b(BarrierVar, BarrierReg)|Bindings0], XCount0),
           CondGetLevel = ""
       )
    ;  V0a = V0,
       BarrierReg = none,
       CondBarrierReg = none,
       CondGetLevel = "",
       flatten_conjunction(CondGoal, CondGoals)
    ),
    % Compile the condition with cuts scoped to CondBarrierReg (when one
    % was reserved); Then/Else revert to the enclosing scope so their
    % cuts stay transparent to the clause / outer condition.
    (   CondBarrierReg == none
    ->  compile_inner_call_goals(CondGoals, V0a, V1, CondCode)
    ;   current_cut_target(OldTarget),
        set_cut_target(CondBarrierReg),
        compile_inner_call_goals(CondGoals, V0a, V1, CondCode),
        set_cut_target(OldTarget)
    ),
    % Then and Else can each be themselves a nested if-then-else --
    % compile_ite_branch recurses on those forms. Else starts from
    % V0a since backtrack restores to before the condition (but the
    % barrier var is already allocated so its slot is reserved).
    compile_ite_branch(ThenGoal, V1, V2, ThenCode),
    compile_ite_branch(ElseGoal, V0a, V3, ElseCode),
    (   V2 = V3 -> Vf = V2
    ;   Vf = V2
    ),
    ( BarrierReg == none
    -> format(string(Code),
          "    try_me_else ~w~n~w~n    cut_ite~n~w~n    jump ~w~n~w:~n    trust_me~n~w~n~w:",
          [ElseLabel, CondCode, ThenCode, ContLabel,
           ElseLabel, ElseCode, ContLabel])
    ;  format(string(Code),
          "    get_level ~w~n    try_me_else ~w~n~w~w~n    cut ~w~n~w~n    jump ~w~n~w:~n    trust_me~n~w~n~w:",
          [BarrierReg, ElseLabel, CondGetLevel, CondCode, BarrierReg, ThenCode,
           ContLabel, ElseLabel, ElseCode, ContLabel])
    ).

%% compile_ite_branch(+Branch, +V0, -Vf, -Code) is det.
%  Compile a Then- or Else-branch of an if-then-else. If the branch
%  is itself another if-then-else (`(C -> T ; E)` or bare `(C -> T)`,
%  the latter treated as `(C -> T ; fail)` to match SWI), recurse;
%  otherwise compile as a flat goal sequence.
compile_ite_branch((Cond2 -> Then2 ; Else2), V0, Vf, Code) :-
    !,
    compile_if_then_else(Cond2, Then2, Else2, V0, Vf, no, Code).
compile_ite_branch((Cond2 -> Then2), V0, Vf, Code) :-
    !,
    compile_if_then_else(Cond2, Then2, fail, V0, Vf, no, Code).
compile_ite_branch(Branch, V0, Vf, Code) :-
    flatten_conjunction(Branch, BranchGoals),
    compile_inner_call_goals(BranchGoals, V0, Vf, Code).

%% compile_disjunction(+Left, +Right, +V0, -Vf, +HasEnv, -Code)
%  Compile (A ; B) to WAM try/trust + jump pattern (no cut).
compile_disjunction(LeftGoal, RightGoal, V0, Vf, _HasEnv, Code) :-
    next_ite_label(RightLabel, ContLabel),
    flatten_conjunction(LeftGoal, LeftGoals),
    flatten_conjunction(RightGoal, RightGoals),
    compile_inner_call_goals(LeftGoals, V0, V1, LeftCode),
    compile_inner_call_goals(RightGoals, V0, V2, RightCode),
    (   V1 = V2 -> Vf = V1 ; Vf = V1 ),
    format(string(Code),
        "    try_me_else ~w~n~w~n    jump ~w~n~w:~n    trust_me~n~w~n~w:",
        [RightLabel, LeftCode, ContLabel, RightLabel, RightCode, ContLabel]).

%% compile_inner_call_goals(+Goals, +V0, -Vf, -Code)
%  Compile all goals as calls (never execute/TCO) for use inside aggregate
%  bodies, if-then-else cond clauses, ite-branch bodies, and disjunction
%  arms. Dispatches on `(C -> T ; E)` / `(A ; B)` the same way the outer
%  `compile_goals` does, so nested if-then-else / disjunction inside a
%  conjunction body compiles to inline try/cut/trust + jump rather than
%  falling through to a generic `Call(";", 2)` (which has no runtime
%  handler and silently fails).
compile_inner_call_goals([], V, V, "").
compile_inner_call_goals([Goal|Rest], V0, Vf, Code) :-
    (   Goal = (CondGoal -> ThenGoal ; ElseGoal)
    ->  compile_if_then_else(CondGoal, ThenGoal, ElseGoal, V0, V1, no, GoalCode),
        compile_inner_call_goals(Rest, V1, Vf, RestCode),
        join_goal_codes(GoalCode, RestCode, Code)
    ;   nonvar(Goal),
        Goal = _ExistentialVars^ExistentialGoal
    ->  flatten_conjunction(ExistentialGoal, ExistentialGoals),
        append(ExistentialGoals, Rest, ExpandedGoals),
        compile_inner_call_goals(ExpandedGoals, V0, Vf, Code)
    ;   Goal = (CondGoal -> ThenGoal)
    ->  compile_if_then_else(CondGoal, ThenGoal, fail, V0, V1, no, GoalCode),
        compile_inner_call_goals(Rest, V1, Vf, RestCode),
        join_goal_codes(GoalCode, RestCode, Code)
    ;   Goal = (LeftGoal ; RightGoal),
        \+ (LeftGoal = (_ -> _))
    ->  compile_disjunction(LeftGoal, RightGoal, V0, V1, no, GoalCode),
        compile_inner_call_goals(Rest, V1, Vf, RestCode),
        join_goal_codes(GoalCode, RestCode, Code)
    ;   Goal = findall(Template, InnerGoal, Result)
    ->  compile_findall(Template, InnerGoal, Result, V0, V1, GoalCode),
        compile_inner_call_goals(Rest, V1, Vf, RestCode),
        join_goal_codes(GoalCode, RestCode, Code)
    % M93b: \+ G inlining for inner goal positions (if-then-else
    % conditions, disjunction arms, etc). Without this, an inner
    % `\+ G' falls through to compile_goal_call which emits
    % `builtin_call \+/1, 1' -- but the LLVM target has no \+/1
    % dispatch case, so the runtime metacall path is taken. That
    % path was previously colliding with op id 99 (getenv) via the
    % catch-all in builtin_op_to_id; even after fixing the
    % collision, no inner backend actually implements \+ as a
    % builtin, so \+ G in an inner position would always fail.
    % Inline-rewrite to the soft-cut form `(G -> fail ; true)' to
    % match the existing top-level handling (compile_goals at the
    % outer call site) and to avoid the nested-cut barrier issue
    % the hard-cut form has when stacked.
    ;   nonvar(Goal),
        Goal = \+(NotGoal),
        wam_inline_not_enabled
    ->  compile_inner_call_goals([((NotGoal -> fail ; true)) | Rest],
                                  V0, Vf, Code)
    % once(G) / forall(G, T) — same desugarings as compile_goals.
    % Recurse with the rewritten goal so the if-then-else / negation
    % machinery picks it up.
    ;   Goal = once(OnceGoal)
    ->  compile_inner_call_goals([(OnceGoal -> true) | Rest], V0, Vf, Code)
    % M71: forall rewrites to soft-cut form (matches the compile_goals
    % clause). The old \+ (G, \+ T) form fails for nested negation
    % because both ! cuts hit the clause''s single cut_barrier.
    ;   Goal = forall(GenGoal, TestGoal)
    ->  compile_inner_call_goals(
            [((GenGoal, (TestGoal -> fail ; true)) -> fail ; true)
             | Rest],
            V0, Vf, Code)
    ;   compile_goal_call(Goal, V0, V1, GoalCode),
        compile_inner_call_goals(Rest, V1, Vf, RestCode),
        join_goal_codes(GoalCode, RestCode, Code)
    ).

join_goal_codes(GoalCode, "", GoalCode) :- !.
join_goal_codes(GoalCode, RestCode, Code) :-
    format(string(Code), "~w~n~w", [GoalCode, RestCode]).

%% allocate_var(+Var, +VarMapIn, -VarMapOut, -Register)
%  Allocate a Y-register for a variable if not already allocated.
allocate_var(Var, VIn, VOut, Reg) :-
    (   get_var_reg(Var, VIn, ExistingReg)
    ->  Reg = ExistingReg, VOut = VIn
    ;   get_yi_alloc(Var, VIn, Reg, VOut)
    ->  true
    ;   next_x_reg(VIn, XReg, V_temp),
        bind_var(Var, XReg, V_temp, VOut),
        Reg = XReg
    ).

% Static module qualifier unwrap. UnifyWeaver's targets resolve
% predicates by name only — there is no per-module dispatch table —
% so `M:p(X)` with a static atom (or string) module name is
% semantically identical to `p(X)`. Recursively compiling the inner
% goal emits a regular `call p/Arity, N` instead of routing through
% the `:/2` builtin path. Cross-target win: every target avoids the
% meta-call overhead (heap walk for the goal structure, register
% shuffling, dispatch table lookup) on the common static-qualifier
% case. The dynamic case (`Module = m, Module:p(X)`) where M is a
% Prolog variable at compile time still falls through to `:/2` —
% that genuinely needs a module registry which no target has yet.
% String + atom guard per #1647 follow-up review (Perplexity)
% covers any code path that represents module names as strings.
% Plain cut. Emit a scope-correct cut: inside an if-then-else condition
% the cut is local to the condition (cut Yn to the condition barrier);
% elsewhere it is transparent to the clause (builtin_call !/0, runtime
% cuts to clause B0). See current_cut_target/1.
compile_goal_call('!', V, V, Code) :-
    !,
    (   current_cut_target(Target),
        Target \== clause
    ->  format(string(Code), "    cut ~w", [Target])
    ;   Code = "    builtin_call !/0, 0"
    ).
compile_goal_call(M:InnerGoal, V0, Vf, Code) :-
    (atom(M) ; string(M)),
    !,
    compile_goal_call(InnerGoal, V0, Vf, Code).
%% Visited-set arg rewrite (Layer 2.5 of the IntSet design). When a
%% goal calls a predicate with `:- visited_set(Pred/Arity, ArgN)` and
%% the arg at position N is a recognised list shape (`[Cat]` bootstrap
%% or `[X|V_visited]` recursive extension), rewrite the arg to a
%% fresh var bound to the constructed-VSet register and INLINE the
%% put_arguments + call. We do NOT recurse on the rewritten goal —
%% that's what caused the previous Layer 2 attempt to hang via the
%% TCO-dispatch / rewrite interaction.
compile_goal_call(Goal, V0, Vf, Code) :-
    nonvar(Goal),
    Goal =.. [Pred|Args],
    Args \== [],
    length(Args, Arity),
    rewrite_visited_set_args(Pred/Arity, Args, NewArgs, ConstructCode, V0, V1),
    !,
    compile_put_arguments(NewArgs, 1, V1, Vf, PutCode),
    (   is_builtin_pred(Pred, Arity)
    ->  format(string(CallCode), "    builtin_call ~w/~w, ~w", [Pred, Arity, Arity])
    ;   format(string(CallCode), "    call ~w/~w, ~w", [Pred, Arity, Arity])
    ),
    join_nonempty([ConstructCode, PutCode, CallCode], Code).
%% =../2 compose-mode lowering: T =.. [Name | FixedArgs] where T is
%% provably unbound and Name is provably bound. Emits PutStructureDyn
%% rather than the generic =../2 builtin call. Falls through to the
%% builtin path if the binding-state preconditions cannot be proved.
compile_goal_call(T =.. L, V0, Vf, Code) :-
    parse_univ_list_pattern(L, NameVar, FixedArgs),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound),
    !,
    emit_put_structure_dyn_lowering(T, NameVar, FixedArgs, V0, Vf, Code).
%% functor/3 compose-mode lowering: functor(T, Name, Arity) where T is
%% provably unbound, Name is provably bound, and Arity is a literal
%% non-negative integer. Lowers to the same PutStructureDyn shape as
%% the =../2 case by synthesising Arity fresh unbound argument slots.
compile_goal_call(functor(T, NameVar, Arity), V0, Vf, Code) :-
    integer(Arity), Arity >= 0,
    var(T), var(NameVar),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound),
    !,
    length(FreshArgs, Arity),
    emit_put_structure_dyn_lowering(T, NameVar, FreshArgs, V0, Vf, Code).
%% arg/3 lowering: arg(N, T, A) where N is a literal positive integer
%% and T is provably bound. Emits a single specialised `arg` WAM
%% instruction that the runtime translates to the Arg ADT constructor,
%% skipping the put_constant + put_value + builtin_call dispatch chain.
%% A may be bound or unbound; the runtime handles both via unification.
compile_goal_call(arg(N, T, A), V0, Vf, Code) :-
    integer(N), N >= 1,
    var(T), var(A),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, bound),
    !,
    emit_arg_lowering(N, T, A, V0, Vf, Code).
%% \+ member(X, V) lowering for visited-set variables (Phase H).
%% Fires when V is a head-arg variable at a position declared via
%% `:- visited_set(Pred/Arity, ArgN)` for this clause's predicate.
%% Emits `not_member_set` (O(log N)) instead of `not_member_list`
%% (O(N)). Must come BEFORE the NotMemberList clause so the more
%% specific case wins.
compile_goal_call(\+ member(X, V), V0, Vf, Code) :-
    var(X), var(V),
    is_visited_set_var(V),
    !,
    emit_not_member_set_lowering(X, V, V0, Vf, Code).
%% \+ member(X, [a,b,c,...]) lowering for compile-time-ground atom
%% lists. Bakes the atoms into a single NotMemberConstAtoms WAM
%% instruction — zero heap allocation, zero list-walk dispatch. Fires
%% whenever the second arg is a proper list of ground atoms in the
%% source, regardless of X's binding state (the runtime checks at
%% dispatch). Must come BEFORE the var(L) clause so the more specific
%% case wins.
compile_goal_call(\+ member(X, L), V0, Vf, Code) :-
    var(X),
    is_ground_atom_list(L, Atoms),
    \+ lowering_disabled(ground_member),
    !,
    emit_not_member_const_atoms_lowering(X, Atoms, V0, Vf, Code).
%% \+ member(X, L) lowering: emits a specialised NotMemberList WAM
%% instruction that walks L inline and skips both the put_structure
%% goal-term construction AND the builtin_call dispatch (4 dispatches +
%% one heap allocation per call). Fires when X and L are Prolog
%% variables that the binding-state analyser proves are both `bound`
%% at the goal site — typical of visited-set checks in graph
%% traversal: `parent(X, Z), \+ member(Z, V), recurse(Z, [Z|V])`.
compile_goal_call(\+ member(X, L), V0, Vf, Code) :-
    var(X), var(L),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, X, bound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, L, bound),
    !,
    emit_not_member_list_lowering(X, L, V0, Vf, Code).
compile_goal_call(Goal, V0, Vf, Code) :-
    Goal =.. [Pred|Args],
    length(Args, Arity),
    compile_put_arguments(Args, 1, V0, Vf, PutCode),
    (   is_builtin_pred(Pred, Arity)
    ->  format(string(CallCode), "    builtin_call ~w/~w, ~w", [Pred, Arity, Arity])
    ;   format(string(CallCode), "    call ~w/~w, ~w", [Pred, Arity, Arity])
    ),
    (   PutCode == ""
    ->  Code = CallCode
    ;   format(string(Code), "~w~n~w", [PutCode, CallCode])
    ).

compile_goal_execute(M:InnerGoal, V0, Vf, Code) :-
    (atom(M) ; string(M)),
    !,
    compile_goal_execute(InnerGoal, V0, Vf, Code).
%% Visited-set arg rewrite, tail-call form. Mirrors compile_goal_call
%% but ends in `execute Pred/Arity` instead of `call`. Same single-pass
%% emission — no recursion on the rewritten goal.
compile_goal_execute(Goal, V0, Vf, Code) :-
    nonvar(Goal),
    Goal =.. [Pred|Args],
    Args \== [],
    length(Args, Arity),
    rewrite_visited_set_args(Pred/Arity, Args, NewArgs, ConstructCode, V0, V1),
    !,
    compile_put_arguments(NewArgs, 1, V1, Vf, PutCode),
    (   is_builtin_pred(Pred, Arity)
    ->  format(string(BuiltinCode), "    builtin_call ~w/~w, ~w", [Pred, Arity, Arity]),
        format(string(ExecCode), "~w~n    proceed", [BuiltinCode])
    ;   format(string(ExecCode), "    execute ~w/~w", [Pred, Arity])
    ),
    join_nonempty([ConstructCode, PutCode, ExecCode], Code).
%% =../2 compose-mode lowering, tail-call form. Produces the same
%% PutStructureDyn lowering followed by `proceed`.
compile_goal_execute(T =.. L, V0, Vf, Code) :-
    parse_univ_list_pattern(L, NameVar, FixedArgs),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound),
    !,
    emit_put_structure_dyn_lowering(T, NameVar, FixedArgs, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
%% functor/3 compose-mode lowering, tail-call form. Same shape as the
%% call form: synthesise Arity fresh unbound slots and reuse the =../2
%% emit helper.
compile_goal_execute(functor(T, NameVar, Arity), V0, Vf, Code) :-
    integer(Arity), Arity >= 0,
    var(T), var(NameVar),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound),
    !,
    length(FreshArgs, Arity),
    emit_put_structure_dyn_lowering(T, NameVar, FreshArgs, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
%% arg/3 lowering, tail-call form.
compile_goal_execute(arg(N, T, A), V0, Vf, Code) :-
    integer(N), N >= 1,
    var(T), var(A),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, T, bound),
    !,
    emit_arg_lowering(N, T, A, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
%% \+ member(X, V) for visited-set V, tail-call form.
compile_goal_execute(\+ member(X, V), V0, Vf, Code) :-
    var(X), var(V),
    is_visited_set_var(V),
    !,
    emit_not_member_set_lowering(X, V, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
%% \+ member(X, [a,b,c,...]) ground-list lowering, tail-call form.
compile_goal_execute(\+ member(X, L), V0, Vf, Code) :-
    var(X),
    is_ground_atom_list(L, Atoms),
    \+ lowering_disabled(ground_member),
    !,
    emit_not_member_const_atoms_lowering(X, Atoms, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
%% \+ member(X, L) lowering, tail-call form.
compile_goal_execute(\+ member(X, L), V0, Vf, Code) :-
    var(X), var(L),
    current_clause_binding_env(BeforeEnv),
    binding_state_analysis:binding_state_at_var(BeforeEnv, X, bound),
    binding_state_analysis:binding_state_at_var(BeforeEnv, L, bound),
    !,
    emit_not_member_list_lowering(X, L, V0, Vf, BodyCode),
    format(string(Code), "~w~n    proceed", [BodyCode]).
compile_goal_execute(Goal, V0, Vf, Code) :-
    Goal =.. [Pred|Args],
    length(Args, Arity),
    compile_put_arguments(Args, 1, V0, Vf, PutCode),
    (   is_builtin_pred(Pred, Arity)
    ->  format(string(BuiltinCode), "    builtin_call ~w/~w, ~w", [Pred, Arity, Arity]),
        format(string(ExecCode), "~w~n    proceed", [BuiltinCode])
    ;   format(string(ExecCode), "    execute ~w/~w", [Pred, Arity])
    ),
    (   PutCode == ""
    ->  Code = ExecCode
    ;   format(string(Code), "~w~n~w", [PutCode, ExecCode])
    ).

%% is_builtin_pred(+Pred, +Arity)
%  Recognized built-in predicates that the WAM runtime handles directly.
%  Delegates to clause_body_analysis for guard/comparison detection,
%  with explicit entries for arithmetic and control builtins.
is_builtin_pred(Pred, Arity) :-
    % Build a goal term to test with is_guard_goal/2
    length(MockArgs, Arity),
    Goal =.. [Pred|MockArgs],
    is_guard_goal(Goal, []),  % empty varmap — we just need structural match
    !.
is_builtin_pred(is, 2).      % arithmetic evaluation (output goal, not a guard)
is_builtin_pred(true, 0).    % control
is_builtin_pred(fail, 0).
is_builtin_pred('!', 0).     % cut
is_builtin_pred(\+, 1).      % negation-as-failure
is_builtin_pred(member, 2).  % list operations
is_builtin_pred(append, 3).
is_builtin_pred(reverse, 2).  % list reverse -- F#, Python, R, Clojure, Go,
                              % Rust, C++ all dispatch this as a builtin
                              % call.  Haskell / Lua targets that
                              % previously relied on `execute reverse/2`
                              % finding a labeled clause may need a
                              % builtin_call handler.
is_builtin_pred(length, 2).
is_builtin_pred(functor, 3). % term inspection: name/arity read or construct
is_builtin_pred(arg, 3).     % term inspection: Nth argument access
is_builtin_pred((=..), 2).   % term inspection: univ (decompose/compose)
is_builtin_pred(copy_term, 2). % term inspection: fresh-variable copy
is_builtin_pred(term_variables, 2). % collect unbound vars in left-to-right order
is_builtin_pred(numbervars, 3).     % bind free vars to $VAR(N) in sequence
is_builtin_pred((=@=), 2).          % variant equivalence (modulo var renaming)
is_builtin_pred((\=@=), 2).         % not variant
is_builtin_pred(unifiable, 3).      % non-binding unification + bindings list
is_builtin_pred(plus, 3).           % bidirectional integer addition
is_builtin_pred(delete, 3).         % remove all matching elements
is_builtin_pred(subtract, 3).       % set difference: List1 minus List2
is_builtin_pred(intersection, 3).   % set intersection: elements in both
is_builtin_pred(union, 3).          % set union: A1 ++ (A2 minus A1)
is_builtin_pred(list_to_set, 2).    % dedupe list (first-occurrence order).
is_builtin_pred(must_be, 2).        % type check with type_error throw
is_builtin_pred(string_chars, 2).   % alias for atom_chars/2 (atoms = strings).
is_builtin_pred(string_codes, 2).   % alias for atom_codes/2.
is_builtin_pred(string_code, 3).    % string_code(+Index, +String, -Code), 1-based.
is_builtin_pred(random, 1).             % random(-X), X in [0, 1) Float.
is_builtin_pred(random_between, 3).     % random_between(+L, +H, -X), Integer.
is_builtin_pred(random_member, 2).      % random_member(-X, +List).
is_builtin_pred(random_permutation, 2). % random_permutation(+List, -Perm).
is_builtin_pred(set_random, 1).         % set_random(seed(N|random)).
is_builtin_pred(sort, 4).               % sort(+Key, +Order, +List, -Sorted).
is_builtin_pred(get_time, 1).           % get_time(-Stamp), Float since epoch.
is_builtin_pred(stamp_date_time, 3).    % stamp_date_time(+Stamp, -DT, +TZ).
is_builtin_pred(date_time_stamp, 2).    % date_time_stamp(+DT, -Stamp).
is_builtin_pred(format_time, 3).        % format_time(-Atom, +Fmt, +Stamp).
is_builtin_pred(open, 3).               % open(+File, +Mode, -Stream).
is_builtin_pred(close, 1).              % close(+Stream).
is_builtin_pred(read_line_to_string, 2). % read_line_to_string(+Stream, -Line).
is_builtin_pred(read_string, 5).        % read_string(+S, +L, ?L, _, -String).
is_builtin_pred(at_end_of_stream, 1).   % at_end_of_stream(+Stream).
is_builtin_pred(write_to_stream, 2).    % write_to_stream(+S, +Term).
is_builtin_pred(nl_to_stream, 1).       % nl_to_stream(+S).
% current_predicate/1 is intentionally NOT registered: the runtime
% intercepts it in the Call/Execute opcode arms so it can push a
% choice-point iterator for nondet enumeration over labels +
% dynamic_db. Emitting BuiltinCall would route to builtin()
% directly, bypassing the iterator and losing the enum semantics.
is_builtin_pred(predicate_property, 2). % predicate_property(+Head, +Prop).
is_builtin_pred(exists_file, 1).        % exists_file(+Path).
is_builtin_pred(exists_directory, 1).   % exists_directory(+Path).
is_builtin_pred(directory_files, 2).    % directory_files(+Dir, -Files).
is_builtin_pred(make_directory, 1).     % make_directory(+Path).
is_builtin_pred(delete_file, 1).        % delete_file(+Path).
is_builtin_pred(rename_file, 2).        % rename_file(+Old, +New).
is_builtin_pred(delete_directory, 1).   % delete_directory(+Path).
is_builtin_pred(size_file, 2).          % size_file(+Path, -Size).
is_builtin_pred(time_file, 2).          % time_file(+Path, -Time).
is_builtin_pred(getenv, 2).             % getenv(+Name, -Value).
is_builtin_pred(setenv, 2).             % setenv(+Name, +Value).
is_builtin_pred(unsetenv, 1).           % unsetenv(+Name).
is_builtin_pred(chmod, 2).              % chmod(+Path, +Mode).
is_builtin_pred(access, 2).             % access(+Path, +ModeBits) -- F_OK=0, R_OK=4, W_OK=2, X_OK=1.
is_builtin_pred(shell, 1).              % shell(+Command).
is_builtin_pred(shell, 2).              % shell(+Command, -Status).
is_builtin_pred(working_directory, 2).  % working_directory(?Old, ?New).
is_builtin_pred(getpid, 1).             % getpid(-Pid).
is_builtin_pred(getuid, 1).             % getuid(-Uid).
is_builtin_pred(geteuid, 1).            % geteuid(-EUid).
is_builtin_pred(getgid, 1).             % getgid(-Gid).
is_builtin_pred(getegid, 1).            % getegid(-EGid).
is_builtin_pred(getppid, 1).            % getppid(-PPid).
is_builtin_pred(getpgrp, 1).            % getpgrp(-PGid) -- process group id.
is_builtin_pred(realpath, 2).           % realpath(+Path, -Abs) -- canonical absolute path.
is_builtin_pred(kill, 2).               % kill(+Pid, +Sig) -- signal 0 = existence check.
is_builtin_pred(truncate, 2).           % truncate(+Path, +Length) -- set file size.
is_builtin_pred(chown, 3).              % chown(+Path, +Uid, +Gid) -- change owner.
is_builtin_pred(ground, 1).             % ground(+Term) -- true iff no unbound vars.
is_builtin_pred(file_base_name, 2).     % file_base_name(+Path, -Base).
is_builtin_pred(file_directory_name, 2).% file_directory_name(+Path, -Dir).
is_builtin_pred(file_name_extension, 3).% file_name_extension(?Base, ?Ext, ?File).
is_builtin_pred(read_link, 2).          % read_link(+Path, -Target) -- libc readlink.
is_builtin_pred(symlink, 2).            % symlink(+Target, +LinkPath) -- libc symlink.
is_builtin_pred(link, 2).               % link(+Old, +New) -- libc link (hard link).
is_builtin_pred(is_absolute_file_name, 1). % is_absolute_file_name(+Path).
is_builtin_pred(same_file, 2).          % same_file(+Path1, +Path2) -- inode equality.
is_builtin_pred(tmp_file, 2).           % tmp_file(+Base, -Path) -- mkstemp-based.
is_builtin_pred(mkfifo, 2).             % mkfifo(+Path, +Mode) -- create named pipe.
is_builtin_pred(umask, 2).              % umask(?Old, +New) -- libc umask.
is_builtin_pred(monotonic_time, 1).     % monotonic_time(-Seconds) -- CLOCK_MONOTONIC.
is_builtin_pred(nice, 1).               % nice(+Inc) -- adjust process priority.
is_builtin_pred(getpriority, 1).        % getpriority(-Prio) -- read self priority.
is_builtin_pred(setpriority, 1).        % setpriority(+Prio) -- set self priority.
is_builtin_pred(getrlimit, 2).          % getrlimit(+Resource, -SoftLimit).
is_builtin_pred(setrlimit, 2).          % setrlimit(+Resource, +SoftLimit).
is_builtin_pred(getlogin, 1).           % getlogin(-Name) -- libc getlogin.
is_builtin_pred(uname_sysname, 1).      % uname_sysname(-Sysname).
is_builtin_pred(uname_machine, 1).      % uname_machine(-Machine).
is_builtin_pred(copy_file, 2).          % copy_file(+Src, +Dst) -- open/read/write/close.
is_builtin_pred(read_file_to_atom, 2).  % read_file_to_atom(+Path, -Atom).
is_builtin_pred(write_atom_to_file, 2). % write_atom_to_file(+Path, +Content) -- O_TRUNC.
is_builtin_pred(append_atom_to_file, 2). % append_atom_to_file(+Path, +Content) -- O_APPEND.
is_builtin_pred(stream_open, 2).        % stream_open(+Path, -Handle) -- buffered line reader.
is_builtin_pred(read_line, 2).          % read_line(+Handle, -LineOrEOF).
is_builtin_pred(stream_close, 1).       % stream_close(+Handle).
is_builtin_pred(errno, 1).              % errno(-N) -- thread-local errno.
is_builtin_pred(strerror, 2).           % strerror(+Errno, -Message).
is_builtin_pred(process_max_rss, 1).    % process_max_rss(-KB) -- getrusage ru_maxrss.
is_builtin_pred(process_user_time, 1).  % process_user_time(-Seconds) -- ru_utime.
is_builtin_pred(process_system_time, 1).% process_system_time(-Seconds) -- ru_stime.
is_builtin_pred(path_join, 3).          % path_join(+Base, +Rel, -Full).
is_builtin_pred(system_to_atom, 2).     % system_to_atom(+Cmd, -Output) -- capture stdout.
is_builtin_pred(atom_to_system, 2).     % atom_to_system(+Cmd, +Content) -- write to stdin.
is_builtin_pred(atom_split, 3).         % atom_split(+Atom, +Sep, -Parts) -- split on single char.
is_builtin_pred(atom_starts_with, 2).   % atom_starts_with(+Atom, +Prefix).
is_builtin_pred(atom_ends_with, 2).     % atom_ends_with(+Atom, +Suffix).
is_builtin_pred(atom_contains, 2).      % atom_contains(+Atom, +Needle).
is_builtin_pred(sleep, 1).              % sleep(+Seconds).
is_builtin_pred(gethostname, 1).        % gethostname(-Name).
is_builtin_pred(cpu_time, 1).           % cpu_time(-Seconds).
is_builtin_pred(halt, 0).               % halt/0 -- exit(0).
is_builtin_pred(halt, 1).               % halt(+Code) -- exit(Code).
is_builtin_pred(write, 1).  % I/O — useful for runtime instrumentation.
is_builtin_pred(display, 1).
is_builtin_pred(nl, 0).
is_builtin_pred(writeln, 1).        % I/O — write/1 + nl/0.
is_builtin_pred(print, 1).          % I/O — alias for write/1.
is_builtin_pred(tab, 1).            % I/O — N spaces.
is_builtin_pred(write_canonical, 1).% I/O — quote atoms as needed.
is_builtin_pred(with_output_to, 2). % I/O — capture goal''s output.
is_builtin_pred(format, 1).  % I/O — formatted output, ~-directives.
is_builtin_pred(format, 2).
is_builtin_pred(format, 3).
is_builtin_pred(atom_codes, 2).   % atom ↔ list of integer codes.
is_builtin_pred(atom_chars, 2).   % atom ↔ list of single-char atoms.
is_builtin_pred(number_codes, 2). % number ↔ list of integer codes.
is_builtin_pred(atom_concat, 3).  % (+, +, ?) — concatenation.
is_builtin_pred(atom_length, 2).  % atom → length in chars.
is_builtin_pred(split_string, 4). % split string by separator chars.
is_builtin_pred(term_to_atom, 2). % bidirectional canonical-form term ↔ atom.
is_builtin_pred(read, 1).         % stdin: read a term terminated by `.`.
is_builtin_pred(read_term, 1).    % alias for read/1.
is_builtin_pred(get_char, 1).     % stdin: read one char as atom.
is_builtin_pred(get_char, 2).     % stream: read one char as atom.
is_builtin_pred(get_code, 1).     % stdin: read one char as int code.
is_builtin_pred(get_code, 2).     % stream: read one char as int code.
is_builtin_pred(peek_char, 1).    % stdin: peek one char (un-consumed).
is_builtin_pred(peek_char, 2).    % stream: peek one char (un-consumed).
is_builtin_pred(put_char, 1).     % stdout: write one single-char atom.
is_builtin_pred(put_char, 2).     % stream: write one single-char atom.
is_builtin_pred(put_code, 1).     % stdout: write one int code as char.
is_builtin_pred(put_code, 2).     % stream: write one int code as char.
is_builtin_pred(atomic_list_concat, 2). % concatenate list of atomics.
is_builtin_pred(atomic_list_concat, 3). % concat with separator (or split).
is_builtin_pred(atom_string, 2).        % atom ↔ string (interchangeable).
is_builtin_pred(atom_number, 2).        % atom <-> number via decimal text.
is_builtin_pred(string_to_atom, 2).     % string ↔ atom (atom_string/2 argument order).
is_builtin_pred(string_concat, 3).      % alias for atom_concat/3.
is_builtin_pred(string_length, 2).      % alias for atom_length/2.
is_builtin_pred(number_chars, 2).       % number ↔ list of single-char atoms.
is_builtin_pred(atom_to_term, 3).       % parse atom + return [] bindings.
is_builtin_pred(char_code, 2).    % char-atom ↔ integer code.
is_builtin_pred(code_type, 2).    % ASCII class check (code + type atom).
is_builtin_pred(between, 3).      % between(+Low, +High, ?X) -- nondet enumeration.
is_builtin_pred(atom_concat, 3).  % atom_concat(+A1, +A2, -A12) -- forward concat.
is_builtin_pred(sub_atom, 5).     % sub_atom(+A, +B, +L, ?After, ?Sub) -- deterministic extraction.
is_builtin_pred(atom_number, 2).  % atom_number(?A, ?N) -- integer mode only.
is_builtin_pred(assertz, 1).      % dynamic db: append fact.
is_builtin_pred(asserta, 1).      % dynamic db: prepend fact.
% retract/1 is nondeterministic — dispatched via the Call/Execute
% step arms (like findall/sub_atom) so the CP iterator can backtrack
% through subsequent matches. NOT in is_builtin_pred so the compiler
% emits `call retract/1, 1` rather than `builtin_call`.
is_builtin_pred(retractall, 1).   % dynamic db: remove all matches.
is_builtin_pred(nb_setval, 2).    % mutable global: replace value.
is_builtin_pred(nb_getval, 2).    % mutable global: read value.
is_builtin_pred(b_setval, 2).     % backtrackable mutable global: bind.
is_builtin_pred(b_getval, 2).     % backtrackable mutable global: read.
is_builtin_pred(@<, 2).           % standard order: less than.
is_builtin_pred(@=<, 2).          % standard order: less or equal.
is_builtin_pred(@>, 2).           % standard order: greater than.
is_builtin_pred(@>=, 2).          % standard order: greater or equal.
is_builtin_pred(compare, 3).      % standard order: -1 / 0 / +1 as atom.
is_builtin_pred(char_type, 2).    % char classification + case conv.
is_builtin_pred(upcase_atom, 2).  % whole-atom case conversion: upper.
is_builtin_pred(downcase_atom, 2).% whole-atom case conversion: lower.
is_builtin_pred(nth0, 3).         % nth0(+Index, +List, ?Elem) -- 0-indexed.
is_builtin_pred(nth1, 3).         % nth1(+Index, +List, ?Elem) -- 1-indexed.
is_builtin_pred(last, 2).         % last(+List, ?Elem).
is_builtin_pred(memberchk, 2).    % memberchk(?Elem, +List) -- deterministic membership.
is_builtin_pred(numlist, 3).      % integer range generator: [Lo..Hi].
is_builtin_pred(sum_list, 2).     % sum_list(+List, ?Sum) -- integer sum.
is_builtin_pred(sumlist, 2).      % alias of sum_list.
is_builtin_pred(max_list, 2).     % max_list(+List, ?Max) -- empty fails.
is_builtin_pred(min_list, 2).     % min_list(+List, ?Min) -- empty fails.
is_builtin_pred(sort, 2).         % stable sort + dedup (std order).
is_builtin_pred(msort, 2).        % stable sort, NO dedup (std order).
is_builtin_pred(select, 3).       % nondet list element selection.
is_builtin_pred(maplist, 2).      % apply goal to each list element.
is_builtin_pred(maplist, 3).
is_builtin_pred(maplist, 4).
is_builtin_pred(maplist, 5).
is_builtin_pred(include, 3).      % filter: keep elems where Goal succeeds.
is_builtin_pred(exclude, 3).      % filter: drop elems where Goal succeeds.
is_builtin_pred(partition, 4).    % split into pass + fail lists.
is_builtin_pred(foldl, 4).        % left fold over one list.
is_builtin_pred(foldl, 5).        % left fold over two lists in parallel.
is_builtin_pred(keysort, 2).      % stable sort of Key-Value pairs by Key.
is_builtin_pred(pairs_keys, 2).   % extract keys from Key-Value pairs.
is_builtin_pred(pairs_values, 2). % extract values from Key-Value pairs.
is_builtin_pred(pairs_keys_values, 3). % split pairs into parallel lists.
% Note: sub_atom/5 is nondeterministic; like findall/bagof/setof it
% goes through the Call/Execute dispatch path (not is_builtin_pred)
% so dispatch_sub_atom can manage its own CP machinery.
is_builtin_pred(=, 2).       % unification: bind / structurally unify two terms.
is_builtin_pred(is_list, 1).
                             % Without this entry, X = Y in a body goal
                             % would compile to `execute =/2`, which looks
                             % up "=/2" as a user predicate, misses, and
                             % resolves to PC=0 at runtime — silently
                             % re-entering the project's first predicate
                             % and corrupting execution state.

compile_put_arguments([], _, V, V, "").
compile_put_arguments([Arg|Rest], I, V0, Vf, Code) :-
    compile_put_argument(Arg, I, V0, V1, ArgCode),
    NI is I + 1,
    compile_put_arguments(Rest, NI, V1, Vf, RestCode),
    (   RestCode == ""
    ->  Code = ArgCode
    ;   format(string(Code), "~w~n~w", [ArgCode, RestCode])
    ).

compile_put_argument(Arg, I, V0, V1, Code) :-
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  format(string(Code), "    put_value ~w, A~w", [Reg, I]),
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  format(string(Code), "    put_variable ~w, A~w", [YReg, I])
        ;   next_x_reg(V0, XReg, V_temp),
            bind_var(Arg, XReg, V_temp, V1),
            format(string(Code), "    put_variable ~w, A~w", [XReg, I])
        )
    ;   atomic(Arg)
    ->  quote_wam_constant(Arg, ArgStr),
        format(string(Code), "    put_constant ~w, A~w", [ArgStr, I]),
        V1 = V0
    ;   is_list_term(Arg),
        proper_list(Arg, _)
    ->  Arg = [H|T],
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V2),
        format(string(ListCode), "    put_list A~w", [I]),
        compile_set_arguments([H, T], V2, V1, SetCode),
        (   SetCode == ""
        ->  Code = ListCode
        ;   format(string(Code), "~w~n~w", [ListCode, SetCode])
        )
    ;   compound(Arg)
    ->  Arg =.. [F|SubArgs],
        length(SubArgs, SArity),
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V2),
        format(string(StructCode), "    put_structure ~w/~w, A~w", [F, SArity, I]),
        compile_set_arguments(SubArgs, V2, V1, SetCode),
        (   SetCode == ""
        ->  Code = StructCode
        ;   format(string(Code), "~w~n~w", [StructCode, SetCode])
        )
    ;   % Fallback for unknown terms — allocate a fresh variable
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1),
        format(string(Code), "    put_variable ~w, A~w", [XReg, I])
    ).

%% compile_set_arguments(+Args, +VIn, -VOut, -Code)
%  Emits set_value/set_variable instructions for put_structure sub-arguments.
%
%  Default behaviour (args-first): defers nested put_structure emit
%  until after all immediate set_*'s for the current compound — see
%  compile_set_arguments_split/5. This preserves heap contiguity of
%  addr+1..addr+arity, which flat-heap target runtimes assume.
%
%  Legacy interleaved behaviour preserved as
%  compile_set_arguments_inline/4 for the
%  args_first_emission(false) opt-out — used when callers need
%  byte-identical bytecode against a pre-flip snapshot.
compile_set_arguments(Args, V0, Vf, Code) :-
    catch(b_getval(wam_args_first_emission, FlagVal), _, FlagVal = true),
    ( FlagVal == false
    -> compile_set_arguments_inline(Args, V0, Vf, Code)
    ;  compile_set_arguments_split(Args, V0, Vf, ImmCode, DeferredCode),
       ( DeferredCode == ""
       -> Code = ImmCode
       ;  ImmCode == ""
       -> Code = DeferredCode
       ;  format(string(Code), "~w~n~w", [ImmCode, DeferredCode])
       )
    ).

% Original interleaved emission — preserved for targets that don't
% opt in to args_first_emission. Behaviour unchanged from pre-flag
% baseline.
compile_set_arguments_inline([], V, V, "").
compile_set_arguments_inline([Arg|Rest], V0, Vf, Code) :-
    (   var(Arg)
    ->  (   get_var_reg(Arg, V0, Reg)
        ->  format(string(ArgCode), "    set_value ~w", [Reg]),
            V1 = V0
        ;   get_yi_alloc(Arg, V0, YReg, V1)
        ->  format(string(ArgCode), "    set_variable ~w", [YReg])
        ;   next_x_reg(V0, XReg, V_temp),
            bind_var(Arg, XReg, V_temp, V1),
            format(string(ArgCode), "    set_variable ~w", [XReg])
        )
    ;   atomic(Arg)
    ->  % For atomic sub-args, emit set_constant directly
        V1 = V0,
        quote_wam_constant(Arg, ArgStr),
        format(string(ArgCode), "    set_constant ~w", [ArgStr])
    ;   % Nested compound — recursively emit put_structure + set_* for sub-args
        compound(Arg)
    ->  Arg =.. [F|NestedArgs],
        length(NestedArgs, NArity),
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1a),
        format(string(SetCode), "    set_variable ~w", [XReg]),
        format(string(PutCode), "    put_structure ~w/~w, ~w", [F, NArity, XReg]),
        compile_set_arguments_inline(NestedArgs, V1a, V1, NestedCode),
        (   NestedCode == ""
        ->  format(string(ArgCode), "~w~n~w", [SetCode, PutCode])
        ;   format(string(ArgCode), "~w~n~w~n~w", [SetCode, PutCode, NestedCode])
        )
    ;   % Fallback
        next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1),
        format(string(ArgCode), "    set_variable ~w", [XReg])
    ),
    compile_set_arguments_inline(Rest, V1, Vf, RestCode),
    (   RestCode == ""
    ->  Code = ArgCode
    ;   format(string(Code), "~w~n~w", [ArgCode, RestCode])
    ).

% Args-first emission: returns Immediate (set_value/set_variable
% /set_constant for each outer arg) AND Deferred (put_structure +
% nested args bodies, recursively args-first). All immediate
% emissions complete BEFORE any deferred — that way the outer
% compound's args are at contiguous heap slots before any nested
% structure body grows the heap.
compile_set_arguments_split([], V, V, "", "").
compile_set_arguments_split([Arg|Rest], V0, Vf, Code, Deferred) :-
    arg_split(Arg, V0, V1, ImmArg, DefArg),
    compile_set_arguments_split(Rest, V1, Vf, ImmRest, DefRest),
    join_lines(ImmArg, ImmRest, Code),
    join_lines(DefArg, DefRest, Deferred).

% Per-arg classification. Returns the immediate emit (Imm) and any
% deferred emit (Def, possibly empty). For nested compounds, the
% deferred emit is the put_structure for the compound + its
% (recursively-split) args.
arg_split(Arg, V0, V1, Imm, "") :-
    var(Arg),
    !,
    (   get_var_reg(Arg, V0, Reg)
    ->  format(string(Imm), "    set_value ~w", [Reg]),
        V1 = V0
    ;   get_yi_alloc(Arg, V0, YReg, V1)
    ->  format(string(Imm), "    set_variable ~w", [YReg])
    ;   next_x_reg(V0, XReg, V_temp),
        bind_var(Arg, XReg, V_temp, V1),
        format(string(Imm), "    set_variable ~w", [XReg])
    ).
arg_split(Arg, V0, V0, Imm, "") :-
    atomic(Arg),
    !,
    quote_wam_constant(Arg, ArgStr),
    format(string(Imm), "    set_constant ~w", [ArgStr]).
arg_split(Arg, V0, V1, Imm, Def) :-
    compound(Arg),
    !,
    Arg =.. [F|NestedArgs],
    length(NestedArgs, NArity),
    next_x_reg(V0, XReg, V_temp),
    bind_var(Arg, XReg, V_temp, V1a),
    format(string(Imm), "    set_variable ~w", [XReg]),
    % Recurse into nested args using the same args-first scheme.
    compile_set_arguments_split(NestedArgs, V1a, V1,
                                 NestedImm, NestedDef),
    format(string(StructLine),
           "    put_structure ~w/~w, ~w", [F, NArity, XReg]),
    % Build the deferred chunk: put_structure for THIS compound,
    % then its immediate args, then any further deferreds.
    join_lines(StructLine, NestedImm, ThisStructWithImm),
    join_lines(ThisStructWithImm, NestedDef, Def).
arg_split(Arg, V0, V1, Imm, "") :-
    % Fallback (rarely reached — covers unknown shapes).
    next_x_reg(V0, XReg, V_temp),
    bind_var(Arg, XReg, V_temp, V1),
    format(string(Imm), "    set_variable ~w", [XReg]).

% Join two code strings with a newline, handling empty-string cases.
join_lines("", B, B) :- !.
join_lines(A, "", A) :- !.
join_lines(A, B, Out) :- format(string(Out), "~w~n~w", [A, B]).

%% Variable Mapping Helpers
%  Bindings use b(Var, Reg) for seen variables, and
%  y_alloc(Var, Reg) for pre-allocated Yi registers not yet seen.
empty_varmap(vmap([], 1)).

get_var_reg(Var, vmap(Bindings, _), Reg) :-
    member(b(V, Reg), Bindings),
    V == Var, !.

%% get_yi_alloc(+Var, +VarMap, -YReg, -VarMapOut)
%  If Var has a pre-allocated Yi register, return it and promote to seen.
get_yi_alloc(Var, vmap(Bindings, X), YReg, vmap(NewBindings, X)) :-
    select(y_alloc(V, YReg), Bindings, Rest),
    V == Var, !,
    NewBindings = [b(Var, YReg)|Rest].

bind_var(Var, Reg, vmap(Bs, X), vmap([b(Var, Reg)|Bs], X)).

next_x_reg(vmap(Bs, X), XReg, vmap(Bs, NX)) :-
    format(atom(XReg), "X~w", [X]),
    NX is X + 1.

%% compile_facts_to_wam(+Pred, +Arity, -Code)
compile_facts_to_wam(PredIndicator, Arity, Code) :-
    % Handle module qualification
    (   PredIndicator = Module:Pred -> true
    ;   PredIndicator = Pred, Module = user
    ),
    functor(Head, Pred, Arity),
    findall(Head-true, clause(Module:Head, true), Clauses),
    (   Clauses = []
    ->  format(user_error, 'WAM target: no facts for ~w:~w/~w~n', [Module, Pred, Arity]),
        fail
    ;   compile_clauses_to_wam(Pred, Arity, Clauses, [], Code)
    ).

%% =====================================================
%% Peephole Optimization
%% =====================================================

%% peephole_optimize(+CodeStr, -OptimizedStr)
%  Applies peephole optimizations to a WAM instruction string.
%  Operates on the string representation, line by line.
peephole_optimize(Code, Optimized) :-
    split_string(Code, "\n", "", Lines),
    peephole_lines(Lines, OptLines),
    atomic_list_concat(OptLines, '\n', Optimized).

peephole_lines([], []).
% Eliminate put_value Xn, Ai followed by get_variable Xn, Ai (identity)
peephole_lines([L1, L2|Rest], Result) :-
    normalize_ws(L1, N1),
    normalize_ws(L2, N2),
    atom_string(N1, S1), atom_string(N2, S2),
    match_put_get_identity(S1, S2), !,
    peephole_lines(Rest, Result).
% Eliminate put_value Xn, Ai immediately followed by put_value Xn, Ai (duplicate)
peephole_lines([L1, L2|Rest], [L1|Result]) :-
    normalize_ws(L1, N1),
    normalize_ws(L2, N2),
    N1 == N2,
    atom_string(N1, S1),
    sub_string(S1, 0, _, _, "put_"), !,
    peephole_lines(Rest, Result).
% Eliminate get_variable Xn, Ai followed by put_value Xn, Ai (pass-through)
% Only safe if Xn is not referenced by any later instruction.
peephole_lines([L1, L2|Rest], Result) :-
    normalize_ws(L1, N1),
    normalize_ws(L2, N2),
    atom_string(N1, S1), atom_string(N2, S2),
    match_get_put_passthrough(S1, S2, Reg),
    \+ reg_used_in_rest(Reg, Rest), !,
    peephole_lines(Rest, Result).
% Eliminate put_variable Xn, Ai followed by put_value Xn, Ai (same register, same arg)
peephole_lines([L1, L2|Rest], [L1|Result]) :-
    normalize_ws(L1, N1),
    normalize_ws(L2, N2),
    atom_string(N1, S1), atom_string(N2, S2),
    match_put_variable_put_value(S1, S2), !,
    peephole_lines(Rest, Result).
peephole_lines([L|Rest], [L|Result]) :-
    peephole_lines(Rest, Result).

normalize_ws(Str, Normalized) :-
    split_string(Str, " \t", " \t", Parts),
    delete(Parts, "", Clean),
    atomic_list_concat(Clean, ' ', Normalized).

%% match_put_get_identity(+PutStr, +GetStr)
%  put_value Xn/Yn, Ai followed by get_variable Xn/Yn, Ai — the get is redundant.
match_put_get_identity(Put, Get) :-
    split_string(Put, " ,", " ,", ["put_value", Reg, Ai]),
    split_string(Get, " ,", " ,", ["get_variable", Reg, Ai]).

%% match_get_put_passthrough(+GetStr, +PutStr, -Reg)
%  get_variable Xn, Ai followed by put_value Xn, Ai — both redundant
%  (the value is already in Ai and doesn't need round-tripping through Xn).
match_get_put_passthrough(Get, Put, Reg) :-
    split_string(Get, " ,", " ,", ["get_variable", Reg, Ai]),
    split_string(Put, " ,", " ,", ["put_value", Reg, Ai]).

%% match_put_variable_put_value(+PutVarStr, +PutValStr)
%  put_variable Xn/Yn, Ai followed by put_value Xn/Yn, Ai where both
%  use the same register and arg — the put_value is redundant.
match_put_variable_put_value(PutVar, PutVal) :-
    split_string(PutVar, " ,", " ,", ["put_variable", Reg, Ai]),
    split_string(PutVal, " ,", " ,", ["put_value", Reg, Ai]).

%% reg_used_in_rest(+Reg, +Lines)
%  True if the register name appears in any subsequent line.
reg_used_in_rest(Reg, Lines) :-
    member(Line, Lines),
    atom_string(Line, LineStr),
    sub_string(LineStr, _, _, _, Reg), !.

%% write_wam_program(+Code, +Filename)
write_wam_program(Code, Filename) :-
    setup_call_cleanup(
        open(Filename, write, Stream),
        format(Stream, "~w~n", [Code]),
        close(Stream)
    ).

%% ========================================================================
%% Binding-state analysis plumbing for =../2 compose-mode lowering.
%%
%% The binding analyser produces a list of `goal_binding(Idx, Before,
%% After)` records per clause. We stash that list in a non-backtrackable
%% global before invoking the body walk, and the new `compile_goal_call`
%% / `compile_goal_execute` clauses for `T =.. L` consult it.
%%
%% The analysis is *additive* — if the global is unset (e.g. when a
%% target invokes `compile_goal_call/4` directly without going through
%% `compile_single_clause_wam`), the lowering simply falls through to
%% the existing builtin path. No regression for any non-WAM-Haskell
%% caller.
%% ========================================================================

%% set_clause_binding_context(+Head, +Body)
%  Run the binding analyser on the clause and stash the resulting list
%  of `goal_binding/3` records in `wam_clause_binding_records`. Also
%  resets the per-goal index counter to 1.
set_clause_binding_context(Head, Body) :-
    catch(
        binding_state_analysis:analyse_clause_bindings(Head, Body, Bindings),
        _Err,
        Bindings = []
    ),
    b_setval(wam_clause_binding_records, Bindings),
    b_setval(wam_clause_goal_idx, 1).

%% current_clause_binding_env(-BeforeEnv)
%  Returns the BeforeEnv of the goal currently being compiled. Defaults
%  to the empty env when no analysis is in scope.
current_clause_binding_env(BeforeEnv) :-
    (   catch(b_getval(wam_clause_binding_records, Bindings), _, fail)
    ->  true
    ;   Bindings = []
    ),
    (   catch(b_getval(wam_clause_goal_idx, Idx), _, fail)
    ->  true
    ;   Idx = 1
    ),
    (   member(goal_binding(Idx, Env, _), Bindings)
    ->  BeforeEnv = Env
    ;   binding_state_analysis:empty_binding_env(BeforeEnv)
    ).

%% advance_clause_goal_idx
%  Step the per-clause goal index forward by one. Called from the body
%  walk between goals so the binding lookup sees the right BeforeEnv.
advance_clause_goal_idx :-
    (   catch(b_getval(wam_clause_goal_idx, Idx), _, fail)
    ->  Idx1 is Idx + 1,
        b_setval(wam_clause_goal_idx, Idx1)
    ;   true
    ).

%% ========================================================================
%% Visited-set context (Layer 2 of the IntSet visited design).
%%
%% A predicate-arg position can be marked as a visited-set via
%%
%%     :- visited_set(Pred/Arity, ArgN).
%%
%% asserted into the user module before compilation. The compiler then:
%%
%%   1. At clause entry, captures which head-arg variables of THIS
%%      clause sit at declared visited-set positions and stashes them
%%      in `wam_clause_visited_vars` (a non-backtrackable global).
%%
%%   2. At a body goal `\+ member(X, V)` where V is in that set, emits
%%      `not_member_set` instead of `not_member_list`.
%%
%%   3. At a CALL site whose target predicate-arg matches a directive
%%      AND whose actual arg is a list-shaped term:
%%        * `[Cat]` (1-elem ground literal)  ⇒
%%            build_empty_set + set_insert(Cat) sequence
%%        * `[X|V_visited]` (cons of head's visited-set var) ⇒
%%            set_insert(X, V_visited, Fresh)
%%      bound to a fresh Prolog variable, which the standard
%%      put_argument path then stores in the call's argument register.
%%
%% Soundness: if `:- visited_set/2` is wrong (e.g. claims an arg is a
%% set but the runtime sees a non-Atom element), `set_insert` /
%% `not_member_set` return Nothing → the goal fails. No silent
%% miscompilation.
%% ========================================================================

%% set_clause_visited_context(+Head)
%  Read user:visited_set(Pred/Arity, ArgN) declarations and capture
%  the head-arg variables matching this clause as the per-clause
%  visited-set var set. Stored as a list because Prolog vars are not
%  groundable for use as map keys without copy_term.
set_clause_visited_context(Head) :-
    (   compound(Head)
    ->  Head =.. [Pred|HeadArgs],
        length(HeadArgs, Arity),
        %% Walk HeadArgs in place (NOT via findall, which would copy
        %% the captured variables and break == identity later).
        collect_visited_vars(HeadArgs, 1, Pred/Arity, VisitedVars)
    ;   VisitedVars = []
    ),
    b_setval(wam_clause_visited_vars, VisitedVars).

%% collect_visited_vars(+Args, +N, +Pred/+Arity, -CapturedVars)
%  Walk Args; for each variable position whose index N matches a
%  visited_set directive on Pred/Arity, capture the variable in
%  CapturedVars (preserving its identity — no findall copy).
collect_visited_vars([], _, _, []).
collect_visited_vars([Arg|Rest], N, PA, [Arg|MoreVars]) :-
    var(Arg),
    is_visited_set_arg(PA, N),
    !,
    N1 is N + 1,
    collect_visited_vars(Rest, N1, PA, MoreVars).
collect_visited_vars([_|Rest], N, PA, MoreVars) :-
    N1 is N + 1,
    collect_visited_vars(Rest, N1, PA, MoreVars).

%% is_visited_set_var(+Var)
%  True when Var is a Prolog variable currently in the per-clause
%  visited-set context (captured by set_clause_visited_context/1).
is_visited_set_var(Var) :-
    var(Var),
    catch(b_getval(wam_clause_visited_vars, Vars), _, fail),
    member(V, Vars),
    V == Var.

%% is_visited_set_arg(+Pred/+Arity, +ArgN)
%  True when the directive `user:visited_set(Pred/Arity, ArgN)` has
%  been asserted.
is_visited_set_arg(Pred/Arity, ArgN) :-
    current_predicate(user:visited_set/2),
    user:visited_set(Pred/Arity, ArgN).


%% is_term_construction_goal(+Goal)
%
%  True when Goal matches a builtin that the WAM compiler recognises
%  for binding-analysis-driven lowering: `T =.. L`, `functor(T, N, A)`,
%  `arg(N, T, A)`, or `\+ member(X, L)`. Used by the TCO routing in
%  compile_goals/5 to direct these goals through compile_goal_execute
%  so the lowering preconditions can be checked.
is_term_construction_goal(Goal) :-
    nonvar(Goal),
    (   Goal = (_ =.. _)
    ;   Goal = functor(_, _, _)
    ;   Goal = arg(_, _, _)
    ;   Goal = (\+ member(_, _))
    ).

%% term_construction_uses_special_lowering(+Goal)
%
%   True iff the term-construction goal will actually take the
%   compose-mode lowering path in compile_goal_execute /
%   compile_goal_call (emit_put_structure_dyn_lowering).  When this
%   holds, the body reads from input registers and Deallocate may
%   safely precede it.  When it fails, compile_goal_execute falls
%   through to the generic builtin path which emits Y-register reads
%   inline, so Deallocate must follow them (otherwise Y reads land
%   on a popped env frame — issue #2400 follow-up).
term_construction_uses_special_lowering(T =.. L) :-
    parse_univ_list_pattern(L, NameVar, _FixedArgs),
    catch(
        ( current_clause_binding_env(BeforeEnv),
          binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
          binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound)
        ),
        _, fail),
    !.
term_construction_uses_special_lowering(functor(T, NameVar, Arity)) :-
    integer(Arity), Arity >= 0,
    var(T), var(NameVar),
    catch(
        ( current_clause_binding_env(BeforeEnv),
          binding_state_analysis:binding_state_at_var(BeforeEnv, T, unbound),
          binding_state_analysis:binding_state_at_var(BeforeEnv, NameVar, bound)
        ),
        _, fail),
    !.
term_construction_uses_special_lowering(\+ member(_, _)).
term_construction_uses_special_lowering(arg(_, _, _)).

%% emit_not_member_list_lowering(+X, +L, +V0, -Vf, -Code)
%
%  Emits a single `not_member_list XReg LReg` WAM instruction. Both
%  X and L are required (by the caller's binding-analysis check) to
%  already have allocated registers on entry; this helper simply
%  looks them up. Falls back to allocating fresh X registers if the
%  variables somehow do not yet have register assignments — a defensive
%  path that should not fire when the precondition holds.
emit_not_member_list_lowering(X, L, V0, Vf, Code) :-
    (   get_var_reg(X, V0, XReg)
    ->  V1 = V0,
        XPrefix = ""
    ;   next_x_reg(V0, XReg, V_temp1),
        bind_var(X, XReg, V_temp1, V1),
        format(string(XPrefix), "    put_variable ~w, A1", [XReg])
    ),
    (   get_var_reg(L, V1, LReg)
    ->  Vf = V1,
        LPrefix = ""
    ;   next_x_reg(V1, LReg, V_temp2),
        bind_var(L, LReg, V_temp2, Vf),
        format(string(LPrefix), "    put_variable ~w, A2", [LReg])
    ),
    format(string(Body), "    not_member_list ~w, ~w", [XReg, LReg]),
    join_nonempty([XPrefix, LPrefix, Body], Code).

%% emit_not_member_set_lowering(+X, +V, +V0, -Vf, -Code)
%
%  Emits a single `not_member_set XReg VReg` WAM instruction (Layer 2
%  of the IntSet visited design). Mirrors the not_member_list helper
%  above; the runtime semantic is O(log N) IntSet lookup instead of
%  O(N) list walk. Pre-condition (checked by the caller): V is in the
%  per-clause visited-set context.
emit_not_member_set_lowering(X, V, V0, Vf, Code) :-
    (   get_var_reg(X, V0, XReg)
    ->  V1 = V0,
        XPrefix = ""
    ;   next_x_reg(V0, XReg, V_temp1),
        bind_var(X, XReg, V_temp1, V1),
        format(string(XPrefix), "    put_variable ~w, A1", [XReg])
    ),
    (   get_var_reg(V, V1, VReg)
    ->  Vf = V1,
        VPrefix = ""
    ;   next_x_reg(V1, VReg, V_temp2),
        bind_var(V, VReg, V_temp2, Vf),
        format(string(VPrefix), "    put_variable ~w, A2", [VReg])
    ),
    format(string(Body), "    not_member_set ~w, ~w", [XReg, VReg]),
    join_nonempty([XPrefix, VPrefix, Body], Code).

%% lowering_disabled(+Tag) is semidet.
%
%  Per-process opt-out hook used by benchmarks to compile a baseline
%  project with a specific lowering turned off. Currently recognised:
%
%    ground_member — disables the literal-ground-list `\+ member`
%                    lowering (NotMemberConstAtoms). Falls through to
%                    the standard builtin dispatch path.
%
%  Default: not disabled. Bench scripts assert
%  `wam_target:lowering_disabled(ground_member)` before generating an
%  unlowered baseline project, then retract afterwards.
:- dynamic(lowering_disabled/1).

%% is_ground_atom_list(+L, -Atoms) is semidet.
%
%  Succeeds when L is a proper list of ground atoms, binding Atoms to
%  the same list. Fails for variables, partial lists, lists containing
%  numbers, structures, or unbound elements. Used to detect the
%  literal-list shape of `\+ member(X, [a, b, c])` for codegen lowering.
is_ground_atom_list(L, Atoms) :-
    nonvar(L),
    proper_list(L, Items),
    Items \== [],
    maplist(atom, Items),
    Atoms = Items.

% Walk a list term, collecting its elements. Must FAIL (not loop) on a
% partial or improper list, so callers (compile_put_argument/5 via the
% `proper_list(Arg, _)` guard from #aac54075, and is_ground_atom_list/2)
% can rely on a clean failure to fall through to the compound branch
% (put_structure for the '[|]'/2 cons cell). The nonvar/1 guards stop the
% recursion the moment a tail is an unbound variable, so a partial list
% like [a|_] fails instead of recursing forever; an improper tail like
% [a|b] fails when proper_list_/2 hits a non-list, non-[] tail.
proper_list(T, Items) :-
    nonvar(T),
    proper_list_(T, Items).

proper_list_(T, []) :- T == [], !.
proper_list_([H|T], [H|R]) :-
    nonvar(T),
    proper_list_(T, R).

%% emit_not_member_const_atoms_lowering(+X, +Atoms, +V0, -Vf, -Code)
%
%  Emits a single `not_member_const_atoms XReg A1 A2 ... AN` WAM
%  instruction. Atoms are interned at the WAM-haskell-target stage,
%  so what we emit here is just the atom names space-separated. X must
%  resolve to a register; if it doesn't already have one, allocate
%  fresh.
emit_not_member_const_atoms_lowering(X, Atoms, V0, Vf, Code) :-
    (   get_var_reg(X, V0, XReg)
    ->  Vf = V0,
        XPrefix = ""
    ;   next_x_reg(V0, XReg, V_temp),
        bind_var(X, XReg, V_temp, Vf),
        format(string(XPrefix), "    put_variable ~w, A1", [XReg])
    ),
    atomic_list_concat(Atoms, ' ', AtomsStr),
    format(string(Body), "    not_member_const_atoms ~w ~w", [XReg, AtomsStr]),
    join_nonempty([XPrefix, Body], Code).

%% rewrite_visited_set_args(+Pred/+Arity, +Args, -NewArgs, -Code, +V0, -Vf)
%
%  Rewrite call-site args at positions declared as visited-sets via
%  `:- visited_set(Pred/Arity, ArgN)`. Recognises two list shapes:
%
%    Pattern 1 — bootstrap `[X]` (1-elem list, var head):
%      build_empty_set Rs ; set_insert XReg, Rs, Rs
%      Replaces the arg with a fresh var bound to Rs.
%
%    Pattern 2 — recursive `[X|V_visited]` (cons of head's visited-set
%      var): set_insert XReg, V_visited_Reg, Rfresh
%      Replaces the arg with a fresh var bound to Rfresh.
%
%  Anything else passes through unchanged. Succeeds only when at
%  least one position rewrites — otherwise fails so the caller falls
%  through to the standard compile_put_arguments path.
rewrite_visited_set_args(PA, Args, NewArgs, Code, V0, Vf) :-
    rewrite_args_loop(Args, 1, PA, NewArgs, V0, Vf, Pieces),
    Pieces \= [],
    join_nonempty(Pieces, Code).

rewrite_args_loop([], _, _, [], V, V, []).
rewrite_args_loop([Arg|Rest], N, PA, [NewArg|NewRest], V0, Vf, Pieces) :-
    (   is_visited_set_arg(PA, N),
        rewrite_visited_arg(Arg, NewArg, V0, V1, ArgCode)
    ->  Pieces = [ArgCode|RestPieces]
    ;   NewArg = Arg, V1 = V0, Pieces = RestPieces
    ),
    N1 is N + 1,
    rewrite_args_loop(Rest, N1, PA, NewRest, V1, Vf, RestPieces).

%% rewrite_visited_arg(+Arg, -NewArg, +V0, -Vf, -Code)
%
%  Recursive extension `[X|V_visited]` (cons of head's visited-set
%  var). Tested FIRST so the more specific case wins — clause-head
%  unification of `[X]` would otherwise bind V_visited=[] and fall
%  through to the bootstrap path with wrong semantics.
rewrite_visited_arg(L, NewArg, V0, Vf, Code) :-
    nonvar(L),
    L = [X|V],
    var(X), var(V),
    is_visited_set_var(V),
    !,
    (   get_var_reg(X, V0, XReg)
    ->  V1 = V0
    ;   next_x_reg(V0, XReg, V_t1),
        bind_var(X, XReg, V_t1, V1)
    ),
    (   get_var_reg(V, V1, VReg)
    ->  V2 = V1
    ;   next_x_reg(V1, VReg, V_t2),
        bind_var(V, VReg, V_t2, V2)
    ),
    next_x_reg(V2, NewSetReg, V3),
    bind_var(NewArg, NewSetReg, V3, Vf),
    format(string(Code), "    set_insert ~w, ~w, ~w", [XReg, VReg, NewSetReg]).
%% Bootstrap: `[X]` (1-elem list with var head and atom-`[]` tail)
%% -> build_empty_set + set_insert(X). The tail-is-atom-[] guard
%% prevents this from matching `[X|V_var]` where V_var would get
%% silently bound to [] by Prolog clause-head unification.
rewrite_visited_arg(L, NewArg, V0, Vf, Code) :-
    nonvar(L),
    L = [X|T],
    var(X),
    nonvar(T), T == [],
    !,
    (   get_var_reg(X, V0, XReg)
    ->  V1 = V0
    ;   next_x_reg(V0, XReg, V_t1),
        bind_var(X, XReg, V_t1, V1)
    ),
    next_x_reg(V1, SetReg, V2),
    bind_var(NewArg, SetReg, V2, Vf),
    format(string(Code),
        "    build_empty_set ~w~n    set_insert ~w, ~w, ~w",
        [SetReg, XReg, SetReg, SetReg]).

%% goal_has_visited_set_arg(+Goal)
%  True when Goal calls a predicate with at least one visited_set
%  declaration. Used by the TCO dispatch in compile_goals/5 to route
%  the goal through compile_goal_execute (where the rewrite fires)
%  instead of the inline put_arguments path.
goal_has_visited_set_arg(Goal) :-
    nonvar(Goal),
    Goal =.. [Pred|Args],
    Args \== [],
    length(Args, Arity),
    is_visited_set_arg(Pred/Arity, _).

%% emit_arg_lowering(+N, +T, +A, +V0, -Vf, -Code)
%
%  Emits a single `arg N TReg AReg` WAM instruction. Allocates X
%  registers for T and A as needed (mirrors the conventions in
%  emit_put_structure_dyn_lowering/6).
emit_arg_lowering(N, T, A, V0, Vf, Code) :-
    %% TReg: T must already have a register (precondition: bound). If
    %% not allocated, allocate one and emit put_variable for safety.
    (   get_var_reg(T, V0, TReg)
    ->  V1 = V0,
        TPrefix = ""
    ;   next_x_reg(V0, TReg, V_temp1),
        bind_var(T, TReg, V_temp1, V1),
        format(string(TPrefix), "    put_variable ~w, A1", [TReg])
    ),
    %% AReg: allocate if not present.
    (   get_var_reg(A, V1, AReg)
    ->  Vf = V1
    ;   next_x_reg(V1, AReg, V_temp2),
        bind_var(A, AReg, V_temp2, Vf)
    ),
    format(string(ArgCode), "    arg ~w, ~w, ~w", [N, TReg, AReg]),
    (   TPrefix == ""
    ->  Code = ArgCode
    ;   format(string(Code), "~w~n~w", [TPrefix, ArgCode])
    ).

%% parse_univ_list_pattern(+List, -NameVar, -FixedArgs)
%
%  Recognises the list literal `[NameVar | FixedArgs]` where NameVar is
%  a Prolog variable and FixedArgs is a fixed-length proper list
%  (length ≥ 0, no tail variables). Used by the =../2 compose-mode
%  lowering to extract the dynamic functor name and the fixed
%  argument list.
parse_univ_list_pattern(List, _NameVar, _FixedArgs) :-
    var(List), !, fail.
parse_univ_list_pattern([NameVar|Rest], NameVar, FixedArgs) :-
    var(NameVar),
    proper_fixed_list(Rest, FixedArgs).

proper_fixed_list(L, _) :- var(L), !, fail.
proper_fixed_list([], []) :- !.
proper_fixed_list([H|T], [H|FixedT]) :-
    proper_fixed_list(T, FixedT).

%% emit_put_structure_dyn_lowering(+T, +NameVar, +FixedArgs, +V0, -Vf, -Code)
%
%  Emit the WAM instruction sequence that constructs a structure whose
%  functor name comes from a register (`NameVar`) and whose arity is
%  the literal length of FixedArgs.
%
%  Sequence:
%      put_value Reg(NameVar), A1     # nameReg
%      put_constant N, A2             # arityReg (literal int)
%      put_structure_dyn A1, A2, A3   # construct Str at A3
%      <set_value/set_variable for each FixedArg>
%      get_value Reg(T), A3           # unify with T
%
%  Pre-condition: the caller has verified that NameVar is `bound` and
%  T is `unbound` in the BeforeEnv.
emit_put_structure_dyn_lowering(T, NameVar, FixedArgs, V0, Vf, Code) :-
    %% A1 = NameVar's register (must already exist; if not, allocate).
    (   get_var_reg(NameVar, V0, NameReg)
    ->  V1 = V0,
        format(string(NameCode), "    put_value ~w, A1", [NameReg])
    ;   next_x_reg(V0, NameReg, V_temp1),
        bind_var(NameVar, NameReg, V_temp1, V1),
        format(string(NameCode), "    put_variable ~w, A1", [NameReg])
    ),
    %% A2 = literal arity.
    length(FixedArgs, Arity),
    format(string(ArityCode), "    put_constant ~w, A2", [Arity]),
    %% A3 = constructed term register.
    next_x_reg(V1, TermReg, V2),
    format(string(StructCode), "    put_structure_dyn A1, A2, ~w", [TermReg]),
    %% Emit set_value/set_variable for each FixedArg.
    compile_set_arguments(FixedArgs, V2, V3, SetCode),
    %% Bind T to the result. If T already has a reg, emit get_value;
    %% otherwise bind T to TermReg directly (T is now aliased to the
    %% constructed term).
    (   get_var_reg(T, V3, TReg)
    ->  Vf = V3,
        format(string(GetCode), "    get_value ~w, ~w", [TReg, TermReg])
    ;   bind_var(T, TermReg, V3, Vf),
        GetCode = ""
    ),
    %% Stitch together, dropping empty pieces.
    join_nonempty(
        [NameCode, ArityCode, StructCode, SetCode, GetCode],
        Code).

join_nonempty(Pieces, Code) :-
    exclude(=(""), Pieces, NonEmpty),
    atomic_list_concat(NonEmpty, '\n', CodeAtom),
    atom_string(CodeAtom, Code).
