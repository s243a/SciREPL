/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2025 John William Creighton (s243a)
 *
 * Target Registry - Central registry for UnifyWeaver compilation targets
 *
 * This module manages metadata about available targets, their runtime families,
 * and capabilities. It enables cross-target glue to determine how targets
 * should communicate.
 */

:- module(target_registry, [
    % Target registration
    register_target/3,          % register_target(Name, Family, Capabilities)
    unregister_target/1,        % unregister_target(Name)

    % Target queries
    target_exists/1,            % target_exists(Name)
    target_family/2,            % target_family(Target, Family)
    target_capabilities/2,      % target_capabilities(Target, Capabilities)
    targets_same_family/2,      % targets_same_family(Target1, Target2)

    % Family queries
    family_targets/2,           % family_targets(Family, Targets)

    % Listing
    list_targets/1,             % list_targets(Targets)
    list_families/1,            % list_families(Families)

    % Location defaults
    default_location/2,         % default_location(Target, Location)
    default_transport/3,        % default_transport(Location1, Location2, Transport)

    % Target module linking
    target_module/2,            % target_module(Target, Module)
    compile_to_target/4,        % compile_to_target(Target, Pred/Arity, Options, Code)
    
    % Capability queries
    target_has_capability/2,    % target_has_capability(Target, Capability)
    targets_with_capability/2   % targets_with_capability(Capability, Targets)
]).

:- use_module(library(lists)).

%% ============================================
%% Dynamic storage for targets
%% ============================================

:- dynamic registered_target/3.  % registered_target(Name, Family, Capabilities)

%% ============================================
%% Target Registration
%% ============================================

%% register_target(+Name, +Family, +Capabilities)
%  Register a new target with its runtime family and capabilities.
%  Capabilities is a list of atoms describing what the target supports.
%
%  Example:
%    register_target(python, python, [streaming, pipes, libraries, ml])
%
register_target(Name, Family, Capabilities) :-
    atom(Name),
    atom(Family),
    is_list(Capabilities),
    (   registered_target(Name, _, _)
    ->  retract(registered_target(Name, _, _))
    ;   true
    ),
    assertz(registered_target(Name, Family, Capabilities)).

%% unregister_target(+Name)
%  Remove a target from the registry.
%
unregister_target(Name) :-
    retractall(registered_target(Name, _, _)).

%% ============================================
%% Target Queries
%% ============================================

%% target_exists(+Name)
%  True if a target with the given name is registered.
%
target_exists(Name) :-
    registered_target(Name, _, _).

%% target_family(?Target, ?Family)
%  Query or check the runtime family of a target.
%
target_family(Target, Family) :-
    registered_target(Target, Family, _).

%% target_capabilities(?Target, ?Capabilities)
%  Query the capabilities list of a target.
%
target_capabilities(Target, Capabilities) :-
    registered_target(Target, _, Capabilities).

%% targets_same_family(+Target1, +Target2)
%  True if both targets belong to the same runtime family.
%  Targets in the same family can communicate in-process.
%
targets_same_family(Target1, Target2) :-
    target_family(Target1, Family),
    target_family(Target2, Family).

%% ============================================
%% Family Queries
%% ============================================

%% family_targets(+Family, -Targets)
%  Get all targets belonging to a runtime family.
%
family_targets(Family, Targets) :-
    findall(T, target_family(T, Family), Targets).

%% ============================================
%% Listing
%% ============================================

%% list_targets(-Targets)
%  Get a list of all registered target names.
%
list_targets(Targets) :-
    findall(Name, registered_target(Name, _, _), Targets).

%% list_families(-Families)
%  Get a list of all unique runtime families.
%
list_families(Families) :-
    findall(F, registered_target(_, F, _), AllFamilies),
    sort(AllFamilies, Families).

%% ============================================
%% Location and Transport Defaults
%% ============================================

%% default_location(+Target, -Location)
%  Get the default location type for a target.
%  Most targets default to local_process.
%
default_location(Target, in_process) :-
    target_family(Target, Family),
    in_process_family(Family),
    !.
default_location(_, local_process).

%% in_process_family(+Family)
%  Families that support in-process communication.
%
in_process_family(dotnet).
in_process_family(jvm).

%% default_transport(+Location1, +Location2, -Transport)
%  Get the default transport for communicating between two locations.
%
default_transport(in_process, in_process, direct) :- !.
default_transport(local_process, local_process, pipe) :- !.
default_transport(local_process, remote(_), http) :- !.
default_transport(remote(_), local_process, http) :- !.
default_transport(remote(_), remote(_), http) :- !.
default_transport(_, _, pipe).  % Fallback

%% ============================================
%% Built-in Target Definitions
%% ============================================

%% Initialize built-in targets on module load
register_builtin_targets :-
    % Shell family - always separate processes, pipe communication
    register_target(bash, shell, [streaming, pipes, process_control, scripting]),
    register_target(awk, shell, [streaming, pipes, regex, aggregation, text_processing]),
    register_target(perl, shell, [streaming, pipes, regex, scripting, text_processing]),

    % R family
    register_target(r, r, [streaming, pipes, data_science, statistical, vectorization]),
    register_target(typr, r, [streaming, pipes, data_science, statistical, vectorization, types, gradual_typing]),

    % Python family
    register_target(python, python, [streaming, pipes, libraries, ml, data_science]),
    register_target(wam_python, python, [compiled, streaming, wam, trail_backtracking, ml_interop, foreign_predicates]),
    register_target(ironpython, dotnet, [streaming, dotnet_interop, scripting]),

    % Ruby family
    register_target(ruby, ruby, [streaming, blocks, metaprogramming, gems, scripting]),

    % Lua family
    register_target(lua, lua, [scripting, fast, embedded, tables, coroutines]),
    register_target(wam_lua, lua, [compiled, scripting, embedded, wam, choice_points, hybrid, tables]),

    % .NET family - can share process
    register_target(csharp, dotnet, [compiled, streaming, linq, async]),
    register_target(csharp_native, dotnet, [compiled, streaming, linq, procedural, recursion]),
    register_target(fsharp, dotnet, [compiled, streaming, functional, linq]),
    register_target(wam_fsharp, dotnet, [compiled, streaming, functional, linq, wam, pattern_matching, choice_points]),
    register_target(powershell, dotnet, [scripting, streaming, system_admin, dotnet_interop]),

    % JVM family - can share process
    register_target(java, jvm, [compiled, streaming, enterprise]),
    register_target(scala, jvm, [compiled, streaming, functional]),
    register_target(clojure, jvm, [compiled, streaming, functional, lisp]),
    register_target(wam_clojure, jvm, [compiled, streaming, functional, lisp, wam, choice_points, hybrid]),
    register_target(jython, jvm, [scripting, jvm_interop]),
    register_target(kotlin, jvm, [compiled, streaming, android, coroutines]),
    register_target(wam_kotlin, jvm, [compiled, streaming, wam, hybrid, choice_points, coroutines]),
    register_target(jamaica, jvm, [assembly, bytecode, macros, native_lowering, recursion, bindings, components]),
    register_target(krakatau, jvm, [assembly, bytecode, roundtrip, native_lowering, recursion, bindings, components]),

    % Native family - compiled binaries
    register_target(go, native, [compiled, streaming, concurrency, cross_platform]),
    register_target(rust, native, [compiled, streaming, memory_safe, performance]),
    register_target(c, native, [compiled, performance, low_level]),
    register_target(wam_c, native, [compiled, performance, low_level, wam, manual_memory]),
    register_target(wam_cpp, native, [compiled, performance, low_level, wam, hybrid, manual_memory, choice_points]),

    % JavaScript family - runtime selection via js_runtime_choice/2
    register_target(typescript, javascript, [types, async, modules, generics]),
    register_target(node, javascript, [streaming, npm, filesystem, async]),
    register_target(deno, javascript, [typescript, permissions, secure, async]),
    register_target(bun, javascript, [fast, npm_compat, bundled, async]),
    register_target(browser, javascript, [dom, async, web_apis, fetch]),

    % Functional family
    register_target(haskell, functional, [compiled, types, lazy, pattern_matching]),

    % BEAM family
    register_target(elixir, beam, [compiled, streaming, functional, actors, pattern_matching]),

    % Low-level family
    register_target(llvm, lowlevel, [compiled, native, optimization]),
    register_target(wasm, lowlevel, [browser, sandboxed, portable]),
    register_target(wat, lowlevel, [browser, sandboxed, portable, structured_control_flow, native_lowering]),

    % Database
    register_target(sql, database, [queries, transactions, relational]).

:- register_builtin_targets.

%% ============================================
%% Target Module Linking
%% ============================================

:- dynamic target_module/2.  % target_module(Name, Module)

target_module(go, go_target).
target_module(rust, rust_target).
target_module(c, c_target).
target_module(wam_c, wam_c_target).
target_module(wam_cpp, wam_cpp_target).
target_module(csharp, csharp_target).
target_module(csharp_native, csharp_native_target).
target_module(fsharp, fsharp_target).
target_module(powershell, powershell_target).
target_module(java, java_target).
target_module(scala, scala_target).
target_module(kotlin, kotlin_target).
target_module(wam_kotlin, wam_kotlin_target).
target_module(clojure, clojure_target).
target_module(wam_clojure, wam_clojure_target).
target_module(jython, jython_target).
target_module(jamaica, jamaica_target).
target_module(krakatau, krakatau_target).
target_module(bash, bash_target).
target_module(awk, awk_target).
target_module(perl, perl_target).
target_module(python, python_target).
target_module(wam_python, wam_python_target).
target_module(r, r_target).
target_module(typr, typr_target).
target_module(ruby, ruby_target).
target_module(lua, lua_target).
target_module(wam_lua, wam_lua_target).
target_module(typescript, typescript_target).
target_module(haskell, haskell_target).
target_module(elixir, elixir_target).
target_module(wam_fsharp, wam_fsharp_target).
target_module(llvm, llvm_target).
target_module(wat, wat_target).
target_module(sql, sql_target).

%% compile_to_target(+Target, +Pred/Arity, +Options, -Code)
%  Unified dispatch to target modules.
%
compile_to_target(Target, PredArity, Options, Code) :-
    (   target_module(Target, Module)
    ->  Module:compile_predicate(PredArity, Options, Code)
    ;   format('Error: No module registered for target ~w~n', [Target]),
        fail
    ).

%% ============================================
%% Capability Queries
%% ============================================

%% target_has_capability(+Target, +Capability)
%  Check if a target has a specific capability.
%
target_has_capability(Target, Capability) :-
    target_capabilities(Target, Caps),
    member(Capability, Caps).

%% targets_with_capability(+Capability, -Targets)
%  Find all targets that have a specific capability.
%
targets_with_capability(Capability, Targets) :-
    findall(T, target_has_capability(T, Capability), Targets).
