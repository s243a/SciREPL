% =============================================================================
% prolog_term_parser.pl
%
% Portable Prolog term parser. Lives in the cross-target-compilable subset
% (the same constructs the WAM-R / WAM-Haskell / WAM-Scala backends consume),
% so the same source can serve as the canonical spec AND be transpiled into
% any target whose runtime needs to turn a string back into a term -- read/2,
% term_to_atom/2, read_term_from_atom/2,3, command-line arg parsing, etc.
%
% Operator tables are caller-supplied data rather than module-local dynamic
% state. Targets keep their own canonical op storage (e.g. WAM-R holds three
% R lists keyed by fixity) and pass a snapshot in at parse time. This keeps
% the parser pure, compiles cleanly, and matches how the runtime parser in
% templates/targets/r_wam/runtime.R.mustache already works.
%
% API
%   parse_term_from_codes(+Codes, +OpTable, -Term).
%   parse_term_from_codes(+Codes, +OpTable, -Term, -VarEnv).
%   parse_term_from_atom (+Atom,  +OpTable, -Term).
%   parse_term_from_atom (+Atom,  +OpTable, -Term, -VarEnv).
%   canonical_op_table(-OpTable).
%
% OpTable is a list of op(Name, Prec, Type) facts; Type is one of
% xfx | xfy | yfx | fx | fy | xf | yf.
%
% Variables sharing a source-level name share a Prolog logic variable
% within a single parse; '_' is anonymous (distinct each occurrence).
%
% Compatibility note: this implementation deliberately matches the
% Pratt-style algorithm in WamRuntime$wam_parse_expr. The xf/yf and
% fx/fy distinctions are not enforced under chained postfix / prefix
% application; both treat the operand precedence ceiling as
% `op_prec - 1`. Same simplification documented in the WAM-R handoff.
%
% Compile-target status: this source compiles cleanly to WAM-R
% (every predicate produces a label + wrapper; see
% tests/test_prolog_term_parser_wam_r_compile.pl), SWI runs it to
% spec, and WAM-R runs representative full-parser drivers end to
% end. R still keeps its inline parser as the hot runtime path
% because benchmarks show the WAM-compiled parser is much slower;
% this source remains the canonical cross-target parser spec and a
% proof that non-trivial parser code can be hosted by generated WAM
% runtimes.
% =============================================================================

:- module(prolog_term_parser, [
    parse_term_from_codes/3,
    parse_term_from_codes/4,
    parse_term_from_atom/3,
    parse_term_from_atom/4,
    canonical_op_table/1
]).

% -----------------------------------------------------------------------------
% Entry points
% -----------------------------------------------------------------------------

parse_term_from_atom(Atom, OpTable, Term) :-
    atom_codes(Atom, Codes),
    parse_term_from_codes(Codes, OpTable, Term).

parse_term_from_atom(Atom, OpTable, Term, VarEnv) :-
    atom_codes(Atom, Codes),
    parse_term_from_codes(Codes, OpTable, Term, VarEnv).

parse_term_from_codes(Codes, OpTable, Term) :-
    parse_term_from_codes(Codes, OpTable, Term, _VarEnv).

parse_term_from_codes(Codes, OpTable, Term, VarEnv) :-
    tokenize(Codes, Tokens),
    !,
    parse_expr(Tokens, OpTable, 1200, Term, _Prec, [], VarEnv, Rest),
    Rest == [].

% -----------------------------------------------------------------------------
% Canonical op table (mirrors WamRuntime$op_infix / op_prefix seeds)
% -----------------------------------------------------------------------------

canonical_op_table([
    op(':-',   1200, xfx),
    op('-->',  1200, xfx),
    op(';',    1100, xfy),
    op('->',   1050, xfy),
    op('*->',  1050, xfy),
    op(',',    1000, xfy),
    op('=',     700, xfx),
    op('\\=',   700, xfx),
    op('==',    700, xfx),
    op('\\==',  700, xfx),
    op('=..',   700, xfx),
    op('is',    700, xfx),
    op('=:=',   700, xfx),
    op('=\\=',  700, xfx),
    op('<',     700, xfx),
    op('>',     700, xfx),
    op('=<',    700, xfx),
    op('>=',    700, xfx),
    op('@<',    700, xfx),
    op('@>',    700, xfx),
    op('@=<',   700, xfx),
    op('@>=',   700, xfx),
    op('+',     500, yfx),
    op('-',     500, yfx),
    op('/\\',   500, yfx),
    op('\\/',   500, yfx),
    op('xor',   500, yfx),
    op('*',     400, yfx),
    op('/',     400, yfx),
    op('//',    400, yfx),
    op('mod',   400, yfx),
    op('rem',   400, yfx),
    op('div',   400, yfx),
    op('<<',    400, yfx),
    op('>>',    400, yfx),
    op('**',    200, xfx),
    op('^',     200, xfy),
    op(':-',   1200, fx),
    op('?-',   1200, fx),
    op('\\+',   900, fy),
    op('-',     200, fy),
    op('+',     200, fy),
    op('\\',    200, fy)
]).

% -----------------------------------------------------------------------------
% Tokenizer
% -----------------------------------------------------------------------------
% codes -> list of:
%   tk_atom(Name)        bare/quoted atoms, single-char solo atoms
%   tk_sym(Name)         symbol-run atoms (`+`, `=:=`, `\\=`, ...)
%   tk_num(Value)        integer or float
%   tk_var(Name)         variable; Name is the source-level identifier
%   tk_lparen / tk_rparen / tk_lbracket / tk_rbracket
%   tk_comma / tk_semicolon / tk_pipe

tokenize(Codes, Tokens) :-
    tokenize_loop(Codes, [], Reverse),
    reverse(Reverse, Tokens).

tokenize_loop([], Acc, Acc).
tokenize_loop([C|Cs], Acc, Out) :-
    (   ws_code(C)
    ->  tokenize_loop(Cs, Acc, Out)
    ;   tokenize_one([C|Cs], Acc, Acc1, Rest),
        tokenize_loop(Rest, Acc1, Out)
    ).

ws_code(32). ws_code(9). ws_code(10). ws_code(13).

% Single-char structural / solo tokens.
tokenize_one([0'(  |R], A, [tk_lparen    |A], R) :- !.
tokenize_one([0')  |R], A, [tk_rparen    |A], R) :- !.
tokenize_one([0'[  |R], A, [tk_lbracket  |A], R) :- !.
tokenize_one([0']  |R], A, [tk_rbracket  |A], R) :- !.
tokenize_one([0',  |R], A, [tk_comma     |A], R) :- !.
tokenize_one([0';  |R], A, [tk_semicolon |A], R) :- !.
tokenize_one([0'|  |R], A, [tk_pipe      |A], R) :- !.
tokenize_one([0'!  |R], A, [tk_atom('!') |A], R) :- !.

% Quoted atom: '...'. Handles \\ and \' escapes; bare \ followed by any
% other char keeps the next char literally (matches the R tokenizer).
tokenize_one([39|R], A, [tk_atom(Atom)|A], Rest) :-
    !,
    take_quoted(R, [], Cs, Rest),
    atom_codes(Atom, Cs).

% Signed number: a `-` followed by a digit, but only when the previous
% emitted token can't combine with `-` as an infix operator (so we don't
% mis-tokenise `X-1` as `X (-1)`). Acc holds the reverse of tokens emitted
% so far.
tokenize_one([0'-, D | R], A, [tk_num(N)|A], Rest) :-
    digit_code(D),
    can_lead_negative(A),
    !,
    take_number_after_sign(D, R, Cs, Rest),
    codes_to_number([0'-|Cs], N).

% Unsigned number.
tokenize_one([D|R], A, [tk_num(N)|A], Rest) :-
    digit_code(D),
    !,
    take_number_after_sign(D, R, Cs, Rest),
    codes_to_number(Cs, N).

% Variable: starts with uppercase or underscore.
tokenize_one([C|R], A, [tk_var(Name)|A], Rest) :-
    var_start_code(C),
    !,
    take_ident([C|R], Cs, Rest),
    atom_codes(Name, Cs).

% Bare atom: lowercase start.
tokenize_one([C|R], A, [tk_atom(Atom)|A], Rest) :-
    lower_code(C),
    !,
    take_ident([C|R], Cs, Rest),
    atom_codes(Atom, Cs).

% Symbol-run atom.
tokenize_one([C|R], A, [tk_sym(Atom)|A], Rest) :-
    sym_code(C),
    !,
    take_syms([C|R], Cs, Rest),
    atom_codes(Atom, Cs).

% Anything else: fail the whole tokenize (unrecognized character).

% --- character classes -------------------------------------------------------

digit_code(C) :- C >= 48, C =< 57.
lower_code(C) :- C >= 97, C =< 122.
upper_code(C) :- C >= 65, C =< 90.
var_start_code(C) :- upper_code(C).
var_start_code(95).                     % `_`
ident_cont(C) :- lower_code(C).
ident_cont(C) :- upper_code(C).
ident_cont(C) :- digit_code(C).
ident_cont(95).                         % `_`

% Same set as the R tokenizer's sym_chars: + - * / \ ^ < > = : @ . ? ~ # $ &.
sym_code(43). sym_code(45). sym_code(42). sym_code(47). sym_code(92).
sym_code(94). sym_code(60). sym_code(62). sym_code(61). sym_code(58).
sym_code(64). sym_code(46). sym_code(63). sym_code(126). sym_code(35).
sym_code(36). sym_code(38).

% --- string-eating helpers ---------------------------------------------------

take_ident([], [], []).
take_ident([C|R], [C|Cs], Rest) :- ident_cont(C), !, take_ident(R, Cs, Rest).
take_ident([C|R], [], [C|R])    :- \+ ident_cont(C).

take_syms([], [], []).
take_syms([C|R], [C|Cs], Rest) :- sym_code(C), !, take_syms(R, Cs, Rest).
take_syms([C|R], [], [C|R])    :- \+ sym_code(C).

% Consume digits, then optional `.digits` for a float. The first digit is
% already consumed by the caller (passed in via Lead); we splice it back.
take_number_after_sign(Lead, R, [Lead|Cs], Rest) :-
    take_digits(R, IntCs, Rest1),
    (   Rest1 = [0'., D | Rest2], digit_code(D)
    ->  take_digits(Rest2, FracCs, Rest),
        append(IntCs, [0'., D | FracCs], Cs)
    ;   Cs = IntCs, Rest = Rest1
    ).

take_digits([], [], []).
take_digits([C|R], [C|Cs], Rest) :- digit_code(C), !, take_digits(R, Cs, Rest).
take_digits([C|R], [], [C|R])    :- \+ digit_code(C).

% Quoted atom body. ' ends the literal; \ acts as a one-char escape so '\''
% and '\\' both round-trip.
take_quoted([39|R], Cs, Cs, R) :- !.
take_quoted([92, C | R], Acc, Out, Rest) :-
    !,
    append(Acc, [C], Acc1),
    take_quoted(R, Acc1, Out, Rest).
take_quoted([C|R], Acc, Out, Rest) :-
    append(Acc, [C], Acc1),
    take_quoted(R, Acc1, Out, Rest).

% codes_to_number: codes -> integer or float. number_codes/2 handles
% both shapes, so the float-vs-int check the original ITE did was
% redundant. Single-clause body avoids the WAM CutIte dependency.
codes_to_number(Cs, N) :-
    number_codes(N, Cs).

% can_lead_negative: a bare `-` followed by a digit is a signed-number lead
% only when the previous emitted token (top of Acc, a reverse stack) is a
% structural separator -- otherwise the `-` is the infix subtraction op.
can_lead_negative([]).
can_lead_negative([T|_]) :- separator_token(T).

separator_token(tk_comma).
separator_token(tk_semicolon).
separator_token(tk_lparen).
separator_token(tk_lbracket).
separator_token(tk_pipe).

% -----------------------------------------------------------------------------
% Parser (Pratt-style)
% -----------------------------------------------------------------------------

% parse_expr(+Tokens, +OpTable, +MaxPrec, -Term, -TermPrec, +Env0, -Env, -Rest).
%   Returns the parsed term plus its precedence so the caller (the
%   recursive parse_op_loop) can enforce strict-vs-non-strict
%   associativity rules: xfx/xfy/xf require lhs strictly less than
%   the op's prec; yfx/yf accept lhs at op prec (left-fold).
parse_expr(Tokens0, OpTable, MaxPrec, Term, TermPrec, Env0, Env, Rest) :-
    parse_primary(Tokens0, OpTable, MaxPrec, Left, LeftPrec, Env0, Env1, Tokens1),
    parse_op_loop(Tokens1, OpTable, MaxPrec, Left, LeftPrec,
                  Term, TermPrec, Env1, Env, Rest).

parse_op_loop([], _, _, Left, LeftPrec, Left, LeftPrec, Env, Env, []).
parse_op_loop([T|Toks], OpTable, MaxPrec, Left, LeftPrec,
              Term, TermPrec, Env0, Env, Rest) :-
    token_op_name(T, Name),
    resolve_infix(Name, OpTable, Prec, Type),
    Prec =< MaxPrec,
    infix_lhs_ok(Type, LeftPrec, Prec),
    !,
    rhs_max_prec(Type, Prec, RhsMax),
    parse_expr(Toks, OpTable, RhsMax, Right, _, Env0, Env1, Toks1),
    T2 =.. [Name, Left, Right],
    parse_op_loop_continue(Toks1, OpTable, MaxPrec, T2, Prec,
                           Term, TermPrec, Env1, Env, Rest).
parse_op_loop([T|Toks], OpTable, MaxPrec, Left, LeftPrec,
              Term, TermPrec, Env0, Env, Rest) :-
    token_op_name(T, Name),
    resolve_postfix(Name, OpTable, Prec, PType),
    Prec =< MaxPrec,
    postfix_lhs_ok(PType, LeftPrec, Prec),
    !,
    T2 =.. [Name, Left],
    parse_op_loop_continue(Toks, OpTable, MaxPrec, T2, Prec,
                           Term, TermPrec, Env0, Env, Rest).
parse_op_loop([T|Toks], _, _, Left, LeftPrec,
              Left, LeftPrec, Env, Env, [T|Toks]).

parse_op_loop_continue([], _, _, Term, TermPrec,
                       Term, TermPrec, Env, Env, []) :- !.
parse_op_loop_continue(Toks, OpTable, MaxPrec, Left, LeftPrec,
                       Term, TermPrec, Env0, Env, Rest) :-
    parse_op_loop(Toks, OpTable, MaxPrec, Left, LeftPrec,
                  Term, TermPrec, Env0, Env, Rest).

% infix_lhs_ok / postfix_lhs_ok: enforce strict (xfx/xfy/xf) vs
% non-strict (yfx/yf) lhs precedence.
infix_lhs_ok(yfx, LeftPrec, OpPrec) :- !, LeftPrec =< OpPrec.
infix_lhs_ok(_,   LeftPrec, OpPrec) :- LeftPrec < OpPrec.

postfix_lhs_ok(yf, LeftPrec, OpPrec) :- !, LeftPrec =< OpPrec.
postfix_lhs_ok(_,  LeftPrec, OpPrec) :- LeftPrec < OpPrec.

% parse_primary: the leading token of an expression. Number / var / atom /
% list / parenthesised / prefix-op application. Returns the parsed term
% AND its precedence (0 for atomic / list / parens / functor, op_prec
% for a prefix-op application) so parse_op_loop can enforce
% strict-vs-non-strict associativity.
parse_primary([tk_num(V)|R], _, _, V, 0, Env, Env, R) :- !.

parse_primary([tk_var(Name)|R], _, _, V, 0, Env0, Env, R) :- !,
    bind_var(Name, V, Env0, Env).

parse_primary([tk_atom(Name)|R], OpTable, MaxPrec, Term, TermPrec, Env0, Env, Rest) :- !,
    parse_atom_head(Name, R, OpTable, MaxPrec, Term, TermPrec, Env0, Env, Rest).

parse_primary([tk_sym(Name)|R], OpTable, MaxPrec, Term, TermPrec, Env0, Env, Rest) :- !,
    parse_atom_head(Name, R, OpTable, MaxPrec, Term, TermPrec, Env0, Env, Rest).

parse_primary([tk_lparen|R], OpTable, _, Term, 0, Env0, Env, Rest) :- !,
    parse_expr(R, OpTable, 1200, Term, _, Env0, Env, [tk_rparen|Rest]).

parse_primary([tk_lbracket|R], OpTable, _, Term, 0, Env0, Env, Rest) :- !,
    parse_list_body(R, OpTable, Term, Env0, Env, Rest).

% parse_atom_head: an atom token at primary position can be (1) a functor
% application (atom immediately followed by `(`), (2) a prefix-op application,
% or (3) a stand-alone atom. Functor / atom are precedence 0; prefix-op is
% the op's own precedence so chained `\+ \+ X` differs correctly between
% `op(900, fx, \+)` and `op(900, fy, \+)`.
parse_atom_head(Name, [tk_lparen|R], OpTable, _, Term, 0, Env0, Env, Rest) :- !,
    parse_args(R, OpTable, Args, Env0, Env, Rest),
    Term =.. [Name|Args].
parse_atom_head(Name, R, OpTable, MaxPrec, Term, Prec, Env0, Env, Rest) :-
    R = [Next|_],
    starts_term(Next),
    resolve_prefix(Name, OpTable, Prec, Type),
    Prec =< MaxPrec,
    !,
    prefix_rhs_max(Type, Prec, OperandMax),
    parse_expr(R, OpTable, OperandMax, Operand, _, Env0, Env, Rest),
    Term =.. [Name, Operand].
parse_atom_head(Name, R, _, _, Name, 0, Env, Env, R).

prefix_rhs_max(fy, Prec, Prec) :- !.
prefix_rhs_max(_,  Prec, Max)  :- Max is Prec - 1.

% parse_args: comma-separated arg list inside `(...)`, max_prec 999 so the
% top-level comma operator (1000) doesn't get folded in.
parse_args(Tokens, OpTable, [Arg|Rest], Env0, Env, RestOut) :-
    parse_expr(Tokens, OpTable, 999, Arg, _ArgPrec, Env0, Env1, Tokens1),
    (   Tokens1 = [tk_comma|Tokens2]
    ->  parse_args(Tokens2, OpTable, Rest, Env1, Env, RestOut)
    ;   Tokens1 = [tk_rparen|RestOut]
    ->  Rest = [], Env = Env1
    ).

% parse_list_body: handles `[]`, `[a, b, c]`, `[H|T]`. Element max_prec 999
% (matches parse_args).
parse_list_body([tk_rbracket|R], _, [], Env, Env, R) :- !.
parse_list_body(Tokens, OpTable, List, Env0, Env, Rest) :-
    parse_list_elems(Tokens, OpTable, Elems, Tail, Env0, Env, Rest),
    list_build(Elems, Tail, List).

parse_list_elems(Tokens, OpTable, [E|Rest], Tail, Env0, Env, RestOut) :-
    parse_expr(Tokens, OpTable, 999, E, _EPrec, Env0, Env1, Tokens1),
    (   Tokens1 = [tk_comma|Tokens2]
    ->  parse_list_elems(Tokens2, OpTable, Rest, Tail, Env1, Env, RestOut)
    ;   Tokens1 = [tk_pipe|Tokens2]
    ->  parse_expr(Tokens2, OpTable, 999, Tail, _TPrec, Env1, Env, Tokens3),
        Tokens3 = [tk_rbracket|RestOut],
        Rest = []
    ;   Tokens1 = [tk_rbracket|RestOut]
    ->  Rest = [], Tail = [], Env = Env1
    ).

list_build([], Tail, Tail).
list_build([E|Es], Tail, [E|Rest]) :- list_build(Es, Tail, Rest).

% --- token / op resolution ---------------------------------------------------

token_op_name(tk_atom(N),    N).
token_op_name(tk_sym(N),     N).
token_op_name(tk_comma,      ',').
token_op_name(tk_semicolon,  ';').

resolve_infix(Name, OpTable, Prec, Type) :-
    member(op(Name, Prec, Type), OpTable),
    is_infix_type(Type),
    !.

resolve_postfix(Name, OpTable, Prec, Type) :-
    member(op(Name, Prec, Type), OpTable),
    is_postfix_type(Type),
    !.

resolve_prefix(Name, OpTable, Prec, Type) :-
    member(op(Name, Prec, Type), OpTable),
    is_prefix_type(Type),
    !.

is_infix_type(xfx).
is_infix_type(xfy).
is_infix_type(yfx).
is_postfix_type(xf).
is_postfix_type(yf).
is_prefix_type(fx).
is_prefix_type(fy).

% rhs_max_prec: xfy keeps the rhs at op_prec (right-associative); xfx/yfx
% drop one (xfx forbids same-prec rhs; yfx folds left through the outer loop
% since each iteration starts at the same MaxPrec ceiling).
rhs_max_prec(xfy, Prec, Prec).
rhs_max_prec(xfx, Prec, Prec1) :- Prec1 is Prec - 1.
rhs_max_prec(yfx, Prec, Prec1) :- Prec1 is Prec - 1.

starts_term(tk_num(_)).
starts_term(tk_var(_)).
starts_term(tk_atom(_)).
starts_term(tk_sym(_)).
starts_term(tk_lparen).
starts_term(tk_lbracket).

% --- variable env ------------------------------------------------------------

% bind_var(+Name, -Var, +Env0, -Env).
%   Looks up Name in Env. If found, unifies Var with the existing logic var.
%   Otherwise adds Name-Var and returns the extended env. The atom '_' is
%   anonymous: every occurrence yields a fresh var.
bind_var('_', _Fresh, Env, Env) :- !.
bind_var(Name, Var, Env, Env) :-
    member(Name-V, Env),
    !,
    Var = V.
bind_var(Name, Var, Env, [Name-Var|Env]).
