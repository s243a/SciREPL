% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% ============================================================================
% Generic LLM Query Module for LogiForge
% ============================================================================
% Provides a generic interface for querying any LLM via local or HTTP modes
% Integrates with LogiForge configuration and supports multiple providers

:- module(query_llm, [
    query_llm/3,           % Main interface: query_llm(Mode, Config, BashScript)
    query_llm/4,           % Extended: query_llm(Mode, Provider, Config, BashScript)
    configure_llm/2,       % Configure global LLM settings
    register_provider/3,   % Register new LLM providers
    detect_packages/2      % Package detection utility
]).

% ============================================================================
% Configuration Management
% ============================================================================

:- dynamic llm_config/2.
:- dynamic llm_provider/3.  % provider(Name, LocalSupport, HttpSupport)
:- dynamic package_detector/2.  % package_detector(Package, DetectorCode)

% Default global configuration
llm_config(trace, '0').
llm_config(python, 'python3').
llm_config(timeout, '30').
llm_config(max_tokens, '500').
llm_config(temperature, '0.7').
llm_config(assumed_packages, []).

% Register built-in providers
llm_provider(phi3, true, true).
llm_provider(llama2, true, true).
llm_provider(gpt2, true, false).
llm_provider(claude, false, true).
llm_provider(ollama, false, true).
llm_provider(openai, false, true).

% Configure LLM settings
configure_llm(Key, Value) :-
    retractall(llm_config(Key, _)),
    assertz(llm_config(Key, Value)).

% Register new provider
register_provider(Name, LocalSupport, HttpSupport) :-
    retractall(llm_provider(Name, _, _)),
    assertz(llm_provider(Name, LocalSupport, HttpSupport)).

% ============================================================================
% Main Interface
% ============================================================================

% query_llm(+Mode, +Config, -BashScript)
% Mode: local | http | auto
% Config: list of key-value pairs
query_llm(Mode, Config, BashScript) :-
    get_config_value(provider, Config, phi3, Provider),  % Default to phi3
    query_llm(Mode, Provider, Config, BashScript).

% query_llm(+Mode, +Provider, +Config, -BashScript)
query_llm(Mode, Provider, Config, BashScript) :-
    validate_mode_provider(Mode, Provider),
    merge_configs(Config, MergedConfig),
    generate_llm_bash_script(Mode, Provider, MergedConfig, BashScript).

% Validate mode and provider compatibility
validate_mode_provider(auto, _) :- !.
validate_mode_provider(local, Provider) :-
    llm_provider(Provider, true, _), !.
validate_mode_provider(http, Provider) :-
    llm_provider(Provider, _, true), !.
validate_mode_provider(Mode, Provider) :-
    throw(error(invalid_mode_provider(Mode, Provider), 
                'Provider does not support requested mode')).

% ============================================================================
% Configuration Utilities
% ============================================================================

% Merge user config with defaults
merge_configs(UserConfig, MergedConfig) :-
    findall(Key-Value, llm_config(Key, Value), Defaults),
    merge_config_lists(Defaults, UserConfig, MergedConfig).

merge_config_lists([], UserConfig, UserConfig).
merge_config_lists([Key-DefaultValue|Rest], UserConfig, MergedConfig) :-
    ( get_config_value(Key, UserConfig, _, _) ->
        merge_config_lists(Rest, UserConfig, MergedConfig)
    ; merge_config_lists(Rest, [Key-DefaultValue|UserConfig], MergedConfig)
    ).

get_config_value(Key, Config, Default, Value) :-
    ( member(Key-Value, Config) -> true
    ; Value = Default
    ).

% ============================================================================
% Package Detection System
% ============================================================================

% Read LogiForge Python paths
read_python_paths(Paths) :-
    findall(Path, find_python_path(Path), Paths).

find_python_path(Path) :-
    python_paths_file(File),
    exists_file(File),
    setup_call_cleanup(
        open(File, read, Stream),
        read_path_from_stream(Stream, Path),
        close(Stream)
    ).

python_paths_file('config/python_paths.txt').
python_paths_file('../config/python_paths.txt').
python_paths_file(File) :-
    prolog_load_context(directory, Dir),
    atomic_list_concat([Dir, '/config/python_paths.txt'], File).

read_path_from_stream(Stream, Path) :-
    read_line_to_string(Stream, Line),
    Line \= end_of_file,
    ( ( Line \= "",
        \+ sub_string(Line, 0, 1, _, "#") ) ->
        Path = Line
    ; read_path_from_stream(Stream, Path)
    ).

% Read assumed packages
read_assumed_packages(Packages) :-
    ( exists_file('config/assumed_packages.txt') ->
        setup_call_cleanup(
            open('config/assumed_packages.txt', read, Stream),
            read_all_packages(Stream, Packages),
            close(Stream))
    ; Packages = []
    ).

read_all_packages(Stream, Packages) :-
    read_string(Stream, _, Content),
    split_string(Content, "\n", "\r\t #", Lines),
    findall(P, (member(L, Lines), L \= "", atom_string(P, L)), Packages).

% Generate package detection code
detect_packages(Package, BashCode) :-
    package_detector(Package, BashCode), !.
detect_packages(Package, BashCode) :-
    generate_default_detector(Package, BashCode).

generate_default_detector(Package, BashCode) :-
    format(atom(BashCode), '
detect_~w() {
    local HAS_PACKAGE=0
    local PACKAGE_PATH=""
    
    # Check LogiForge paths
    for path in "${LOGIFORGE_PYTHON_PATHS[@]}"; do
        if [[ -f "$path/~w/__init__.py" ]]; then
            PACKAGE_PATH="$path"
            HAS_PACKAGE=1
            return 0
        fi
    done
    
    # Check global installation
    if $PYTHON -c "import ~w" 2>/dev/null; then
        HAS_PACKAGE=1
        PACKAGE_PATH="global"
        return 0
    fi
    
    return 1
}', [Package, Package, Package]).

% ============================================================================
% Bash Script Generation
% ============================================================================

generate_llm_bash_script(Mode, Provider, Config, BashScript) :-
    get_config_value(model, Config, 'default-model', Model),
    get_config_value(host, Config, 'localhost', Host),
    get_config_value(port, Config, '11434', Port),
    get_config_value(trace, Config, '0', Trace),
    get_config_value(python, Config, 'python3', Python),
    get_config_value(timeout, Config, '30', Timeout),
    get_config_value(max_tokens, Config, '500', MaxTokens),
    get_config_value(temperature, Config, '0.7', Temperature),
    
    read_python_paths(PythonPaths),
    read_assumed_packages(_AssumedPackages),

    % Generate mode-specific code
    generate_mode_functions(Mode, Provider, Config, ModeFunctions),
    
    % Generate provider-specific code
    generate_provider_code(Provider, Config, ProviderCode),
    
    % Generate package detection code
    get_required_packages(Provider, Mode, RequiredPackages),
    generate_detection_code(RequiredPackages, DetectionCode),
    
    format(atom(BashScript), '#!/bin/bash
# ============================================================================
# LogiForge Generic LLM Query Script
# Provider: ~w | Mode: ~w
# ============================================================================

set -euo pipefail

# Configuration
LLM_PROVIDER="~w"
LLM_MODE="~w"
LLM_MODEL="${LLM_MODEL:-~w}"
LLM_HOST="${LLM_HOST:-~w}"
LLM_PORT="${LLM_PORT:-~w}"
TRACE="${TRACE:-~w}"
PYTHON="${PYTHON:-~w}"
TIMEOUT="${TIMEOUT:-~w}"
MAX_TOKENS="${MAX_TOKENS:-~w}"
TEMPERATURE="${TEMPERATURE:-~w}"

# LogiForge Python paths
LOGIFORGE_PYTHON_PATHS=(~w)

# Platform detection
IS_CYGWIN=$([[ "$(uname -s)" == CYGWIN* ]] && echo 1 || echo 0)

# Path conversion utility
convert_path() {
    local path="$1"
    if [[ $IS_CYGWIN -eq 1 ]] && command -v cygpath >/dev/null 2>&1; then
        if [[ "$path" =~ ^[A-Za-z]: ]]; then
            cygpath -u "$path"
        else
            echo "$path"
        fi
    else
        echo "$path"
    fi
}

# Convert all paths
for i in "${!LOGIFORGE_PYTHON_PATHS[@]}"; do
    LOGIFORGE_PYTHON_PATHS[$i]=$(convert_path "${LOGIFORGE_PYTHON_PATHS[$i]}")
done

~w

~w

~w

# Main query function
query_llm() {
    local prompt="$1"
    local mode="${2:-$LLM_MODE}"
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Provider: $LLM_PROVIDER, Mode: $mode" >&2
    
    case "$mode" in
        local)
            query_llm_local "$prompt"
            ;;
        http)
            query_llm_http "$prompt"
            ;;
        auto)
            if command -v query_llm_local >/dev/null 2>&1; then
                query_llm_local "$prompt" || query_llm_http "$prompt"
            else
                query_llm_http "$prompt"
            fi
            ;;
        *)
            echo "Error: Invalid mode: $mode" >&2
            return 1
            ;;
    esac
}

# Entry point
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [[ $# -eq 0 ]]; then
        echo "Usage: $0 \"prompt\" [mode]"
        echo "Modes: local, http, auto"
        echo "Provider: $LLM_PROVIDER"
        echo "Model: $LLM_MODEL"
        exit 1
    fi
    
    query_llm "$@"
fi
', [Provider, Mode, Provider, Mode, Model, Host, Port, Trace, Python, 
    Timeout, MaxTokens, Temperature, 
    format_list(PythonPaths), DetectionCode, ProviderCode, ModeFunctions]).

% Format list for bash array
format_list([], '').
format_list(List, Formatted) :-
    maplist(quote_item, List, Quoted),
    atomic_list_concat(Quoted, ' ', Formatted).

quote_item(Item, Quoted) :-
    format(atom(Quoted), '"~w"', [Item]).

% ============================================================================
% Mode-Specific Function Generation
% ============================================================================

generate_mode_functions(local, Provider, Config, Functions) :-
    generate_local_function(Provider, Config, Functions).
generate_mode_functions(http, Provider, Config, Functions) :-
    generate_http_function(Provider, Config, Functions).
generate_mode_functions(auto, Provider, Config, Functions) :-
    generate_local_function(Provider, Config, LocalFunc),
    generate_http_function(Provider, Config, HttpFunc),
    format(atom(Functions), '~w~n~n~w', [LocalFunc, HttpFunc]).

% Generate local mode function
generate_local_function(Provider, _Config, Function) :-
    format(atom(Function), '
query_llm_local() {
    local prompt="$1"
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Querying ~w locally" >&2
    
    # Provider-specific local implementation
    if command -v query_~w_local >/dev/null 2>&1; then
        query_~w_local "$prompt"
    else
        echo "Error: Local mode not implemented for ~w" >&2
        return 1
    fi
}', [Provider, Provider, Provider, Provider]).

% Generate HTTP mode function
generate_http_function(Provider, _Config, Function) :-
    format(atom(Function), '
query_llm_http() {
    local prompt="$1"
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Querying ~w via HTTP" >&2
    
    # Provider-specific HTTP implementation
    if command -v query_~w_http >/dev/null 2>&1; then
        query_~w_http "$prompt"
    else
        # Generic HTTP fallback
        query_generic_http "$prompt"
    fi
}

query_generic_http() {
    local prompt="$1"
    
    $PYTHON <<\'PYEOF\'
import sys, json, os

try:
    import requests
    
    prompt = """\'$prompt\'"""
    host = os.environ.get("LLM_HOST", "localhost")
    port = os.environ.get("LLM_PORT", "11434")
    
    # Try common API formats
    endpoints = [
        (f"http://{host}:{port}/api/generate", "ollama"),
        (f"http://{host}:{port}/v1/completions", "openai"),
        (f"http://{host}:{port}/completions", "generic")
    ]
    
    for url, api_type in endpoints:
        try:
            if api_type == "ollama":
                resp = requests.post(url, json={
                    "model": os.environ.get("LLM_MODEL", "phi3"),
                    "prompt": prompt,
                    "stream": False
                }, timeout=30)
            else:
                resp = requests.post(url, json={
                    "model": os.environ.get("LLM_MODEL", "default"),
                    "prompt": prompt,
                    "max_tokens": int(os.environ.get("MAX_TOKENS", "500"))
                }, timeout=30)
            
            if resp.status_code == 200:
                data = resp.json()
                if "response" in data:
                    text = data["response"]
                elif "choices" in data:
                    text = data["choices"][0].get("text", "")
                else:
                    text = str(data)
                print(json.dumps({"success": True, "response": text}))
                sys.exit(0)
        except:
            continue
    
    print(json.dumps({"success": False, "error": "No working endpoint found"}))
    
except ImportError:
    print(json.dumps({"success": False, "error": "requests not installed"}))
\'PYEOF
}', [Provider, Provider, Provider]).

% ============================================================================
% Provider-Specific Code Generation
% ============================================================================

generate_provider_code(phi3, _Config, Code) :-
    Code = '
# Phi3-specific functions
query_phi3_local() {
    local prompt="$1"
    echo "Error: Phi3 local mode requires model file" >&2
    return 1
}

query_phi3_http() {
    query_generic_http "$1"
}'.

generate_provider_code(ollama, _Config, Code) :-
    Code = '
# Ollama-specific functions
query_ollama_http() {
    local prompt="$1"
    
    curl -s "$LLM_HOST:$LLM_PORT/api/generate" \
        -H "Content-Type: application/json" \
        -d "{\"model\":\"$LLM_MODEL\",\"prompt\":\"$prompt\",\"stream\":false}" \
        | $PYTHON -c "import sys,json; print(json.load(sys.stdin).get(\'response\',\'\'))"
}'.

generate_provider_code(claude, _Config, Code) :-
    Code = '
# Claude-specific functions (requires API key)
query_claude_http() {
    local prompt="$1"
    
    if [[ -z "$ANTHROPIC_API_KEY" ]]; then
        echo "Error: ANTHROPIC_API_KEY not set" >&2
        return 1
    fi
    
    curl -s https://api.anthropic.com/v1/messages \
        -H "x-api-key: $ANTHROPIC_API_KEY" \
        -H "anthropic-version: 2023-06-01" \
        -H "content-type: application/json" \
        -d "{\"model\":\"$LLM_MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"$prompt\"}],\"max_tokens\":$MAX_TOKENS}" \
        | $PYTHON -c "import sys,json; d=json.load(sys.stdin); print(d.get(\'content\',[{}])[0].get(\'text\',\'\'))"
}'.

generate_provider_code(_Provider, _Config, Code) :-
    Code = '# No provider-specific code'.

% ============================================================================
% Package Detection Code Generation
% ============================================================================

get_required_packages(phi3, local, ['transformers', 'torch']).
get_required_packages(phi3, http, ['requests']).
get_required_packages(ollama, _, ['requests']).
get_required_packages(claude, _, ['requests']).
get_required_packages(_, _, ['requests']).  % Default

generate_detection_code(Packages, Code) :-
    maplist(detect_packages, Packages, Detectors),
    atomic_list_concat(Detectors, '\n', Code).

% ============================================================================
% Testing and Examples
% ============================================================================

test_query_llm :-
    format('~n=== Testing Generic LLM Module ===~n', []),
    
    % Test 1: Generate HTTP script for Phi3
    format('~nTest 1: Phi3 HTTP mode~n', []),
    query_llm(http, [provider-phi3, model-'phi3-mini'], Script1),
    format('Generated ~w bytes~n', [atom_length(Script1)]),
    
    % Test 2: Generate local script for Llama2
    format('~nTest 2: Llama2 local mode~n', []),
    query_llm(local, [provider-llama2, model-'llama2-7b'], Script2),
    format('Generated ~w bytes~n', [atom_length(Script2)]),
    
    % Test 3: Auto mode for Claude
    format('~nTest 3: Claude auto mode~n', []),
    query_llm(auto, claude, [model-'claude-3-opus'], Script3),
    format('Generated ~w bytes~n', [atom_length(Script3)]),
    
    format('~n=== All tests completed ===~n', []).

% Export script
export_llm_script(Mode, Provider, Config, Filename) :-
    query_llm(Mode, Provider, Config, Script),
    open(Filename, write, Stream),
    write(Stream, Script),
    close(Stream),
    format('Exported ~w script for ~w to ~w~n', [Mode, Provider, Filename]).