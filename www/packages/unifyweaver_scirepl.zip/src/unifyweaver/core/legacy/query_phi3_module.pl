% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% query_phi3(+Prompt, -Response)
%
% Purpose: Interface predicate for querying the Phi-3 language model
% This predicate generates bash code with embedded Python that:
%   1. Checks LogiForge config/python_paths.txt for agentRag
%   2. Checks if agentRag is globally installed (pip)
%   3. Uses agentRag's LocalModelManager if available
%   4. Falls back to direct HTTP calls if not
%
% Arguments:
%   Prompt   - The input query/prompt to send to the Phi-3 model
%   Response - The generated response from the model OR generated bash code
%
% Configuration:
%   config/python_paths.txt     - Additional Python module roots
%   config/assumed_packages.txt - Packages to assume are available

:- module(query_phi3_module, [query_phi3/2, configure_phi3/2]).

% Configuration predicates
:- dynamic phi3_config/2.

% Default configuration
phi3_config(model, 'microsoft/phi-3-mini-4k-instruct').
phi3_config(host, 'localhost').
phi3_config(port, '11434').
phi3_config(trace, '0').
phi3_config(assume_agentrag, false).

% Configure options
configure_phi3(Key, Value) :-
    retractall(phi3_config(Key, _)),
    assertz(phi3_config(Key, Value)).

% Main entry point
query_phi3(generate_bash, BashScript) :-
    !,
    generate_phi3_bash_script(BashScript).

query_phi3(Prompt, Response) :-
    atom_string(Prompt, PromptStr),
    % For actual queries, we generate a specialized bash script
    generate_query_bash(PromptStr, BashScript),
    % In a real implementation, this would execute the bash script
    % For now, return the script as the response
    Response = BashScript.

% Read LogiForge Python paths configuration
read_logiforge_python_paths(Paths) :-
    % Try to find config file
    ( exists_file('config/python_paths.txt') ->
        ConfigFile = 'config/python_paths.txt'
    ; exists_file('../config/python_paths.txt') ->
        ConfigFile = '../config/python_paths.txt'
    ; prolog_load_context(directory, Dir),
      atomic_list_concat([Dir, '/config/python_paths.txt'], ConfigFile),
      exists_file(ConfigFile)
    ),
    !,
    setup_call_cleanup(
        open(ConfigFile, read, Stream),
        read_python_paths_from_stream(Stream, Paths),
        close(Stream)
    ).
read_logiforge_python_paths([]).

read_python_paths_from_stream(Stream, Paths) :-
    read_string(Stream, _, Content),
    split_string(Content, "\n", "\r\t ", Lines),
    findall(Path, 
            (member(Line, Lines),
             \+ sub_string(Line, 0, 1, _, "#"),
             Line \= "",
             Path = Line),
            Paths).

% Read assumed packages configuration
read_assumed_packages(Packages) :-
    ( exists_file('config/assumed_packages.txt') ->
        ConfigFile = 'config/assumed_packages.txt'
    ; Packages = []
    ),
    !,
    ( ConfigFile \= [] ->
        setup_call_cleanup(
            open(ConfigFile, read, Stream),
            read_packages_from_stream(Stream, Packages),
            close(Stream)
        )
    ; true
    ).

read_packages_from_stream(Stream, Packages) :-
    read_string(Stream, _, Content),
    split_string(Content, "\n", "\r\t ", Lines),
    findall(Package, 
            (member(Line, Lines),
             \+ sub_string(Line, 0, 1, _, "#"),
             Line \= "",
             Package = Line),
            Packages).

% Generate the full bash script with comprehensive detection
generate_phi3_bash_script(BashScript) :-
    phi3_config(model, Model),
    phi3_config(host, Host),
    phi3_config(port, Port),
    phi3_config(trace, Trace),
    phi3_config(assume_agentrag, AssumeAgentRag),
    read_logiforge_python_paths(PythonPaths),
    read_assumed_packages(AssumedPackages),
    
    % Convert paths to bash array format
    format_paths_for_bash(PythonPaths, BashPaths),
    format_packages_for_bash(AssumedPackages, BashPackages),
    
    format(atom(BashScript), '#!/bin/bash
# ============================================================================
# LogiForge - Phi3 Query Script with Comprehensive Package Detection
# ============================================================================
# Auto-generated bash script with embedded Python for LLM operations
# Integrates with LogiForge configuration system

set -euo pipefail

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

PHI3_MODEL="${PHI3_MODEL:-~w}"
PHI3_HOST="${PHI3_HOST:-~w}"
PHI3_PORT="${PHI3_PORT:-~w}"
TRACE="${TRACE:-~w}"
PYTHON="${PYTHON:-python3}"

# LogiForge configuration paths (from config/python_paths.txt)
LOGIFORGE_PYTHON_PATHS=(~w)

# Assumed packages (from config/assumed_packages.txt)
ASSUMED_PACKAGES=(~w)

# Assume agentRag is available (from Prolog configuration)
ASSUME_AGENTRAG=~w

# Detect if running on Cygwin
if [[ "$(uname -s)" == CYGWIN* ]]; then
    IS_CYGWIN=1
else
    IS_CYGWIN=0
fi

# ----------------------------------------------------------------------------
# Path Conversion Utilities
# ----------------------------------------------------------------------------

convert_path() {
    local path="$1"
    if [[ $IS_CYGWIN -eq 1 ]] && command -v cygpath >/dev/null 2>&1; then
        # Convert Windows paths to Cygwin paths
        if [[ "$path" =~ ^[A-Za-z]: ]]; then
            cygpath -u "$path"
        else
            echo "$path"
        fi
    else
        echo "$path"
    fi
}

# ----------------------------------------------------------------------------
# AgentRag Detection (Multi-layered)
# ----------------------------------------------------------------------------

HAS_AGENTRAG=0
AGENTRAG_PATH=""

detect_agentrag() {
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Starting comprehensive agentRag detection..." >&2
    
    # Layer 0: Check if we should assume it exists
    if [[ "$ASSUME_AGENTRAG" == "true" ]] || [[ " ${ASSUMED_PACKAGES[@]} " =~ " agentRag " ]]; then
        [[ $TRACE -eq 1 ]] && echo "[TRACE] Assuming agentRag is available (config)" >&2
        HAS_AGENTRAG=1
        AGENTRAG_PATH="assumed"
        return 0
    fi
    
    # Layer 1: Check LogiForge configured paths
    for raw_path in "${LOGIFORGE_PYTHON_PATHS[@]}"; do
        local path=$(convert_path "$raw_path")
        [[ $TRACE -eq 1 ]] && echo "[TRACE] Checking LogiForge path: $path" >&2
        
        if [[ -f "$path/agent_rag/core/local_model_integration.py" ]]; then
            AGENTRAG_PATH="$path"
            HAS_AGENTRAG=1
            [[ $TRACE -eq 1 ]] && echo "[TRACE] Found agentRag in LogiForge config: $path" >&2
            return 0
        fi
    done
    
    # Layer 2: Check if globally installed via pip
    if $PYTHON -c "import agent_rag.core.local_model_integration" 2>/dev/null; then
        HAS_AGENTRAG=1
        AGENTRAG_PATH="global"
        [[ $TRACE -eq 1 ]] && echo "[TRACE] Found agentRag globally installed" >&2
        return 0
    fi
    
    # Layer 3: Check environment variables
    if [[ -n "${RAG_TOOLS_ROOT:-}" ]]; then
        local env_path=$(convert_path "$RAG_TOOLS_ROOT")
        if [[ -f "$env_path/agent_rag/core/local_model_integration.py" ]]; then
            AGENTRAG_PATH="$env_path"
            HAS_AGENTRAG=1
            [[ $TRACE -eq 1 ]] && echo "[TRACE] Found agentRag via RAG_TOOLS_ROOT" >&2
            return 0
        fi
    fi
    
    # Layer 4: Check common project locations
    local common_paths=(
        "./src/agent_rag/core"
        "../agentRAG/src/agent_rag/core"
        "$HOME/projects/agentRAG/src/agent_rag/core"
        "$HOME/Dropbox/projects/agentRAG/src/agent_rag/core"
    )
    
    if [[ $IS_CYGWIN -eq 1 ]]; then
        # Add Cygwin-specific paths
        common_paths+=(
            "/cygdrive/c/Users/*/Dropbox/projects/agentRAG/src/agent_rag/core"
            "/cygdrive/c/Users/*/projects/agentRAG/src/agent_rag/core"
        )
    fi
    
    for path_pattern in "${common_paths[@]}"; do
        for path in $path_pattern; do
            if [[ -f "$path/local_model_integration.py" ]]; then
                AGENTRAG_PATH="$(dirname "$path")"
                HAS_AGENTRAG=1
                [[ $TRACE -eq 1 ]] && echo "[TRACE] Found agentRag at: $AGENTRAG_PATH" >&2
                return 0
            fi
        done
    done
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] agentRag not found" >&2
    return 1
}

# ----------------------------------------------------------------------------
# Query Functions
# ----------------------------------------------------------------------------

query_phi3_with_agentrag() {
    local prompt="$1"
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Using agentRag LocalModelManager" >&2
    
    $PYTHON <<PYEOF
import sys
import json
import os

# Add path if not globally installed
agentrag_path = "$AGENTRAG_PATH"
if agentrag_path not in ["global", "assumed"]:
    sys.path.insert(0, agentrag_path)

try:
    from agent_rag.core.local_model_integration import LocalModelManager
    
    prompt = """$prompt"""
    
    # Detect provider from environment
    provider = os.environ.get("LOCAL_MODEL_PROVIDER", "ollama")
    
    if provider == "ollama":
        config = {
            "local_model_provider": "ollama",
            "server_url": os.environ.get("OLLAMA_BASE_URL", "http://$PHI3_HOST:$PHI3_PORT"),
            "local_retrieval_model": os.environ.get("LOCAL_RETRIEVAL_MODEL", "$PHI3_MODEL")
        }
    else:
        config = {
            "local_model_provider": "llama.cpp",
            "server_url": f"http://{os.environ.get(\'PHI3_HOST\', \'$PHI3_HOST\')}:{os.environ.get(\'PHI3_PORT\', \'$PHI3_PORT\')}",
            "local_retrieval_model": "$PHI3_MODEL"
        }
    
    manager = LocalModelManager(config)
    
    # Use manager for inference
    if hasattr(manager, \'generate\'):
        response = manager.generate(prompt, max_tokens=500)
    else:
        # Fallback to basic completion
        response = manager.complete(prompt)
    
    print(json.dumps({"success": True, "response": response}))
    
except ImportError as e:
    print(json.dumps({"success": False, "error": f"Failed to import agentRag: {e}"}))
except Exception as e:
    print(json.dumps({"success": False, "error": str(e)}))
PYEOF
}

query_phi3_direct() {
    local prompt="$1"
    
    [[ $TRACE -eq 1 ]] && echo "[TRACE] Using direct HTTP calls (no agentRag)" >&2
    
    $PYTHON <<\'PYEOF\'
import sys
import json
import os

try:
    import requests
except ImportError:
    print(json.dumps({"success": False, "error": "requests library not installed"}))
    sys.exit(1)

prompt = """'"$prompt"\'"""
host = os.environ.get("PHI3_HOST", "'"$PHI3_HOST"\'")
port = os.environ.get("PHI3_PORT", "'"$PHI3_PORT"\'")
model = os.environ.get("PHI3_MODEL", "'"$PHI3_MODEL"\'")

# Try Ollama API first
try:
    response = requests.post(
        f"http://{host}:{port}/api/generate",
        json={
            "model": model,
            "prompt": prompt,
            "stream": False
        },
        timeout=30
    )
    
    if response.status_code == 200:
        data = response.json()
        text = data.get("response", "")
        print(json.dumps({"success": True, "response": text, "provider": "ollama"}))
        sys.exit(0)
except:
    pass

# Try OpenAI-compatible API
try:
    response = requests.post(
        f"http://{host}:{port}/v1/completions",
        json={
            "model": model,
            "prompt": prompt,
            "max_tokens": 500,
            "temperature": 0.7
        },
        timeout=30
    )
    
    if response.status_code == 200:
        data = response.json()
        text = data["choices"][0]["text"].strip()
        print(json.dumps({"success": True, "response": text, "provider": "openai"}))
        sys.exit(0)
except:
    pass

# Fallback error
print(json.dumps({"success": False, "error": "No compatible API endpoint found"}))
\'PYEOF\'
}

# ----------------------------------------------------------------------------
# Main Query Function
# ----------------------------------------------------------------------------

query_phi3() {
    local prompt="$1"
    local response
    
    detect_agentrag
    
    if [[ $HAS_AGENTRAG -eq 1 ]]; then
        [[ $TRACE -eq 1 ]] && echo "[TRACE] AgentRag path: $AGENTRAG_PATH" >&2
        response=$(query_phi3_with_agentrag "$prompt")
    else
        [[ $TRACE -eq 1 ]] && echo "[TRACE] Falling back to direct HTTP" >&2
        response=$(query_phi3_direct "$prompt")
    fi
    
    # Parse response
    local success=$(echo "$response" | $PYTHON -c "import sys,json; print(json.load(sys.stdin).get(\'success\', False))")
    
    if [[ "$success" == "True" ]]; then
        echo "$response" | $PYTHON -c "import sys,json; print(json.load(sys.stdin).get(\'response\', \'\'))"
        return 0
    else
        local error=$(echo "$response" | $PYTHON -c "import sys,json; print(json.load(sys.stdin).get(\'error\', \'Unknown error\'))")
        echo "Error: $error" >&2
        return 1
    fi
}

# ----------------------------------------------------------------------------
# Test/Demo Mode
# ----------------------------------------------------------------------------

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "=== Phi3 Query Tool (LogiForge Edition) ==="
    echo
    
    if [[ $# -eq 0 ]]; then
        echo "Usage: $0 \"your prompt here\""
        echo
        echo "Configuration:"
        echo "  PHI3_MODEL - Model name (default: $PHI3_MODEL)"
        echo "  PHI3_HOST  - Server host (default: $PHI3_HOST)"
        echo "  PHI3_PORT  - Server port (default: $PHI3_PORT)"
        echo "  TRACE      - Enable trace output (0/1)"
        echo
        echo "LogiForge paths configured: ${#LOGIFORGE_PYTHON_PATHS[@]}"
        echo "Assumed packages: ${#ASSUMED_PACKAGES[@]}"
        echo
        echo "Example: $0 \"What is the capital of France?\""
        exit 1
    fi
    
    prompt="$1"
    echo "Prompt: $prompt"
    echo "---"
    
    if response=$(query_phi3 "$prompt"); then
        echo "$response"
    else
        echo "Query failed"
        exit 1
    fi
fi
', [Model, Host, Port, Trace, BashPaths, BashPackages, AssumeAgentRag]).

% Format lists for bash arrays
format_paths_for_bash([], '').
format_paths_for_bash(Paths, BashArray) :-
    maplist(quote_for_bash, Paths, QuotedPaths),
    atomic_list_concat(QuotedPaths, ' ', BashArray).

format_packages_for_bash([], '').
format_packages_for_bash(Packages, BashArray) :-
    maplist(quote_for_bash, Packages, QuotedPackages),
    atomic_list_concat(QuotedPackages, ' ', BashArray).

quote_for_bash(String, Quoted) :-
    format(atom(Quoted), '"~w"', [String]).

% Generate a query-specific bash command
generate_query_bash(Prompt, BashScript) :-
    % Escape the prompt for bash
    escape_for_bash(Prompt, EscapedPrompt),
    format(atom(BashScript), 
           'query_phi3 "~w"', 
           [EscapedPrompt]).

% Helper to escape strings for bash
escape_for_bash(Input, Output) :-
    atom_string(Input, Str),
    % Replace quotes and backslashes
    string_chars(Str, Chars),
    escape_chars(Chars, EscapedChars),
    string_chars(Output, EscapedChars).

escape_chars([], []).
escape_chars(['"'|Rest], ['\\'', '"'|EscapedRest]) :- 
    !, escape_chars(Rest, EscapedRest).
escape_chars(['\\'|Rest], ['\\'', '\\'|EscapedRest]) :- 
    !, escape_chars(Rest, EscapedRest).
escape_chars([C|Rest], [C|EscapedRest]) :- 
    escape_chars(Rest, EscapedRest).

% Create config files if they don't exist
create_config_files :-
    ( \+ exists_file('config/assumed_packages.txt') ->
        open('config/assumed_packages.txt', write, Stream),
        write(Stream, '# Packages to assume are available\n'),
        write(Stream, '# One package name per line\n'),
        write(Stream, '# Example:\n'),
        write(Stream, '# agentRag\n'),
        write(Stream, '# requests\n'),
        close(Stream),
        format('Created config/assumed_packages.txt~n', [])
    ; true
    ).

% Test predicates
test_query_phi3 :-
    % Ensure config files exist
    create_config_files,
    
    % Test 1: Show configuration
    format('~n=== Current Configuration ===~n', []),
    forall(phi3_config(Key, Value),
           format('  ~w: ~w~n', [Key, Value])),
    
    % Test 2: Check Python paths
    format('~n=== LogiForge Python Paths ===~n', []),
    read_logiforge_python_paths(Paths),
    ( Paths = [] ->
        format('  No paths configured~n', [])
    ; forall(member(Path, Paths),
             format('  ~w~n', [Path]))
    ),
    
    % Test 3: Check assumed packages
    format('~n=== Assumed Packages ===~n', []),
    read_assumed_packages(Packages),
    ( Packages = [] ->
        format('  No packages assumed~n', [])
    ; forall(member(Package, Packages),
             format('  ~w~n', [Package]))
    ),
    
    % Test 4: Generate bash script
    format('~n=== Generating Bash Script ===~n', []),
    query_phi3(generate_bash, Script),
    format('Script length: ~w characters~n', [atom_length(Script)]).

% Export the script to a file
export_phi3_script(Filename) :-
    query_phi3(generate_bash, Script),
    open(Filename, write, Stream),
    write(Stream, Script),
    close(Stream),
    format('Exported script to ~w~n', [Filename]).

% Example of configuring to assume agentRag is available
assume_agentrag :-
    configure_phi3(assume_agentrag, true),
    format('Configured to assume agentRag is available~n', []).