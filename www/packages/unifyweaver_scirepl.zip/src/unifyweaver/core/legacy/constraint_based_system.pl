% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

:- encoding(utf8).
% constraint_based_system.pl - Handle constraints including order independence

:- module(constraint_based_system, [
    compile_with_constraints/3,
    test_constraints/0
]).

% ============================================================================
% Detect and Handle Constraints
% ============================================================================

compile_with_constraints(Functor/Arity, Options, Output) :-
    format('~n=== Compiling ~w/~w ===~n', [Functor, Arity]),
    
    % Get clause
    functor(Head, Functor, Arity),
    findall(Body, clause(Head, Body), Bodies),
    
    % Check for constraint declarations
    detect_constraints_in_bodies(Bodies, ConstraintInfo),
    format('Constraint info: ~w~n', [ConstraintInfo]),
    
    % Generate based on constraints
    ( ConstraintInfo = order_independent ->
        compile_order_independent(Functor, Bodies, Output)
    ; ConstraintInfo = has_inequality ->
        compile_with_inequality(Functor, Bodies, Output)
    ;
        compile_standard(Functor, Bodies, Options, Output)
    ).

% ============================================================================
% Detect Constraint Types
% ============================================================================

detect_constraints_in_bodies(Bodies, ConstraintType) :-
    ( member(Body, Bodies), contains_order_independent(Body) ->
        ConstraintType = order_independent
    ; member(Body, Bodies), contains_inequality(Body) ->
        ConstraintType = has_inequality
    ;
        ConstraintType = none
    ).

contains_order_independent(Body) :-
    Body =.. [',', _, _],
    member_conjunction(constraint(orderIndependent, _), Body).

contains_inequality(Body) :-
    member_conjunction((_ \= _), Body).

member_conjunction(Goal, Goal).
member_conjunction(Goal, (G1, G2)) :-
    (member_conjunction(Goal, G1) ; member_conjunction(Goal, G2)).

% ============================================================================
% Order Independent Compilation (uses sort -u)
% ============================================================================

compile_order_independent(Functor, Bodies, Output) :-
    format('Compiling with order independence (will use sort -u)~n'),
    
    % Extract the actual code from constraint wrapper
    extract_from_constraints(Bodies, CleanBodies),
    
    % Compile normally but ensure sort -u
    compile_bodies_with_uniqueness(Functor, CleanBodies, Output).

extract_from_constraints([], []).
extract_from_constraints([Body|Rest], [Clean|CleanRest]) :-
    ( Body = (_, constraint(orderIndependent, Code), _) ->
        Clean = Code
    ; Body = constraint(orderIndependent, Code) ->
        Clean = Code
    ;
        Clean = Body
    ),
    extract_from_constraints(Rest, CleanRest).

compile_bodies_with_uniqueness(Functor, Bodies, Output) :-
    % Generate pipeline
    generate_pipeline_code(Functor, Bodies, BaseCode),
    
    % Ensure sort -u is added
    ensure_sort_unique(Functor, BaseCode, Output).

ensure_sort_unique(Functor, BaseCode, Output) :-
    format(string(Output), 
'~w

# Wrapper with guaranteed uniqueness (order independent)
~w_unique() {
    ~w | sort -u
}', [BaseCode, Functor, Functor]).

% ============================================================================
% Standard Pipeline Generation
% ============================================================================

generate_pipeline_code(Functor, [Body], Output) :-
    parse_body_simple(Body, Predicates),
    ( Predicates = [P1, P2] ->
        format(string(Output),
'#!/bin/bash
# ~w - standard pipeline

~w_stream() {
    for key in "${!~w_data[@]}"; do
        echo "$key"
    done
}

~w_join_~w() {
    while IFS= read -r input; do
        IFS=":" read -r a b <<< "$input"
        for key in "${!~w_data[@]}"; do
            IFS=":" read -r c d <<< "$key"
            [[ "$b" == "$c" ]] && echo "$a:$d"
        done
    done
}

~w() {
    ~w_stream | ~w_join_~w
}', [Functor, P1, P1, P1, P2, P2, Functor, P1, P1, P2])
    ;
        format(string(Output), '#!/bin/bash\n# TODO: Handle ~w\n', [Predicates])
    ).

parse_body_simple(Body, Predicates) :-
    flatten_simple(Body, Goals),
    findall(P, (member(G, Goals), G \= (_ \= _), functor(G, P, _)), Predicates).

flatten_simple(true, []) :- !.
flatten_simple((G1, G2), Goals) :-
    !,
    flatten_simple(G1, G1s),
    flatten_simple(G2, G2s),
    append(G1s, G2s, Goals).
flatten_simple(Goal, [Goal]).

% ============================================================================
% Compile Standard (no special constraints)
% ============================================================================

compile_standard(Functor, Bodies, _Options, Output) :-
    length(Bodies, N),
    format('Standard compilation: ~w bodies~n', [N]),
    generate_pipeline_code(Functor, Bodies, Output).

% ============================================================================
% Compile with Inequality
% ============================================================================

compile_with_inequality(Functor, [_Body], Output) :-
    format('Compiling with inequality constraint~n'),
    format(string(Output),
'#!/bin/bash
# ~w - with inequality (X != Y)

~w() {
    # Hash-based uniqueness for inequality
    declare -A seen
    
    for key1 in "${!parent_data[@]}"; do
        IFS=":" read -r parent1 child1 <<< "$key1"
        
        for key2 in "${!parent_data[@]}"; do
            IFS=":" read -r parent2 child2 <<< "$key2"
            
            # Same parent, different children
            if [[ "$parent1" == "$parent2" && "$child1" != "$child2" ]]; then
                pair="$child1:$child2"
                if [[ -z "${seen[$pair]}" ]]; then
                    seen[$pair]=1
                    echo "$pair"
                fi
            fi
        done
    done
}', [Functor, Functor]).

% ============================================================================
% Test with Examples
% ============================================================================

test_constraints :-
    format('~n=== Testing Constraint-Based System ===~n'),
    
    % Clear
    abolish(test_ordered/2),
    abolish(test_unordered/2),
    abolish(sibling/2),
    
    % Example 1: Order independent declaration
    assertz((test_ordered(X, Z) :- 
        parent(X, Y),
        constraint(orderIndependent, parent(Y, Z)))),
    
    % Example 2: Regular without constraint
    assertz((test_unordered(X, Z) :- 
        parent(X, Y),
        parent(Y, Z))),
    
    % Example 3: Sibling with inequality
    assertz((sibling(X, Y) :- 
        parent(P, X),
        parent(P, Y),
        X \= Y)),
    
    % Compile each
    format('~n1. Order independent:~n'),
    compile_with_constraints(test_ordered/2, [], Out1),
    open('output/test_ordered.sh', write, S1, [newline(posix)]),
    write(S1, Out1),
    close(S1),
    
    format('~n2. Standard:~n'),
    compile_with_constraints(test_unordered/2, [], Out2),
    open('output/test_unordered.sh', write, S2, [newline(posix)]),
    write(S2, Out2),
    close(S2),
    
    format('~n3. With inequality:~n'),
    compile_with_constraints(sibling/2, [], Out3),
    open('output/sibling_hash.sh', write, S3, [newline(posix)]),
    write(S3, Out3),
    close(S3),
    
    format('~nGenerated files in output/~n'),
    format('Order independent uses sort -u~n'),
    format('Inequality uses hash table for uniqueness~n').