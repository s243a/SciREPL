% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% ============================================================================
% Purity Annotations for Execution Strategy Selection
% ============================================================================

:- module(purity_control, [
    pure_forall/1,      % Mark predicate as pure, wanting all solutions
    pure_first/1,       % Mark as pure, but only need first solution
    impure_ordered/1,   % Has side effects, must execute in order
    declare_pure/2,     % Declare purity properties
    analyze_purity/2    % Analyze predicate for purity
]).

% ============================================================================
% Purity Declaration System
% ============================================================================

:- dynamic predicate_purity/2.
:- dynamic execution_strategy/2.

% User declarations for purity
declare_pure(Predicate, Properties) :-
    assertz(predicate_purity(Predicate, Properties)),
    determine_execution_strategy(Predicate, Properties, Strategy),
    assertz(execution_strategy(Predicate, Strategy)).

% ============================================================================
% Execution Strategy Selection
% ============================================================================

determine_execution_strategy(Pred, Props, Strategy) :-
    member(pure(true), Props),
    member(all_solutions(true), Props),
    !,
    Strategy = stream_parallel.  % Can use table streaming approach

determine_execution_strategy(Pred, Props, Strategy) :-
    member(pure(true), Props),
    member(all_solutions(false), Props),
    !,
    Strategy = stream_lazy.  % Stream but stop at first solution

determine_execution_strategy(Pred, Props, Strategy) :-
    member(side_effects(true), Props),
    !,
    Strategy = sequential_ordered.  % Must maintain strict order

determine_execution_strategy(_, _, sequential_safe).  % Default conservative

% ============================================================================
% Purity Analysis (Static)
% ============================================================================

analyze_purity(Predicate, Properties) :-
    % Check if predicate is pure by analyzing its definition
    get_predicate_body(Predicate, Body),
    analyze_body_purity(Body, BodyProps),
    
    % Check for various impurities
    (contains_cut(Body) -> 
        Props1 = [has_cut(true)|BodyProps] 
    ; Props1 = BodyProps),
    
    (contains_side_effect(Body) -> 
        Props2 = [side_effects(true)|Props1]
    ; Props2 = [side_effects(false)|Props1]),
    
    (contains_io(Body) -> 
        Props3 = [has_io(true)|Props2]
    ; Props3 = Props2),
    
    determine_overall_purity(Props3, Properties).

% Side effect detection
contains_side_effect(Body) :-
    (Body = (_, _) ->  % Conjunction
        (contains_side_effect_goal(Body) ; 
         Body = (A, B), (contains_side_effect(A) ; contains_side_effect(B)))
    ; contains_side_effect_goal(Body)).

contains_side_effect_goal(assert(_)).
contains_side_effect_goal(retract(_)).
contains_side_effect_goal(assertz(_)).
contains_side_effect_goal(retractall(_)).
contains_side_effect_goal(python_call(_, _)).
contains_side_effect_goal(shell(_, _)).
contains_side_effect_goal(write(_)).
contains_side_effect_goal(format(_, _)).

% I/O detection
contains_io(Body) :-
    contains_io_goal(Body).

contains_io_goal(read(_)).
contains_io_goal(write(_)).
contains_io_goal(open(_, _, _)).
contains_io_goal(close(_)).
contains_io_goal(see(_)).
contains_io_goal(tell(_)).

% Cut detection
contains_cut(!) :- !.
contains_cut((A, B)) :- contains_cut(A) ; contains_cut(B).
contains_cut((A ; B)) :- contains_cut(A) ; contains_cut(B).

% ============================================================================
% Execution Wrappers Based on Purity
% ============================================================================

% Pure, all solutions - can parallelize and stream
pure_forall(Goal) :-
    Goal =.. [Pred|Args],
    execution_strategy(Pred, stream_parallel),
    !,
    compile_to_streaming_states(Goal, States),
    execute_parallel_streams(States, Args).

pure_forall(Goal) :-
    % Fallback to findall for unmarked predicates
    findall(Goal, Goal, _).

% Pure, first solution - can stream but stop early
pure_first(Goal) :-
    Goal =.. [Pred|Args],
    execution_strategy(Pred, stream_lazy),
    !,
    compile_to_lazy_states(Goal, States),
    execute_until_first(States, Args).

pure_first(Goal) :-
    % Fallback to once
    once(Goal).

% Impure, must maintain order
impure_ordered(Goal) :-
    Goal =.. [Pred|Args],
    execution_strategy(Pred, sequential_ordered),
    !,
    compile_to_sequential_states(Goal, States),
    execute_in_order(States, Args).

impure_ordered(Goal) :-
    % Just call it normally
    call(Goal).

% ============================================================================
% Compilation Strategies
% ============================================================================

compile_to_streaming_states(Goal, States) :-
    % Generate states that can be executed in parallel
    % Each state maintains only position in stream, no stack
    Goal =.. [Pred|Args],
    get_predicate_body(Pred, Body),
    flatten_to_stream_operations(Body, Args, StreamOps),
    generate_parallel_states(StreamOps, States).

compile_to_lazy_states(Goal, States) :-
    % Generate states that stream but can exit early
    Goal =.. [Pred|Args],
    get_predicate_body(Pred, Body),
    flatten_to_stream_operations(Body, Args, StreamOps),
    add_early_exit_transitions(StreamOps, States).

compile_to_sequential_states(Goal, States) :-
    % Generate states that maintain strict ordering
    % May need limited stack for complex patterns
    Goal =.. [Pred|Args],
    get_predicate_body(Pred, Body),
    generate_sequential_states(Body, Args, States).

% ============================================================================
% Example Declarations
% ============================================================================

% Pure predicates that can be fully parallelized
:- declare_pure(parent/2, [pure(true), all_solutions(true), side_effects(false)]).
:- declare_pure(ancestor/2, [pure(true), all_solutions(true), side_effects(false)]).
:- declare_pure(member/2, [pure(true), all_solutions(true), side_effects(false)]).

% Pure but only need first solution
:- declare_pure(sorted/1, [pure(true), all_solutions(false), side_effects(false)]).
:- declare_pure(valid/1, [pure(true), all_solutions(false), side_effects(false)]).

% Impure predicates that must run in order
:- declare_pure(log_query/2, [pure(false), side_effects(true), has_io(true)]).
:- declare_pure(update_database/2, [pure(false), side_effects(true)]).
:- declare_pure(call_python/2, [pure(false), side_effects(true)]).

% ============================================================================
% Usage Examples
% ============================================================================

example_pure_streaming :-
    % This can be parallelized and streamed
    pure_forall(recommend_movie(alice, Movie)),
    format('Recommended movie: ~w~n', [Movie]).

example_impure_ordered :-
    % This must run sequentially
    impure_ordered((
        log_query(start, 'Beginning analysis'),
        analyze_data(Result),
        log_query(result, Result),
        update_database(analysis, Result)
    )).

example_mixed :-
    % Pure part can be optimized, impure part runs sequentially
    pure_forall(find_candidates(X)),  % Parallel stream
    impure_ordered(process_candidate(X)).  % Sequential per candidate

% ============================================================================
% Automatic Purity Inference (Optional)
% ============================================================================

infer_purity(Predicate) :-
    analyze_purity(Predicate, Properties),
    (member(side_effects(false), Properties),
     member(has_io(false), Properties),
     \+ member(has_cut(true), Properties) ->
        declare_pure(Predicate, [pure(true)|Properties])
    ;
        declare_pure(Predicate, [pure(false)|Properties])
    ).

% ============================================================================
% Safety Checks
% ============================================================================

verify_purity_declaration(Predicate) :-
    % Check if user declaration matches analysis
    predicate_purity(Predicate, DeclaredProps),
    analyze_purity(Predicate, AnalyzedProps),
    
    (member(pure(true), DeclaredProps),
     member(side_effects(true), AnalyzedProps) ->
        format('WARNING: ~w declared pure but has side effects!~n', [Predicate]),
        fail
    ; true).

% ============================================================================
% Bash Generation Hints
% ============================================================================

generate_bash_for_predicate(Predicate, BashCode) :-
    execution_strategy(Predicate, Strategy),
    
    (Strategy = stream_parallel ->
        generate_parallel_bash(Predicate, BashCode)
    ; Strategy = stream_lazy ->
        generate_lazy_bash(Predicate, BashCode)
    ; Strategy = sequential_ordered ->
        generate_sequential_bash(Predicate, BashCode)
    ; 
        generate_safe_bash(Predicate, BashCode)
    ).

generate_parallel_bash(Pred, Code) :-
    format(atom(Code), '# Parallel streaming execution for ~w
# Can split work across processes
for chunk in "${data_chunks[@]}"; do
    process_chunk "$chunk" &
done
wait', [Pred]).

generate_sequential_bash(Pred, Code) :-
    format(atom(Code), '# Sequential execution for ~w (has side effects)
# Must maintain order
for item in "${data[@]}"; do
    process_item "$item"  # No backgrounding
    [[ $? -ne 0 ]] && handle_error
done', [Pred]).