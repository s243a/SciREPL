% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% ============================================================================
% LogiForge LLM System - Example Usage
% ============================================================================
% Shows how to use the modular LLM query system with various providers

:- use_module(query_llm).
:- use_module(phi3_provider).
:- use_module(agentrag_integration).

% ============================================================================
% Setup and Configuration
% ============================================================================

setup_llm_system :-
    format('~n=== Setting up LogiForge LLM System ===~n', []),
    
    % 1. Register agentRag integration
    register_agentrag,
    
    % 2. Setup Phi3 provider
    setup_phi3,
    
    % 3. Register additional providers
    register_provider(llama2, true, true),
    register_provider(gpt4, false, true),
    register_provider(mixtral, true, true),
    
    % 4. Configure global settings
    configure_llm(trace, '0'),
    configure_llm(timeout, '30'),
    configure_llm(max_tokens, '500'),
    
    format('[Setup] LLM system ready~n', []).

% ============================================================================
% Example 1: Simple Queries
% ============================================================================

example_simple_queries :-
    format('~n=== Example 1: Simple Queries ===~n', []),
    
    % Query with default provider (Phi3)
    query_phi3("What is machine learning?", Response1),
    format('Phi3 response generated~n', []),
    
    % Query with specific mode
    query_phi3(http, [], "Explain REST APIs", Response2),
    format('HTTP mode response generated~n', []),
    
    % Query with custom configuration
    Config = [model-'phi3-medium', temperature-'0.3'],
    query_phi3(http, Config, "Define authentication", Response3),
    format('Custom config response generated~n', []).

% ============================================================================
% Example 2: Multi-Provider Queries
% ============================================================================

example_multi_provider :-
    format('~n=== Example 2: Multi-Provider Queries ===~n', []),
    
    Prompt = "What are the benefits of functional programming?",
    
    % Query different providers
    query_llm(http, phi3, [model-'phi3-mini'], Script1),
    query_llm(http, ollama, [model-'llama2'], Script2),
    query_llm(http, gpt4, [model-'gpt-4'], Script3),
    
    format('Generated scripts for 3 providers~n', []).

% ============================================================================
% Example 3: Local vs HTTP Mode
% ============================================================================

example_mode_comparison :-
    format('~n=== Example 3: Mode Comparison ===~n', []),
    
    Prompt = "Explain recursion",
    Config = [model-'phi3-mini', trace-'1'],
    
    % Generate scripts for different modes
    query_llm(local, phi3, Config, LocalScript),
    query_llm(http, phi3, Config, HttpScript),
    query_llm(auto, phi3, Config, AutoScript),
    
    format('Local script: ~w bytes~n', [atom_length(LocalScript)]),
    format('HTTP script: ~w bytes~n', [atom_length(HttpScript)]),
    format('Auto script: ~w bytes~n', [atom_length(AutoScript)]).

% ============================================================================
% Example 4: Integration with to_lang
% ============================================================================

example_to_lang_integration :-
    format('~n=== Example 4: to_lang Integration ===~n', []),
    
    % Define a Prolog predicate that uses LLM
    assertz((analyze_code(Code, Analysis) :-
        format(atom(Prompt), 'Analyze this code: ~w', [Code]),
        query_phi3(http, [], Prompt, Analysis)
    )),
    
    % Convert to bash using to_lang
    % to_lang(analyze_code/2, bash, [], BashCode),
    
    format('Ready for to_lang conversion~n', []).

% ============================================================================
% Example 5: AgentRag Integration
% ============================================================================

example_agentrag :-
    format('~n=== Example 5: AgentRag Integration ===~n', []),
    
    % Check agentRag availability
    detect_agentrag(Status),
    format('AgentRag status: ~w~n', [Status]),
    
    % Generate code that uses agentRag if available
    generate_agentrag_code(phi3, [model-'phi3'], AgentRagCode),
    
    % Create a complete script with fallback
    query_llm(auto, phi3, [prefer_agentrag-true], Script),
    
    format('Generated agentRag-aware script~n', []).

% ============================================================================
% Example 6: Batch Processing
% ============================================================================

example_batch_processing :-
    format('~n=== Example 6: Batch Processing ===~n', []),
    
    % Define prompts
    Prompts = [
        "What is AI?",
        "Explain neural networks",
        "Define machine learning",
        "What is deep learning?"
    ],
    
    % Generate batch processing script
    generate_batch_script(Prompts, Script),
    
    format('Generated batch script for ~w prompts~n', [length(Prompts)]).

generate_batch_script(Prompts, Script) :-
    % Generate base script
    query_llm(http, phi3, [], BaseScript),
    
    % Add batch processing logic
    maplist(format_prompt_call, Prompts, Calls),
    atomic_list_concat(Calls, '\n', BatchCalls),
    
    format(atom(Script), '~w~n~n# Batch Processing~nprocess_all() {~n~w~n}~n~nprocess_all',
           [BaseScript, BatchCalls]).

format_prompt_call(Prompt, Call) :-
    format(atom(Call), '    echo "Processing: ~w"~n    query_llm "~w"~n    echo ""',
           [Prompt, Prompt]).

% ============================================================================
% Example 7: Export Scripts
% ============================================================================

example_export_scripts :-
    format('~n=== Example 7: Export Scripts ===~n', []),
    
    % Create output directory
    ( exists_directory('output') ; make_directory('output') ),
    
    % Export different configurations
    export_llm_script(http, phi3, [], 'output/phi3_http.sh'),
    export_llm_script(local, llama2, [], 'output/llama2_local.sh'),
    export_llm_script(auto, mixtral, [], 'output/mixtral_auto.sh'),
    
    % Export with agentRag
    export_llm_script(auto, phi3, [prefer_agentrag-true], 'output/phi3_agentrag.sh'),
    
    format('Exported 4 scripts to output/~n', []).

% ============================================================================
% Main Demo
% ============================================================================

run_all_examples :-
    setup_llm_system,
    example_simple_queries,
    example_multi_provider,
    example_mode_comparison,
    example_to_lang_integration,
    example_agentrag,
    example_batch_processing,
    example_export_scripts,
    format('~n=== All examples completed ===~n', []).

% ============================================================================
% Quick Start
% ============================================================================

quick_start :-
    format('~n=== LogiForge LLM Quick Start ===~n~n', []),
    format('1. Setup the system:~n'),
    format('   ?- setup_llm_system.~n~n'),
    format('2. Simple query:~n'),
    format('   ?- query_phi3("Hello", Response).~n~n'),
    format('3. Generate bash script:~n'),
    format('   ?- query_llm(http, phi3, [], Script).~n~n'),
    format('4. Export script:~n'),
    format('   ?- export_llm_script(http, phi3, [], \'query.sh\').~n~n'),
    format('5. Run all examples:~n'),
    format('   ?- run_all_examples.~n~n').

% Auto-display quick start on load
:- initialization(quick_start).