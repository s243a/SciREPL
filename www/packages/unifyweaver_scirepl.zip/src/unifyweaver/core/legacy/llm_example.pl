% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% ============================================================================
% Complete LLM Example - Prolog to Bash Compilation
% ============================================================================
% Shows the full flow from declarative Prolog to executable bash with Python

:- module(llm_example, [
    analyze_code/2,        % Main predicate to compile
    test_compilation/0,    % Test the compilation
    show_example/0        % Show usage example
]).

% ============================================================================
% Declarative LLM Logic in Prolog
% ============================================================================

% Main predicate: Analyze code using LLM
analyze_code(Code, Analysis) :-
    % State 1: Validate input
    validate_code_input(Code),
    
    % State 2: Detect available tools
    detect_analysis_tools(Tools),
    
    % State 3: Prepare prompt
    prepare_analysis_prompt(Code, Tools, Prompt),
    
    % State 4: Query LLM
    query_llm_for_analysis(Tools, Prompt, RawResponse),
    
    % State 5: Process response
    process_analysis_response(RawResponse, Analysis).

% Validate that we have actual code to analyze
validate_code_input(Code) :-
    atom(Code),
    atom_length(Code, Len),
    Len > 0,
    Len < 10000.  % Reasonable limit

% Detect what analysis tools are available
detect_analysis_tools(Tools) :-
    findall(Tool, detect_tool(Tool), Tools).

detect_tool(agentrag) :- 
    detect_agentrag.
detect_tool(ast_parser) :- 
    detect_python,
    python_can_import(ast).
detect_tool(ollama) :- 
    detect_ollama.
detect_tool(basic) :- 
    detect_python.

% Prepare the analysis prompt based on available tools
prepare_analysis_prompt(Code, Tools, Prompt) :-
    ( member(ast_parser, Tools) ->
        PrepPrompt = 'Analyze this code with attention to AST structure:\n\n'
    ; PrepPrompt = 'Analyze this code:\n\n'
    ),
    atom_concat(PrepPrompt, Code, TempPrompt),
    atom_concat(TempPrompt, '\n\nProvide: 1) Summary 2) Issues 3) Suggestions', Prompt).

% Query the LLM using best available method
query_llm_for_analysis(Tools, Prompt, Response) :-
    ( member(agentrag, Tools) ->
        query_with_agentrag(Prompt, Response)
    ; member(ollama, Tools) ->
        query_with_ollama(Prompt, Response)
    ; member(basic, Tools) ->
        query_with_python(Prompt, Response)
    ; Response = 'No LLM provider available'
    ).

% Process and format the response
process_analysis_response(RawResponse, Analysis) :-
    atom_string(RawResponse, ResponseStr),
    ( sub_string(ResponseStr, _, _, _, "Error") ->
        format(atom(Analysis), 'Analysis failed: ~w', [RawResponse])
    ; Analysis = RawResponse
    ).

% ============================================================================
% Intrinsic Predicates (Map to Bash/Python)
% ============================================================================

% Detection intrinsics
detect_agentrag :- 
    llm_intrinsic(detect_agentrag).

detect_ollama :- 
    llm_intrinsic(detect_ollama).

detect_python :- 
    llm_intrinsic(detect_python).

python_can_import(Module) :-
    llm_intrinsic(python_can_import, Module).

% Query intrinsics
query_with_agentrag(Prompt, Response) :-
    llm_intrinsic(query_agentrag, Prompt, Response).

query_with_ollama(Prompt, Response) :-
    llm_intrinsic(query_ollama, Prompt, Response).

query_with_python(Prompt, Response) :-
    llm_intrinsic(query_python, Prompt, Response).

% Mark predicates as intrinsics for to_lang
llm_intrinsic(_).
llm_intrinsic(_, _).
llm_intrinsic(_, _, _).

% ============================================================================
% Intrinsic Bash Implementations
% ============================================================================

:- multifile to_lang:bash_intrinsic/2.

% Detection intrinsics
to_lang:bash_intrinsic(detect_agentrag, '
detect_agentrag() {
    for path in "${PYTHON_PATHS[@]:-}"; do
        [[ -f "$path/agent_rag/core/local_model_integration.py" ]] && return 0
    done
    $PYTHON -c "import agent_rag.core.local_model_integration" 2>/dev/null
}').

to_lang:bash_intrinsic(detect_ollama, '
detect_ollama() {
    command -v ollama >/dev/null 2>&1 || \
    curl -sf http://localhost:11434/api/tags >/dev/null 2>&1
}').

to_lang:bash_intrinsic(detect_python, '
detect_python() {
    command -v ${PYTHON:-python3} >/dev/null 2>&1
}').

to_lang:bash_intrinsic(python_can_import, '
python_can_import() {
    local module="$1"
    $PYTHON -c "import $module" 2>/dev/null
}').

% Query intrinsics with embedded Python
to_lang:bash_intrinsic(query_agentrag, '
query_with_agentrag() {
    local prompt="$1"
    local response
    
    response=$($PYTHON <<\'PYEOF\'
import sys, json, os

# Add agentRag paths
for path in os.environ.get("PYTHONPATH", "").split(":"):
    if path and path not in sys.path:
        sys.path.insert(0, path)

prompt = """\'$prompt\'"""

try:
    from agent_rag.core.local_model_integration import LocalModelManager
    
    config = {
        "local_model_provider": "ollama",
        "server_url": os.environ.get("LLM_URL", "http://localhost:11434"),
        "local_retrieval_model": os.environ.get("MODEL", "phi3")
    }
    
    manager = LocalModelManager(config)
    result = manager.generate(prompt, max_tokens=1000)
    print(result)
    
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
\'PYEOF
    )
    
    echo "$response"
}').

to_lang:bash_intrinsic(query_ollama, '
query_with_ollama() {
    local prompt="$1"
    local response
    
    response=$(curl -sf http://localhost:11434/api/generate \
        -d "{\"model\":\"${MODEL:-phi3}\",\"prompt\":\"$prompt\",\"stream\":false}" \
        | jq -r ".response // empty")
    
    if [[ -z "$response" ]]; then
        echo "Error: Ollama query failed" >&2
        return 1
    fi
    
    echo "$response"
}').

to_lang:bash_intrinsic(query_python, '
query_with_python() {
    local prompt="$1"
    
    $PYTHON <<\'PYEOF\'
import os, sys

prompt = """\'$prompt\'"""

# Fallback: Just echo with a note
print(f"[Fallback Analysis - No LLM Available]\n\nCode received for analysis:\n{prompt[:200]}...\n\nPlease install Ollama or agentRag for actual LLM analysis.")
\'PYEOF
}').

% ============================================================================
% Compilation Configuration
% ============================================================================

:- multifile to_lang:compilation_config/2.

% Configure how analyze_code/2 should be compiled
to_lang:compilation_config(analyze_code/2, [
    mode-state_machine,
    intrinsics-enabled,
    python_embedding-enabled,
    error_handling-robust,
    trace_support-enabled
]).

% ============================================================================
% Test Compilation
% ============================================================================

test_compilation :-
    format('~n=== Testing Complete LLM Compilation ===~n', []),
    
    % Create output directory
    ( exists_directory('output') ; make_directory('output') ),
    
    % Compile analyze_code/2 to bash
    format('~nCompiling analyze_code/2 to bash...~n', []),
    
    % In real usage, this would call to_lang
    % For demonstration, we generate the expected output
    generate_compiled_bash(BashScript),
    
    % Save to file
    open('output/analyze_code.sh', write, Stream),
    write(Stream, BashScript),
    close(Stream),
    
    format('Compiled to output/analyze_code.sh (~w bytes)~n', 
           [atom_length(BashScript)]),
    
    % Show usage
    format('~nUsage:~n', []),
    format('  chmod +x output/analyze_code.sh~n', []),
    format('  ./output/analyze_code.sh "function hello() { return 42; }"~n', []).

% Generate the compiled bash (simulating what to_lang would produce)
generate_compiled_bash(Script) :-
    Script = '#!/bin/bash
# Generated by LogiForge from analyze_code/2
set -euo pipefail

# Configuration
PYTHON="${PYTHON:-python3}"
MODEL="${MODEL:-phi3}"
LLM_URL="${LLM_URL:-http://localhost:11434}"
TRACE="${TRACE:-0}"

# Load Python paths from LogiForge config
PYTHON_PATHS=()
if [[ -f "config/python_paths.txt" ]]; then
    while IFS= read -r line; do
        [[ "$line" =~ ^#.*$ ]] && continue
        [[ -z "$line" ]] && continue
        PYTHON_PATHS+=("$line")
    done < config/python_paths.txt
fi

# Add to PYTHONPATH
for path in "${PYTHON_PATHS[@]}"; do
    export PYTHONPATH="${PYTHONPATH:+$PYTHONPATH:}$path"
done

# ============================================================================
# Intrinsic Functions
# ============================================================================

detect_agentrag() {
    for path in "${PYTHON_PATHS[@]:-}"; do
        [[ -f "$path/agent_rag/core/local_model_integration.py" ]] && return 0
    done
    $PYTHON -c "import agent_rag.core.local_model_integration" 2>/dev/null
}

detect_ollama() {
    command -v ollama >/dev/null 2>&1 || \
    curl -sf http://localhost:11434/api/tags >/dev/null 2>&1
}

detect_python() {
    command -v ${PYTHON:-python3} >/dev/null 2>&1
}

python_can_import() {
    local module="$1"
    $PYTHON -c "import $module" 2>/dev/null
}

query_with_agentrag() {
    local prompt="$1"
    local response
    
    response=$($PYTHON <<\'PYEOF\'
import sys, json, os

for path in os.environ.get("PYTHONPATH", "").split(":"):
    if path and path not in sys.path:
        sys.path.insert(0, path)

prompt = """\'$prompt\'"""

try:
    from agent_rag.core.local_model_integration import LocalModelManager
    
    config = {
        "local_model_provider": "ollama",
        "server_url": os.environ.get("LLM_URL", "http://localhost:11434"),
        "local_retrieval_model": os.environ.get("MODEL", "phi3")
    }
    
    manager = LocalModelManager(config)
    result = manager.generate(prompt, max_tokens=1000)
    print(result)
    
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
\'PYEOF
    )
    
    echo "$response"
}

query_with_ollama() {
    local prompt="$1"
    local response
    
    response=$(curl -sf http://localhost:11434/api/generate \
        -d "{\"model\":\"${MODEL:-phi3}\",\"prompt\":\"$prompt\",\"stream\":false}" \
        | jq -r ".response // empty")
    
    [[ -n "$response" ]] && echo "$response" || return 1
}

query_with_python() {
    local prompt="$1"
    
    $PYTHON <<\'PYEOF\'
import os

prompt = """\'$prompt\'"""
print(f"[Fallback] Code analysis requested but no LLM available. Code length: {len(prompt)}")
\'PYEOF
}

# ============================================================================
# State Machine Implementation
# ============================================================================

analyze_code() {
    local code="$1"
    local analysis=""
    
    # State: validate_code_input
    [[ $TRACE -eq 1 ]] && echo "[STATE] validate_code_input" >&2
    if [[ -z "$code" ]] || [[ ${#code} -gt 10000 ]]; then
        echo "Error: Invalid code input" >&2
        return 1
    fi
    
    # State: detect_analysis_tools
    [[ $TRACE -eq 1 ]] && echo "[STATE] detect_analysis_tools" >&2
    local tools=()
    detect_agentrag && tools+=("agentrag")
    detect_ollama && tools+=("ollama")
    detect_python && tools+=("python")
    python_can_import ast && tools+=("ast_parser")
    
    [[ $TRACE -eq 1 ]] && echo "[INFO] Available tools: ${tools[*]}" >&2
    
    # State: prepare_analysis_prompt
    [[ $TRACE -eq 1 ]] && echo "[STATE] prepare_analysis_prompt" >&2
    local prompt="Analyze this code"
    if [[ " ${tools[*]} " =~ " ast_parser " ]]; then
        prompt="$prompt with attention to AST structure"
    fi
    prompt="$prompt:\n\n$code\n\nProvide: 1) Summary 2) Issues 3) Suggestions"
    
    # State: query_llm_for_analysis
    [[ $TRACE -eq 1 ]] && echo "[STATE] query_llm_for_analysis" >&2
    local response=""
    
    if [[ " ${tools[*]} " =~ " agentrag " ]]; then
        [[ $TRACE -eq 1 ]] && echo "[INFO] Using agentrag" >&2
        response=$(query_with_agentrag "$prompt")
    elif [[ " ${tools[*]} " =~ " ollama " ]]; then
        [[ $TRACE -eq 1 ]] && echo "[INFO] Using ollama" >&2
        response=$(query_with_ollama "$prompt")
    elif [[ " ${tools[*]} " =~ " python " ]]; then
        [[ $TRACE -eq 1 ]] && echo "[INFO] Using python fallback" >&2
        response=$(query_with_python "$prompt")
    else
        response="No LLM provider available"
    fi
    
    # State: process_analysis_response
    [[ $TRACE -eq 1 ]] && echo "[STATE] process_analysis_response" >&2
    if [[ "$response" == *"Error"* ]]; then
        analysis="Analysis failed: $response"
    else
        analysis="$response"
    fi
    
    # Output result
    echo "$analysis"
}

# ============================================================================
# Main Entry Point
# ============================================================================

main() {
    if [[ $# -eq 0 ]]; then
        echo "Usage: $0 \"code to analyze\""
        echo "Environment variables:"
        echo "  MODEL - LLM model to use (default: phi3)"
        echo "  LLM_URL - LLM server URL (default: http://localhost:11434)"
        echo "  TRACE - Enable tracing (0/1)"
        exit 1
    fi
    
    analyze_code "$1"
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi'.

% ============================================================================
% Usage Example
% ============================================================================

show_example :-
    format('~n=== Complete LLM Example ===~n~n', []),
    
    format('This example shows how Prolog predicates compile to bash with Python.~n~n', []),
    
    format('1. Define logic in Prolog:~n', []),
    format('   analyze_code(Code, Analysis) :- ...~n~n', []),
    
    format('2. Mark intrinsics for bash/Python:~n', []),
    format('   detect_agentrag :- llm_intrinsic(detect_agentrag).~n~n', []),
    
    format('3. Register bash implementations:~n', []),
    format('   to_lang:bash_intrinsic(detect_agentrag, \'...\').~n~n', []),
    
    format('4. Compile to bash:~n', []),
    format('   ?- to_lang(analyze_code/2, bash, [], Script).~n~n', []),
    
    format('5. Run the compiled script:~n', []),
    format('   $ ./analyze_code.sh "function test() { return 42; }"~n~n', []),
    
    format('The system will:~n', []),
    format('  - Detect available tools (agentRag, Ollama, etc.)~n', []),
    format('  - Use the best available LLM provider~n', []),
    format('  - Fall back gracefully if tools are missing~n', []),
    format('  - Respect LogiForge configuration~n~n', []),
    
    format('To test: ?- test_compilation.~n', []).