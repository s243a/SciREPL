% SPDX-License-Identifier: MIT OR Apache-2.0
% Copyright (c) 2025 John William Creighton (s243a)
%
% This file is part of UnifyWeaver.
% Licensed under either MIT or Apache-2.0 at your option.

% ============================================================================
% Pragmatic Purity Model Based on Possibility Space
% ============================================================================

:- module(pragmatic_purity, [
    declare_space/2,        % Declare possibility space properties
    execution_mode/2,       % Determine execution mode from space
    dependency_chain/2      % Handle dependent operations
]).

% ============================================================================
% Possibility Space Classification
% ============================================================================

:- dynamic space_properties/2.
:- dynamic operation_dependency/2.

% Classify operations by their possibility space
declare_space(Operation, Properties) :-
    assertz(space_properties(Operation, Properties)),
    determine_execution_mode(Properties, Mode),
    assertz(execution_mode(Operation, Mode)).

% Space types:
% - bounded_discrete: Finite, enumerable (e.g., database facts)
% - bounded_fuzzy: Finite but not exact (e.g., LLM with temperature=0)
% - unbounded_discrete: Infinite but enumerable (e.g., natural numbers)
% - unbounded_fuzzy: Infinite and non-deterministic (e.g., creative generation)

determine_execution_mode(Props, Mode) :-
    member(space(bounded_discrete), Props),
    member(side_effects(none), Props),
    !,
    Mode = parallel_stream.  % Can fully parallelize

determine_execution_mode(Props, Mode) :-
    member(space(bounded_fuzzy), Props),
    member(variance(low), Props),  % "Essentially the same" results
    !,
    Mode = cached_parallel.  % Parallelize with caching

determine_execution_mode(Props, Mode) :-
    member(space(bounded_fuzzy), Props),
    member(variance(medium), Props),
    !,
    Mode = ordered_cached.  % Maintain order but cache results

determine_execution_mode(Props, Mode) :-
    member(space(unbounded_discrete), Props),
    !,
    Mode = lazy_stream.  % Stream but don't enumerate all

determine_execution_mode(Props, Mode) :-
    member(space(unbounded_fuzzy), Props),
    !,
    Mode = sequential_stateful.  % Must maintain state and order

determine_execution_mode(_, sequential_safe).  % Conservative default

% ============================================================================
% Real-World Examples
% ============================================================================

% Database queries - bounded, discrete, pure
:- declare_space(query_database/2, [
    space(bounded_discrete),
    side_effects(none),
    variance(none)
]).

% LLM with low temperature - bounded, fuzzy but consistent
:- declare_space(ask_llm_factual/2, [
    space(bounded_fuzzy),
    side_effects(none),
    variance(low),  % "essentially the same" answers
    cacheable(true)
]).

% LLM with high temperature - unbounded, fuzzy
:- declare_space(ask_llm_creative/2, [
    space(unbounded_fuzzy),
    side_effects(none),
    variance(high),
    cacheable(false)
]).

% Vector DB similarity search - bounded, fuzzy
:- declare_space(vector_search/3, [
    space(bounded_fuzzy),
    side_effects(none),
    variance(low),  % Same query = same top-K results
    cacheable(true)
]).

% External API call - depends on external state
:- declare_space(call_external_api/2, [
    space(unbounded_fuzzy),
    side_effects(external),
    variance(unknown),
    cacheable(false)
]).

% ============================================================================
% Dependency Handling
% ============================================================================

% When operations depend on each other, ordering matters
declare_dependency(OpA, OpB) :-
    assertz(operation_dependency(OpA, OpB)).

% Example: LLM generates query, then we execute it
dependency_chain(llm_to_db, [
    step(1, ask_llm_factual(prompt, SQLQuery), [
        mode(cached_parallel),
        outputs([SQLQuery])
    ]),
    step(2, execute_query(SQLQuery, Results), [
        mode(ordered_cached),  % Order matters once we have specific query
        inputs([SQLQuery]),
        outputs([Results])
    ]),
    step(3, format_results(Results, Report), [
        mode(parallel_stream),  % Pure transformation
        inputs([Results])
    ])
]).

% ============================================================================
% Execution Strategy Based on Dependencies
% ============================================================================

compile_dependency_chain(ChainName, States) :-
    dependency_chain(ChainName, Steps),
    compile_steps(Steps, [], States).

compile_steps([], States, States).
compile_steps([step(N, Op, Props)|Rest], AccStates, States) :-
    member(mode(Mode), Props),
    member(inputs(Inputs), Props),
    member(outputs(Outputs), Props),
    
    generate_step_states(N, Op, Mode, Inputs, Outputs, StepStates),
    append(AccStates, StepStates, NewStates),
    compile_steps(Rest, NewStates, States).

generate_step_states(StepNum, Operation, Mode, Inputs, Outputs, States) :-
    Operation =.. [OpName|Args],
    format(atom(StateId), 'step_~w_~w', [StepNum, OpName]),
    
    (Mode = parallel_stream ->
        States = [
            state(StateId,
                  command(parallel_execute, Operation),
                  success(next),
                  fail(error),
                  unify(Outputs),
                  parallel(true))
        ]
    ; Mode = cached_parallel ->
        States = [
            state(StateId,
                  command(check_cache, Operation),
                  success(use_cache),
                  fail(execute_and_cache),
                  unify(Outputs)),
            state(execute_and_cache,
                  command(parallel_execute_and_cache, Operation),
                  success(next),
                  fail(error),
                  unify(Outputs))
        ]
    ; Mode = ordered_cached ->
        States = [
            state(StateId,
                  command(sequential_with_cache, Operation),
                  success(next),
                  fail(retry_or_error),
                  unify(Outputs),
                  maintain_order(true))
        ]
    ; % Default sequential
        States = [
            state(StateId,
                  command(sequential_execute, Operation),
                  success(next),
                  fail(error),
                  unify(Outputs))
        ]
    ).

% ============================================================================
% Practical Examples
% ============================================================================

% Example 1: Mostly pure but with dependencies
recommend_movies_with_llm(User, Recommendations) :-
    % Step 1: Bounded, discrete - can parallelize
    pure_forall(user_preferences(User, Pref)),
    
    % Step 2: Bounded fuzzy - essentially same result, can cache
    ask_llm_factual(
        "Given preferences: ~w, suggest movie genres" - Pref,
        Genres
    ),
    
    % Step 3: Depends on Step 2, but space is bounded
    % Can't parallelize across different Genres values
    % But once Genres is known, can parallelize the search
    forall(member(Genre, Genres),
           parallel_search_movies(Genre, Movies)),
    
    % Step 4: Another LLM call but creative (high variance)
    ask_llm_creative(
        "Write personalized descriptions for: ~w" - Movies,
        Recommendations
    ).

% Example 2: Handling unknown possibility spaces
explore_solution(Problem, Solution) :-
    % We don't know how many attempts this will take
    repeat,
    generate_candidate(Problem, Candidate),  % Unbounded space
    test_candidate(Candidate, Result),       % Bounded check
    (Result = success ->
        Solution = Candidate, !
    ; fail).

% ============================================================================
% Bash Generation Hints
% ============================================================================

generate_bash_for_space(Operation, BashCode) :-
    space_properties(Operation, Props),
    execution_mode(Operation, Mode),
    
    (member(space(bounded_discrete), Props) ->
        format(atom(BashCode), '# Bounded discrete space - full parallelization safe
# Can enumerate all possibilities
parallel --jobs +0 process_item ::: "${all_items[@]}"', [])
    
    ; member(space(bounded_fuzzy), Props), member(variance(low), Props) ->
        format(atom(BashCode), '# Bounded fuzzy space - cache and parallelize
cache_key=$(echo "$input" | sha256sum)
if [[ -f "cache/$cache_key" ]]; then
    cat "cache/$cache_key"
else
    result=$(query_llm "$input")  # Essentially deterministic
    echo "$result" > "cache/$cache_key"
    echo "$result"
fi', [])
    
    ; member(space(unbounded_fuzzy), Props) ->
        format(atom(BashCode), '# Unbounded fuzzy space - sequential with state
# Cannot predict or enumerate outcomes
while true; do
    result=$(generate_next)  # Each call may be different
    process_sequential "$result"
    [[ "$result" == "done" ]] && break
done', [])
    
    ; 
        format(atom(BashCode), '# Unknown space - conservative approach
for item in "${items[@]}"; do
    process_item "$item"  # Sequential, no assumptions
done', [])
    ).

% ============================================================================
% Pragmatic Guidelines
% ============================================================================

/*
Guidelines for declaring possibility spaces:

1. Database/Facts: bounded_discrete
   - Can fully enumerate
   - Safe to parallelize
   - Example: parent(X,Y) facts

2. LLM Factual Queries (temp=0): bounded_fuzzy with low variance
   - "What is the capital of France?" 
   - Safe to cache
   - Can parallelize with same input

3. LLM Creative (temp=0.7+): unbounded_fuzzy
   - "Write a story about X"
   - Don't cache
   - Maintain order if outputs affect subsequent calls

4. Mathematical Computations: bounded_discrete or unbounded_discrete
   - Fibonacci: unbounded_discrete (infinite but enumerable)
   - Primality test: bounded_discrete (yes/no)

5. External APIs: unbounded_fuzzy
   - Weather API: changes over time
   - Stock prices: continuous updates
   - Usually shouldn't cache

The key insight: It's not just about side effects, but about
the SIZE and NATURE of the possibility space!
*/