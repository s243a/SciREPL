"""testmod — A test module installed via package system v2."""

def greet(name="World"):
    return f"Hello, {name}! (from testmod)"

def add(a, b):
    return a + b
