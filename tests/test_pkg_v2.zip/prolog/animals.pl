:- module(animals, [animal/1, legs/2]).

animal(cat).
animal(dog).
animal(bird).
animal(snake).

legs(cat, 4).
legs(dog, 4).
legs(bird, 2).
legs(snake, 0).
